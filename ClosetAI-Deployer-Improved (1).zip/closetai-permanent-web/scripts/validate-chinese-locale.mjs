import { readFile } from 'node:fs/promises';

const i18nSource = await readFile(new URL('../lib/i18n.ts', import.meta.url), 'utf8');
if (!i18nSource.includes("code: 'zh'") || !i18nSource.includes("label: 'Mandarin'") || !i18nSource.includes("nativeLabel: '中文'")) {
  throw new Error('Mandarin (zh) language option missing in lib/i18n.ts');
}

if (!i18nSource.includes('myWardrobe: \'我的衣橱\'') || !i18nSource.includes('settings: \'设置\'')) {
  throw new Error('Mandarin translation strings incomplete in lib/i18n.ts');
}

const appContextSource = await readFile(new URL('../contexts/AppContext.tsx', import.meta.url), 'utf8');
if (!appContextSource.includes('STORAGE_KEYS') || !appContextSource.includes('LANGUAGE')) {
  throw new Error('Language storage key missing in AppContext.tsx');
}

const settingsSource = await readFile(new URL('../app/settings.tsx', import.meta.url), 'utf8');
if (!settingsSource.includes('Mandarin (中文)') || !settingsSource.includes('setLanguage(\'zh\')')) {
  throw new Error('Mandarin selection option missing in settings.tsx');
}

console.log('Verification passed: Chinese (Mandarin) localization, persistence, and settings selector are fully configured and verified.');
