import { readFile } from 'node:fs/promises';

const packageJson = JSON.parse(await readFile(new URL('../package.json', import.meta.url), 'utf8'));
const requiredScripts = ['expo:check', 'expo:demo:check', 'expo:demo', 'typecheck'];
const missingScripts = requiredScripts.filter((name) => !packageJson.scripts?.[name]);
if (missingScripts.length > 0) {
  throw new Error(`Missing Expo scripts: ${missingScripts.join(', ')}`);
}
console.log('Expo demo package scripts are present.');
console.log(`Expo package version: ${packageJson.dependencies?.expo ?? 'unknown'}`);
