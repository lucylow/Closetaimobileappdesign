const demoOnly = process.env.EXPO_DEMO_MODE === "1" || process.env.EXPO_DEMO_MODE === "true";

const requiredEnvironment = [
  {
    key: "REPLIT_DEV_DOMAIN",
    help: "Run this command inside an active Replit workspace so the mobile app can compile with that workspace's HTTPS API domain.",
  },
  {
    key: "DATABASE_URL",
    help: "Add the authorized PostgreSQL connection string in Replit Tools → Secrets. The existing Express routes use the database for the app's persisted data.",
  },
];

if (demoOnly) {
  console.log("ClosetAI Expo demo preflight passed: offline Demo Mode can run without Replit live API configuration.");
  console.log("Live YouCam, server-backed auth, and remote persistence remain disabled until Replit workspace variables are configured.");
  process.exit(0);
}

const missing = requiredEnvironment.filter(({ key }) => !process.env[key]?.trim());

if (missing.length > 0) {
  console.error("ClosetAI Replit Expo preflight could not start.");
  for (const { key, help } of missing) {
    console.error(`- ${key} is required. ${help}`);
  }
  console.error("For a local hackathon recording, use the demo-only command: EXPO_DEMO_MODE=1 node scripts/replit-expo-preflight.mjs");
  console.error("Provider credentials remain optional for non-live flows and must stay in Replit Secrets, never EXPO_PUBLIC_* variables.");
  process.exit(1);
}

console.log("ClosetAI Replit Expo preflight passed: the server and Expo Go tunnel will use the active Replit HTTPS domain.");
