const fs = require("fs");
const path = require("path");
const { spawnSync } = require("child_process");

function stripProtocol(value) {
  const normalized = /^https?:\/\//i.test(value)
    ? value
    : `https://${value}`;
  return new URL(normalized).host;
}

function getDeploymentDomain() {
  const value =
    process.env.REPLIT_INTERNAL_APP_DOMAIN ||
    process.env.REPLIT_DEV_DOMAIN ||
    process.env.EXPO_PUBLIC_DOMAIN;

  if (!value) {
    throw new Error(
      "No deployment domain found. Set REPLIT_INTERNAL_APP_DOMAIN, REPLIT_DEV_DOMAIN, or EXPO_PUBLIC_DOMAIN.",
    );
  }

  return stripProtocol(value);
}

function readExpoConfig() {
  const appJson = JSON.parse(
    fs.readFileSync(path.resolve("app.json"), "utf8"),
  );
  return appJson.expo || {};
}

function createManifest({
  platform,
  metadata,
  config,
  timestamp,
  baseUrl,
  domain,
}) {
  const platformMetadata = metadata.fileMetadata?.[platform];
  if (!platformMetadata?.bundle) {
    throw new Error(`Expo export did not produce a ${platform} bundle.`);
  }

  const bundlePath = platformMetadata.bundle.replace(/^\/+/, "");
  const assets = (platformMetadata.assets || []).map((asset) => {
    const assetPath = asset.path.replace(/^\/+/, "");
    const extension = asset.ext || "bin";
    return {
      hash: path.basename(assetPath),
      key: path.basename(assetPath),
      fileExtension: extension,
      contentType:
        extension === "ttf"
          ? "font/ttf"
          : extension === "png"
            ? "image/png"
            : extension === "jpg" || extension === "jpeg"
              ? "image/jpeg"
              : "application/octet-stream",
      url: `${baseUrl}/${timestamp}/${assetPath}`,
    };
  });

  const clientConfig = {
    name: config.name,
    slug: config.slug,
    version: config.version,
    orientation: config.orientation,
    scheme: config.scheme,
    userInterfaceStyle: config.userInterfaceStyle,
    extra: config.extra || {},
    hostUri: `${domain}/${platform}`,
    mainModuleName: "node_modules/expo-router/entry",
    developer: { tool: "expo-cli" },
  };

  return {
    id: `${config.slug}-${timestamp}-${platform}`,
    createdAt: new Date().toISOString(),
    runtimeVersion: config.version || "1.0.0",
    launchAsset: {
      key: path.basename(bundlePath),
      version: "1",
      url: `${baseUrl}/${timestamp}/${bundlePath}`,
      contentType: "application/javascript",
    },
    assets,
    metadata: {
      buildTimestamp: timestamp,
      platform,
    },
    extra: {
      expoClient: clientConfig,
      expoGo: {
        debuggerHost: `${domain}/${platform}`,
        packagerOpts: {
          dev: false,
          minify: true,
          hot: false,
          lazy: false,
        },
      },
    },
  };
}

function main() {
  console.log("Building static Expo Go deployment with Expo export...");

  const domain = getDeploymentDomain();
  const baseUrl = `https://${domain}`;
  const timestamp = `${Date.now()}-${process.pid}`;
  const staticRoot = path.resolve("static-build");
  const exportDir = path.join(staticRoot, timestamp);
  const config = readExpoConfig();

  fs.rmSync(staticRoot, { recursive: true, force: true });
  fs.mkdirSync(staticRoot, { recursive: true });

  const exportEnv = {
    ...process.env,
    EXPO_PUBLIC_DOMAIN: domain,
  };
  const exportResult = spawnSync(
    "pnpm",
    [
      "exec",
      "expo",
      "export",
      "--platform",
      "all",
      "--output-dir",
      exportDir,
      "--no-bytecode",
    ],
    {
      stdio: "inherit",
      env: exportEnv,
    },
  );

  if (exportResult.status !== 0) {
    throw new Error(
      `Expo export failed with exit code ${exportResult.status ?? "unknown"}.`,
    );
  }

  const metadataPath = path.join(exportDir, "metadata.json");
  const metadata = JSON.parse(fs.readFileSync(metadataPath, "utf8"));

  for (const platform of ["ios", "android"]) {
    const manifest = createManifest({
      platform,
      metadata,
      config,
      timestamp,
      baseUrl,
      domain,
    });
    const manifestDir = path.join(staticRoot, platform);
    fs.mkdirSync(manifestDir, { recursive: true });
    fs.writeFileSync(
      path.join(manifestDir, "manifest.json"),
      JSON.stringify(manifest, null, 2),
    );
  }

  console.log(`Build complete. Static Expo files are in ${staticRoot}.`);
}

try {
  main();
} catch (error) {
  console.error(`Build failed: ${error instanceof Error ? error.message : error}`);
  process.exit(1);
}