# ClosetAI — Replit and Expo Verified Handoff

## Verification status

This source release was tested from a new isolated copy, rather than the existing development `node_modules` directory. The clean copy completed `npm ci`, the Replit Expo preflight, strict TypeScript, all repository regression contracts, `expo-doctor`, and an Expo web export. The full machine-readable output is recorded in `staging_validation/replit-expo-clean-validation.log`.

> The preflight deliberately stops with a clear message when either the active Replit domain or `DATABASE_URL` is absent. It does not print any secret value.

## Start in Replit

Import the ZIP or repository into a Node.js Replit workspace. In the Shell, install exactly the locked dependency graph:

```bash
npm ci
```

Open **Tools → Secrets** and provide `DATABASE_URL`, because the existing Express application owns database-backed routes. Add the authorized Perfect Corp / YouCam or OpenAI secrets only for live server-side provider paths you intend to test. Never use an `EXPO_PUBLIC_*` name for a provider or database credential.

The Replit **Run** button now invokes `npm run replit:expo`. It first confirms that Replit supplied `REPLIT_DEV_DOMAIN` and that `DATABASE_URL` is configured. It then starts the Express API and Expo Metro tunnel together. The terminal shows an Expo QR code; scan it with the current Expo Go app on a physical iPhone or Android device.

| Task | Exact command or action | Expected result |
| --- | --- | --- |
| Confirm prerequisites without launching Metro | `npm run replit:expo:check` | A secret-safe success message, or a precise missing-variable instruction. |
| Open ClosetAI on a phone | Click **Run** or execute `npm run replit:expo` | The API and Expo tunnel start together; Expo prints a QR code. |
| Inspect the web representation | Stop Expo, then run `npm run replit:web` | A static Expo web bundle and API are served through the Replit preview. |
| Run the release gate after edits | `npx tsc --noEmit && npx tsx tests/*.test.ts && npx expo-doctor && npx expo export --platform web` | Type, contract, Expo-health, and routing/bundling validation complete successfully. |

## Device test sequence

After Expo Go opens the QR code, first confirm Home, Wardrobe, Outfits, Try-On, and Skin Care navigation. Then test Demo Mode disclosures, optional camera permission, a user-selected photo flow, the local AR texture preview, fictional mock cart, and the four-step mock checkout. The existing `CLOSETAI_EXPO_REPLIT_PROJECT_GUIDE.md` provides the complete safety-aware test matrix.

Virtual try-on and local AR previews must use only a user-selected image. Mock checkout remains local and fictional: it does not collect payment, address, email, card, order, reservation, or live inventory data. Missing or unauthorized provider secrets should produce a recovery state rather than a stock-model substitution or invented provider result.
