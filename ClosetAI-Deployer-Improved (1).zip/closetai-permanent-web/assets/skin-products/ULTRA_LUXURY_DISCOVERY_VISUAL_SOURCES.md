# Ultra-Luxury Skin Discovery Visual Source Register

The mobile product-discovery cards use the following generic, non-branded still-life images. They are deliberately separate from official brand product photography and are not representations of real listings, price, inventory, packaging, efficacy, or availability.

| Local reference label | Public app URL | Source family |
| --- | --- | --- |
| White serum still life | https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/ehtxFjXuAKwDWBlf.jpg | Unsplash skincare bottle / non-branded still life |
| Neutral serum and cream flat lay | https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/JePRBYTLSZdVgqVi.jpg | Unsplash skincare flat lay / non-branded products |
| Dark spa bottle flat lay | https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/eQkJerDSJfHVXYrE.jpg | Unsplash spa product flat lay / non-branded products |
| Pink packaging still life | https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/XaJbsClLHcdmDtvO.jpg | Unsplash skincare packaging still life / non-branded products |
| Golden cream jar still life | https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/qhCtOsBZshcGqZGP.jpg | Unsplash cream jar still life / non-branded products |

Source collection queries: `Unsplash skincare cream jar product still life`, `Unsplash skincare serum bottles flat lay`, and `Unsplash luxury skincare bottles no brand`.

The official external destinations used by the accompanying discovery records are recorded separately in [`ULTRA_LUXURY_SKIN_DISCOVERY_SOURCE_REGISTER.md`](../../ULTRA_LUXURY_SKIN_DISCOVERY_SOURCE_REGISTER.md).
