# Fictional Demo Garment Asset Sources

These six generic garment-only and accessories-only images were collected from Unsplash image-search results for use in the clearly disclosed fictional Demo Mode catalog. They are product-reference media only; they do not identify a user, serve as a virtual try-on person image, indicate live inventory, or represent a fit or purchase recommendation.

| Local asset | Search result context | Published demo URL |
|---|---|---|
| `flatlay-accessories.jpg` | Unsplash fashion flatlay / accessories | https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/QimdFCItxDelThHP.jpg |
| `flatlay-bright-casual.jpg` | Unsplash flatlay clothes / bright casual garments | https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/nSBLCBOpQegKgBaO.jpg |
| `flatlay-dark-layering.jpg` | Unsplash fashion flatlay / dark layering garments | https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/TpsfGKhIQidWfUle.jpg |
| `red-blazer.jpg` | Unsplash women blazer / garment-only product photo | https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/kUChShMwgUWugMzI.jpg |
| `flatlay-activewear.jpg` | Unsplash clothing flat lay / activewear garments | https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/nVekdlwJfjFlXLyZ.jpg |
| `flatlay-sandals-denim.jpg` | Unsplash travel flat lay / sandals and denim garments | https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/mtnUoSsWkSbREpFS.jpg |
| `neutral-accessories-flatlay.jpg` | Unsplash fashion flatlay / garment-and-accessories-only reference | https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/uEGuUQznzoQGxTyI.jpg |
| `colorful-activewear-flatlay.jpg` | Unsplash clothing flat lay / colorful garments-only reference | https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/aoDpHwsuIVqkqJpl.jpg |
| `neutral-wardrobe-rail.jpg` | Unsplash wardrobe rail / garment-only reference | https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/GaOMnbGAuDYVmWGG.jpg |
| `curated-clothing-rail.jpg` | Unsplash clothes rail / garment-only reference | https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/hjmzuQIkJyHxhodK.jpg |
| `bright-accessories-flatlay.jpg` | Unsplash accessories flatlay / garment-and-accessories-only reference | https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/XEbwjTSbANPzrRPD.jpg |

Source collection query family: `Unsplash clothing flat lay garment only`, `Unsplash shoes handbag garment flat lay`, `Unsplash dress blazer clothing product`, and `Unsplash wardrobe clothing product no model`.
