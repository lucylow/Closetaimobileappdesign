# AI Shoes Virtual Try-On Provider Source Notes

## Official sources

- [Perfect Corp. AI Shoes Virtual Try-On overview](https://docs.perfectcorp.com/reference/ai_shoes)
- [Perfect Corp. AI Shoes OpenAPI schema](https://docs.perfectcorp.com/_bundle/reference/ai_shoes.yaml?download)

| Item | Verified provider detail | ClosetAI implementation choice |
|---|---|---|
| Task creation | `POST /s2s/v2.0/task/shoes` | Server-only request with existing YouCam v2 credentials. |
| Task status | `GET /s2s/v2.0/task/shoes/{task_id}` | Bounded server polling; task IDs remain server-side. |
| Target image | `src_file_id` or a public URL | Private signed upload and `src_file_id`; only the user-selected target photo is accepted. |
| Shoe reference | `ref_file_id` or a public URL | Private signed upload and `ref_file_id`; only user-selected shoe-reference images are accepted. |
| Style | `random`, `style_minimalist`, `style_bohemian`, `style_cottagecore`, `style_french_elegance`, `style_retro_fashion` | The documented values are provided as optional visual render styles. |
| Required provider setting | The OpenAPI schema requires a `gender` enum of `female` or `male` | ClosetAI requests a user-selected **provider rendering setting** only; it is not inferred from the photo, used as identity data, or stored. |
| Target-photo guidance | One visible subject, clear face, head-to-chest or half-body framing preferred | UI requires a single user-selected image and explicit confirmation that only the user appears. |
| Shoe-reference guidance | One unobstructed product or qualifying worn shoe image | UI asks for a single product reference image and rejects a missing reference. |
| Output | Single URL documented as temporary | Normalize only HTTPS temporary result output; do not persist it. |

## ClosetAI product boundary

This optional feature is a **creative virtual try-on visualization**, not a product-fit guarantee, size recommendation, body measurement, identity or gender inference, attractiveness assessment, or purchase claim. The target photo must be the user’s selected image; ClosetAI never substitutes a stock model. The reference shoe image must be selected by the user. The provider-required rendering setting is explicitly chosen for rendering only, is never inferred from an image, and is not treated as a statement of identity. Source images and temporary result URLs are not written to history, and no stock, demo, stale, or fabricated image is shown after a failure.
