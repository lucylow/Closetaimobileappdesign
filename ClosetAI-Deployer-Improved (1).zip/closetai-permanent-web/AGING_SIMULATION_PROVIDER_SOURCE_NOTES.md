# AI Aging Simulation Provider Source Notes

## Official sources

- [Perfect Corp. AI Aging Simulation overview](https://docs.perfectcorp.com/reference/ai_aging_simulation)
- [Perfect Corp. AI Aging Simulation OpenAPI schema](https://docs.perfectcorp.com/_bundle/reference/ai_aging_simulation.yaml?download)
- [Perfect Corp. Face Aging Simulation API product page](https://yce.perfectcorp.com/ai-api/products/ai-aging-simulation-api)

## Verified v2 contract

| Item | Verified detail |
|---|---|
| Task creation | `POST /s2s/v2.0/task/aging` |
| Task status | `GET /s2s/v2.0/task/aging/{task_id}` |
| Authentication | Server-only Bearer API key |
| Input | Either `src_file_id` or a public `src_file_url`; ClosetAI uses a private file upload and `src_file_id` |
| Task status | `running`, `success`, or `error` |
| Result output | `data.results.output[]` items contain temporary `url` and `res_age` |
| Result URL retention | Documented as valid for two hours |
| Provider inferred age | `data.results.age`; intentionally not returned, stored, or shown by ClosetAI |
| Input guidance | Single person JPEG/JPG under 10MB; long side no greater than 4096px; forward-facing pose constraints documented by the provider |

## ClosetAI product boundary

The feature is an explicitly consented **creative age-progression visualization**, not a future prediction or current-age estimator. Although the provider product page describes a detected-age field, ClosetAI deliberately excludes `data.results.age` from its application model and UI. It never substitutes a generated image after a failure and does not persist a preview URL or generated image in skin history.
