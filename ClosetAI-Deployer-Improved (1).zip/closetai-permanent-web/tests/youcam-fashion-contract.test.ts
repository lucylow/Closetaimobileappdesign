import { mapWardrobeCategoryToFashionCategory, supportsYouCamFashionCategory } from "../server/youcam";
import { FASHION_TRY_ON_CATEGORIES } from "../shared/fashion-tryon-categories";

const expectations: Array<[string, string]> = [
  ["Tops", "upper_body"],
  ["Jeans", "lower_body"],
  ["Maxi Dress", "full_body"],
  ["Leather Jacket", "outerwear"],
  ["Sneakers", "shoes"],
  ["Activewear", "auto"],
  ["Swimwear", "full_body"],
  ["Bag", "auto"],
  ["Hat", "auto"],
  ["Jewelry", "auto"],
];

if (FASHION_TRY_ON_CATEGORIES.length !== 10) {
  throw new Error(`Expected ten selectable fashion categories; received ${FASHION_TRY_ON_CATEGORIES.length}.`);
}

for (const [category, expected] of expectations) {
  const actual = mapWardrobeCategoryToFashionCategory(category);
  if (actual !== expected) {
    throw new Error(`Expected ${category} to map to ${expected}; received ${actual}.`);
  }
}

const supportedYouCamCategories = FASHION_TRY_ON_CATEGORIES.filter((category) => supportsYouCamFashionCategory(category.id));
if (supportedYouCamCategories.length !== 7) {
  throw new Error(`Expected seven YouCam AI Clothes-compatible categories; received ${supportedYouCamCategories.length}.`);
}

console.log(JSON.stringify({
  result: "PASS",
  categoryCount: FASHION_TRY_ON_CATEGORIES.length,
  assertions: expectations.map(([category, expected]) => `${category} -> ${expected}`),
  note: "No network request, credential access, or user image processing occurred.",
}, null, 2));
