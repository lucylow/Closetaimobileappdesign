import { readFileSync } from "node:fs";
import { ABS_FILTER_SIMULATION_DISCLOSURE, normalizeAbsFilterIntensity, normalizeAbsFilterMode, normalizeProviderAbsFilterSimulation } from "../shared/abs-filter-simulation";

if (normalizeAbsFilterMode("Six-pack") !== "Six-pack" || normalizeAbsFilterMode("Vest-line") !== "Vest-line") throw new Error("Both documented AI Abs Filter modes must be supported.");
if (normalizeAbsFilterMode("Eight-pack") !== null || normalizeAbsFilterIntensity(1) !== 1 || normalizeAbsFilterIntensity(2) !== 2 || normalizeAbsFilterIntensity(3) !== null) {
  throw new Error("Only documented AI Abs Filter modes and intensity levels may be used.");
}
const normalized = normalizeProviderAbsFilterSimulation({ results: { url: "https://example.com/temporary-abs-preview.jpg" }, bodyFat: 12 }, "Six-pack", 2);
if (!normalized || normalized.resultUrl !== "https://example.com/temporary-abs-preview.jpg" || normalized.mode !== "Six-pack" || normalized.intensity !== 2 || normalized.expiresInHours !== 2) {
  throw new Error("Only a secure temporary provider result URL and selected documented controls may be normalized.");
}
if (JSON.stringify(normalized).includes("bodyFat") || normalizeProviderAbsFilterSimulation({ url: "http://unsafe.example.com/preview.jpg" }, "Six-pack", 1) !== null) {
  throw new Error("Body assessment data and insecure provider URLs must never enter application state.");
}
if (!ABS_FILTER_SIMULATION_DISCLOSURE.includes("Adult-only") || !ABS_FILTER_SIMULATION_DISCLOSURE.includes("not medical advice") || !ABS_FILTER_SIMULATION_DISCLOSURE.includes("not saved to history") || !ABS_FILTER_SIMULATION_DISCLOSURE.includes("no stock or fallback")) {
  throw new Error("Disclosure must preserve adult-only, non-medical, temporary, and no-fallback boundaries.");
}

const taskClient = readFileSync("server/youcam-abs-filter.ts", "utf8");
const routeSource = readFileSync("server/routes.ts", "utf8");
const screenSource = readFileSync("app/skin/abs-filter.tsx", "utf8");
const hubSource = readFileSync("components/skin/SkinCareHub.tsx", "utf8");
if (!taskClient.includes('"/s2s/v2.0/task/abs-shape"') || !taskClient.includes("src_file_id") || !taskClient.includes("mode") || !taskClient.includes("intensity") || !taskClient.includes("/s2s/v2.0/task/abs-shape/${encodeURIComponent(taskId)}")) {
  throw new Error("AI Abs Filter client must use the documented v2 task and status endpoints with source file ID, mode, and intensity.");
}
if (!routeSource.includes('app.post("/api/skin/abs-filter"') || !routeSource.includes("adultConfirmed !== true") || !routeSource.includes("singlePersonConfirmed !== true") || !routeSource.includes("consent !== true")) {
  throw new Error("AI Abs Filter route must require adult, single-person, and explicit non-medical consent gates.");
}
if (!screenSource.includes("I confirm that I am 18 or older") || !screenSource.includes("contains only me") || !screenSource.includes("not medical, health, fitness, anatomy, or attractiveness assessment") || !screenSource.includes("No image was shown")) {
  throw new Error("Expo screen must retain adult-only, photo ownership, non-medical, and no-fallback presentation boundaries.");
}
if (!hubSource.includes('router.push("/skin/abs-filter")')) throw new Error("AI Abs Filter screen must be reachable from the canonical Skin Care hub.");

console.log(JSON.stringify({ result: "PASS", normalized, assertions: [
  "Only documented modes and intensity levels are accepted.",
  "Provider output retains only a temporary HTTPS URL and user-selected controls, never body-assessment data.",
  "Server requires adult, single-person, and explicit cosmetic-consent acknowledgements.",
  "The canonical Skin Care hub exposes the user-photo-only adult cosmetic workflow without a stock fallback.",
] }, null, 2));
