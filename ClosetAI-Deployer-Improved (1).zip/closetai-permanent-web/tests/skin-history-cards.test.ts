import { buildSkinHistoryCards } from "../lib/skin-history-cards";

const demoSnapshots = [
  { id: "demo-1", date: "Today", score: 76, summary: "Fictional reference", status: "New" as const },
];

const demoCards = buildSkinHistoryCards([], demoSnapshots);
if (demoCards.length !== 1 || demoCards[0].sourceLabel !== "Fictional Demo Mode") {
  throw new Error("History must fall back to clearly labeled fictional demo cards when no local result exists.");
}
if (!demoCards[0].disclosure.includes("Fictional Demo Mode")) {
  throw new Error("Demo history cards must preserve the fictional disclosure.");
}

const liveCards = buildSkinHistoryCards([
  {
    id: "live-1",
    createdAt: "2026-08-15T12:00:00.000Z",
    source: "youcam",
    overallScore: 0,
    metrics: [],
    routine: [],
    disclaimer: "General wellness guidance only.",
    visualSignalSummary: "Live visual analysis returned normalized signals.",
  },
  {
    id: "demo-saved",
    createdAt: "not-a-date",
    source: "demo",
    metrics: [],
    routine: [],
    disclaimer: "Demo disclaimer.",
  },
], demoSnapshots);

if (liveCards.length !== 2 || liveCards[0].id !== "live-1" || liveCards[0].sourceLabel !== "Live visual analysis") {
  throw new Error("Persisted local summaries must take precedence over static demo snapshots.");
}
if (liveCards[0].scoreLabel !== "0" || !liveCards[0].disclosure.includes("Original selfie")) {
  throw new Error("Live history cards must preserve valid zero scores and the no-original-selfie disclosure.");
}
if (liveCards[1].date !== "Saved snapshot" || liveCards[1].scoreLabel !== "Score unavailable") {
  throw new Error("Malformed local summary metadata must render conservative fallback labels.");
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "Local saved summaries take precedence over static demo history.",
    "Live, demo, and malformed metadata receive explicit safe source labels.",
    "History cards preserve no-original-selfie and fictional-demo disclosures.",
  ],
}, null, 2));
