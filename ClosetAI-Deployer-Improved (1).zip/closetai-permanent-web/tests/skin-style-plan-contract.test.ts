import { readFileSync } from "node:fs";
import type { WardrobeItem } from "../lib/demo-data";
import { buildSkinStylePlan, resolveSkinStyleLookItems, SKIN_STYLE_DISCLOSURE } from "../lib/skin-style-plan";

const wardrobe: WardrobeItem[] = [
  { id: "own-top", name: "Own Navy Shirt", category: "top", color: "Navy", brand: "User wardrobe", imageUrl: "local://top", tags: ["office"], usageCount: 2, lastWorn: "2026-07-01", notes: "", createdAt: "2026-01-01" },
  { id: "own-bottom", name: "Own Stone Trousers", category: "bottom", color: "Taupe", brand: "User wardrobe", imageUrl: "local://bottom", tags: ["office"], usageCount: 1, lastWorn: "2026-06-20", notes: "", createdAt: "2026-01-01" },
  { id: "own-shoes", name: "Own White Sneakers", category: "shoes", color: "White", brand: "User wardrobe", imageUrl: "local://shoes", tags: ["weekend"], usageCount: 3, lastWorn: "2026-07-15", notes: "", createdAt: "2026-01-01" },
];

const live = buildSkinStylePlan({
  source: "youcam",
  metrics: [{ key: "radiance", score: 55, available: true }],
  selectedGoals: ["radiance"],
  wardrobe,
  occasion: "Office",
});
const demo = buildSkinStylePlan({ source: "demo", metrics: [], selectedGoals: ["calm"], wardrobe });
const starter = buildSkinStylePlan({ source: "none", metrics: [], selectedGoals: [], wardrobe });
const empty = buildSkinStylePlan({ source: "none", metrics: [], selectedGoals: [], wardrobe: [wardrobe[0]!] });

if (live.source !== "youcam" || !live.sourceLabel.includes("Live normalized visual context") || demo.source !== "demo" || !demo.sourceLabel.includes("Fictional Demo Mode") || starter.source !== "none" || !starter.sourceLabel.includes("local style choices")) {
  throw new Error("Skin × Style must distinguish live, fictional Demo Mode, and no-scan wardrobe-first source states.");
}
if (!live.palette.includes("Warm White") || !live.reasons.some((reason) => reason.includes("radiance support"))) {
  throw new Error("Local goals must produce explainable optional palette direction without an identity or color-season claim.");
}
if (!live.looks.length || !live.looks.every((look) => look.itemIds.every((id) => wardrobe.some((item) => item.id === id)))) {
  throw new Error("Every Skin × Style look must contain only actual user wardrobe item IDs.");
}
if (resolveSkinStyleLookItems(live.looks[0]!, wardrobe).length !== live.looks[0]!.itemIds.length) {
  throw new Error("Rendered style look items must resolve directly from the current wardrobe inventory.");
}
if (!empty.emptyMessage?.includes("No stock or fictional outfit") || empty.looks.length !== 0) {
  throw new Error("Sparse wardrobes must show an honest empty state rather than a stock or fabricated outfit.");
}
if (!starter.weatherNote.includes("unavailable") || !SKIN_STYLE_DISCLOSURE.includes("identity") || !SKIN_STYLE_DISCLOSURE.includes("Every suggested look uses only your actual ClosetAI wardrobe items")) {
  throw new Error("Skin × Style must preserve weather-unavailable transparency, no-inference boundaries, and wardrobe-only disclosure.");
}

const plannerSource = readFileSync("lib/skin-style-plan.ts", "utf8");
const screenSource = readFileSync("components/skin/SkinJourneyPage.tsx", "utf8");
if (!plannerSource.includes("buildWardrobeRecommendations") || !plannerSource.includes("Fictional Demo Mode") || !plannerSource.includes("No stock or fictional outfit")) {
  throw new Error("Skin × Style planner must compose through the existing wardrobe outfit service and preserve demo/empty-state safeguards.");
}
if (!screenSource.includes("buildSkinStylePlan") || !screenSource.includes("Optional palette direction") || !screenSource.includes("Generate from my wardrobe") || !screenSource.includes("Select ${occasion} occasion")) {
  throw new Error("Skin × Style screen must render source-aware planning, palette direction, occasion controls, and wardrobe-only generation navigation.");
}

console.log(JSON.stringify({ result: "PASS", assertions: [
  "Live, fictional Demo Mode, and wardrobe-first no-scan contexts remain explicitly labeled.",
  "Goals supply optional, explainable palette direction without identity or color-season inference.",
  "All generated looks resolve exclusively to the user’s actual wardrobe inventory.",
  "Sparse wardrobes return an honest no-stock/no-fictional-outfit state.",
  "The Expo Skin × Style screen provides occasion controls, palette direction, and live wardrobe generation navigation.",
] }, null, 2));
