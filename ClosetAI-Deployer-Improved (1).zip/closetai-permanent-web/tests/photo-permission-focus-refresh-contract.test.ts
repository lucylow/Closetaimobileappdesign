import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const source = readFileSync(join(root, "components/skin/SelfieFlowScreen.tsx"), "utf8");

if (!source.includes("useFocusEffect(React.useCallback")) {
  throw new Error("The selfie flow must refresh permission state whenever the route regains focus.");
}
if (!source.includes("ImagePicker.getCameraPermissionsAsync()") || !source.includes("ImagePicker.getMediaLibraryPermissionsAsync()")) {
  throw new Error("Focus refresh must check both camera and photo-library permissions.");
}
if (!source.includes("camera.granted || library.granted ? \"granted\" : \"blocked\"")) {
  throw new Error("Permission state must reflect either camera or library access after returning from Settings.");
}
if (!source.includes("let active = true") || !source.includes("if (!active) return")) {
  throw new Error("Permission refresh must ignore late responses after the screen loses focus.");
}
if (!source.includes('Photo access is currently off') || !source.includes('label="Open Photo Settings"')) {
  throw new Error("The capture screen must show an actionable settings notice when photo access is blocked.");
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "Photo permissions refresh on screen focus.",
    "Camera and library permission states are combined safely.",
    "Late permission responses are ignored after focus cleanup.",
    "Blocked state exposes an accessible Open Photo Settings action.",
  ],
}, null, 2));
