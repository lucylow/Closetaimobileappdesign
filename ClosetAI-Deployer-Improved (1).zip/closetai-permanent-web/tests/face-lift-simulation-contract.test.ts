import { readFileSync } from "node:fs";
import {
  EMPTY_FACE_LIFT_FEATURES,
  FACE_LIFT_SIMULATION_DISCLOSURE,
  normalizeFaceLiftFeatures,
  normalizeProviderFaceLiftSimulation,
} from "../shared/face-lift-simulation";

const validFeatures = normalizeFaceLiftFeatures({ eye_bag: 25, cheek: 0, forehead: 0, shape: 50, mouth: 0 });
if (!validFeatures || validFeatures.eye_bag !== 25 || validFeatures.shape !== 50) {
  throw new Error("Documented custom face-lift values from 0 through 100 must normalize.");
}
if (normalizeFaceLiftFeatures(EMPTY_FACE_LIFT_FEATURES) !== null || normalizeFaceLiftFeatures({ eye_bag: 101, cheek: 0, forehead: 0, shape: 0, mouth: 0 }) !== null || normalizeFaceLiftFeatures({ eye_bag: 10.5, cheek: 0, forehead: 0, shape: 0, mouth: 0 }) !== null) {
  throw new Error("All-zero, fractional, and out-of-range custom face-lift requests must fail closed.");
}
const normalized = normalizeProviderFaceLiftSimulation({ url: "https://example.com/temporary-face-preview.jpg", beauty_score: 100 }, validFeatures);
if (!normalized || normalized.resultUrl !== "https://example.com/temporary-face-preview.jpg" || normalized.expiresInHours !== 2) {
  throw new Error("Only a temporary secure provider result URL and user-selected controls may be normalized.");
}
if (JSON.stringify(normalized).includes("score") || normalizeProviderFaceLiftSimulation({ url: "http://unsafe.example.com/preview.jpg" }, validFeatures) !== null) {
  throw new Error("Beauty scoring and insecure URLs must not enter app state.");
}
if (!FACE_LIFT_SIMULATION_DISCLOSURE.includes("not medical advice") || !FACE_LIFT_SIMULATION_DISCLOSURE.includes("attractiveness") || !FACE_LIFT_SIMULATION_DISCLOSURE.includes("not saved to history") || !FACE_LIFT_SIMULATION_DISCLOSURE.includes("No stock or fallback")) {
  throw new Error("Face Lift disclosure must preserve non-medical, non-evaluative, temporary, and no-fallback boundaries.");
}

const taskClient = readFileSync("server/youcam-face-lift.ts", "utf8");
const routeSource = readFileSync("server/routes.ts", "utf8");
const screenSource = readFileSync("app/skin/face-lift.tsx", "utf8");
const hubSource = readFileSync("components/skin/SkinCareHub.tsx", "utf8");
for (const endpoint of ["/s2s/v2.0/task/face-lift/pre-process", "/s2s/v2.0/task/face-lift/pre-process/${encodeURIComponent(taskId)}", "/s2s/v2.0/task/face-lift", "/s2s/v2.0/task/face-lift/${encodeURIComponent(taskId)}"]) {
  if (!taskClient.includes(endpoint)) throw new Error(`Missing documented Face Lift endpoint: ${endpoint}`);
}
if (!taskClient.includes('version: "1.0"') || !taskClient.includes('type: "custom"') || !taskClient.includes("index: 0")) {
  throw new Error("Face Lift custom request must include the documented version, custom type, and selected single-face index.");
}
if (!routeSource.includes('app.post("/api/skin/face-lift"') || !routeSource.includes("consent !== true") || !routeSource.includes("faceCount !== 1") || !routeSource.includes("normalizeFaceLiftFeatures")) {
  throw new Error("Face Lift route must require consent, enforce exactly one detected face, and validate feature controls.");
}
if (!screenSource.includes("not medical advice, a diagnosis, a surgical plan, or a prediction") || !screenSource.includes("only you") || !screenSource.includes("No image was shown") || !screenSource.includes("Select at least one non-zero control")) {
  throw new Error("Expo screen must retain non-medical, user-photo-only, no-fallback, and non-zero-control boundaries.");
}
if (!hubSource.includes('router.push("/skin/face-lift")')) throw new Error("Face Lift screen must be reachable from the canonical Skin Care hub.");

console.log(JSON.stringify({ result: "PASS", normalized, assertions: [
  "Only documented 0–100 custom controls and a non-empty visual adjustment request are accepted.",
  "Provider output exposes only a temporary HTTPS URL and user-selected controls, never beauty scoring.",
  "Server requires explicit consent and refuses group photo target selection through its single-face pre-process gate.",
  "Mobile copy stays cosmetic and non-medical, and no stock or fabricated fallback is displayed.",
] }, null, 2));
