import { readFileSync } from "node:fs";

import { decodeAgingJpegUpload, eraseTransientAgingImage } from "../server/aging-upload-security";

function expectReject(label: string, value: unknown): void {
  try {
    decodeAgingJpegUpload(value);
  } catch {
    return;
  }
  throw new Error(`${label} must be rejected by the aging JPEG upload boundary.`);
}

function encodedJpeg(byteLength = 128): string {
  const bytes = Buffer.alloc(byteLength, 0);
  bytes[0] = 0xff;
  bytes[1] = 0xd8;
  bytes[2] = 0xff;
  bytes[byteLength - 2] = 0xff;
  bytes[byteLength - 1] = 0xd9;
  return bytes.toString("base64");
}

const valid = decodeAgingJpegUpload(`data:image/jpeg;base64,${encodedJpeg()}`);
if (valid.contentType !== "image/jpeg" || valid.buffer.length !== 128) {
  throw new Error("A valid JPEG data URI must produce a JPEG-only buffer for the private signed upload.");
}

const retainedReference = valid.buffer;
eraseTransientAgingImage(retainedReference);
if (!retainedReference.every((value) => value === 0)) {
  throw new Error("Transient aging image buffers must be overwritten after upload processing.");
}

expectReject("A PNG payload", `data:image/png;base64,${Buffer.from("not a jpeg").toString("base64")}`);
expectReject("A malformed base64 payload", "data:image/jpeg;base64,not-base64%%%=");
expectReject("A JPEG missing the required end marker", Buffer.from([0xff, 0xd8, 0xff, 0x00, 0x00]).toString("base64"));
expectReject("An overlarge base64 payload", "A".repeat(14_000_001));

const routeSource = readFileSync("server/routes.ts", "utf8");
const providerClientSource = readFileSync("server/youcam-skin-v2.ts", "utf8");
const agingScreenSource = readFileSync("app/skin/aging.tsx", "utf8");
const skinHubSource = readFileSync("components/skin/SkinCareHub.tsx", "utf8");

if (!routeSource.includes("decodeAgingJpegUpload") || !routeSource.includes("eraseTransientAgingImage") || !routeSource.includes("finally")) {
  throw new Error("The aging route must validate images and erase the raw buffer on every outcome.");
}
if (!providerClientSource.includes('signedUrl.protocol !== "https:"') || !providerClientSource.includes('redirect: "error"') || !providerClientSource.includes('cache: "no-store"')) {
  throw new Error("The provider client must enforce HTTPS for signed uploads and reject redirects without caching sensitive requests.");
}
if (!agingScreenSource.includes('accessibilityLiveRegion="polite"') || !agingScreenSource.includes('accessibilityLiveRegion="assertive"')) {
  throw new Error("The aging screen must announce loading and error states to assistive technologies.");
}
if (!agingScreenSource.includes('accessibilityRole="radio"') || !agingScreenSource.includes('accessibilityRole="radiogroup"')) {
  throw new Error("Mutually exclusive aging stages must use radio semantics rather than generic button semantics.");
}
if (!agingScreenSource.includes("accessibilityHint=\"When checked, this enables creation of temporary creative previews") || !agingScreenSource.includes("Temporary provider-generated creative age-progression visualization")) {
  throw new Error("The aging screen must explain consent action and label the temporary, non-predictive preview clearly.");
}
if (!skinHubSource.includes('accessibilityLiveRegion="polite"') || !skinHubSource.includes('accessibilityLabel={`Snapshot source: ${sourceCopy.badge}')) {
  throw new Error("The Skin Care Hub must announce demo loading and describe snapshot provenance for assistive technologies.");
}
if (!skinHubSource.includes("accessibilityElementsHidden") || !skinHubSource.includes('importantForAccessibility="no-hide-descendants"')) {
  throw new Error("The decorative Skin Care Hub header icon must be hidden from assistive technologies.");
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "Only a bounded, canonical JPEG payload with JPEG signature markers is accepted for aging upload.",
    "Every transient raw image buffer can be explicitly zeroed after use.",
    "Signed uploads require HTTPS; sensitive provider requests reject redirects and do not use cache storage.",
    "Aging generation, errors, consent, stage selection, and temporary-result context expose accessible semantics.",
    "The Skin Care Hub exposes demo work status and snapshot provenance while hiding decorative imagery.",
  ],
}, null, 2));
