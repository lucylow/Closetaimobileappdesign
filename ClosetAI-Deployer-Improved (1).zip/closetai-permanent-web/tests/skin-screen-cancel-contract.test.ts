import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const source = readFileSync(join(root, "components/skin/SkinScreen.tsx"), "utf8");

if (!source.includes("const scanRunRef = useRef(0);")) {
  throw new Error("SkinScreen must track the active scan run for stale-result protection.");
}
if (!source.includes("const cancelScan = () =>") || !source.includes("scanRunRef.current += 1;")) {
  throw new Error("SkinScreen must expose cancellation that invalidates the active scan.");
}
if (!source.includes("if (!isCurrentRun()) return;")) {
  throw new Error("SkinScreen must ignore late results and errors from cancelled runs.");
}
if (!source.includes("accessibilityLabel=\"Cancel skin analysis\"")) {
  throw new Error("The cancel action must be accessible.");
}
if (!source.includes("Analysis cancelled. Your selected photo remains available for review.")) {
  throw new Error("Cancellation must communicate that the selected photo remains available.");
}
if (!source.includes("You can cancel and keep the selected photo for review.")) {
  throw new Error("The analyzing state must provide a clear cancellation affordance.");
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "Active scan runs have identity-based stale-result protection.",
    "Cancellation invalidates the active run.",
    "The cancel action is accessible and preserves the selected photo.",
  ],
}, null, 2));
