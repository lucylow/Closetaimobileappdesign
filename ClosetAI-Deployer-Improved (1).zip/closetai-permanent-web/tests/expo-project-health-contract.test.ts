import { existsSync, readFileSync } from "node:fs";
import { resolve } from "node:path";

const root = process.cwd();
const packageJson = JSON.parse(readFileSync(resolve(root, "package.json"), "utf8")) as {
  scripts?: Record<string, string>;
  dependencies?: Record<string, string>;
};
const gitIgnore = readFileSync(resolve(root, ".gitignore"), "utf8");
const dependencies = packageJson.dependencies ?? {};

const expectedSdk54Dependencies: Record<string, string> = {
  expo: "~54.0.36",
  "babel-preset-expo": "~54.0.10",
  "expo-crypto": "~15.0.9",
  "expo-font": "~14.0.12",
  "expo-file-system": "~19.0.23",
  "expo-glass-effect": "~0.1.10",
  "expo-image-picker": "~17.0.11",
  "expo-linking": "~8.0.12",
  "expo-router": "~6.0.24",
  "expo-web-browser": "~15.0.11",
};

for (const [name, expectedVersion] of Object.entries(expectedSdk54Dependencies)) {
  if (dependencies[name] !== expectedVersion) {
    throw new Error(`Expected ${name}@${expectedVersion} for the verified Expo SDK 54 project health baseline; found ${dependencies[name] ?? "missing"}.`);
  }
}

if (!gitIgnore.split(/\r?\n/).includes(".expo/")) {
  throw new Error("The project must ignore Expo machine-local state via .expo/.");
}

if (existsSync(resolve(root, "patches", "expo-asset+12.0.12.patch"))) {
  throw new Error("The obsolete expo-asset patch must not be restored because Expo SDK 54 no longer installs its patch target.");
}

if (!packageJson.scripts?.postinstall?.includes("patch-package")) {
  throw new Error("The postinstall step must retain patch-package support for any future valid project patches.");
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "Expo SDK 54 dependency versions, including required FileSystem and Babel preset support, match the repaired diagnostic baseline without requiring a custom keyboard native module.",
    "Machine-local .expo state is excluded from Git.",
    "The obsolete missing-target expo-asset postinstall patch remains removed.",
  ],
}, null, 2));
