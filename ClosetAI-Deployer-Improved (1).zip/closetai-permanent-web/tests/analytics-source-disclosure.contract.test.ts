import fs from 'node:fs';
import path from 'node:path';

const file = path.resolve(process.cwd(), 'app/business-dashboard.tsx');
const source = fs.readFileSync(file, 'utf8');

for (const marker of [
  "const analyticsSource = analytics ? 'Synced analytics' : 'Local privacy-preserving summary';",
  'Metrics were returned by the analytics endpoint',
  'The endpoint was unavailable',
  'No fabricated performance data is added.',
  'accessibilityRole="summary"',
  'analyticsSourceCard',
]) {
  if (!source.includes(marker)) throw new Error(`Missing analytics source disclosure marker: ${marker}`);
}

console.log('Analytics source disclosure contract passed.');
