import { readFileSync } from "node:fs";

const packageJson = JSON.parse(readFileSync("package.json", "utf8")) as {
  dependencies?: Record<string, string>;
  scripts?: Record<string, string>;
};
const appConfig = JSON.parse(readFileSync("app.json", "utf8")) as {
  expo?: { plugins?: unknown[]; web?: Record<string, unknown> };
};
const layout = readFileSync("app/_layout.tsx", "utf8");
const imageUtility = readFileSync("lib/selected-image-base64.ts", "utf8");
const skinScreen = readFileSync("components/skin/SkinScreen.tsx", "utf8");
const selfieFlow = readFileSync("components/skin/SelfieFlowScreen.tsx", "utf8");
const keyboardWrapper = readFileSync("components/KeyboardAwareScrollViewCompat.tsx", "utf8");
const tabLayout = readFileSync("app/(tabs)/_layout.tsx", "utf8");
const readme = readFileSync("README.md", "utf8");

if (packageJson.dependencies?.expo !== "~54.0.36") throw new Error("The app must remain on the validated Expo SDK 54 line.");
if (packageJson.dependencies?.["expo-router"] !== "~6.0.24") throw new Error("Expo Router must remain on the validated SDK 54-compatible line.");
if (packageJson.dependencies?.["react-native-keyboard-controller"] !== undefined) {
  throw new Error("Expo Go must not require the custom keyboard-controller native module.");
}
if (!packageJson.scripts?.["replit:expo"] || !packageJson.scripts?.["replit:build"]) {
  throw new Error("Replit Expo and build scripts must remain available.");
}
if (!JSON.stringify(appConfig.expo?.plugins).includes("expo-router")) throw new Error("Expo Router must remain registered as a plugin.");
const expoPlugins = JSON.stringify(appConfig.expo?.plugins);
if (!expoPlugins.includes("expo-camera")) throw new Error("The camera permission plugin must remain registered.");
if (!expoPlugins.includes('"recordAudioAndroid":false')) throw new Error("The Expo camera plugin must not request unused Android microphone access.");
if (!appConfig.expo?.web) throw new Error("Web export configuration must remain present for Replit preview validation.");
for (const [label, source] of [
  ["selected-image conversion", imageUtility],
  ["Skin Care screen", skinScreen],
  ["selfie flow", selfieFlow],
] as const) {
  if (!source.includes("expo-file-system/legacy")) {
    throw new Error(`${label} must use the Expo SDK 54 legacy FileSystem API.`);
  }
}
for (const prohibited of ["react-native-keyboard-controller", "KeyboardProvider"]) {
  if (layout.includes(prohibited) || keyboardWrapper.includes(prohibited)) {
    throw new Error(`Expo Go-incompatible keyboard integration remains: ${prohibited}`);
  }
}
if (!keyboardWrapper.includes("KeyboardAvoidingView") || !keyboardWrapper.includes("Platform.OS === \"web\"")) {
  throw new Error("Keyboard handling must use built-in native primitives and preserve a web-safe branch.");
}
if (!tabLayout.includes('Platform.OS === "ios" && isLiquidGlassAvailable()')) {
  throw new Error("Unstable NativeTabs must be restricted to supported iOS devices.");
}
if (!readme.includes("# ClosetAI React Native / Expo Mobile App") || !readme.includes("open it in Expo Go")) {
  throw new Error("The repository handoff must identify the React Native Expo mobile workflow.");
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "Expo SDK 54 and Expo Router versions remain pinned to the validated compatibility line.",
    "No custom keyboard native module is required by the Expo Go bundle.",
    "Selected-image conversion and skincare selfie flows use the SDK 54-compatible legacy FileSystem API.",
    "Camera, Router, web export, and Replit scripts remain registered.",
  ],
}, null, 2));
