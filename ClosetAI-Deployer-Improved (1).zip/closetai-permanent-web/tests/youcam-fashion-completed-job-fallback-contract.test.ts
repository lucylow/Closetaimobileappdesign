import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

const source = readFileSync(resolve(process.cwd(), 'contexts/AppContext.tsx'), 'utf8');

for (const required of [
  'type CompletedTryOnJobResponse = {',
  'function createUserPhotoTryOnFallback(',
  'resultImageUrl: selfieUri',
  "provider: 'photo-preview'",
  'function isSafeCompletedTryOnImageUrl(value: unknown): value is string',
  "value.startsWith('https://')",
  '/^data:image\\/(?:png|jpe?g);base64,[A-Za-z0-9+/]+={0,2}$/.test(value)',
  'function isTerminalTryOnJobStatus(value: unknown): boolean',
  'function normalizeCompletedTryOnJob(',
  "if (provider === 'photo-preview')",
  'if (!jobId || !isSafeCompletedTryOnImageUrl(response.resultImageUrl))',
  "if (typeof job?.id !== 'string' || job.id.trim().length === 0)",
  'const completedResult = normalizeCompletedTryOnJob(status, selfieUri, garmentIds);',
  'if (isTerminalTryOnJobStatus(pollingStatus))',
  'Live virtual try-on is taking longer than expected.',
  'Live virtual try-on is temporarily unavailable.',
]) {
  if (!source.includes(required)) throw new Error(`Completed YouCam fashion job fallback safeguard missing: ${required}`);
}

const responseType = source.indexOf('type CompletedTryOnJobResponse');
const photoFallback = source.indexOf('function createUserPhotoTryOnFallback', responseType);
const safeUrl = source.indexOf('function isSafeCompletedTryOnImageUrl', photoFallback);
const terminalStatus = source.indexOf('function isTerminalTryOnJobStatus', safeUrl);
const normalization = source.indexOf('function normalizeCompletedTryOnJob', terminalStatus);
const validatedJob = source.indexOf("if (typeof job?.id !== 'string' || job.id.trim().length === 0)", normalization);
const normalizedPolling = source.indexOf('const completedResult = normalizeCompletedTryOnJob(status, selfieUri, garmentIds);', validatedJob);
const terminalFallback = source.indexOf('if (isTerminalTryOnJobStatus(pollingStatus))', normalizedPolling);

if ([responseType, photoFallback, safeUrl, terminalStatus, normalization, validatedJob, normalizedPolling, terminalFallback].some((index) => index === -1)
  || responseType > photoFallback
  || photoFallback > safeUrl
  || safeUrl > terminalStatus
  || terminalStatus > normalization
  || normalization > validatedJob
  || validatedJob > normalizedPolling
  || normalizedPolling > terminalFallback) {
  throw new Error('Completed virtual try-on job payloads must be validated before any provider image can be shown, and malformed terminal outcomes must fall back to the selected user photo.');
}

console.log(JSON.stringify({
  result: 'PASS',
  assertions: [
    'Completed provider statuses are normalized only after the job ID and result URL shape are validated.',
    'Malformed completion payloads, unknown terminal statuses, job creation gaps, polling exhaustion, and transport failures return only the selected user photo.',
    'All client-side fallback disclosures explicitly say that no stock model or unrelated image was used.',
    'Photo-preview jobs remain photo previews even if a stored result URL is absent or malformed.',
  ],
}, null, 2));
