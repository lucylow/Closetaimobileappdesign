import fs from 'node:fs';
import path from 'node:path';

const file = path.resolve(process.cwd(), 'app/(tabs)/outfits.tsx');
const source = fs.readFileSync(file, 'utf8');

for (const marker of [
  'Source: bounded retailer search.',
  'Search basis: ${item.category}.',
  'No product availability or purchase claim.',
  'Bounded retailer search · {item.category}',
  'external retailer search link derived from wardrobe context',
  'accessibilityRole="button"',
]) {
  if (!source.includes(marker)) throw new Error(`Missing retailer provenance card marker: ${marker}`);
}

console.log('Retailer provenance card contract passed.');
