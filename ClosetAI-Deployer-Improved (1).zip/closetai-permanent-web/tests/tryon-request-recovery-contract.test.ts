import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

const source = readFileSync(resolve(process.cwd(), 'contexts/AppContext.tsx'), 'utf8');

for (const required of [
  'type TryOnRequestRecovery =',
  'function resolveTryOnRequestRecovery(error: unknown): TryOnRequestRecovery',
  "message.includes('EXPO_PUBLIC_DOMAIN is not set')",
  'if (status === 401 || status === 403)',
  'if (status === 400 || status === 404 || status === 409 || status === 413 || status === 422)',
  'if (status === 402)',
  'if (status === 408 || status === 504)',
  'if (status === 429)',
  'if (status !== null && status >= 500 && status <= 599)',
  "if (recovery.kind === 'actionable')",
  "throw new Error(recovery.message)",
  "console.warn('Try-on job failed; showing selected-photo fallback:', err)",
  'return createUserPhotoTryOnFallback(selfieUri, garmentIds, undefined, recovery.disclosure);',
]) {
  if (!source.includes(required)) throw new Error(`Try-on request recovery safeguard missing: ${required}`);
}

const helper = source.indexOf('function resolveTryOnRequestRecovery(error: unknown): TryOnRequestRecovery');
const actionable = source.indexOf("if (recovery.kind === 'actionable')", helper);
const fallback = source.indexOf('return createUserPhotoTryOnFallback(selfieUri, garmentIds, undefined, recovery.disclosure);', actionable);
const demoFallback = source.indexOf("'Photo preview shown. Live virtual try-on is not available in this demo session.'", fallback);

if ([helper, actionable, fallback, demoFallback].some(index => index === -1)
  || helper > actionable
  || actionable > fallback
  || fallback > demoFallback) {
  throw new Error('Actionable request errors must remain separate from provider-failure photo previews, and the explicit Demo Mode fallback must remain after the live path.');
}

for (const boundary of [
  'no live outfit was produced and no stock model was used.',
  'resultImageUrl: selfieUri',
  "provider: 'photo-preview'",
]) {
  if (!source.includes(boundary)) throw new Error(`Selected-photo-only fallback boundary missing: ${boundary}`);
}

console.log(JSON.stringify({
  result: 'PASS',
  assertions: [
    'Session, configuration, photo, wardrobe, concurrency, and credit errors remain actionable rather than silently becoming fallback previews.',
    'Timeout, rate-limit, 5xx, and unknown provider failures produce a clearly labeled selected-photo-only fallback.',
    'The fallback preserves the selected user photo and never inserts a stock model or unrelated image.',
  ],
}, null, 2));
