import { readFileSync } from "node:fs";
import { createSkinSimulationRequest, normalizeSkinSimulationAdjustments, SKIN_SIMULATION_DISCLOSURE } from "../shared/skin-simulation";

const normalized = normalizeSkinSimulationAdjustments({ wrinkle: 0.251, pores: 2, radiance: -1, unknown: 0.8 });
if (!normalized || normalized.wrinkle !== 0.25 || normalized.pores !== 1 || "radiance" in normalized || "unknown" in normalized) {
  throw new Error("Simulation adjustments must clamp known values and drop zero, negative, and unknown keys.");
}
if (createSkinSimulationRequest({ wrinkle: 0, pores: 0 }) !== null) {
  throw new Error("A cosmetic simulation request must require at least one explicit nonzero adjustment.");
}
if (!SKIN_SIMULATION_DISCLOSURE.includes("not a medical assessment")) {
  throw new Error("Simulation contract must include a non-medical, non-predictive disclosure.");
}

const routeSource = readFileSync("server/routes.ts", "utf8");
const screenSource = readFileSync("app/skin/simulation.tsx", "utf8");
const hubSource = readFileSync("components/skin/SkinCareHub.tsx", "utf8");
if (!routeSource.includes('app.post("/api/skin/simulation"') || !routeSource.includes("createSkinSimulationRequest")) {
  throw new Error("Server must expose an authenticated, validated simulation endpoint.");
}
if (!screenSource.includes("No generated image was shown") || !screenSource.includes("short-lived provider preview")) {
  throw new Error("Mobile simulation screen must not fabricate an image when live simulation fails.");
}
if (!hubSource.includes('router.push("/skin/simulation")')) {
  throw new Error("Skin Care hub must expose the optional simulation flow.");
}

console.log(JSON.stringify({
  result: "PASS",
  normalized,
  assertions: [
    "Only documented concerns and intensities from 0.01 through 1.0 are submitted.",
    "At least one user-selected adjustment is required.",
    "The server route is authenticated and source-aware.",
    "No demo or stock simulation preview is substituted after failure.",
    "The cosmetic preview route is reachable from the visible Skin Care hub.",
  ],
}, null, 2));
