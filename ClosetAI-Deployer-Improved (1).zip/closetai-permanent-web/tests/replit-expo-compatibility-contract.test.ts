import { readFileSync, existsSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import assert from "node:assert/strict";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const packageJson = JSON.parse(readFileSync(resolve(root, "package.json"), "utf8"));
const scripts = packageJson.scripts ?? {};
const replitConfig = readFileSync(resolve(root, ".replit"), "utf8");
const guide = readFileSync(resolve(root, "REPLIT_EXPO_RUN_GUIDE.md"), "utf8");

assert.equal(packageJson.main, "expo-router/entry", "Expo Router must remain the mobile application entry point.");
assert.match(String(packageJson.dependencies?.expo), /^~54\./, "The Replit project must preserve the Expo SDK 54 baseline.");
assert.match(String(scripts["replit:web"]), /replit:preview/, "Replit needs a complete Expo preview and API script.");
assert.match(String(scripts["replit:expo"]), /concurrently/, "Expo Go on Replit must run the API and Metro together.");
assert.match(String(scripts["replit:expo"]), /expo start --tunnel/, "Expo Go on Replit needs a tunnel-based run script.");
assert.match(String(scripts["replit:preview"]), /replit:build/, "The Replit preview script must use the consolidated build before serving it.");
assert.match(String(scripts["replit:build"]), /expo:static:build/, "The consolidated Replit build must generate the static Expo bundle.");
assert.match(String(scripts["replit:build"]), /server:build/, "The Replit deployment build must compile the Express API server.");
assert.match(replitConfig, /run = "npm run replit:expo"/, "The default Replit command must launch the complete Expo Go preview.");
assert.match(replitConfig, /localPort = 5000/, "The Replit deployment must expose the Express/preview port.");
assert.match(replitConfig, /build = "npm run replit:build"/, "Replit deployment must use the consolidated Expo and server build command.");
assert.equal(existsSync(resolve(root, "app.json")), true, "Expo application configuration must remain present.");
assert.match(guide, /Expo Go/, "The setup guide must explain how to run the native mobile app in Expo Go.");
assert.match(guide, /PERFECT_YOUCAM_API_KEY/, "The setup guide must list the core YouCam secret.");
assert.doesNotMatch(guide, /EXPO_PUBLIC_PERFECT_YOUCAM/, "Provider credential values must not be configured as Expo public values.");

console.log(JSON.stringify({ result: "PASS", assertions: 14 }, null, 2));
