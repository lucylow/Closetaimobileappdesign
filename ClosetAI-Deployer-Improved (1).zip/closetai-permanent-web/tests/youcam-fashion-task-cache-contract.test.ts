import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

const cache = readFileSync(resolve(process.cwd(), 'server/youcam-cache.ts'), 'utf8');
const youcam = readFileSync(resolve(process.cwd(), 'server/youcam.ts'), 'utf8');

for (const required of [
  'delete(key: string): void {',
  'this.entries.delete(key);',
]) {
  if (!cache.includes(required)) throw new Error(`Cache eviction capability missing: ${required}`);
}

for (const required of [
  'if (!/^[A-Za-z0-9._:-]{1,256}$/.test(taskId))',
  'return { error: "Live YouCam clothing task is unavailable." };',
  'if (cached.value && isSafeFashionResultUrl(cached.value.resultUrl))',
  'return { ...cached.value, cacheStatus: "hit" };',
  'if (cached.value) completedFashionTaskCache.delete(taskId);',
]) {
  if (!youcam.includes(required)) throw new Error(`Safe fashion task-cache handling missing: ${required}`);
}

const idGuard = youcam.indexOf('if (!/^[A-Za-z0-9._:-]{1,256}$/.test(taskId))');
const cacheRead = youcam.indexOf('const cached = completedFashionTaskCache.get(taskId);', idGuard);
const safeCache = youcam.indexOf('if (cached.value && isSafeFashionResultUrl(cached.value.resultUrl))', cacheRead);
const cacheEviction = youcam.indexOf('if (cached.value) completedFashionTaskCache.delete(taskId);', safeCache);
const livePoll = youcam.indexOf('for (let attempt = 0; attempt < maxAttempts; attempt++)', cacheEviction);
if ([idGuard, cacheRead, safeCache, cacheEviction, livePoll].some((index) => index === -1)
  || idGuard > cacheRead
  || cacheRead > safeCache
  || safeCache > cacheEviction
  || cacheEviction > livePoll) {
  throw new Error('Fashion task cache entries must be validated and evicted before any live provider poll proceeds.');
}

console.log(JSON.stringify({
  result: 'PASS',
  assertions: [
    'Only valid task identifiers can read or poll the fashion task cache.',
    'Cached results must still pass the credential-free HTTPS result URL check before reuse.',
    'Malformed cached results are evicted and cannot bypass live-result safeguards or reach the mobile client.',
  ],
}, null, 2));
