import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const context = readFileSync(join(root, "contexts/SelfieScanContext.tsx"), "utf8");
const journey = readFileSync(join(root, "components/skin/SkinJourneyPage.tsx"), "utf8");

if (!context.includes("clearSavedHistory: () => Promise<void>")) {
  throw new Error("Selfie scan state must expose an async clear-history action.");
}
if (!context.includes("await clearSkinMetricHistory();") || !context.includes("await AsyncStorage.removeItem(SAVED_RESULTS_KEY);") || !context.includes("await clearSkinAnalysisRetryQueue();") || !context.includes("setSavedResults([]);")) {
  throw new Error("Clear-history must remove local metric rows, saved summaries, and in-memory history together.");
}
if (!journey.includes("Clear saved Skin Care history?") || !journey.includes("style: \"destructive\"")) {
  throw new Error("The history UI must require an explicit destructive confirmation before clearing local data.");
}
if (!journey.includes("Original selfies, raw provider output, and remote provider data are not stored here")) {
  throw new Error("The clear-history confirmation must preserve the local-only privacy boundary.");
}
if (!journey.includes("Clear saved history")) {
  throw new Error("The history route must expose the clear saved history action when local summaries exist.");
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "Clear-history coordinates AsyncStorage, SQLite metric history, in-memory state, and queued retry metadata.",
    "The UI requires destructive confirmation before deleting local history.",
    "The confirmation preserves no-original-selfie and no-raw-provider-data disclosures.",
  ],
}, null, 2));
