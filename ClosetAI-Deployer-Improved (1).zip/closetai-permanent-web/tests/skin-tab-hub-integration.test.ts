import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const root = process.cwd();
const tabRoute = readFileSync(resolve(root, "app/(tabs)/skin.tsx"), "utf8");
const hub = readFileSync(resolve(root, "components/skin/SkinCareHub.tsx"), "utf8");

if (!tabRoute.includes("SkinCareHub")) throw new Error("The visible Skin tab must mount the canonical SkinCareHub.");
if (!hub.includes('router.push("/skin/selfie-scan")')) throw new Error("The Skin tab must expose the secure optional selfie flow.");
if (!hub.includes('analyzeSkin({ demo: true')) throw new Error("The Skin tab must retain a credential-free explicit demo scan path.");
if (!hub.includes("SkinIntelligenceDashboard")) throw new Error("The Skin tab must render normalized source-aware dashboard data.");
if (!hub.includes('router.push("/skin/style-match")')) throw new Error("The Skin tab must connect users to Skin × Style.");
if (!hub.includes("not a diagnosis")) throw new Error("The Skin tab must retain its non-diagnostic disclosure.");

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "Visible Skin tab mounts the canonical integrated hub.",
    "Hub provides optional secure selfie flow and explicit demo fallback.",
    "Hub renders normalized dashboard results and Skin × Style navigation.",
    "Hub retains privacy and non-diagnostic disclosures.",
  ],
}, null, 2));
