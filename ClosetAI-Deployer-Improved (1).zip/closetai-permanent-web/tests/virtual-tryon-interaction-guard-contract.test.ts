import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const source = readFileSync(resolve(process.cwd(), "app/(tabs)/tryon.tsx"), "utf8");

for (const required of [
  "const isMountedRef = React.useRef(true)",
  "const pickerInFlightRef = React.useRef(false)",
  "const tryOnInFlightRef = React.useRef(false)",
  "const processingIntervalRef = React.useRef<ReturnType<typeof setInterval> | null>(null)",
  "if (pickerInFlightRef.current || tryOnInFlightRef.current) return",
  "if (!selfieUri || selectedGarments.length === 0 || tryOnInFlightRef.current || pickerInFlightRef.current) return",
  "if (processingIntervalRef.current) clearInterval(processingIntervalRef.current)",
  "if (isMountedRef.current) setIsProcessing(false)",
  "if (isMountedRef.current) setIsPickingSelfie(false)",
]) {
  if (!source.includes(required)) throw new Error(`Virtual try-on lifecycle safeguard missing: ${required}`);
}

for (const required of [
  "const isInteractionLocked = isProcessing || isPickingSelfie",
  "accessibilityState={{ disabled: isInteractionLocked, busy: isPickingSelfie }}",
  "accessibilityState={{ checked: active, disabled: isInteractionLocked }}",
  "accessibilityState={{ checked: selected, disabled: isInteractionLocked }}",
  "accessibilityState={{ disabled: !selfieUri || selectedGarments.length === 0 || isInteractionLocked, busy: isProcessing }}",
  "Wait until the current photo or try-on action finishes.",
]) {
  if (!source.includes(required)) throw new Error(`Virtual try-on accessible lockout missing: ${required}`);
}

for (const boundary of [
  "Uses only the photo you select. ClosetAI never substitutes a stock model.",
  "Your photo only · never a stock model substitution.",
  "Creates a result using your selected photo only.",
  "Demo mode keeps your uploaded photo on device and will never substitute a stock model image.",
]) {
  if (!source.includes(boundary)) throw new Error(`Virtual try-on user-photo-only boundary missing: ${boundary}`);
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "Photo picking and try-on generation reject overlapping requests and clear result lifecycle state only while mounted.",
    "Processing intervals are cleared and conflicting photo, garment, category, generation, reset, and shoe controls expose accessible lockout states.",
    "The workflow preserves a selected-user-photo-only result boundary, including its demo disclosure and no-stock-model guarantee.",
  ],
}, null, 2));
