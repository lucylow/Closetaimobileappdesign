import { readFileSync } from "node:fs";
import { buildSkinProgressMetricSummary, buildSkinProgressOverview, getSkinProgressMetricPoints, progressDirectionLabel, SKIN_PROGRESS_DISCLOSURE } from "../lib/skin-progress-trends";

const points = [
  { scanId: "scan-2", capturedAt: "2026-08-08T12:00:00Z", source: "youcam" as const, metricKey: "hydration", score: 54 },
  { scanId: "scan-1", capturedAt: "2026-08-01T12:00:00Z", source: "youcam" as const, metricKey: "hydration", score: 48 },
  { scanId: "scan-1", capturedAt: "2026-08-01T12:00:00Z", source: "youcam" as const, metricKey: "radiance", score: 59 },
  { scanId: "scan-2", capturedAt: "2026-08-08T12:00:00Z", source: "youcam" as const, metricKey: "radiance", score: 60 },
  { scanId: "demo-1", capturedAt: "2026-08-10T12:00:00Z", source: "demo" as const, metricKey: "pores", score: 44 },
];

const overview = buildSkinProgressOverview(points);
const hydration = buildSkinProgressMetricSummary(points, "hydration");
const radiance = buildSkinProgressMetricSummary(points, "radiance");
const mixed = buildSkinProgressMetricSummary([...points.filter((point) => point.metricKey === "hydration"), { scanId: "demo-hydration", capturedAt: "2026-08-11T12:00:00Z", source: "demo" as const, metricKey: "hydration", score: 58 }], "hydration");
const orderedHydration = getSkinProgressMetricPoints(points, "hydration");
const sparse = buildSkinProgressMetricSummary(points, "pores");

if (overview.snapshotCount !== 3 || overview.captureDayCount !== 3 || overview.sources.length !== 2) {
  throw new Error("Progress overview must deduplicate scan-level snapshot counts and track capture days and sources without source images.");
}
if (hydration.direction !== "up" || hydration.delta !== 6 || hydration.source !== "youcam" || !hydration.note.includes("Normalized live snapshot direction")) {
  throw new Error("Live same-source metric summaries must sort chronologically and report conservative direction language without clinical claims.");
}
if (radiance.direction !== "steady" || progressDirectionLabel(radiance.direction) !== "Steady") {
  throw new Error("Small changes must be labeled steady rather than meaningful treatment improvement.");
}
if (mixed.direction !== "mixed" || mixed.delta !== undefined || !mixed.note.includes("not combined")) {
  throw new Error("Mixed source histories must not calculate a combined personal direction.");
}
if (sparse.direction !== "insufficient" || !sparse.note.includes("at least two snapshots")) {
  throw new Error("Single snapshot histories must fail closed with an insufficient-data explanation.");
}
if (orderedHydration[0]?.scanId !== "scan-1" || orderedHydration[1]?.scanId !== "scan-2") {
  throw new Error("Metric history must be chronologically ordered before trend display.");
}
if (!SKIN_PROGRESS_DISCLOSURE.includes("not medical advice") || !SKIN_PROGRESS_DISCLOSURE.includes("Original selfies") || !SKIN_PROGRESS_DISCLOSURE.includes("raw provider output")) {
  throw new Error("Progress disclosure must preserve non-medical and no-selfie/raw-provider-persistence boundaries.");
}

const historySource = readFileSync("lib/skin-metric-history.native.ts", "utf8");
const chartSource = readFileSync("components/skin/SkinMetricProgressChart.tsx", "utf8");
if (!historySource.includes("the selfie, image URI, masks, and raw API response are never written to SQLite")) {
  throw new Error("Native metric history must preserve the no-selfie/raw-payload SQLite contract.");
}
if (!chartSource.includes("buildSkinProgressOverview") || !chartSource.includes("Clear local progress history?") || !chartSource.includes("Fictional Demo Mode") || !chartSource.includes("Snapshot direction")) {
  throw new Error("Your Progress UI must render the upgraded overview, source-safe direction, Demo Mode label, and local-clear control.");
}

console.log(JSON.stringify({ result: "PASS", assertions: [
  "Progress overview deduplicates local normalized snapshots and tracks dates and sources without image data.",
  "Live same-source directions are chronological and use non-clinical up/down/steady language.",
  "Mixed and sparse histories fail closed without a combined personal trend claim.",
  "Your Progress keeps original selfies and raw provider output out of local SQLite trend history.",
  "The Expo card provides source-aware summaries, accessible trends, and explicit local-history controls.",
] }, null, 2));
