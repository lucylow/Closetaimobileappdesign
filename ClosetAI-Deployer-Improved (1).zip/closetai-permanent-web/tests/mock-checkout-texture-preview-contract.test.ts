import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

import { mockSkinCommerceProvider } from '../lib/skin-commerce-provider';
import { ULTRA_LUXURY_SKIN_DISCOVERY_RECORDS } from '../lib/ultra-luxury-skin-discovery';

const root = process.cwd();
const cartScreen = readFileSync(resolve(root, 'app/skin/mock-cart.tsx'), 'utf8');
const texturePreview = readFileSync(resolve(root, 'app/skin/texture-preview.tsx'), 'utf8');
const discoveryPanel = readFileSync(resolve(root, 'components/skin/UltraLuxurySkinDiscoveryPanel.tsx'), 'utf8');
const providerSource = readFileSync(resolve(root, 'lib/skin-commerce-provider.ts'), 'utf8');

async function run() {
  for (const record of ULTRA_LUXURY_SKIN_DISCOVERY_RECORDS) {
    const listing = await mockSkinCommerceProvider.getListing(record.id);
    if (!listing) throw new Error(`${record.id} must be available to the local mock-cart provider.`);
    if (listing.provider !== 'mock' || listing.mode !== 'mock' || listing.checkoutEnabled !== false) {
      throw new Error(`${record.id} must remain a mock listing with live checkout disabled.`);
    }
    if (!listing.disclosure.includes('fictional local simulation') || !listing.disclosure.includes(`not affiliated with ${record.brand}`)) {
      throw new Error(`${record.id} must state its external-reference and fictional-local-simulation boundary.`);
    }
  }

  const requiredCartBoundaries = [
    'Simulate Mock Checkout',
    'does not collect payment or address data',
    'No payment, order, reservation, or external contact occurred.',
    'hasUnavailableLine',
  ];
  for (const boundary of requiredCartBoundaries) {
    if (!cartScreen.includes(boundary)) throw new Error(`Mock cart screen must retain checkout safety boundary: ${boundary}`);
  }
  if (cartScreen.includes('TextInput') || cartScreen.includes('checkoutUrl') || cartScreen.includes('WebView')) {
    throw new Error('Mock checkout must not collect payment data or open a real checkout destination.');
  }

  const requiredTextureBoundaries = [
    "expo-image-picker",
    'photoUri',
    'Visual-preview consent',
    'It does not analyse skin, predict results, diagnose, claim efficacy, reproduce a brand formula, or show a stock model.',
    'does not upload it or save a history entry',
    'setPhotoUri(null)',
    'ULTRA_LUXURY_SKIN_DISCOVERY_RECORDS',
  ];
  for (const boundary of requiredTextureBoundaries) {
    if (!texturePreview.includes(boundary)) throw new Error(`Cosmetic texture preview must retain safety boundary: ${boundary}`);
  }
  if (texturePreview.includes('fetch(') || texturePreview.includes('analyzeSkin') || texturePreview.includes('imageBase64')) {
    throw new Error('Cosmetic texture preview must remain local and must not send the selected photo to an AI or provider route.');
  }

  if (!discoveryPanel.includes('addExternalReferenceToMockCart') || !discoveryPanel.includes('Try a cosmetic texture preview')) {
    throw new Error('The ultra-luxury discovery panel must connect both the mock-cart and local texture-preview flows.');
  }
  if (!providerSource.includes('ultraLuxuryMockListingData') || !providerSource.includes('never mirror a house')) {
    throw new Error('The mock provider must document that ultra-luxury values never mirror live retail data.');
  }

  console.log(JSON.stringify({
    result: 'PASS',
    ultraLuxuryListingCount: ULTRA_LUXURY_SKIN_DISCOVERY_RECORDS.length,
    assertions: [
      'All ultra-luxury discovery records enter only a local mock cart with live checkout disabled.',
      'Mock checkout simulates a local confirmation without payment, address, order, reservation, or external contact.',
      'Cosmetic texture preview uses an optional user-selected photo locally and does not analyse, upload, diagnose, predict, or imitate a formula.',
    ],
  }, null, 2));
}

run().catch((error) => {
  console.error(error);
  process.exit(1);
});
