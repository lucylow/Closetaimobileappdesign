import fs from 'node:fs';
import path from 'node:path';

const file = path.resolve(process.cwd(), 'components/skin/LiveSkinCamera.tsx');
const source = fs.readFileSync(file, 'utf8');

for (const marker of [
  'CAPTURE BOUNDARY',
  'Camera → Review → Optional YouCam',
  'Local stream',
  'You approve',
  'Consent + request',
  'Face presence helps framing only.',
  'No identity classification, hidden upload, or diagnosis',
  'accessibilityRole="summary"',
]) {
  if (!source.includes(marker)) throw new Error(`Missing live-camera disclosure marker: ${marker}`);
}

if (!source.includes('takePictureAsync({ quality: 0.72, exif: false, base64: false })')) {
  throw new Error('Camera capture must remain an explicit local frame capture before review.');
}

if (!source.includes('router.replace("/skin/selfie-review")')) {
  throw new Error('Captured frames must continue through the review screen before optional analysis.');
}

if (!source.includes('Only the photo you approve continues to the optional scan flow.')) {
  throw new Error('The camera flow must preserve the selected-photo approval boundary.');
}

console.log('Live camera pipeline disclosure contract passed.');
