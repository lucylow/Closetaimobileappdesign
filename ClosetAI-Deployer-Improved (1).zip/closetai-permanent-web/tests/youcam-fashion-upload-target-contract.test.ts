import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

const source = readFileSync(resolve(process.cwd(), 'server/youcam.ts'), 'utf8');

for (const required of [
  'function isSafeFashionUploadUrl(value: unknown): value is string',
  'url.protocol === "https:" && !url.username && !url.password',
  'function normalizeFashionUploadHeaders(value: unknown): Record<string, string> | null',
  '["authorization", "cookie", "host", "content-length", "proxy-authorization"].includes(normalizedName)',
  '/[\\r\\n\\0]/.test(headerValue)',
  'Live YouCam image upload target could not be prepared.',
  'Live YouCam image upload did not return a usable file identifier.',
  'Live YouCam image upload did not return a secure upload target.',
  'Live YouCam image upload returned unsafe upload headers.',
  'if (!isSafeFashionUploadUrl(input.uploadUrl))',
  'if (!normalizeFashionUploadHeaders(input.uploadHeaders))',
  'redirect: "error"',
  'Live YouCam image upload did not complete.',
]) {
  if (!source.includes(required)) throw new Error(`Safe fashion upload-target safeguard missing: ${required}`);
}

for (const prohibited of [
  'YouCam fashion file request failed (${result.status})',
  'YouCam fashion upload failed (${res.status})',
  'return { fileId: file.file_id, uploadUrl: request.url, uploadHeaders: request.headers || {} };',
]) {
  if (source.includes(prohibited)) throw new Error(`Raw provider upload handling remains: ${prohibited}`);
}

const targetValidator = source.indexOf('function isSafeFashionUploadUrl');
const headerValidator = source.indexOf('function normalizeFashionUploadHeaders', targetValidator);
const fileId = source.indexOf('if (typeof file?.file_id !== "string"', headerValidator);
const target = source.indexOf('if (!isSafeFashionUploadUrl(request?.url))', fileId);
const headers = source.indexOf('const uploadHeaders = normalizeFashionUploadHeaders(request?.headers);', target);
const directUpload = source.indexOf('if (!isSafeFashionUploadUrl(input.uploadUrl))', headers);
const redirect = source.indexOf('redirect: "error"', directUpload);
if ([targetValidator, headerValidator, fileId, target, headers, directUpload, redirect].some((index) => index === -1)
  || targetValidator > headerValidator
  || headerValidator > fileId
  || fileId > target
  || target > headers
  || headers > directUpload
  || directUpload > redirect) {
  throw new Error('Provider upload targets and headers must be validated before both return and PUT upload use, with redirects blocked.');
}

console.log(JSON.stringify({
  result: 'PASS',
  assertions: [
    'Only credential-free HTTPS upload targets with safe provider headers are accepted.',
    'Unsafe identifiers, targets, headers, redirects, and upload failures resolve to stable public recovery messages.',
    'Raw provider status and response details do not enter mobile-visible fallback behavior.',
  ],
}, null, 2));
