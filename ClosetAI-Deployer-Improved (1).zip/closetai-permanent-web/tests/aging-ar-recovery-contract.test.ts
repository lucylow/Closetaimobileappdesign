import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const source = readFileSync(resolve(process.cwd(), "app/skin/aging.tsx"), "utf8");

for (const required of [
  "const requestIdRef = React.useRef(0);",
  "const isCurrentRequest = () => requestIdRef.current === runId;",
  "if (asset.uri !== selectedAssetUri) return;",
  "const cancelPreview = () =>",
  "Cancel AI aging visualization",
  "Creative preview cancelled. No generated image was shown or saved.",
  "Retry AI aging visualization",
  "Retries the temporary provider visualization with the same selected selfie and consent.",
  "No image was shown.",
]) {
  if (!source.includes(required)) throw new Error(`AI aging AR recovery safeguard missing: ${required}`);
}

for (const boundary of [
  "does not know your current age",
  "predict what you will look like in the future",
  "will never substitute a stock face or fictional aging image",
  "Generated results are not saved to history",
  "not a prediction of your future appearance",
]) {
  if (!source.includes(boundary)) throw new Error(`AI aging AR privacy/safety boundary missing: ${boundary}`);
}

if (!source.includes("disabled={busy || !consent}") || !source.includes("accessibilityRole=\"progressbar\"")) {
  throw new Error("AI aging generation must remain consent-gated and announce busy state accessibly.");
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "AI aging generation is identity-guarded against cancellation, unmount, and changed selected selfie.",
    "Provider failures expose an accessible in-screen retry using the same selected context.",
    "No generated fallback is fabricated, and non-predictive temporary-preview disclosures remain visible.",
  ],
}, null, 2));
