import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const source = readFileSync(join(root, "app/(tabs)/tryon.tsx"), "utf8");

if (!source.includes("const tryOnRunRef = React.useRef(0);")) {
  throw new Error("Native try-on must track an active run identity.");
}
if (!source.includes("const cancelTryOn = () =>") || !source.includes("tryOnRunRef.current += 1;")) {
  throw new Error("Native try-on must invalidate the active run when cancelled or reset.");
}
if (!source.includes("if (!isCurrentRun()) return;")) {
  throw new Error("Native try-on must ignore late provider results and cleanup from cancelled runs.");
}
if (!source.includes("accessibilityLabel=\"Cancel virtual try-on\"")) {
  throw new Error("Native try-on cancellation must be accessible.");
}
if (!source.includes("Try-on cancelled. Your selected photo and garments remain available for review.")) {
  throw new Error("Cancellation must preserve and disclose the selected user photo and garments.");
}
if (!source.includes("accessibilityLiveRegion=\"polite\"")) {
  throw new Error("Cancellation recovery must be announced politely to assistive technologies.");
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "Virtual try-on cancellation invalidates the active run.",
    "Late provider results cannot overwrite cancelled state.",
    "Cancellation is accessible and preserves selected user media context.",
  ],
}, null, 2));
