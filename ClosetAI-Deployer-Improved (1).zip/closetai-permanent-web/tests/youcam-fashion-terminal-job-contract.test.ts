import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

const routes = readFileSync(resolve(process.cwd(), 'server/routes.ts'), 'utf8');
const storage = readFileSync(resolve(process.cwd(), 'server/storage.ts'), 'utf8');

for (const required of [
  'restoreCredits(userId: string, amount: number): Promise<boolean>;',
  'async restoreCredits(userId: string, amount: number): Promise<boolean>',
  'if (!Number.isFinite(amount) || amount <= 0) return false;',
  'set({ credits: credits + amount, updatedAt: new Date() })',
]) {
  if (!storage.includes(required)) throw new Error(`Credit restoration contract missing: ${required}`);
}

for (const required of [
  'const restoreLiveTryOnCredits = async (): Promise<boolean> => {',
  'fallbackReason = "Live YouCam clothing rendering did not return a usable result.";',
  'fallbackReason = "Live YouCam clothing rendering was temporarily unavailable.";',
  'fallbackReason = fallbackReason || "Live clothing edit was temporarily unavailable.";',
  'const creditsRestored = resultProvider === "photo-preview" ? await restoreLiveTryOnCredits() : false;',
  'status: completedStatusForFashionProvider("photo-preview"),',
  'resultImageUrl: userPhotoUrl,',
  'User-photo preview shown instead.',
  'if (job.status === "failed") {',
  'resultImageUrl: job.resultImageUrl || job.selfieUrl,',
]) {
  if (!routes.includes(required)) throw new Error(`Terminal YouCam fashion fallback safeguard missing: ${required}`);
}

for (const prohibited of [
  'fallbackReason = fashionResult.error',
  'fallbackReason = (fashionError as Error).message',
  'fallbackReason || (openAiError as Error).message',
  'status: "failed",\n            errorMessage: "Processing failed"',
]) {
  if (routes.includes(prohibited)) throw new Error(`Raw provider detail or preview-less terminal failure remains: ${prohibited}`);
}

const rawFailure = routes.indexOf('} catch (e) {\n          console.error("Try-on processing error:", e);');
const terminalPreview = routes.indexOf('status: completedStatusForFashionProvider("photo-preview"),', rawFailure);
const terminalPhoto = routes.indexOf('resultImageUrl: userPhotoUrl,', terminalPreview);
const readRepair = routes.indexOf('if (job.status === "failed") {', terminalPhoto);
if ([rawFailure, terminalPreview, terminalPhoto, readRepair].some((index) => index === -1)
  || rawFailure > terminalPreview
  || terminalPreview > terminalPhoto
  || terminalPhoto > readRepair) {
  throw new Error('Every terminal processing failure must persist a completed user-photo preview before the job can be read by mobile clients.');
}

console.log(JSON.stringify({
  result: 'PASS',
  assertions: [
    'Provider, upload, task, and secondary-edit failure details are replaced by stable source-aware public messages.',
    'Terminal server failures persist a completed photo-preview job with the original user photo, never a preview-less failed row.',
    'Live try-on credits are restored whenever the terminal provider is the selected-photo preview.',
    'Legacy failed rows are repaired to the same source-labeled preview contract when mobile clients read them.',
  ],
}, null, 2));
