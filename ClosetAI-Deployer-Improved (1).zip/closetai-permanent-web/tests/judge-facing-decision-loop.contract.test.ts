import fs from 'node:fs';
import path from 'node:path';

const homePath = path.resolve(process.cwd(), 'app/(tabs)/index.tsx');
const homeSource = fs.readFileSync(homePath, 'utf8');

const requiredSourceMarkers = [
  'THE CLOSETAI LOOP',
  'wardrobe-first workflow',
  'Demo / offline',
  'Live / retryable',
  'Your photo only',
  'Fictional demo context stays labeled',
  'Live requests use explicit consent',
  'router.push(step.route as any)',
];

for (const marker of requiredSourceMarkers) {
  if (!homeSource.includes(marker)) {
    throw new Error(`Missing judge-facing decision-loop marker: ${marker}`);
  }
}

if (!homeSource.includes("route: '/(tabs)/tryon'")) {
  throw new Error('Decision loop must link to the user-photo-only try-on screen.');
}

if (!homeSource.includes("route: '/(tabs)/outfits'")) {
  throw new Error('Decision loop must link to outfit planning and retail-aware context.');
}

console.log('Judge-facing decision loop contract passed.');
