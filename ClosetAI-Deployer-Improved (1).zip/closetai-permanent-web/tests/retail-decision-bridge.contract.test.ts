import fs from 'node:fs';
import path from 'node:path';

const outfitsPath = path.resolve(process.cwd(), 'app/(tabs)/outfits.tsx');
const outfitsSource = fs.readFileSync(outfitsPath, 'utf8');

const requiredMarkers = [
  'From wardrobe context to a bounded search',
  'Use what you own',
  'Name a gap',
  'Explore a retailer',
  'official retailer search',
  'No products, prices, discounts, or availability are invented',
  'does not claim that a product will fit, be in stock, or be the right purchase',
];

for (const marker of requiredMarkers) {
  if (!outfitsSource.includes(marker)) {
    throw new Error(`Missing retail decision bridge marker: ${marker}`);
  }
}

if (!outfitsSource.includes('retailRecommendations.length')) {
  throw new Error('Retail decision bridge must report the current search count from live state.');
}

console.log('Retail decision bridge contract passed.');
