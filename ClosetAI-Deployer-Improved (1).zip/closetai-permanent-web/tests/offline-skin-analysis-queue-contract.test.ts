import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const root = process.cwd();
const queue = readFileSync(resolve(root, "lib/skin-analysis-retry-queue.ts"), "utf8");
const screen = readFileSync(resolve(root, "components/skin/SelfieFlowScreen.tsx"), "utf8");
const controller = readFileSync(resolve(root, "lib/skin-analysis-controller.ts"), "utf8");

for (const required of [
  '@closetai_skin_analysis_retry_queue_v1',
  'MAX_QUEUE_AGE_MS',
  'saveSkinAnalysisRetryQueue',
  'loadSkinAnalysisRetryQueue',
  'clearSkinAnalysisRetryQueue',
  'acceptsGuidance: true',
  'reason: "youcam-unavailable"',
]) {
  if (!queue.includes(required)) throw new Error(`The Skin Care local retry queue must retain: ${required}`);
}

for (const required of [
  'const [queuedRetry, setQueuedRetry] = useState<SkinAnalysisRetryQueueEntry | null>(null);',
  'loadSkinAnalysisRetryQueue()',
  'const retryEntry = createSkinAnalysisRetryQueueEntry(activeAssetUri, activeSaveSnapshot);',
  'await saveSkinAnalysisRetryQueue(retryEntry)',
  'Live Skin Care retry saved locally',
  'cloud-offline-outline',
  'Retry saved Skin Care analysis',
  'No fictional Demo Mode result was substituted.',
  'const retryQueuedAnalysis = () =>',
  'const updateGuidanceConsent = (value: boolean) =>',
  'const updateSaveSummary = (value: boolean) =>',
]) {
  if (!screen.includes(required)) throw new Error(`The native Skin Care flow must retain: ${required}`);
}

if (!screen.includes('demo: false, saveSnapshot: activeSaveSnapshot')) {
  throw new Error('The native Skin Care retry path must remain a live analysis request, never an implicit demo request.');
}
if (!screen.includes('setQueuedRetry(null);\n      void clearSkinAnalysisRetryQueue();')) {
  throw new Error('Successful Skin Care live completion must clear local retry metadata.');
}
if (!screen.includes('setQueuedRetry(null);\n    void clearSkinAnalysisRetryQueue();')) {
  throw new Error('Changing consent or cancelling the native Skin Care request must clear stale retry metadata.');
}
if (!queue.includes('Date.now() - queuedAt <= MAX_QUEUE_AGE_MS')) {
  throw new Error('Skin Care retry metadata must expire instead of persisting indefinitely.');
}
if (!controller.includes('source: "demo"') || !controller.includes('source: "youcam"')) {
  throw new Error('Skin Care controller must retain distinct Demo Mode and live YouCam source labels.');
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "Skin Care retry metadata is local, bounded, and limited to the selected selfie and explicit preferences.",
    "Provider-unavailable fallback is visibly labeled as fictional Demo Mode guidance without medical claims.",
    "Accessible Retry and Dismiss actions preserve consent boundaries and clear stale entries on context changes.",
  ],
}, null, 2));
