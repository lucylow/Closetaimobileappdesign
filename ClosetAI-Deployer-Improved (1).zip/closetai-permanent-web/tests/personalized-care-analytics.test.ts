import { buildClosetAnalytics } from "../shared/closet-analytics";

const analytics = buildClosetAnalytics({
  items: [
    { id: "top-1", category: "top", usageCount: 2 },
    { id: "bag-1", category: "bag", usageCount: 0 },
    { id: "watch-1", category: "watch", usageCount: 1, lastWornAt: "2026-08-11T12:00:00.000Z" },
  ],
  outfits: [{ saved: true }, { saved: false }],
  snapshots: [{ source: "youcam" }, { source: "demo" }],
  trackedSearches: 3,
  subscription: { tier: "free", creditsUsed: 4, monthlyCredits: 25 },
});

if (analytics.wardrobe.total !== 3 || analytics.wardrobe.worn !== 2 || analytics.wardrobe.accessories !== 2) {
  throw new Error(`Unexpected wardrobe analytics: ${JSON.stringify(analytics.wardrobe)}`);
}
if (analytics.care.liveSnapshots !== 1 || analytics.care.savedSnapshots !== 2) {
  throw new Error(`Unexpected care analytics: ${JSON.stringify(analytics.care)}`);
}
if (analytics.commerce.trackedSearches !== 3 || analytics.outfits.saved !== 1) {
  throw new Error(`Unexpected commerce/outfit analytics: ${JSON.stringify({ commerce: analytics.commerce, outfits: analytics.outfits })}`);
}
if (analytics.categories.jewelry !== 1 || analytics.categories.bag !== 1) {
  throw new Error(`Expected watch and bag categories to be normalized in analytics. Received: ${JSON.stringify(analytics.categories)}`);
}

console.log(JSON.stringify({
  result: "PASS",
  analytics,
  guarantee: "All metrics are derived from the supplied records; no placeholder dashboard values are used.",
}, null, 2));
