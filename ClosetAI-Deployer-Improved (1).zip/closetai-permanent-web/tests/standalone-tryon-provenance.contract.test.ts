import { readFileSync } from "fs";
import { resolve } from "path";

export function runStandaloneTryOnProvenanceContractTest() {
  const root = resolve(__dirname, "..");
  const resultScreenCode = readFileSync(resolve(root, "app/tryon-result.tsx"), "utf8");
  const tryOnTabCode = readFileSync(resolve(root, "app/(tabs)/tryon.tsx"), "utf8");

  if (!tryOnTabCode.includes("pathname: '/tryon-result'")) {
    throw new Error("TryOn tab missing standalone result route push.");
  }
  if (!tryOnTabCode.includes("provider: tryOnProvider || 'youcam-ai-clothes-v4'")) {
    throw new Error("TryOn tab missing provider parameter handoff.");
  }
  if (!tryOnTabCode.includes("demo: String(demoMode)")) {
    throw new Error("TryOn tab missing demo parameter handoff.");
  }
  if (!resultScreenCode.includes("useLocalSearchParams") || !resultScreenCode.includes("fashionTryOnResultPresentation")) {
    throw new Error("Standalone result route missing search params or presentation helpers.");
  }
  if (!resultScreenCode.includes("Source Lineage & Provenance") || !resultScreenCode.includes("Fictional Demo Mode uses offline presentation")) {
    throw new Error("Standalone result route missing mode-specific provenance disclaimers.");
  }
  if (!resultScreenCode.includes("youcam-ai-clothes-v4")) {
    throw new Error("Standalone result route missing normalization for youcam-ai-clothes-v4 provider.");
  }
  if (!resultScreenCode.includes("/outfits") || !resultScreenCode.includes("retail-gap")) {
    throw new Error("Standalone result route missing consumer-to-retail gap handoff.");
  }
  console.log("Standalone Try-On Provenance Contract Test: PASSED");
}

if (require.main === module) {
  runStandaloneTryOnProvenanceContractTest();
}
