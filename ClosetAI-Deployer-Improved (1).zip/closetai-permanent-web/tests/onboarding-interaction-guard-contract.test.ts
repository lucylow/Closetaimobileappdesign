import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const source = readFileSync(resolve(process.cwd(), "app/onboarding.tsx"), "utf8");

for (const required of [
  "const isMountedRef = useRef(true)",
  "const completionInFlightRef = useRef(false)",
  "if (completionInFlightRef.current) return",
  "completionInFlightRef.current = true",
  "completionInFlightRef.current = false",
  "await Promise.resolve(signInAsGuest())",
  "await Promise.resolve(setHasSeenOnboarding(true))",
  "if (isMountedRef.current) router.replace('/(tabs)')",
  "if (isMountedRef.current) setIsCompleting(false)",
  "We could not finish setup. Please try again.",
]) {
  if (!source.includes(required)) throw new Error(`Onboarding completion safeguard missing: ${required}`);
}

for (const required of [
  "getItemLayout={(_, index) => ({ length: SCREEN_WIDTH, offset: SCREEN_WIDTH * index, index })}",
  "accessibilityRole=\"progressbar\"",
  "accessibilityLabel=\"Onboarding progress\"",
  "Step {currentIndex + 1} of {ONBOARDING_SLIDES.length}",
  "accessibilityRole=\"alert\" accessibilityLiveRegion=\"assertive\"",
  "accessibilityLabel=\"Explore in demo mode\"",
  "accessibilityState={{ disabled: isCompleting, busy: isCompleting }}",
  "Finishing setup…",
]) {
  if (!source.includes(required)) throw new Error(`Onboarding accessibility or progression feature missing: ${required}`);
}

for (const requiredBoundary of [
  "signInAsGuest()",
  "setHasSeenOnboarding(true)",
  "router.replace('/(tabs)')",
  "Starts ClosetAI in clearly labeled demo mode.",
]) {
  if (!source.includes(requiredBoundary)) throw new Error(`Onboarding completion boundary missing: ${requiredBoundary}`);
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "Onboarding completion rejects duplicate skip or finish actions and clears loading state only while mounted.",
    "Guest/demo initialization and onboarding persistence finish before tab navigation.",
    "Progress, completion busy state, errors, and demo-mode entry are exposed through accessible controls and feedback.",
  ],
}, null, 2));
