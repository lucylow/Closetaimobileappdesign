import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

import {
  LUXURY_DISCOVERY_DISCLOSURE,
  LUXURY_DISCOVERY_RECORDS,
} from '../lib/luxury-discovery-catalog';

const root = process.cwd();
const wardrobeSource = readFileSync(resolve(root, 'app/(tabs)/wardrobe.tsx'), 'utf8');
const sourceRegister = readFileSync(resolve(root, 'LUXURY_DISCOVERY_SOURCE_REGISTER.md'), 'utf8');
const expectedHouses = ['Hermès', 'Louis Vuitton', 'Chanel', 'Dior', 'Gucci', 'Fendi'];
const allowedOfficialHosts = ['hermes.com', 'louisvuitton.com', 'chanel.com', 'dior.com', 'gucci.com', 'fendi.com'];

if (LUXURY_DISCOVERY_RECORDS.length < 12) {
  throw new Error('Luxury discovery must provide at least twelve detailed external inspiration records.');
}
if (!LUXURY_DISCOVERY_DISCLOSURE.includes('mock data') || !LUXURY_DISCOVERY_DISCLOSURE.includes('live price, inventory, checkout')) {
  throw new Error('Luxury discovery must prominently disclose its mock and non-commerce boundaries.');
}

for (const house of expectedHouses) {
  if (!LUXURY_DISCOVERY_RECORDS.some((record) => record.house === house)) {
    throw new Error(`Luxury discovery must include ${house}.`);
  }
}

for (const record of LUXURY_DISCOVERY_RECORDS) {
  const parsed = new URL(record.officialUrl);
  if (parsed.protocol !== 'https:' || !allowedOfficialHosts.some((host) => parsed.hostname.endsWith(host))) {
    throw new Error(`${record.id} must link only to an HTTPS official luxury-house destination.`);
  }
  if (!record.externalOnly || record.dataMode !== 'mock-discovery' || !record.disclosure.includes('not affiliated')) {
    throw new Error(`${record.id} must remain an external-only mock discovery entry.`);
  }
  if (!record.genericReferenceImageUrl.includes('files.manuscdn.com') || !record.imageDisclosure.includes('not official brand photography')) {
    throw new Error(`${record.id} must use a separately labeled generic reference image rather than brand product photography.`);
  }
  if (!record.pieceName || !record.styleDirection || record.occasionTags.length === 0 || record.palette.length === 0) {
    throw new Error(`${record.id} must retain detailed, non-transactional styling context.`);
  }
}

if (!sourceRegister.includes('Hermès') || !sourceRegister.includes('Louis Vuitton') || !sourceRegister.includes('Chanel') || !sourceRegister.includes('Gucci')) {
  throw new Error('The luxury discovery source register must document validated official brand destinations.');
}
if (!wardrobeSource.includes('LuxuryDiscoveryPanel') || !wardrobeSource.includes('DEMO MODE · EXTERNAL DISCOVERY') || !wardrobeSource.includes('Linking.openURL') || !wardrobeSource.includes('Prices, inventory, and checkout are not provided by ClosetAI')) {
  throw new Error('The Wardrobe tab must surface the luxury data as clearly labeled external discovery only.');
}
if (!wardrobeSource.includes('demoMode && <LuxuryDiscoveryPanel')) {
  throw new Error('Luxury discovery must remain inside intentional Demo Mode instead of appearing as a real marketplace.');
}

console.log(JSON.stringify({
  result: 'PASS',
  houseCount: expectedHouses.length,
  recordCount: LUXURY_DISCOVERY_RECORDS.length,
  assertions: [
    'Luxury inspiration records cover Hermès, Louis Vuitton, Chanel, Dior, Gucci, and Fendi.',
    'All records link to official HTTPS destinations and use generic labeled reference media rather than brand product photography.',
    'The Wardrobe experience exposes the collection only as disclosed mock external discovery, with no live local price, inventory, or checkout claim.',
  ],
}, null, 2));
