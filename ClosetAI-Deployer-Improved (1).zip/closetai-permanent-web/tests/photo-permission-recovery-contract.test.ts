import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const source = readFileSync(join(root, "components/skin/SelfieFlowScreen.tsx"), "utf8");

if (!source.includes("import { Alert, Linking,")) {
  throw new Error("The selfie flow must use the platform settings bridge for permission recovery.");
}
if (!source.includes("const openPhotoSettings = async () =>") || !source.includes("await Linking.openSettings();")) {
  throw new Error("Denied photo access must offer a direct device-settings recovery path.");
}
if (!source.includes("Photo access is off") || !source.includes("Continue with Demo")) {
  throw new Error("Permission denial must preserve a clearly disclosed Demo Mode fallback.");
}
if (!source.includes("Demo Mode remains available without photo access")) {
  throw new Error("Settings-link failure must still explain that Demo Mode is available without camera access.");
}
if (!source.includes("Open Settings")) {
  throw new Error("Permission denial must expose an actionable Open Settings choice.");
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "Denied photo access offers direct platform-settings recovery.",
    "Demo Mode remains available without camera or library permissions.",
    "Settings-link failure has a user-safe manual recovery message.",
  ],
}, null, 2));
