import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const source = readFileSync(join(root, "app/tryon/shoes.tsx"), "utf8");

if (!source.includes("{canSubmit && <Pressable onPress={() => { void createPreview(); }}")) {
  throw new Error("AI Shoes errors must offer an in-screen retry when the request can be repeated.");
}
if (!source.includes("accessibilityLabel=\"Retry AI Shoes preview\"")) {
  throw new Error("AI Shoes retry must be accessible.");
}
if (!source.includes("Retries the preview with the same selected photos and settings.")) {
  throw new Error("AI Shoes retry must disclose that the existing selected context is preserved.");
}
if (!source.includes("setStatus(null); setResult(null);")) {
  throw new Error("Retrying AI Shoes must clear stale status and result state before a new request.");
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "AI Shoes recoverable errors expose an in-screen retry.",
    "Retry is accessible and preserves selected context.",
    "Retry clears stale status and result state before reprocessing.",
    "The retry callback is wrapped for React Native Pressable event typing.",
  ],
}, null, 2));
