import fs from 'node:fs';
import path from 'node:path';

const file = path.resolve(process.cwd(), 'components/skin/SelfieFlowScreen.tsx');
const source = fs.readFileSync(file, 'utf8');

for (const marker of [
  'this flow stops with retry metadata; Demo Mode remains a separate choice.',
  'Demo Mode remains a separate choice; no diagnosis or treatment claim was added.',
  'this live path stopped without substituting fictional Demo Mode guidance.',
  'Retry uses the same selected selfie and consent choice',
  'Retry saved Skin Care analysis',
]) {
  if (!source.includes(marker)) throw new Error(`Missing Skin live/Demo boundary marker: ${marker}`);
}

if (source.includes('falling back safely to a demo result')) {
  throw new Error('The live Skin path must not imply automatic Demo Mode substitution.');
}

console.log('Skin live-versus-Demo boundary contract passed.');
