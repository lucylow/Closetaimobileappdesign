import { readFileSync } from "node:fs";
import { AGING_SIMULATION_DISCLOSURE, normalizeProviderAgingSimulation } from "../shared/aging-simulation";

const normalized = normalizeProviderAgingSimulation({
  output: [
    { url: "https://example.com/older.jpg", res_age: 70 },
    { url: "https://example.com/younger.jpg", res_age: 12 },
  ],
  age: 31,
});
if (!normalized || normalized.previews.length !== 2 || normalized.previews[0]?.displayAge !== 12 || normalized.previews[1]?.displayAge !== 70) {
  throw new Error("Documented provider aging output must normalize and sort temporary visual stages.");
}
const { analyzedAt: _analyzedAt, ...normalizedWithoutTimestamp } = normalized;
if (JSON.stringify(normalizedWithoutTimestamp).includes("31") || Object.prototype.hasOwnProperty.call(normalized, "age")) {
  throw new Error("Provider inferred current age must not enter the application model.");
}
if (normalizeProviderAgingSimulation({ output: [{ url: "http://unsafe.example.com/x.jpg", res_age: 70 }] }) !== null) {
  throw new Error("Aging previews require secure provider URLs and documented age stages.");
}
if (!AGING_SIMULATION_DISCLOSURE.includes("does not predict") || !AGING_SIMULATION_DISCLOSURE.includes("estimate your current age") || !AGING_SIMULATION_DISCLOSURE.includes("not saved to history")) {
  throw new Error("The aging disclosure must preserve non-predictive, age-estimate, and persistence boundaries.");
}

const taskClient = readFileSync("server/youcam-aging.ts", "utf8");
const routeSource = readFileSync("server/routes.ts", "utf8");
const screenSource = readFileSync("app/skin/aging.tsx", "utf8");
const hubSource = readFileSync("components/skin/SkinCareHub.tsx", "utf8");
if (!taskClient.includes('"/s2s/v2.0/task/aging"') || !taskClient.includes("src_file_id") || !taskClient.includes("/s2s/v2.0/task/aging/${encodeURIComponent(taskId)}")) throw new Error("Aging client must use documented create and status endpoints with a file ID.");
if (!routeSource.includes('app.post("/api/skin/aging"') || !routeSource.includes("consent !== true")) throw new Error("Server route must require explicit consent.");
if (!screenSource.includes("non-predictive creative visualization") || !screenSource.includes("No image was shown") || !screenSource.includes("Generated results are not saved to history")) throw new Error("Mobile screen must require clear consent and have no fabricated fallback or persistent generated history.");
if (!hubSource.includes('router.push("/skin/aging")')) throw new Error("Aging screen must be reachable from the Skin Care hub.");

console.log(JSON.stringify({ result: "PASS", normalized, assertions: [
  "Only documented secure temporary preview URLs and target stages are retained.",
  "Provider inferred age is omitted from app state and UI.",
  "Explicit non-predictive consent is mandatory before the server request.",
  "No generated fallback preview is substituted and history remains clean.",
] }, null, 2));
