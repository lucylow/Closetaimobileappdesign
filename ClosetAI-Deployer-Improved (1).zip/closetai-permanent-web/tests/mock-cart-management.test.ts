import { activeSkinCommerceProvider } from "../lib/skin-commerce-provider";
import { addMockCartItem, emptyMockCart, MOCK_COMMERCE_DISCLOSURE, mockCartItemCount, mockCartSubtotal, removeMockCartItem, setMockCartItemQuantity } from "../lib/mock-commerce-cart";

async function run() {
  const cleanser = await activeSkinCommerceProvider.getListing("cerave-hydrating-facial-cleanser");
  const lowStockMoisturizer = await activeSkinCommerceProvider.getListing("lrp-toleriane-double-repair");
  const unavailableCream = await activeSkinCommerceProvider.getListing("cerave-skin-renewing-night-cream");
  if (!cleanser || !lowStockMoisturizer || !unavailableCream) throw new Error("Expected all mock inventory test listings.");

  let cart = emptyMockCart();
  let result = addMockCartItem(cart, cleanser);
  if (result.operation !== "added" || result.cart.lines[0]?.quantity !== 1) throw new Error("First add should create one local cart line.");
  cart = result.cart;

  result = addMockCartItem(cart, cleanser);
  if (result.operation !== "added" || result.cart.lines[0]?.quantity !== 2 || mockCartItemCount(result.cart) !== 2) throw new Error("Repeat adds should increase the saved local quantity.");
  cart = result.cart;

  result = setMockCartItemQuantity(cart, cleanser, 3);
  if (result.operation !== "quantity_updated" || result.cart.lines[0]?.quantity !== 3 || mockCartSubtotal(result.cart) !== 47.97) throw new Error("Quantity control should update the local subtotal deterministically.");
  cart = result.cart;

  result = setMockCartItemQuantity(cart, cleanser, 99);
  if (result.operation !== "stock_limit" || result.cart.lines[0]?.quantity !== cleanser.availableQuantity) throw new Error("Quantity must be capped by the current mock inventory limit.");

  result = addMockCartItem(emptyMockCart(), lowStockMoisturizer);
  const lowStockCart = result.cart;
  result = setMockCartItemQuantity(lowStockCart, lowStockMoisturizer, lowStockMoisturizer.availableQuantity + 1);
  if (result.operation !== "stock_limit" || result.cart.lines[0]?.quantity !== lowStockMoisturizer.availableQuantity) throw new Error("Low mock stock must cap quantity and remain visible to the user.");

  result = addMockCartItem(emptyMockCart(), unavailableCream);
  if (result.operation !== "unavailable" || result.cart.lines.length !== 0) throw new Error("Out-of-stock mock items must not be added to a local cart.");

  result = setMockCartItemQuantity(cart, cleanser, 0);
  if (result.operation !== "removed" || result.cart.lines.length !== 0) throw new Error("Setting quantity to zero must remove the saved cart line.");

  const offlineRemovalCart = addMockCartItem(emptyMockCart(), cleanser).cart;
  result = removeMockCartItem(offlineRemovalCart, cleanser.productId);
  if (result.operation !== "removed" || result.cart.lines.length !== 0) throw new Error("A persisted line must remain removable without a fresh catalog listing.");
  if (!result.cart.disclosure.includes(MOCK_COMMERCE_DISCLOSURE)) throw new Error("The required mock commerce disclosure must persist after every cart mutation.");

  console.log(JSON.stringify({
    result: "PASS",
    tested: ["add", "repeat add", "quantity update", "stock cap", "low stock", "out of stock", "remove", "offline removal", "disclosure"],
    guarantee: "The persistent cart is local prototype state only; no real inventory, checkout, or transaction is created.",
  }, null, 2));
}

run().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
