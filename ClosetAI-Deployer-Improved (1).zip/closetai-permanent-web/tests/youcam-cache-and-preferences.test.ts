import { BoundedTtlCache } from "../server/youcam-cache";
import { normalizeRecommendationPreferences } from "../shared/recommendation-preferences";
import { buildWardrobeRecommendations } from "../shared/outfit-recommendations";

async function run() {
  const cache = new BoundedTtlCache<string>(2);
  if (cache.get("missing").status !== "miss") throw new Error("Expected cache miss.");
  cache.set("one", "first", 1_000);
  if (cache.get("one").value !== "first") throw new Error("Expected cache hit for a fresh result.");
  cache.set("two", "second", 1_000);
  cache.set("three", "third", 1_000);
  if (cache.size() !== 2 || cache.get("one").status !== "miss") throw new Error("Expected bounded cache eviction.");
  cache.set("expired", "old", 1);
  await new Promise((resolve) => setTimeout(resolve, 5));
  if (cache.get("expired").status !== "stale") throw new Error("Expected expired cache entry to be discarded.");

  const preferences = normalizeRecommendationPreferences({
    occasion: "  Office   Meeting ",
    weather: " rainy 48F ",
    colorPalette: ["Navy", "navy", "Camel", 7, "", "Cream", "Gold", "Black", "White", "Red"],
  });
  if (preferences.occasion !== "Office Meeting" || preferences.weather !== "rainy 48F") {
    throw new Error("Expected normalized occasion and weather preferences.");
  }
  if (preferences.colorPalette?.join("|") !== "Navy|Camel|Cream|Gold|Black|White") {
    throw new Error(`Unexpected normalized palette: ${preferences.colorPalette?.join(", ")}`);
  }

  const recommendations = buildWardrobeRecommendations([
    { id: "top-navy", name: "Navy Shirt", category: "top", color: "Navy", tags: [], usageCount: 5 },
    { id: "top-cream", name: "Cream Shirt", category: "top", color: "Cream", tags: [], usageCount: 0 },
    { id: "bottom-black", name: "Black Trouser", category: "bottom", color: "Black", tags: [], usageCount: 0 },
  ], preferences.occasion, preferences.weather, ["Navy"]);
  if (!recommendations[0]?.itemIds.includes("top-navy")) {
    throw new Error("Expected the selected palette to prioritize a matching user wardrobe item.");
  }

  console.log(JSON.stringify({
    result: "PASS",
    cache: "bounded, hit/miss/stale behavior verified",
    preferences,
    paletteFirstRecommendation: recommendations[0]?.itemIds,
  }, null, 2));
}

run();
