import { normalizeSkinSnapshot } from "../shared/skin";
import { buildSkinScanDataQuality } from "../shared/skin-scan-data-quality";

const normalized = normalizeSkinSnapshot({
  result: {
    skin_type: "Combination",
    concerns: [
      { key: "hydration", score: 76 },
      { key: "moisture", score: 74 },
      { key: "pore", score: 64 },
      { key: "age_spot", score: 58 },
      { key: "fine_lines", score: null },
      { key: "radiance", score: 82 },
    ],
  },
}, "normalization-quality-test");

const keys = normalized.concerns.map((concern) => concern.key);
if (keys.filter((key) => key === "moisture").length !== 1) throw new Error("Hydration/moisture aliases must normalize to one canonical signal.");
if (!keys.includes("pores") || !keys.includes("spots") || !keys.includes("wrinkles")) throw new Error("Known provider aliases must normalize to canonical app keys.");
if (normalized.concerns.find((concern) => concern.key === "wrinkles")?.score !== null) throw new Error("Missing provider data must remain unavailable rather than becoming a score of zero.");
if (!normalized.dataQuality || normalized.dataQuality.availableSignals !== 4 || normalized.dataQuality.expectedSignals !== 9) throw new Error("Data quality must count only available canonical core signals.");
if (!normalized.dataQuality.missingSignalKeys.includes("wrinkles")) throw new Error("Data quality must identify unavailable core signals.");

const quality = buildSkinScanDataQuality({ availableKeys: ["moisture", "oiliness", "texture", "pores", "redness", "acne", "radiance", "spots", "wrinkles"] });
if (quality.coveragePercent !== 100 || quality.missingSignalKeys.length !== 0) throw new Error("Complete canonical coverage must be represented accurately.");

console.log(JSON.stringify({
  result: "PASS",
  normalizedKeys: keys,
  coverage: normalized.dataQuality,
  assertions: [
    "Provider aliases normalize to stable application keys.",
    "Duplicate visual signals are suppressed.",
    "Missing scores remain unavailable rather than being fabricated.",
    "Coverage is completeness metadata, not medical confidence.",
  ],
}, null, 2));
