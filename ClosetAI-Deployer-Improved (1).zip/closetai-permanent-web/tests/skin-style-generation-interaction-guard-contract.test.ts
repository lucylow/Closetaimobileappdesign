import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const source = readFileSync(resolve(process.cwd(), "components/skin/SkinJourneyPage.tsx"), "utf8");

for (const required of [
  "const isMountedRef = React.useRef(true)",
  "const buildLookInFlightRef = React.useRef(false)",
  "if (buildLookInFlightRef.current) return",
  "buildLookInFlightRef.current = true",
  "buildLookInFlightRef.current = false",
  "if (isMountedRef.current) router.push(\"/(tabs)/outfits\")",
  "if (isMountedRef.current) setIsBuildingLook(false)",
  "if (isMountedRef.current) setStyleBuildError",
]) {
  if (!source.includes(required)) throw new Error(`Skin × Style lifecycle safeguard missing: ${required}`);
}

for (const required of [
  "disabled={isBuildingLook}",
  "accessibilityState={{ checked: styleOccasion === occasion, disabled: isBuildingLook }}",
  "accessibilityState={{ disabled: isBuildingLook, busy: isBuildingLook }}",
  "Occasion choices are unavailable while ClosetAI builds from your wardrobe.",
  "accessibilityRole=\"alert\" accessibilityLiveRegion=\"assertive\"",
  "Building live outfits from your wardrobe",
]) {
  if (!source.includes(required)) throw new Error(`Skin × Style accessible busy or recovery feedback missing: ${required}`);
}

for (const boundary of [
  "Add at least two items to ClosetAI",
  "No stock or fictional outfit is shown.",
  "Builds outfits from your own wardrobe. No stock or fictional outfit is shown.",
  "await generateOutfits(styleOccasion)",
]) {
  if (!source.includes(boundary)) throw new Error(`Skin × Style wardrobe-only boundary missing: ${boundary}`);
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "Skin × Style ignores duplicate outfit-generation actions and clears state only while the screen is mounted.",
    "Occasion and navigation controls expose disabled and busy states while a wardrobe-only generation request is active.",
    "Generation failures receive assertive, recoverable feedback without substituting stock or fictional outfits.",
  ],
}, null, 2));
