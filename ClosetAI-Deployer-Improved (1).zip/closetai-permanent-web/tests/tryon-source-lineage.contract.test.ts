import fs from 'node:fs';
import path from 'node:path';

const file = path.resolve(process.cwd(), 'app/(tabs)/tryon.tsx');
const source = fs.readFileSync(file, 'utf8');

for (const marker of [
  'Source lineage',
  "accessibilityRole=\"summary\"",
  'Perfect Corp. YouCam AI Clothes',
  'Photo-safe assisted path',
  'Fictional Demo Mode',
  'Your selected photo + {selectedItems.length} wardrobe garment',
  'Temporary visualization; no fit, size, or purchase guarantee',
]) {
  if (!source.includes(marker)) throw new Error(`Missing try-on lineage marker: ${marker}`);
}

if (!source.includes("tryOnProvider === 'youcam-ai-clothes-v4' ? 'LIVE'")) {
  throw new Error('Live YouCam results must be visibly distinguished from demo and assisted paths.');
}

if (!source.includes("kind={demoMode ? 'local-only' : 'temporary-result'}")) {
  throw new Error('Result status must preserve the local-only versus temporary-result distinction.');
}

console.log('Try-on source-lineage contract passed.');
