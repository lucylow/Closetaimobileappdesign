import { derivePersonalStyleProfile } from "../shared/personal-style-profile";
import { normalizeFashionTryOnCategory } from "../shared/fashion-tryon-categories";
import { buildRetailRecommendations } from "../shared/retail-recommendations";

const wardrobe = [
  { id: "top-blue", name: "Blue Oxford", category: "top", color: "Navy", tags: ["Classic", "Office"] },
  { id: "bottom-gray", name: "Gray Trouser", category: "bottom", color: "Gray", tags: ["Tailored", "Office"] },
  { id: "shoe-black", name: "Black Loafer", category: "shoes", color: "Black", tags: ["Classic"] },
];

const profile = derivePersonalStyleProfile(wardrobe, { colors: ["Camel"], styles: ["Classic"], fitPrefs: ["Tailored"] });
if (profile.colors[0] !== "Camel" || profile.styles[0] !== "Classic" || profile.fitPrefs[0] !== "Tailored") {
  throw new Error("Expected persisted personal profile values to take precedence over inferred wardrobe values.");
}
if (normalizeFashionTryOnCategory("Watch") !== "jewelry") {
  throw new Error("Expected watches to map to the real jewelry/watches/scarves accessory category.");
}

const commerce = buildRetailRecommendations(wardrobe, { occasion: "Business", colorPalette: [] }, profile);
const watch = commerce.find((item) => item.id === "watch-gap");
if (!watch || !watch.searchQuery.toLowerCase().includes("camel business watch")) {
  throw new Error(`Expected profile color to guide a watch-gap commerce search. Received: ${commerce.map((item) => item.searchQuery).join(" | ")}`);
}
if (!commerce.every((item) => item.source === "retailer-search" && item.searchUrl.startsWith("https://www.google.com/search?tbm=shop"))) {
  throw new Error("Commerce results must remain transparent retailer searches.");
}

console.log(JSON.stringify({
  result: "PASS",
  profile,
  commerceQueries: commerce.map((item) => item.searchQuery),
  guarantee: "No fictional product listings, prices, inventory, or retailer availability were returned.",
}, null, 2));
