import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const root = process.cwd();
const replit = readFileSync(resolve(root, ".replit"), "utf8");
const packageJson = readFileSync(resolve(root, "package.json"), "utf8");
const preflight = readFileSync(resolve(root, "scripts/replit-expo-preflight.mjs"), "utf8");
const apiClient = readFileSync(resolve(root, "lib/query-client.ts"), "utf8");
const appConfig = readFileSync(resolve(root, "app.json"), "utf8");

const requiredRunPath = [
  'run = "npm run replit:expo"',
  '"replit:expo": "node scripts/replit-expo-preflight.mjs && concurrently',
  "EXPO_PACKAGER_PROXY_URL=https://$REPLIT_DEV_DOMAIN",
  "REACT_NATIVE_PACKAGER_HOSTNAME=$REPLIT_DEV_DOMAIN",
  "EXPO_PUBLIC_DOMAIN=$REPLIT_DEV_DOMAIN",
];
for (const required of requiredRunPath) {
  if (!(replit + packageJson).includes(required)) {
    throw new Error(`Replit Expo launch path must retain: ${required}`);
  }
}

for (const required of ["REPLIT_DEV_DOMAIN", "DATABASE_URL", "Tools → Secrets", "never EXPO_PUBLIC_*"]) {
  if (!preflight.includes(required)) {
    throw new Error(`Replit preflight must provide a clear, secret-safe check for: ${required}`);
  }
}

for (const required of ["process.env.EXPO_PUBLIC_DOMAIN", "https://${host}"]) {
  if (!apiClient.includes(required)) {
    throw new Error(`Expo Go client must resolve its Replit API URL with: ${required}`);
  }
}

for (const required of ["expo-router", "expo-camera", "cameraPermission"]) {
  if (!appConfig.includes(required)) {
    throw new Error(`Expo configuration must retain the physical-device integration: ${required}`);
  }
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "The Replit Run button starts the combined Expo Go tunnel and server path.",
    "A preflight explains missing runtime requirements without exposing secret values.",
    "Expo Go receives the active Replit HTTPS API domain at bundle time.",
    "Expo Router and camera configuration remain registered for physical-device testing.",
  ],
}, null, 2));
