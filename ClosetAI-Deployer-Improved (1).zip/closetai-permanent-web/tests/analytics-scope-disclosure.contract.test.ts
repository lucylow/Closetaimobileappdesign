import fs from 'node:fs';
import path from 'node:path';

const file = path.resolve(process.cwd(), 'app/business-dashboard.tsx');
const source = fs.readFileSync(file, 'utf8');

for (const marker of [
  'Planning scope',
  'Included: wardrobe counts, outfit activity, normalized care summaries, and bounded commerce-search counts.',
  'Excluded: raw selfies, identity profiles, purchase outcomes, and fabricated campaign performance.',
  'accessibilityRole="summary"',
  'analyticsScopeCard',
]) {
  if (!source.includes(marker)) throw new Error(`Missing analytics scope disclosure marker: ${marker}`);
}

console.log('Analytics scope disclosure contract passed.');
