import { buildSkinIntelligenceDashboard } from "../lib/skin-intelligence-dashboard";
import type { SkinAnalysisResult } from "../lib/skin-analysis-controller";
import { toPersistedSkinAnalysisSummary } from "../lib/skin-analysis-persistence";
import { readPersistedSkinResults } from "../lib/skin-scan-persistence";

const scan: SkinAnalysisResult = {
  id: "live-scan-privacy-test",
  createdAt: "2026-08-12T00:00:00.000Z",
  source: "youcam",
  overallScore: 71,
  skinType: "Combination",
  imageUri: "file:///private-user-selfie.jpg",
  processingTimeMs: 840,
  fallbackReason: "Should not persist.",
  visualSignalCoverage: { available: 2, total: 2, percent: 100 },
  visualSignalSummary: "Live YouCam visual analysis returned 2 normalized visual signals.",
  disclaimer: "General wellness and style guidance, not medical advice.",
  metrics: [
    { key: "hydration", label: "Hydration", score: 68, status: "Good", available: true, source: "youcam" },
    { key: "pores", label: "Pores", score: 42, status: "Good", available: true, source: "youcam" },
  ],
  routine: [{ id: "am-cleanse", period: "AM", order: 1, title: "Gentle cleanser", guidance: "Start comfortably." }],
};

const summary = toPersistedSkinAnalysisSummary(scan);
if ("imageUri" in summary || "processingTimeMs" in summary || "fallbackReason" in summary) {
  throw new Error("Persisted skin summary must exclude image references and transient provider metadata.");
}
if (summary.metrics !== scan.metrics || summary.routine !== scan.routine) {
  throw new Error("Persisted summary must retain normalized dashboard signals and routine data.");
}

const restored = readPersistedSkinResults(JSON.stringify([scan, { id: 123 }, "invalid"]));
if (restored.length !== 1 || "imageUri" in restored[0] || "fallbackReason" in restored[0]) {
  throw new Error("Legacy local history must be sanitized and malformed entries ignored.");
}
if (readPersistedSkinResults("{not-json").length !== 0) {
  throw new Error("Malformed persisted history must fail closed to an empty history.");
}

const dashboard = buildSkinIntelligenceDashboard(scan);
if (!dashboard.sourceDetail.includes("normalized visual signals") || dashboard.sourceDetail.includes("private-user-selfie")) {
  throw new Error("Dashboard source summary must use normalized signals without exposing the image URI.");
}
if (dashboard.sourceDetail.toLowerCase().includes("diagnos")) {
  throw new Error("Dashboard summary must not make a medical diagnosis claim.");
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "Persisted summaries exclude image URI, timing, and fallback reason.",
    "Malformed local history fails closed.",
    "Legacy entries are migrated through the privacy sanitizer.",
    "Dashboard exposes normalized source-aware detail without raw image data or diagnosis claims.",
  ],
}, null, 2));
