import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const source = readFileSync(join(root, "components/skin/SkinScreen.tsx"), "utf8");

if (!source.includes("Photo access is off. Open settings")) {
  throw new Error("The Skin Care header must expose an accessible blocked-permission label.");
}
if (!source.includes("Photo access is available") || !source.includes("Checking photo access")) {
  throw new Error("The header indicator must distinguish available and pending permission states.");
}
if (!source.includes("photoPermissionState === 'blocked' ? 'lock-closed-outline'") || !source.includes("'lock-open-outline'")) {
  throw new Error("The header indicator must use distinct blocked and available icons.");
}
if (!source.includes("void openPhotoSettings();")) {
  throw new Error("Pressing the blocked header indicator must open device settings.");
}
if (!source.includes("Fictional Demo Mode remains available")) {
  throw new Error("Pending permission messaging must preserve the fictional Demo Mode disclosure.");
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "Header indicator exposes blocked, available, and pending status labels.",
    "Blocked state opens device settings.",
    "Status icons communicate permission state accessibly.",
    "Demo Mode remains disclosed in pending status messaging.",
  ],
}, null, 2));
