import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const onboarding = readFileSync(resolve(process.cwd(), "app/onboarding.tsx"), "utf8");
const home = readFileSync(resolve(process.cwd(), "app/(tabs)/index.tsx"), "utf8");

for (const required of [
  "const APP_VALUE_PROMISE = 'Organize the pieces you own, turn them into a clearer outfit choice, and preview only with a photo you choose.'",
  "ONE CLOSET. LESS GUESSWORK.",
  "Demo context is labeled. No stock model is substituted for you.",
  "What ClosetAI helps you do:",
  "index === 0",
]) {
  if (!onboarding.includes(required)) throw new Error(`Onboarding value proposition missing: ${required}`);
}

for (const required of [
  "YOUR CLOSET, CLEARER",
  "Organize what you own. Choose a look with less guesswork.",
  "Start with one item, plan around your day, and preview only with a photo you choose.",
  "Demo context is labeled. No stock model is substituted for you.",
  "Start with one great piece.",
  "Add your first item",
  "accessibilityLabel=\"ClosetAI value proposition.",
]) {
  if (!home.includes(required)) throw new Error(`Home value proposition missing: ${required}`);
}

for (const forbidden of ["Guaranteed", "Perfect outfit", "Stock model preview", "Real-time purchase"]) {
  if (onboarding.includes(forbidden) || home.includes(forbidden)) {
    throw new Error(`Value proposition must not make unsupported claims: ${forbidden}`);
  }
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "First-use messaging names the core value: organize owned pieces, choose a look, and optionally preview on a user-chosen photo.",
    "Home offers a concrete first action for an empty wardrobe and preserves the labeled demo and no-stock-model boundaries.",
    "Value proposition content is available to assistive technology and avoids unsupported guarantees or commerce claims.",
  ],
}, null, 2));
