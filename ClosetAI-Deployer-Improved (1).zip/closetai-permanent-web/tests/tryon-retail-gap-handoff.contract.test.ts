import fs from 'node:fs';
import path from 'node:path';

const tryOnFile = path.resolve(process.cwd(), 'app/(tabs)/tryon.tsx');
const outfitsFile = path.resolve(process.cwd(), 'app/(tabs)/outfits.tsx');
const tryOnSource = fs.readFileSync(tryOnFile, 'utf8');
const outfitsSource = fs.readFileSync(outfitsFile, 'utf8');

for (const marker of [
  "params: { intent: 'retail-gap' }",
  'Review a bounded retail gap',
  'without fabricated products or purchase claims',
]) {
  if (!tryOnSource.includes(marker)) throw new Error(`Missing try-on handoff marker: ${marker}`);
}

for (const marker of [
  'useLocalSearchParams',
  "intent === 'retail-gap'",
  'Try-on handoff ready',
  'Choose Find gaps only if you want to explore a category',
  'no product or purchase claim is implied',
  'accessibilityRole="summary"',
]) {
  if (!outfitsSource.includes(marker)) throw new Error(`Missing Outfit Planning intent marker: ${marker}`);
}

console.log('Try-on to retail-gap handoff contract passed.');
