import { skinDemoProfiles } from "../lib/skin-demo-profiles";
import { getDemoPaletteIdeas, getDemoPriorities, getDemoProducts, getDemoProgressHistory, getDemoWardrobeRecommendations } from "../lib/skin-demo-content";

const requiredMetrics = ["hydration", "oiliness", "texture", "pores", "redness", "blemishes", "radiance", "dark-spots", "fine-lines"];
const expectedDemoNames = ["Maya", "Sofia", "Aisha", "Leila", "Nora"];
if (skinDemoProfiles.length < expectedDemoNames.length || expectedDemoNames.some((name) => !skinDemoProfiles.some((profile) => profile.displayName === name))) {
  throw new Error("Skin Demo Mode must provide the five named fictional profile examples.");
}
for (const profile of skinDemoProfiles) {
  if (typeof profile.overallScore !== "number" || !profile.skinType) throw new Error(`Missing preloaded score or skin type for ${profile.id}.`);
  if (!profile.displayName || !profile.profileDisclosure?.includes("Fictional adult demo profile")) throw new Error(`Missing fictional-profile disclosure for ${profile.id}.`);
  const metricIds = profile.metrics.map((metric) => metric.id);
  for (const metric of requiredMetrics) {
    if (!metricIds.includes(metric)) throw new Error(`Missing ${metric} demo metric for ${profile.id}.`);
  }
  if (profile.morningRoutine.length < 3 || profile.eveningRoutine.length < 3) throw new Error(`Missing AM/PM routine depth for ${profile.id}.`);
  if (getDemoProducts(profile.id).length < 3) throw new Error(`Missing demo products for ${profile.id}.`);
  if (getDemoWardrobeRecommendations(profile.id).length < 2) throw new Error(`Missing Skin × Wardrobe recommendations for ${profile.id}.`);
  if (getDemoProgressHistory(profile.id).length < 3) throw new Error(`Missing demo progress/history for ${profile.id}.`);
  if (getDemoPriorities(profile.id).length < 3 || getDemoPaletteIdeas(profile.id).length < 2) throw new Error(`Missing demo guidance coverage for ${profile.id}.`);
}

console.log(JSON.stringify({
  result: "PASS",
  profileCount: skinDemoProfiles.length,
  requiredMetrics,
  coverage: ["preloaded profile", "score", "skin type", "all skin metrics", "AM routine", "PM routine", "fictional products", "Skin × Wardrobe", "progress/history", "demo controls", "optional selfie flow"],
  guarantee: "All asserted skin data is fictional and is intended only for clearly labeled Demo Mode.",
}, null, 2));
