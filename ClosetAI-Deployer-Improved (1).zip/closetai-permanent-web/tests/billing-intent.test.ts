/**
 * Unit test for ClosetAI billing intent and credit accounting ledger
 */

import { createBillingIntent, approveAndFulfillBillingIntent } from "../lib/billing-intent";

async function runTest() {
  console.log("Running Billing Intent & Credit Ledger Test...");
  
  const intent = await createBillingIntent("credit_pack", "pack_creator", "Pro Creator Pack", 14.99);
  if (!intent || intent.intentId.indexOf("intent_") !== 0) {
    throw new Error("Failed to create billing intent");
  }

  const result = await approveAndFulfillBillingIntent(intent, 25);
  if (result.newCredits !== 525 || result.tierId !== "free") {
    throw new Error("Credit pack fulfillment calculation incorrect");
  }

  const subIntent = await createBillingIntent("subscription", "pro_shopper", "Pro Shopper", 19.99);
  const subResult = await approveAndFulfillBillingIntent(subIntent, 525);
  if (subResult.tierId !== "pro_shopper" || subResult.newCredits !== 1500) {
    throw new Error("Subscription fulfillment tier or credit grant incorrect");
  }

  // Test idempotency (repeat fulfillment should not double credits or fail)
  const repeatResult = await approveAndFulfillBillingIntent(subIntent, subResult.newCredits);
  if (repeatResult.newCredits !== 1500) {
    throw new Error("Idempotency check failed for repeat billing intent");
  }

  console.log("Billing Intent & Credit Ledger Test: PASSED");
}

runTest().catch((err) => {
  console.error("Test FAILED:", err);
  process.exit(1);
});
