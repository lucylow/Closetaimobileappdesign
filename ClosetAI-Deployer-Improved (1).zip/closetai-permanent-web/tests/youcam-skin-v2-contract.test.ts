import { readFileSync } from "node:fs";
import { buildSkinAnalysisPlan, isValidSkinAnalysisPlan, resolveSkinAnalysisPlan } from "../shared/skin-analysis-plan";
import { normalizeSkinSnapshot } from "../shared/skin";

const sd = buildSkinAnalysisPlan("sd");
const hd = buildSkinAnalysisPlan("hd");
if (!isValidSkinAnalysisPlan(sd) || !isValidSkinAnalysisPlan(hd)) throw new Error("Default SD and HD action plans must validate.");
if (sd.actions.some((action) => action.startsWith("hd_")) || hd.actions.some((action) => !action.startsWith("hd_"))) throw new Error("SD and HD action groups must remain mutually exclusive.");
if (resolveSkinAnalysisPlan({ tier: "sd", actions: ["hd_texture"], outputFormat: "json" }).tier !== "sd" || resolveSkinAnalysisPlan({ tier: "sd", actions: ["hd_texture"], outputFormat: "json" }).actions.some((action) => action.startsWith("hd_"))) {
  throw new Error("An invalid mixed-tier plan must fall back to the safe default SD plan.");
}

const snapshot = normalizeSkinSnapshot({
  data: {
    task_status: "success",
    results: {
      output: [
        { type: "hd_moisture", ui_score: 74, raw_score: 58.2, mask_urls: ["https://private-provider.example/mask.png"] },
        { type: "pore", ui_score: 68, raw_score: 51.1 },
        { type: "hd_texture", whole: { ui_score: 79, raw_score: 63.4 } },
      ],
    },
  },
}, "v2-normalization-test");

const moisture = snapshot.concerns.find((concern) => concern.key === "moisture");
const pores = snapshot.concerns.find((concern) => concern.key === "pores");
const texture = snapshot.concerns.find((concern) => concern.key === "texture");
if (moisture?.score !== 74 || pores?.score !== 68 || texture?.score !== 79) throw new Error("V2 output ui_score and nested whole-face score must normalize correctly.");
if (JSON.stringify(snapshot).includes("private-provider.example")) throw new Error("Provider mask URLs must not enter normalized snapshot data.");
if (snapshot.dataQuality?.availableSignals !== 3) throw new Error("V2 normalized coverage must count only available canonical signals.");

const routeSource = readFileSync("server/routes.ts", "utf8");
if (!routeSource.includes("isYouCamSkinV2Configured") || !routeSource.includes("resolveSkinAnalysisPlan")) throw new Error("The scan route must support the version-safe v2 action-plan path.");

console.log(JSON.stringify({
  result: "PASS",
  sdActionCount: sd.actions.length,
  hdActionCount: hd.actions.length,
  normalizedSignals: snapshot.concerns.map((concern) => ({ key: concern.key, score: concern.score })),
  assertions: [
    "SD and HD provider actions cannot be mixed.",
    "Invalid client-supplied plans fail closed to the safe default.",
    "YouCam v2 ui_score and nested output entries normalize to application signals.",
    "Mask URLs and raw provider data do not enter the mobile snapshot.",
  ],
}, null, 2));
