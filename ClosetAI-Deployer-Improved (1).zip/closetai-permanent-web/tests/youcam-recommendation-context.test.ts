import { buildYouCamRecommendationContext } from "../shared/youcam-recommendation-context";

const liveSnapshot = {
  id: "live-youcam-snapshot",
  source: "youcam",
  createdAt: "2026-08-12T00:00:00.000Z",
  consentVersion: "skin-v1",
  styleInsights: [
    { title: "Color direction", detail: "Use cream, camel, and navy for balanced styling.", colorFamilies: ["Cream", "Camel", "Navy"] },
    { title: "Finishing touch", detail: "Use one intentional accessory.", colorFamilies: ["Gold"] },
  ],
};

const context = buildYouCamRecommendationContext(liveSnapshot);
if (!context) throw new Error("Expected a recommendation context from a saved live YouCam snapshot.");
if (context.colorFamilies.join("|") !== "Cream|Camel|Navy|Gold") {
  throw new Error(`Unexpected YouCam color context: ${context.colorFamilies.join(", ")}`);
}
if (!context.styleNotes.some((note) => note.includes("Color direction"))) {
  throw new Error("Expected saved style notes in the recommendation context.");
}
if (buildYouCamRecommendationContext({ ...liveSnapshot, source: "demo" }) !== null) {
  throw new Error("Demo snapshots must never be presented as a real YouCam recommendation context.");
}

console.log(JSON.stringify({
  result: "PASS",
  source: context.source,
  colorFamilies: context.colorFamilies,
  privacyGuarantee: "Only saved style text and color families are surfaced; no selfie, mask, score, or diagnosis is included.",
}, null, 2));
