import { getSkinAnalysisFallbackReason, getSkinScoreStatus } from "../lib/skin-analysis-status";

if (getSkinScoreStatus(undefined) !== "Unavailable") {
  throw new Error("Missing skin scores must be presented as unavailable rather than available.");
}
if (getSkinScoreStatus(Number.NaN) !== "Unavailable" || getSkinScoreStatus(Number.POSITIVE_INFINITY) !== "Unavailable") {
  throw new Error("Non-finite skin scores must fail closed as unavailable.");
}
if (getSkinScoreStatus(0) !== "Focus area") {
  throw new Error("A valid zero score must remain a focus area instead of being treated as missing.");
}
if (getSkinScoreStatus(50) !== "Fair" || getSkinScoreStatus(65) !== "Good" || getSkinScoreStatus(80) !== "Excellent") {
  throw new Error("Skin score status thresholds changed unexpectedly.");
}

const providerError = new Error("provider response contained secret task token");
const fallback = getSkinAnalysisFallbackReason(providerError);
if (fallback.includes(providerError.message) || fallback.includes("secret task token")) {
  throw new Error("Provider error details must not be exposed in the mobile fallback reason.");
}
const abortFallback = getSkinAnalysisFallbackReason(Object.assign(new Error("request aborted"), { name: "AbortError" }));
if (abortFallback !== "Live analysis was cancelled before completion.") {
  throw new Error("Abort failures must use the stable cancellation message.");
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "Missing and non-finite scores fail closed as unavailable.",
    "A valid zero score is preserved as a focus area.",
    "Provider and cancellation details are represented by stable user-safe fallback messages.",
  ],
}, null, 2));
