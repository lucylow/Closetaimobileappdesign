/**
 * Unit test for ClosetAI central entitlements resolver and funnel event logging
 */

import { getUserEntitlements, updateUserTier, getFunnelEvents, logFunnelEvent } from "../lib/commerce-entitlements-resolver";

async function runTest() {
  console.log("Running Entitlements & Funnel Resolver Test...");
  
  const initial = await getUserEntitlements();
  if (!initial || initial.tierId !== "free") {
    throw new Error("Initial entitlement tier should be free");
  }

  await updateUserTier("pro_shopper");
  const upgraded = await getUserEntitlements();
  if (upgraded.tierId !== "pro_shopper" || upgraded.creditsRemaining !== 1500) {
    throw new Error("Failed to update user tier to pro_shopper");
  }

  await logFunnelEvent("test_conversion_event", { testId: 123 });
  const events = await getFunnelEvents();
  const found = events.find(e => e.event === "test_conversion_event");
  if (!found) {
    throw new Error("Funnel event logging failed");
  }

  console.log("Entitlements & Funnel Resolver Test: PASSED");
}

runTest().catch((err) => {
  console.error("Test FAILED:", err);
  process.exit(1);
});
