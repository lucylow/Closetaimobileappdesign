import { readFileSync } from "node:fs";
import { getCatalogProduct } from "../lib/skin-product-catalog";
import { buildRecommendedProducts, RECOMMENDED_PRODUCTS_DISCLOSURE } from "../lib/recommended-skin-products";

const live = buildRecommendedProducts({
  source: "youcam",
  metrics: [
    { key: "hydration", score: 48, available: true },
    { key: "pores", score: 52, available: true },
    { key: "radiance", score: 82, available: true },
    { key: "redness", score: 0, available: false },
  ],
  selectedGoals: ["hydration", "texture"],
  savedProductIds: ["lrp-toleriane-double-repair"],
});
const demo = buildRecommendedProducts({ source: "demo", metrics: [{ key: "hydration", score: 48, available: true }], selectedGoals: ["hydration"] });
const starter = buildRecommendedProducts({ source: "none", metrics: [], selectedGoals: ["tone"] });
const pm = buildRecommendedProducts({ source: "none", routineFilter: "PM", selectedGoals: [] });

if (live.source !== "youcam" || !live.sourceLabel.includes("Live visual context") || demo.source !== "demo" || !demo.sourceLabel.includes("Fictional Demo Mode") || starter.source !== "none" || !starter.sourceLabel.includes("Local care goals only")) {
  throw new Error("Recommendation source labels must distinguish live context, fictional Demo Mode, and no-scan local-goal starter discovery.");
}
if (!live.items.length || !live.items.every((item) => Boolean(getCatalogProduct(item.id)))) {
  throw new Error("Recommended Products may return only verified catalog records.");
}
if (!live.items.some((item) => item.matchedGoals.includes("hydration")) || !live.items.some((item) => item.savedLocally && item.recommendationReasons.some((reason) => reason.includes("saved")))) {
  throw new Error("Local goals and saved product references must transparently affect recommendation explanation.");
}
if (live.items.some((item) => item.matchedSignals.includes("redness"))) {
  throw new Error("Unavailable normalized signals must not influence product recommendations.");
}
if (pm.items.some((item) => item.routine === "AM")) {
  throw new Error("PM product filter must exclude AM-only catalog records.");
}
if (!RECOMMENDED_PRODUCTS_DISCLOSURE.includes("not medical advice") || !RECOMMENDED_PRODUCTS_DISCLOSURE.includes("ingredient-compatibility guarantee") || !RECOMMENDED_PRODUCTS_DISCLOSURE.includes("availability")) {
  throw new Error("Recommended Products disclosure must preserve non-medical, non-guarantee, and current-listing verification boundaries.");
}
const plannerSource = readFileSync("lib/recommended-skin-products.ts", "utf8");
const screenSource = readFileSync("components/skin/SkinJourneyPage.tsx", "utf8");
if (!plannerSource.includes("realSkinProductCatalog") || !plannerSource.includes("Fictional Demo Mode") || !plannerSource.includes("savedLocally")) {
  throw new Error("Planner must use verified catalog records and preserve demo and saved-reference transparency.");
}
if (!screenSource.includes("buildRecommendedProducts") || !screenSource.includes("Show ${filter} routine products") || !screenSource.includes("Open personalized AM/PM routine") || !screenSource.includes("Review manufacturer details")) {
  throw new Error("Products screen must expose source-aware recommendation, routine filters, routine navigation, and manufacturer-detail actions.");
}

console.log(JSON.stringify({ result: "PASS", assertions: [
  "Live, fictional Demo Mode, and no-scan starter discovery remain source-labeled.",
  "Recommendations resolve only verified catalog records and present explainable local-goal, signal, and saved-reference reasons.",
  "Unavailable signals are excluded and AM/PM filters respect catalog routine labels.",
  "Product discovery preserves non-medical, non-guarantee, and official-listing verification boundaries.",
  "The Expo products screen exposes the enhanced source-aware, routine-connected recommendation flow.",
] }, null, 2));
