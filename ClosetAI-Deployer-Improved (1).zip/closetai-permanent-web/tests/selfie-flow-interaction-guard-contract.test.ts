import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const source = readFileSync(resolve(process.cwd(), "components/skin/SelfieFlowScreen.tsx"), "utf8");

for (const required of [
  "const isMountedRef = useRef(true)",
  "const pickerInFlightRef = useRef(false)",
  "const analysisInFlightRef = useRef(false)",
  "if (pickerInFlightRef.current || analysisInFlightRef.current) return",
  "const approvedCurrentPhoto = Boolean(asset && quality && quality.band !== \"retake\" && acceptsGuidance)",
  "if (!activeAssetUri || (!queuedInput && !approvedCurrentPhoto) || analysisInFlightRef.current || pickerInFlightRef.current) return",
  "pickerInFlightRef.current = false",
  "analysisInFlightRef.current = false",
  "if (isMountedRef.current) setIsPicking(false)",
  "if (isMountedRef.current) setBusy(false)",
]) {
  if (!source.includes(required)) throw new Error(`Selfie lifecycle safeguard missing: ${required}`);
}

for (const required of [
  "disabled={isWorking}",
  "accessibilityState={{ checked: acceptsGuidance, disabled: isWorking }}",
  "accessibilityState={{ checked: saveSummary, disabled: isWorking }}",
  "accessibilityState={{ disabled, busy }}",
  "Wait while ClosetAI completes the current photo action.",
  "Opening Photo Library…",
]) {
  if (!source.includes(required)) throw new Error(`Selfie busy-state accessibility safeguard missing: ${required}`);
}

for (const boundary of [
  "A selfie is optional.",
  "Use Demo Scan",
  "Explores fictional guidance without using a selfie.",
  "not a diagnosis or treatment.",
  "does not retain the original selfie in history.",
]) {
  if (!source.includes(boundary)) throw new Error(`Selfie privacy or demo boundary missing: ${boundary}`);
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "Photo picking and analysis reject overlapping actions and avoid state updates after unmount.",
    "Consent, summary preferences, navigation, reset, and conflicting photo actions are locked with accessible busy feedback during processing.",
    "The flow retains optional-photo, demo-mode, non-diagnostic, and no-original-selfie-history boundaries.",
    "Queued retries bypass only the current in-memory review guard after restoring the persisted selected selfie and consent-safe settings.",
  ],
}, null, 2));
