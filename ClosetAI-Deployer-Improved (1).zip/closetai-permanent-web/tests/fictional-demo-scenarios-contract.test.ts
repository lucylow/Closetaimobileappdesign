import { readFileSync } from "node:fs";
import { resolve } from "node:path";

import {
  FICTIONAL_AGENT_PLANS,
  FICTIONAL_AR_PREVIEW_SCENARIOS,
  FICTIONAL_DEMO_SCENARIOS_DISCLOSURE,
  FICTIONAL_PERSONA_LOOKBOOKS,
  FICTIONAL_PRODUCT_CATEGORY_CARDS,
  FICTIONAL_ROUTINE_SCENARIOS,
  FICTIONAL_WARDROBE_CAPSULES,
} from "../lib/fictional-demo-scenarios";

const root = process.cwd();
const agentScreen = readFileSync(resolve(root, "app/agents.tsx"), "utf8");
const textureScreen = readFileSync(resolve(root, "app/skin/texture-preview.tsx"), "utf8");
const skinJourneyScreen = readFileSync(resolve(root, "components/skin/SkinJourneyPage.tsx"), "utf8");

if (!FICTIONAL_DEMO_SCENARIOS_DISCLOSURE.includes("Fictional Demo Mode") || !FICTIONAL_DEMO_SCENARIOS_DISCLOSURE.includes("not user records")) {
  throw new Error("The fictional scenario registry must state that records are prototype data and not user records.");
}
if (FICTIONAL_PERSONA_LOOKBOOKS.length < 50 || new Set(FICTIONAL_PERSONA_LOOKBOOKS.map((lookbook) => lookbook.persona)).size < 5 || !["maya-jade-studio-lookbook", "sofia-apricot-terrace-lookbook", "aisha-midnight-column-lookbook", "leila-butter-transit-lookbook", "nora-clay-canvas-lookbook"].every((id) => FICTIONAL_PERSONA_LOOKBOOKS.some((lookbook) => lookbook.id === id)) || FICTIONAL_PERSONA_LOOKBOOKS.some((lookbook) => !lookbook.anchorPieces.length || !lookbook.stylingPrompt || !lookbook.disclosure.includes("Fictional Demo Mode"))) {
  throw new Error("Fictional persona lookbooks must cover all five personas with disclosed styling anchors.");
}
if (FICTIONAL_WARDROBE_CAPSULES.length < 70 || new Set(FICTIONAL_WARDROBE_CAPSULES.map((scenario) => scenario.persona)).size < 5 || !["maya-jade-studio", "sofia-apricot-terrace", "aisha-midnight-column", "leila-butter-transit", "nora-clay-canvas"].every((id) => FICTIONAL_WARDROBE_CAPSULES.some((scenario) => scenario.id === id))) {
  throw new Error("Fictional wardrobe capsules must cover all five named demo personas.");
}
for (const scenario of FICTIONAL_WARDROBE_CAPSULES) {
  if (!scenario.disclosure.includes("Fictional Demo Mode") || !scenario.garmentNames.length || !scenario.accessoryNames.length) {
    throw new Error(`Wardrobe capsule ${scenario.id} is missing fictional disclosure or styling content.`);
  }
}
if (FICTIONAL_ROUTINE_SCENARIOS.length < 69 || new Set(FICTIONAL_ROUTINE_SCENARIOS.map((scenario) => scenario.persona)).size < 5 || !["maya-pm-jade-studio", "sofia-am-apricot-terrace", "aisha-pm-midnight-column", "leila-am-butter-transit", "nora-am-pm-clay-canvas"].every((id) => FICTIONAL_ROUTINE_SCENARIOS.some((scenario) => scenario.id === id)) || FICTIONAL_ROUTINE_SCENARIOS.some((scenario) => scenario.sourceLabel !== "Fictional Demo Mode" || scenario.steps.length < 3)) {
  throw new Error("Fictional routine scenarios must provide five source-labeled, multi-step routines.");
}
if (FICTIONAL_PRODUCT_CATEGORY_CARDS.length < 70 || new Set(FICTIONAL_PRODUCT_CATEGORY_CARDS.map((card) => card.persona)).size < 5 || !["maya-jade-moisture", "sofia-apricot-spf", "aisha-midnight-serum", "leila-butter-cleanser", "nora-clay-treatment"].every((id) => FICTIONAL_PRODUCT_CATEGORY_CARDS.some((card) => card.id === id)) || FICTIONAL_PRODUCT_CATEGORY_CARDS.some((card) => !card.disclosure.includes("Fictional Demo Mode") || !card.labelPrompt || !["AM", "PM", "AM / PM"].includes(card.routineTime))) {
  throw new Error("Fictional product-category cards must be disclosed, label-aware, and routine-timed.");
}
if (FICTIONAL_AGENT_PLANS.length < 48 || !FICTIONAL_AGENT_PLANS.some((plan) => plan.agent === "fashion") || !FICTIONAL_AGENT_PLANS.some((plan) => plan.agent === "skincare") || !["fictional-agent-fashion-maya-jade", "fictional-agent-fashion-sofia-apricot", "fictional-agent-skincare-aisha-midnight", "fictional-agent-skincare-leila-butter"].every((requestId) => FICTIONAL_AGENT_PLANS.some((plan) => plan.requestId === requestId))) {
  throw new Error("Fictional agent fallbacks must cover fashion and skincare.");
}
for (const plan of FICTIONAL_AGENT_PLANS) {
  if (plan.mode !== "fictional_demo" || !plan.usedFallback || !plan.disclosure.includes("fictional") || plan.validationFlags.length < 2) {
    throw new Error(`Agent fallback ${plan.requestId} is missing fictional mode or validation metadata.`);
  }
}
if (FICTIONAL_AR_PREVIEW_SCENARIOS.length < 66 || new Set(FICTIONAL_AR_PREVIEW_SCENARIOS.map((scenario) => scenario.persona)).size < 5 || !["maya-satin-jade-balanced", "sofia-dewy-apricot-subtle", "aisha-soft-focus-midnight-balanced", "leila-guide-butter-subtle", "nora-dewy-clay-balanced"].every((id) => FICTIONAL_AR_PREVIEW_SCENARIOS.some((scenario) => scenario.id === id)) || FICTIONAL_AR_PREVIEW_SCENARIOS.some((scenario) => !scenario.disclosure.includes("Fictional Demo Mode") || !scenario.controls.includes("Use own selected photo"))) {
  throw new Error("Fictional AR preview scenarios must remain user-photo-only and disclosed.");
}
if (!agentScreen.includes("getFictionalAgentPlan") || !agentScreen.includes("Showing a clearly labeled Fictional Demo Mode plan instead") || !agentScreen.includes("FICTIONAL_PERSONA_LOOKBOOKS") || !agentScreen.includes("Persona lookbooks") || !agentScreen.includes(".slice(-5)")) {
  throw new Error("Agent Studio must use the fictional agent plan only as a clearly labeled Demo Mode fallback.");
}
if (!textureScreen.includes("LOCAL_TEXTURE_PREVIEW_BOUNDARY") || !textureScreen.includes("show a stock model") || !textureScreen.includes("FICTIONAL_AR_PREVIEW_SCENARIOS") || !textureScreen.includes("fictionalPreviewPresets") || !textureScreen.includes("Fictional Demo Mode preview presets") || !textureScreen.includes("applyFictionalPreview")) {
  throw new Error("Local AR preview must retain its no-stock-model disclosure boundary.");
}
if (!skinJourneyScreen.includes("FICTIONAL_PRODUCT_CATEGORY_CARDS.slice(-10)") || !skinJourneyScreen.includes("newest fictional set")) {
  throw new Error("Skin Care Hub must surface the newest fictional category set with disclosure.");
}

console.log(JSON.stringify({
  result: "PASS",
  personaLookbookCount: FICTIONAL_PERSONA_LOOKBOOKS.length,
  wardrobeCapsuleCount: FICTIONAL_WARDROBE_CAPSULES.length,
  routineScenarioCount: FICTIONAL_ROUTINE_SCENARIOS.length,
  productCategoryCardCount: FICTIONAL_PRODUCT_CATEGORY_CARDS.length,
  agentPlanCount: FICTIONAL_AGENT_PLANS.length,
  arScenarioCount: FICTIONAL_AR_PREVIEW_SCENARIOS.length,
  assertions: [
    "All five fictional personas have ten disclosed persona lookbooks.",
    "All five fictional personas have at least five wardrobe capsule scenarios.",
    "AM, PM, and AM / PM routines remain fictional and non-diagnostic.",
    "Skincare product-category cards remain label-aware and do not claim live inventory or efficacy.",
    "Fashion and skincare agent fallbacks are server-failure recovery only in Demo Mode.",
    "AR scenario metadata preserves own-photo-only and local-overlay boundaries.",
    "The current wave contributes five wardrobe, lookbook, routine, category, and AR records plus four agent fallback plans.",
    "Newest-wave records are surfaced in Agent Studio and Skin Care Hub rather than remaining unused in the registry.",
  ],
}, null, 2));
