import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const root = process.cwd();
const tokens = readFileSync(resolve(root, "constants/colors.ts"), "utf8");
const home = readFileSync(resolve(root, "app/(tabs)/index.tsx"), "utf8");
const wardrobe = readFileSync(resolve(root, "app/(tabs)/wardrobe.tsx"), "utf8");
const outfits = readFileSync(resolve(root, "app/(tabs)/outfits.tsx"), "utf8");
const tryOn = readFileSync(resolve(root, "app/(tabs)/tryon.tsx"), "utf8");
const skinHub = readFileSync(resolve(root, "components/skin/SkinCareHub.tsx"), "utf8");

if (!tokens.includes("export const interaction") || !tokens.includes("primaryPressScale") || !tokens.includes("disabledOpacity")) {
  throw new Error("The frontend must expose shared interaction-feedback tokens.");
}

if (!home.includes("accessibilityLabel=\"Open settings\"") || !home.includes("accessibilityLabel={`View ${stat.value}")) {
  throw new Error("Home settings and status cards must have descriptive accessible names.");
}
if (!home.includes("accessibilityHint={action.desc}") || !home.includes("interaction.cardPressScale")) {
  throw new Error("Home quick actions must explain their destination and use shared card feedback.");
}
if (!home.includes("Open today’s outfit") || !home.includes("else router.push('/(tabs)/outfits')")) {
  throw new Error("Home must keep Today’s Pick discoverable and avoid a non-responsive Saved summary card.");
}

if (!wardrobe.includes("accessibilityRole=\"radio\"") || !wardrobe.includes("accessibilityLabel={`All wardrobe items")) {
  throw new Error("Wardrobe filters must expose their selected state and item counts accessibly.");
}
if (!wardrobe.includes("Open ${item.name}") || !wardrobe.includes("Long press to remove it")) {
  throw new Error("Wardrobe item cards must explain both their detail and long-press actions.");
}

if (!outfits.includes("accessibilityRole=\"tab\"") || !outfits.includes("accessibilityState={{ selected: active }}")) {
  throw new Error("Outfit view switches must expose tab semantics.");
}
if (!outfits.includes("Remove like from") || !outfits.includes("Remove ${outfit.name} from saved outfits")) {
  throw new Error("Outfit rating and save controls must expose their current action state.");
}
if (!outfits.includes("Refresh outfit suggestions") || !outfits.includes("interaction.disabledOpacity")) {
  throw new Error("Outfit refresh must clearly communicate its action and unavailable state.");
}

if (!tryOn.includes("Select your try-on photo") || !tryOn.includes("never substitutes a stock model")) {
  throw new Error("Try-On photo selection must retain its user-photo-only accessibility guidance.");
}
if (!tryOn.includes("accessibilityRole=\"checkbox\"") || !tryOn.includes("Select ${item.name} for try-on")) {
  throw new Error("Try-On garment selection must expose accessible checkbox state.");
}
if (!tryOn.includes("accessibilityRole=\"radio\"") || !tryOn.includes("Open AI Shoes Virtual Try-On")) {
  throw new Error("Try-On categories and the dedicated Shoes route must be accessible controls.");
}

if (!skinHub.includes('import { interaction } from "@/constants/colors"') || !skinHub.includes("interaction.primaryPressScale")) {
  throw new Error("Skin Care must use the shared primary-action feedback token.");
}
if (!skinHub.includes("source-aware detail view") || !skinHub.includes("Skin and Style suggestions")) {
  throw new Error("Skin Care snapshot controls must retain clear, source-aware destinations.");
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "Core screens share consistent press-scale and disabled-state feedback tokens.",
    "Home, Wardrobe, Outfits, Try-On, and Skin Care controls expose descriptive accessible names and state semantics.",
    "The saved-outfit, photo-only try-on, and source-aware Skin Care journeys retain clear frontend destinations.",
  ],
}, null, 2));
