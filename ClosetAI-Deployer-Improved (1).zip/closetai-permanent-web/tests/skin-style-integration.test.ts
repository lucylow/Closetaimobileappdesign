import { buildWardrobeStyleMatch } from "../lib/wardrobe-style-match";
import type { WardrobeItem } from "../lib/demo-data";

const sampleWardrobe: WardrobeItem[] = [
  { id: "test-cream-knit", name: "Cream Knit", category: "top", color: "Cream", brand: "Sample", imageUrl: "", tags: ["neutral", "knit"], usageCount: 0, lastWorn: null, notes: "", createdAt: "2026-08-12T00:00:00.000Z" },
  { id: "test-navy-trouser", name: "Navy Trouser", category: "bottom", color: "Navy", brand: "Sample", imageUrl: "", tags: ["tailored"], usageCount: 0, lastWorn: null, notes: "", createdAt: "2026-08-12T00:00:00.000Z" },
  { id: "test-camel-jacket", name: "Camel Jacket", category: "outerwear", color: "Camel", brand: "Sample", imageUrl: "", tags: ["layer"], usageCount: 0, lastWorn: null, notes: "", createdAt: "2026-08-12T00:00:00.000Z" },
];

const match = buildWardrobeStyleMatch(sampleWardrobe);

if (match.itemCount !== 3) throw new Error(`Expected 3 wardrobe items, received ${match.itemCount}`);
if (match.colors.join("|") !== "Cream|Navy|Camel") throw new Error(`Unexpected wardrobe colors: ${match.colors.join(", ")}`);
if (!match.detail.includes("3 items")) throw new Error(`Expected user-wardrobe detail, received: ${match.detail}`);
if (!match.detail.includes("top")) throw new Error(`Expected category summary, received: ${match.detail}`);

const selectedForOfflineOutfit = sampleWardrobe.slice(0, Math.min(3, sampleWardrobe.length));
if (selectedForOfflineOutfit.some((item) => !sampleWardrobe.some((source) => source.id === item.id))) {
  throw new Error("Offline outfit fallback selected an item outside the user wardrobe.");
}

console.log(JSON.stringify({
  result: "PASS",
  title: match.title,
  colors: match.colors,
  itemCount: match.itemCount,
  selectedOutfitItemIds: selectedForOfflineOutfit.map((item) => item.id),
}, null, 2));
