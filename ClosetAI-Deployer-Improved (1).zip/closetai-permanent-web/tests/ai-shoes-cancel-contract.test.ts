import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const source = readFileSync(join(root, "app/tryon/shoes.tsx"), "utf8");

if (!source.includes("const tryOnRunRef = React.useRef(0);")) {
  throw new Error("AI Shoes must track an active request identity.");
}
if (!source.includes("const cancelPreview = () =>") || !source.includes("tryOnRunRef.current += 1;")) {
  throw new Error("AI Shoes must invalidate the active request when cancelled.");
}
if (!source.includes("if (!isCurrentRun() || !isMountedRef.current) return;")) {
  throw new Error("AI Shoes must suppress late results after cancellation or unmount.");
}
if (!source.includes("accessibilityLabel=\"Cancel AI Shoes preview\"")) {
  throw new Error("AI Shoes cancellation must be accessible.");
}
if (!source.includes("Shoe preview cancelled. Your selected photos and settings remain available for review.")) {
  throw new Error("AI Shoes cancellation must preserve the selected media context.");
}
if (!source.includes("accessibilityLiveRegion=\"polite\"")) {
  throw new Error("AI Shoes recovery must be announced politely.");
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "AI Shoes cancellation invalidates the active run.",
    "Late provider results cannot overwrite cancelled state.",
    "Cancellation is accessible and preserves selected media context.",
  ],
}, null, 2));
