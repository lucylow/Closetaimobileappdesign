import { readFileSync } from "node:fs";
import { FACIAL_COLOR_TONES_DISCLOSURE, normalizeFaceAngleStrictness, normalizeProviderFacialColorTones } from "../shared/facial-color-tones";

const tones = normalizeProviderFacialColorTones({
  skin_color: "#b9947c", eye_color: "293F9B", eye_color_name: "Blue", lip_color: "#D23245", eyebrow_color: "#5B2B31", hair_color: "#A0A0A0", hair_color_name: "Auburn",
});
if (!tones || tones.skinColor !== "#B9947C" || tones.eyeColor !== "#293F9B" || tones.eyeColorName !== "Blue" || tones.hairColorName !== "Auburn") {
  throw new Error("Documented provider color fields must normalize to validated, uppercase application values.");
}
if (normalizeProviderFacialColorTones({ skin_color: "#fff" }) !== null) {
  throw new Error("Incomplete or invalid provider color output must not be displayed.");
}
if (normalizeFaceAngleStrictness("flexible") !== "flexible" || normalizeFaceAngleStrictness("unbounded") !== "high") {
  throw new Error("Face-angle strictness must remain in the documented allowed set.");
}
if (!FACIAL_COLOR_TONES_DISCLOSURE.includes("not an ethnicity") || !FACIAL_COLOR_TONES_DISCLOSURE.includes("no result is fabricated")) {
  throw new Error("Color-tone disclosure must preserve identity and no-fabrication boundaries.");
}

const routeSource = readFileSync("server/routes.ts", "utf8");
const screenSource = readFileSync("app/skin/color-tones.tsx", "utf8");
const hubSource = readFileSync("components/skin/SkinCareHub.tsx", "utf8");
if (!routeSource.includes('app.post("/api/skin/color-tones"') || !routeSource.includes("normalizeProviderFacialColorTones")) throw new Error("Authenticated endpoint must normalize provider results before returning them.");
if (!screenSource.includes("No color values were shown") || !screenSource.includes("not added to skin history")) throw new Error("Mobile screen must not substitute fallback colors or persist tones by default.");
if (!hubSource.includes('router.push("/skin/color-tones")')) throw new Error("Color-tone screen must be reachable from the Skin Care hub.");

console.log(JSON.stringify({ result: "PASS", tones, assertions: [
  "Provider hex values and documented names normalize deterministically.",
  "Incomplete provider results are rejected rather than fabricated.",
  "Strictness is bounded to documented levels.",
  "The live-only mobile flow preserves privacy and no-fallback rules.",
] }, null, 2));
