/**
 * Unit test for ClosetAI purchase ledger and conversion summary
 */

import { recordPurchase, getPurchaseLedger, getConversionSummary } from "../lib/purchase-ledger";

async function runTest() {
  console.log("Running Purchase Ledger & Conversion Summary Test...");

  await recordPurchase({
    type: "subscription",
    title: "Pro Shopper Subscription",
    amountUSD: 19.99,
    isDemo: true,
    lifecycleStatus: "active",
  });

  await recordPurchase({
    type: "credit_pack",
    title: "Pro Creator Pack",
    amountUSD: 14.99,
    isDemo: true,
    lifecycleStatus: "active",
  });

  const ledger = await getPurchaseLedger();
  if (ledger.length < 2) {
    throw new Error("Purchase ledger failed to record items");
  }

  const summary = await getConversionSummary();
  if (summary.demoSimulationRevenueUSD !== 34.98 || summary.activeSubscriptions !== 1) {
    throw new Error("Conversion summary calculation for demo revenue or active subscriptions incorrect");
  }

  console.log("Purchase Ledger & Conversion Summary Test: PASSED");
}

runTest().catch((err) => {
  console.error("Test FAILED:", err);
  process.exit(1);
});
