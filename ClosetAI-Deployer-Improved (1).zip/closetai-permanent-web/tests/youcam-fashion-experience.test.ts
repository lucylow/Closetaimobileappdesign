import { buildYouCamFashionCapability, buildYouCamFashionReadiness, YOUCAM_USER_PHOTO_GUARANTEE } from "../shared/youcam-fashion-experience";

const configured = buildYouCamFashionCapability(true);
if (!configured.configured || configured.provider !== "youcam-ai-clothes-v4") throw new Error("Configured capability did not identify YouCam AI Clothes v4.");
if (configured.liveCategoryIds.length !== 7 || configured.assistedCategoryIds.length !== 3) throw new Error("Capability category routing no longer matches the 10-category fashion contract.");
if (!configured.userPhotoOnly || configured.maxImageBytes !== 10 * 1024 * 1024 || configured.resultCacheMinutes !== 10) throw new Error("Capability safety or bounded-cache metadata is incorrect.");

const liveReady = buildYouCamFashionReadiness({ configured: true, selectedItems: [{ id: "top-1", category: "Tops", imageUrl: "https://images.example.com/top.jpg" }] });
if (liveReady.mode !== "live-ready" || !liveReady.liveEligibleItemIds.includes("top-1")) throw new Error("A supported garment with a public image should be live-ready.");

const needsReference = buildYouCamFashionReadiness({ configured: true, selectedItems: [{ id: "top-2", category: "Tops", imageUrl: "file://local-top.jpg" }] });
if (needsReference.mode !== "needs-garment-reference" || !needsReference.missingReferenceItemIds.includes("top-2")) throw new Error("A local-only supported garment must explain its reference requirement.");

const accessory = buildYouCamFashionReadiness({ configured: true, selectedItems: [{ id: "bag-1", category: "Bags", imageUrl: "https://images.example.com/bag.jpg" }] });
if (accessory.mode !== "assisted-edit" || !accessory.assistedItemIds.includes("bag-1")) throw new Error("Accessory categories must remain on the user-photo-only assisted route.");

const unavailable = buildYouCamFashionReadiness({ configured: false, selectedItems: [{ id: "dress-1", category: "Dresses", imageUrl: "https://images.example.com/dress.jpg" }] });
if (unavailable.mode !== "provider-unavailable" || !unavailable.detail.includes("selected photo")) throw new Error("Provider-unavailable mode must retain the user-photo-safe fallback explanation.");
if (!YOUCAM_USER_PHOTO_GUARANTEE.includes("never substitutes a stock model")) throw new Error("The explicit no-stock-model guarantee is required.");

console.log(JSON.stringify({
  result: "PASS",
  modes: [liveReady.mode, needsReference.mode, accessory.mode, unavailable.mode],
  guarantee: YOUCAM_USER_PHOTO_GUARANTEE,
}, null, 2));
