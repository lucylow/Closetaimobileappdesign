import { activeSkinCommerceProvider, mockSkinCommerceProvider, MOCK_COMMERCE_DISCLOSURE } from "../lib/skin-commerce-provider";

const disclosure = MOCK_COMMERCE_DISCLOSURE;

async function run() {
  const listing = await activeSkinCommerceProvider.getListing("cerave-hydrating-facial-cleanser");
  if (!listing) throw new Error("Expected a mock listing for the catalog cleanser.");
  if (listing.provider !== "mock" || listing.mode !== "mock") throw new Error("Mock provider must explicitly identify its prototype mode.");
  if (listing.unitPrice <= 0 || listing.availableQuantity < 1 || listing.availability !== "in_stock") throw new Error("Expected a usable in-stock mock listing.");
  if (!listing.disclosure.includes(disclosure)) throw new Error("Mock listing must include the mandatory disclosure.");
  if (listing.checkoutEnabled || listing.checkoutUrl) throw new Error("Mock listings must never expose a live checkout URL.");

  const cart = await activeSkinCommerceProvider.createCart(listing.productId, 2);
  if (!cart || cart.subtotal !== Number((listing.unitPrice * 2).toFixed(2))) throw new Error("Mock cart did not preserve quantity and fictional subtotal.");
  if (!cart.disclosure.includes(disclosure) || cart.checkoutEnabled || cart.checkoutUrl) throw new Error("Mock cart disclosure or checkout boundary is incorrect.");

  const outOfStock = await mockSkinCommerceProvider.getListing("cerave-skin-renewing-night-cream");
  if (!outOfStock || outOfStock.availability !== "out_of_stock" || outOfStock.availableQuantity !== 0) throw new Error("Expected the night cream to model a safe out-of-stock state.");
  if (await mockSkinCommerceProvider.createCart("cerave-skin-renewing-night-cream")) throw new Error("An out-of-stock listing must not create a mock cart.");
  if (await mockSkinCommerceProvider.getListing("unknown-product")) throw new Error("Unknown catalog products must not fabricate a listing.");

  console.log(JSON.stringify({
    result: "PASS",
    provider: listing.provider,
    listing: { productId: listing.productId, availability: listing.availability, price: listing.unitPrice },
    cart: { quantity: cart.lineItems[0].quantity, subtotal: cart.subtotal },
    outOfStock: outOfStock.productId,
    guarantee: "No live store credentials, real inventory, transaction, or checkout URL are used in mock mode; disclosure is mandatory.",
  }, null, 2));
}

run().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
