import { readFileSync } from "node:fs";
import { FITZPATRICK_DISCLOSURE, normalizeFitzpatrickType, normalizeProviderFitzpatrickProfile } from "../shared/fitzpatrick-profile";

if (normalizeFitzpatrickType("type iv") !== "IV" || normalizeFitzpatrickType("VII") !== null) {
  throw new Error("Only the six explicit Fitzpatrick types may normalize.");
}
const profile = normalizeProviderFitzpatrickProfile({ fitzpatrick_type: "V" }, "Verified provider");
if (profile?.type !== "V" || profile.source !== "provider") {
  throw new Error("A profile must originate from an explicit provider-returned value.");
}
if (normalizeProviderFitzpatrickProfile({ selfieHue: 24 }) !== null) {
  throw new Error("Local selfie attributes must never be converted into a Fitzpatrick classification.");
}
if (!FITZPATRICK_DISCLOSURE.includes("not an ethnicity inference") || !FITZPATRICK_DISCLOSURE.includes("not a medical diagnosis")) {
  throw new Error("The mandatory disclosure must state the non-ethnicity and non-medical boundaries.");
}

const serverSource = readFileSync("server/fitzpatrick.ts", "utf8");
const routeSource = readFileSync("server/routes.ts", "utf8");
const screenSource = readFileSync("app/skin/fitzpatrick.tsx", "utf8");
const hubSource = readFileSync("components/skin/SkinCareHub.tsx", "utf8");
if (!serverSource.includes("will not estimate a classification from your photo")) throw new Error("Capability adapter must fail closed when a verified provider contract is unavailable.");
if (!routeSource.includes('app.get("/api/skin/fitzpatrick/capability"')) throw new Error("Authenticated capability route is required.");
if (!screenSource.includes("No selfie is sent from this screen") || !screenSource.includes("does not infer ethnicity")) throw new Error("Mobile screen must expose key privacy and interpretation boundaries.");
if (!hubSource.includes('router.push("/skin/fitzpatrick")')) throw new Error("Fitzpatrick screen must be reachable from the canonical Skin Care hub.");

console.log(JSON.stringify({
  result: "PASS",
  profile,
  assertions: [
    "Only canonical I–VI provider values are accepted.",
    "No local selfie-derived classification is permitted.",
    "Capability reports unavailable rather than fabricating a live result.",
    "The visible mobile flow includes ethical and privacy disclosures.",
  ],
}, null, 2));
