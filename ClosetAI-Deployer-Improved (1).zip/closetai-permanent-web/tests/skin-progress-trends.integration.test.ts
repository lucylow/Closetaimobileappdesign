import { readFileSync } from "node:fs";
import { buildSkinProgressOverview, getSkinProgressMetricPoints } from "../lib/skin-progress-trends";
import type { SkinMetricHistoryPoint } from "../lib/skin-metric-history";

const historyFixture: SkinMetricHistoryPoint[] = [
  { scanId: "live-1", capturedAt: "2026-08-01T09:00:00Z", source: "youcam", overallScore: 61, metricKey: "hydration", score: 49 },
  { scanId: "live-1", capturedAt: "2026-08-01T09:00:00Z", source: "youcam", overallScore: 61, metricKey: "radiance", score: 62 },
  { scanId: "live-2", capturedAt: "2026-08-08T09:00:00Z", source: "youcam", overallScore: 64, metricKey: "hydration", score: 55 },
  { scanId: "live-2", capturedAt: "2026-08-08T09:00:00Z", source: "youcam", overallScore: 64, metricKey: "radiance", score: 63 },
];

const overview = buildSkinProgressOverview(historyFixture);
const hydrationBars = getSkinProgressMetricPoints(historyFixture, "hydration");
const hydrationSummary = overview.metricSummaries.find((summary) => summary.metricKey === "hydration");
if (overview.snapshotCount !== 2 || overview.captureDayCount !== 2 || overview.sources.join("|") !== "youcam") {
  throw new Error("Integration: local scan rows must flow into a live normalized snapshot overview with correct scan/day/source summary.");
}
if (hydrationBars.length !== 2 || hydrationBars[0]?.score !== 49 || hydrationBars[1]?.score !== 55 || hydrationSummary?.direction !== "up") {
  throw new Error("Integration: selected metric history must flow into the chart window and source-safe direction summary in chronological order.");
}

const root = process.cwd();
const adapter = readFileSync(`${root}/lib/skin-metric-history.ts`, "utf8");
const nativeAdapter = readFileSync(`${root}/lib/skin-metric-history.native.ts`, "utf8");
const webAdapter = readFileSync(`${root}/lib/skin-metric-history.web.ts`, "utf8");
const chart = readFileSync(`${root}/components/skin/SkinMetricProgressChart.tsx`, "utf8");
const journey = readFileSync(`${root}/components/skin/SkinJourneyPage.tsx`, "utf8");

for (const required of ["saveSkinMetricHistory", "loadSkinMetricHistory", "clearSkinMetricHistory"]) {
  if (!(adapter + nativeAdapter + webAdapter).includes(required)) throw new Error(`Integration: missing history adapter operation ${required}.`);
}
for (const forbidden of ["image_uri", "raw_response", "face_mask", "base64"]) {
  if (nativeAdapter.toLowerCase().includes(forbidden)) throw new Error(`Integration: native history persistence must exclude ${forbidden}.`);
}
for (const required of ["buildSkinProgressOverview", "getSkinProgressMetricPoints", "Clear local progress history?", "accessibilityRole=\"radio\"", "Fictional Demo Mode", "No fictional trend values are shown"]) {
  if (!chart.includes(required)) throw new Error(`Integration: progress UI binding is missing ${required}.`);
}
if (!journey.includes("SkinMetricProgressChart") || !journey.includes("key === \"progress\"")) {
  throw new Error("Integration: the canonical Skin Care journey must mount the upgraded progress component for the Your Progress route.");
}

console.log(JSON.stringify({ result: "PASS", type: "integration", flow: [
  "Normalized local history rows",
  "Source-aware progress overview",
  "Selected metric chart window",
  "Accessible Your Progress UI",
  "Canonical Skin Care progress route",
], assertions: [
  "No original selfie or raw provider payload enters the SQLite history contract.",
  "A live same-source fixture becomes a chronological non-clinical direction summary.",
  "The UI provides source labels, Demo Mode disclosure, unavailable-history honesty, and an explicit local clear confirmation.",
] }, null, 2));
