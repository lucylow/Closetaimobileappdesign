import { readFileSync } from "node:fs";
import { FACE_ATTRIBUTES_DISCLOSURE, normalizeFaceAttributeActions, normalizeProviderFaceAttributes } from "../shared/face-attributes";

const actions = normalizeFaceAttributeActions(["faceShape", "eyeShape", "gender", "age", "faceAspectRatio", "unknown"]);
if (actions.includes("gender" as any) || actions.includes("age" as any) || actions.includes("unknown" as any) || !actions.includes("faceShape") || !actions.includes("faceAspectRatio")) {
  throw new Error("Only supported non-sensitive face styling actions may be selected.");
}
const normalized = normalizeProviderFaceAttributes({
  faceshape: "Oval",
  eyelid: { left_shape: "Almond", left_eyelid: "Double-lid" },
  eyebrow: { left_shape: "Soft Angled" },
  lipshape: ["Bow", "Full"],
  nose: { width: "Average", length: "Short" },
  cheekbone: { overrall: "High Cheekbone" },
  facialratio: { face_aspect_ratio: [1, 1.46] },
  agegender: { age: 32, gender: "female" },
}, actions);
if (!normalized || normalized.faceShape !== "Oval" || normalized.eyeShape !== "Almond" || normalized.proportions.faceAspectRatio?.[1] !== 1.46) {
  throw new Error("Selected provider geometry must normalize correctly.");
}
if (Object.prototype.hasOwnProperty.call(normalized, "age") || Object.prototype.hasOwnProperty.call(normalized, "gender") || Object.prototype.hasOwnProperty.call(normalized, "agegender") || JSON.stringify(normalized).includes("female")) {
  throw new Error("Age and gender output must never enter the application result model.");
}
if (!FACE_ATTRIBUTES_DISCLOSURE.includes("not an attractiveness score") || !FACE_ATTRIBUTES_DISCLOSURE.includes("age or gender estimate")) {
  throw new Error("The feature disclosure must enforce non-evaluative and sensitive-attribute boundaries.");
}

const taskClient = readFileSync("server/youcam-face-attributes.ts", "utf8");
const routeSource = readFileSync("server/routes.ts", "utf8");
const screenSource = readFileSync("app/skin/face-attributes.tsx", "utf8");
const hubSource = readFileSync("components/skin/SkinCareHub.tsx", "utf8");
if (!taskClient.includes("request_id") || !taskClient.includes("file_sets") || !taskClient.includes("dst_actions")) throw new Error("Task client must use the documented v2 request envelope.");
if (!routeSource.includes('app.post("/api/skin/face-attributes"') || !routeSource.includes("normalizeProviderFaceAttributes")) throw new Error("Server must normalize requested provider output before return.");
if (!screenSource.includes("not compared with an ideal") || !screenSource.includes("infer age or gender")) throw new Error("Mobile presentation must exclude golden-ratio scoring and sensitive estimates.");
if (!hubSource.includes('router.push("/skin/face-attributes")')) throw new Error("Face styling screen must be reachable from the Skin Care hub.");

console.log(JSON.stringify({ result: "PASS", actions, normalized, assertions: [
  "The contract excludes age and gender actions even if supplied by a client.",
  "Only selected style geometry is normalized from the provider response.",
  "Raw proportions are displayed without beauty or ideal-ratio evaluation.",
  "The documented v2 request envelope and mobile navigation are present.",
] }, null, 2));
