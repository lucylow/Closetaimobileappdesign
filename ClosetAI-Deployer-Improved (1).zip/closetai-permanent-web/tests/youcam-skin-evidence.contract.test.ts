import fs from 'node:fs';
import path from 'node:path';

const skinHubPath = path.resolve(process.cwd(), 'components/skin/SkinCareHub.tsx');
const skinHubSource = fs.readFileSync(skinHubPath, 'utf8');

const requiredMarkers = [
  'YouCam Skin Analysis, made inspectable',
  'Perfect Corp. YouCam Skin Analysis',
  'Fictional Demo Signals',
  'Normalized local summary',
  'Selected selfie + explicit consent',
  'Normalized metrics only',
  'General visual guidance; never a diagnosis',
  'not the original selfie',
  'without pretending to offer medical certainty',
];

for (const marker of requiredMarkers) {
  if (!skinHubSource.includes(marker)) {
    throw new Error(`Missing Skin YouCam evidence marker: ${marker}`);
  }
}

if (!skinHubSource.includes('accessibilityRole="summary"')) {
  throw new Error('Skin YouCam evidence must be exposed as an accessible summary.');
}

console.log('YouCam Skin evidence contract passed.');
