import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

const source = readFileSync(resolve(process.cwd(), 'server/youcam.ts'), 'utf8');

for (const required of [
  'const FASHION_RESPONSE_MAX_BYTES = 512 * 1024;',
  'async function readFashionResponseBody(response: Response)',
  'contentLength > FASHION_RESPONSE_MAX_BYTES',
  'totalBytes > FASHION_RESPONSE_MAX_BYTES',
  'await reader.cancel();',
  'function parseFashionResponseObject(body: string): Record<string, unknown> | null',
  'parsed && typeof parsed === "object" && !Array.isArray(parsed)',
  'const responseBody = await readFashionResponseBody(res);',
  'if (responseBody.tooLarge || responseBody.body === null)',
  'if (!data) return { status: res.status, ok: false, data: {} };',
]) {
  if (!source.includes(required)) throw new Error(`Bounded YouCam fashion response parser missing: ${required}`);
}

const fashionRequestStart = source.indexOf('async function fashionApiRequest');
if (fashionRequestStart === -1) throw new Error('Fashion API request wrapper is missing.');
const fashionRequestSource = source.slice(fashionRequestStart);

for (const prohibited of [
  'const text = await res.text();',
  'data = { raw: text };',
]) {
  if (fashionRequestSource.includes(prohibited)) throw new Error(`Unsafe fashion provider payload handling remains: ${prohibited}`);
}

const reader = source.indexOf('async function readFashionResponseBody(response: Response)');
const parser = source.indexOf('function parseFashionResponseObject(body: string)', reader);
const request = fashionRequestStart;
const boundedRead = source.indexOf('const responseBody = await readFashionResponseBody(res);', request);
const malformedFallback = source.indexOf('if (!data) return { status: res.status, ok: false, data: {} };', boundedRead);
if ([reader, parser, request, boundedRead, malformedFallback].some((index) => index === -1)
  || reader > parser
  || parser > request
  || request > boundedRead
  || boundedRead > malformedFallback) {
  throw new Error('Fashion provider responses must be size-bounded and object-validated before any task or upload parser uses them.');
}

console.log(JSON.stringify({
  result: 'PASS',
  assertions: [
    'Fashion provider response bodies are capped before parsing to protect server memory.',
    'Malformed, empty, array, and oversized responses become stable unavailable outcomes without retaining raw payload text.',
    'Downstream fashion task, upload, and polling fallbacks receive only safe empty response objects.',
  ],
}, null, 2));
