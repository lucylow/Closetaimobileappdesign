import { readFileSync } from "node:fs";
import { join } from "node:path";

const root = join(process.cwd());
const camera = readFileSync(join(root, "components/skin/LiveSkinCamera.tsx"), "utf8");
const history = readFileSync(join(root, "lib/skin-metric-history.native.ts"), "utf8");
const progress = readFileSync(join(root, "components/skin/SkinMetricProgressChart.tsx"), "utf8");
const context = readFileSync(join(root, "contexts/SelfieScanContext.tsx"), "utf8");

for (const expected of ["CameraView", "useCameraPermissions", "detectFacesAsync", "FaceDetectorMode.fast", "selfie-review"]) {
  if (!camera.includes(expected)) throw new Error(`Live camera integration is missing ${expected}.`);
}
for (const forbidden of ["image_uri", "raw_response", "face_mask", "base64"]) {
  if (history.toLowerCase().includes(forbidden)) throw new Error(`SQLite history must not persist ${forbidden}.`);
}
for (const expected of ["skin_metric_scans", "skin_metric_values", "saveSkinMetricHistory", "loadSkinMetricHistory"]) {
  if (!(history + context + progress).includes(expected)) throw new Error(`Expected local metric-history contract member ${expected}.`);
}
if (!progress.includes("Saved normalized scores only") || !progress.includes("Photos and raw API data are not stored here")) {
  throw new Error("Progress chart must disclose its local privacy boundary.");
}

console.log(JSON.stringify({
  result: "PASS",
  camera: "Expo Camera capture with on-device face-presence validation and manual-review fallback",
  localHistory: "SQLite stores normalized scan IDs, timestamps, source labels, overall scores, metric keys, and scores only",
  chart: "Metric-specific local progression chart with sparse-history state",
}, null, 2));
