import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

const source = readFileSync(resolve(process.cwd(), 'server/youcam.ts'), 'utf8');

for (const required of [
  'export function isSafeFashionResultUrl(value: unknown): value is string',
  'const url = new URL(value);',
  'url.protocol === "https:" && !url.username && !url.password',
  'if (status === "success" && isSafeFashionResultUrl(resultUrl))',
  'if (status === "success") return { error: "Live YouCam clothing rendering returned an unusable result." };',
  'if (["failed", "error", "cancelled"].includes(status)) return { error: "Live YouCam clothing rendering did not complete." };',
  'let encounteredTransportFailure = false;',
  'return { error: encounteredTransportFailure ? "Live YouCam clothing rendering was temporarily unavailable." : "Live YouCam clothing rendering timed out." };',
]) {
  if (!source.includes(required)) throw new Error(`Safe YouCam fashion result URL safeguard missing: ${required}`);
}

for (const prohibited of [
  'lastTransportError = `YouCam fashion task status failed (${result.status}).`',
  'return { error: data?.error || data?.error_code || "YouCam fashion task failed." }',
  'lastTransportError = error instanceof Error ? error.message',
]) {
  if (source.includes(prohibited)) throw new Error(`Raw provider detail can still escape from fashion polling: ${prohibited}`);
}

const validator = source.indexOf('export function isSafeFashionResultUrl');
const poller = source.indexOf('export async function pollFashionTryOnTask', validator);
const guardedSuccess = source.indexOf('if (status === "success" && isSafeFashionResultUrl(resultUrl))', poller);
const unusable = source.indexOf('Live YouCam clothing rendering returned an unusable result.', guardedSuccess);
const stableTransport = source.indexOf('Live YouCam clothing rendering was temporarily unavailable.', unusable);
if ([validator, poller, guardedSuccess, unusable, stableTransport].some((index) => index === -1)
  || validator > poller
  || poller > guardedSuccess
  || guardedSuccess > unusable
  || unusable > stableTransport) {
  throw new Error('Fashion output URLs must be validated before caching, with stable source-aware error recovery afterward.');
}

console.log(JSON.stringify({
  result: 'PASS',
  assertions: [
    'Only credential-free HTTPS provider result URLs can enter the completed fashion task cache.',
    'Unsafe, expired, malformed, and missing success URLs are converted to a stable unusable-result fallback.',
    'Provider transport and failure payload details do not become client-facing fallback text.',
  ],
}, null, 2));
