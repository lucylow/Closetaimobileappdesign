import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const source = readFileSync(join(root, "contexts/SelfieScanContext.tsx"), "utf8");

if (!source.includes("const [hydrated, setHydrated] = useState(false);")) {
  throw new Error("Selfie scan persistence must track whether AsyncStorage hydration has completed.");
}
if (!source.includes(".finally(() => setHydrated(true));")) {
  throw new Error("Selfie scan persistence must release the hydration guard after restore success or failure.");
}
if (!source.includes("if (!hydrated) return;")) {
  throw new Error("Selfie scan persistence must not write the initial empty state before hydration.");
}
if (!source.includes("[savedResults, hydrated]")) {
  throw new Error("Selfie scan persistence must react to restored and newly saved results after hydration.");
}

const hydrationIndex = source.indexOf(".finally(() => setHydrated(true));");
const writeGuardIndex = source.indexOf("if (!hydrated) return;");
if (hydrationIndex < 0 || writeGuardIndex < 0 || writeGuardIndex < hydrationIndex) {
  throw new Error("The persistence write guard must be declared after the restore lifecycle is established.");
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "Selfie summaries are restored before persistence writes are enabled.",
    "Hydration completes on both AsyncStorage success and failure paths.",
    "The initial empty state cannot overwrite existing local scan history.",
  ],
}, null, 2));
