import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const source = readFileSync(join(root, "components/skin/SkinScreen.tsx"), "utf8");

if (!source.includes("useFocusEffect(React.useCallback")) {
  throw new Error("The Skin Care hub must refresh photo permission state when it regains focus.");
}
if (!source.includes("ImagePicker.getCameraPermissionsAsync()") || !source.includes("ImagePicker.getMediaLibraryPermissionsAsync()")) {
  throw new Error("The Skin Care hub must check both camera and library permissions.");
}
if (!source.includes("setPhotoPermissionState(camera.granted || library.granted ? 'granted' : 'blocked')")) {
  throw new Error("The hub must combine permission state conservatively across the two photo sources.");
}
if (!source.includes("const openPhotoSettings = async () =>") || !source.includes("await Linking.openSettings();")) {
  throw new Error("The hub must expose direct device-settings recovery.");
}
if (!source.includes("Fictional Demo Mode remains available")) {
  throw new Error("The blocked-permission notice must preserve the fictional Demo Mode fallback disclosure.");
}
if (!source.includes("accessibilityLabel=\"Open photo settings\"")) {
  throw new Error("The hub settings action must be accessible.");
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "Skin Care hub permissions refresh on focus.",
    "Camera and library access are combined safely.",
    "Blocked access offers an accessible Settings action.",
    "Demo Mode remains disclosed and available without photo access.",
  ],
}, null, 2));
