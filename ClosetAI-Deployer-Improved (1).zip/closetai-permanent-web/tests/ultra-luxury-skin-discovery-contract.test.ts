import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

import {
  ULTRA_LUXURY_SKIN_DISCOVERY_DISCLOSURE,
  ULTRA_LUXURY_SKIN_DISCOVERY_RECORDS,
} from '../lib/ultra-luxury-skin-discovery';

const root = process.cwd();
const panelSource = readFileSync(resolve(root, 'components/skin/UltraLuxurySkinDiscoveryPanel.tsx'), 'utf8');
const journeySource = readFileSync(resolve(root, 'components/skin/SkinJourneyPage.tsx'), 'utf8');
const sourceRegister = readFileSync(resolve(root, 'ULTRA_LUXURY_SKIN_DISCOVERY_SOURCE_REGISTER.md'), 'utf8');
const visualRegister = readFileSync(resolve(root, 'assets/skin-products/ULTRA_LUXURY_DISCOVERY_VISUAL_SOURCES.md'), 'utf8');
const expectedBrands = ['La Prairie', 'Guerlain', 'La Mer', 'Augustinus Bader', 'MBR', 'Valmont'];
const officialHosts = ['laprairie.com', 'guerlain.com', 'cremedelamer.com', 'augustinusbader.com', 'mbrcare.com', 'lamaisonvalmont.com'];

if (ULTRA_LUXURY_SKIN_DISCOVERY_RECORDS.length < 12) {
  throw new Error('Ultra-luxury skin-care discovery must provide at least twelve source-labeled external reference records.');
}
if (!ULTRA_LUXURY_SKIN_DISCOVERY_DISCLOSURE.includes('mock discovery data') || !ULTRA_LUXURY_SKIN_DISCOVERY_DISCLOSURE.includes('live price, inventory, checkout, medical advice')) {
  throw new Error('Ultra-luxury skin-care discovery must retain its explicit mock-commerce and non-medical boundary.');
}
for (const brand of expectedBrands) {
  if (!ULTRA_LUXURY_SKIN_DISCOVERY_RECORDS.some((record) => record.brand === brand)) {
    throw new Error(`Ultra-luxury discovery must include ${brand}.`);
  }
}
for (const record of ULTRA_LUXURY_SKIN_DISCOVERY_RECORDS) {
  const url = new URL(record.officialUrl);
  if (url.protocol !== 'https:' || !officialHosts.some((host) => url.hostname.endsWith(host))) {
    throw new Error(`${record.id} must point to an HTTPS official brand destination.`);
  }
  if (!record.externalOnly || record.dataMode !== 'mock-discovery' || !record.disclosure.includes('not affiliated')) {
    throw new Error(`${record.id} must remain external-only mock discovery data.`);
  }
  if (!record.genericVisualUrl.includes('files.manuscdn.com') || !record.imageDisclosure.includes('not official brand photography')) {
    throw new Error(`${record.id} must use a separately disclosed generic visual rather than copied product photography.`);
  }
  if (!record.productName || !record.discoveryFocus || !record.officialSourceLabel) {
    throw new Error(`${record.id} must carry detailed discovery context.`);
  }
}
if (!sourceRegister.includes('La Prairie') || !sourceRegister.includes('Guerlain') || !sourceRegister.includes('MBR') || !sourceRegister.includes('Valmont')) {
  throw new Error('The official-source register must retain all six requested ultra-luxury discovery brands.');
}
if (!visualRegister.includes('generic, non-branded still-life') || !visualRegister.includes('not representations of real listings')) {
  throw new Error('The visual source register must state that generic discovery visuals are not brand product photography or commerce data.');
}
if (!panelSource.includes('ULTRA_LUXURY_SKIN_DISCOVERY_DISCLOSURE') || !panelSource.includes('Linking.openURL') || !panelSource.includes('external official brand destination')) {
  throw new Error('The discovery panel must expose an accessible official-link flow with its disclosure.');
}
if (!journeySource.includes('UltraLuxurySkinDiscoveryPanel') || !journeySource.includes('Verified routine references')) {
  throw new Error('The Skin Journey product flow must keep verified routine references separate from ultra-luxury discovery data.');
}

console.log(JSON.stringify({
  result: 'PASS',
  brandCount: expectedBrands.length,
  recordCount: ULTRA_LUXURY_SKIN_DISCOVERY_RECORDS.length,
  assertions: [
    'Ultra-luxury discovery covers all six requested brands with official HTTPS destinations.',
    'Records retain generic non-branded visuals and explicit non-commerce and non-medical disclosure.',
    'Skin Journey keeps verified routine products separate from optional external luxury discovery.',
  ],
}, null, 2));
