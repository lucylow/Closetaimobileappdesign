import fs from 'node:fs';
import path from 'node:path';

const file = path.resolve(process.cwd(), 'app/(tabs)/tryon.tsx');
const source = fs.readFileSync(file, 'utf8');

for (const marker of [
  'Live provider path stopped here.',
  'Retry is available;',
  'no fictional result or stock model was substituted.',
  '!demoMode',
  'accessibilityRole="alert"',
  'accessibilityLabel="Retry virtual try-on request"',
]) {
  if (!source.includes(marker)) throw new Error(`Missing live Fashion failure boundary marker: ${marker}`);
}

console.log('Live Fashion failure boundary contract passed.');
