import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const root = process.cwd();
const shared = readFileSync(resolve(root, "shared/closetai-agent-contracts.ts"), "utf8");
const coordinator = readFileSync(resolve(root, "server/closetai-agents.ts"), "utf8");
const routes = readFileSync(resolve(root, "server/routes.ts"), "utf8");
const client = readFileSync(resolve(root, "lib/closetai-agents.ts"), "utf8");
const studio = readFileSync(resolve(root, "app/agents.tsx"), "utf8");
const home = readFileSync(resolve(root, "app/(tabs)/index.tsx"), "utf8");
const skinHub = readFileSync(resolve(root, "components/skin/SkinCareHub.tsx"), "utf8");

for (const required of [
  'CLOSET_AGENT_IDS = ["fashion", "skincare"]',
  "FASHION_AGENT_DISCLOSURE",
  "SKINCARE_AGENT_DISCLOSURE",
  "AGENT_BLOCKED_LANGUAGE",
  "saved_normalized_skin_summary",
  "external_category_reference",
]) {
  if (!shared.includes(required)) throw new Error(`Agent contract must retain: ${required}`);
}

for (const blocked of ["diagnose", "treat", "prescription", "guarantee", "in stock", "checkout"]) {
  if (!shared.includes(`"${blocked}"`)) throw new Error(`Agent safety contract must block: ${blocked}`);
}

for (const required of [
  "function fashionFallback",
  "function skincareFallback",
  "function hasBlockedLanguage",
  "function planFromDraft",
  "const hasLiveModel = Boolean(process.env.AI_INTEGRATIONS_OPENAI_API_KEY?.trim())",
  "apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY || \"not-configured\"",
  "input.includeLatestNormalizedSummary",
]) {
  if (!coordinator.includes(required)) throw new Error(`Agent coordinator must retain: ${required}`);
}

if (coordinator.includes("EXPO_PUBLIC_")) {
  throw new Error("Agent coordinator must not receive provider credentials through Expo public variables.");
}
if (coordinator.includes("imageBase64") || coordinator.includes("imageUri")) {
  throw new Error("Agent coordinator must not accept original image data or image URIs.");
}

for (const required of ["app.post(\"/api/agents/plan\", authenticateToken", "createClosetAgentPlan", "body.prompt.length > 360"]) {
  if (!routes.includes(required)) throw new Error(`Agent endpoint must retain: ${required}`);
}
if (client.includes("EXPO_PUBLIC_") || !client.includes('apiRequest("POST", "/api/agents/plan", request)')) {
  throw new Error("Mobile agent client must use the existing authenticated API helper and no public credential.");
}

for (const required of [
  "Fashion Look Planner",
  "Skin Routine Companion",
  "includeLatestNormalizedSummary: includeSummary",
  "Original photos are not sent to this agent.",
  "accessibilityRole=\"tab\"",
  "accessibilityState={{ disabled: isLoading, busy: isLoading }}",
  "LOCAL PLANNING FALLBACK",
]) {
  if (!studio.includes(required)) throw new Error(`Agent Studio must retain: ${required}`);
}
if (studio.includes("ImagePicker") || studio.includes("expo-camera") || studio.includes("imageBase64")) {
  throw new Error("Agent Studio must not introduce a new photo-collection or raw-image path.");
}

for (const [name, source] of [["Home", home], ["Skin Care hub", skinHub]] as const) {
  if (!source.includes("pathname: '/agents'") && !source.includes('pathname: "/agents"')) {
    throw new Error(`${name} must route into the integrated Agent Studio.`);
  }
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "Fashion Look Planner and Skin Routine Companion are distinct specialist agents.",
    "Credential handling is server-only and agent inputs exclude original images.",
    "Both live-output and deterministic fallback paths pass a blocked-language and identifier gate.",
    "Skincare planning remains general cosmetic guidance with explicit non-diagnostic boundaries.",
    "Home and Skin Care provide accessible, integrated Agent Studio entry points.",
  ],
}, null, 2));
