import fs from 'node:fs';
import path from 'node:path';

const tryOnPath = path.resolve(process.cwd(), 'app/(tabs)/tryon.tsx');
const tryOnSource = fs.readFileSync(tryOnPath, 'utf8');

const requiredMarkers = [
  'IMPLEMENTATION PATH',
  'YouCam fashion rendering, made inspectable',
  'Perfect Corp. YouCam AI Clothes',
  'Fictional Demo Mode',
  'Selected-photo-safe path',
  'Your photo + wardrobe garment references',
  'Temporary visualization, not a fit or size guarantee',
  'no provider result',
  'will not present a fake live result',
  'Consumer value: preview a candidate look',
];

for (const marker of requiredMarkers) {
  if (!tryOnSource.includes(marker)) {
    throw new Error(`Missing provider-evidence marker: ${marker}`);
  }
}

if (!tryOnSource.includes("router.push('/tryon/shoes')")) {
  throw new Error('The try-on flow must retain the dedicated AI Shoes route.');
}

console.log('YouCam provider-evidence contract passed.');
