import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const source = readFileSync(join(root, "app/(tabs)/tryon.tsx"), "utf8");

if (!source.includes("const retryTryOnAfterError = () =>")) {
  throw new Error("Fashion try-on must expose a native retry handler for recoverable errors.");
}
if (!source.includes("setResultUri(null);") || !source.includes("setShowComparison(false);")) {
  throw new Error("Fashion try-on retry must clear stale result and comparison state before rerunning.");
}
if (!source.includes("void handleTryOn();")) {
  throw new Error("Fashion try-on retry must rerun the existing selected-photo request lifecycle.");
}
if (!source.includes("accessibilityLabel=\"Retry fashion try-on\"")) {
  throw new Error("Fashion try-on retry must be accessible to assistive technologies.");
}
if (!source.includes("Retries the selected-photo try-on without changing your photo or garments.")) {
  throw new Error("Fashion try-on retry must preserve and disclose the selected user photo and garment context.");
}
if (!source.includes("{!!selfieUri && selectedGarments.length > 0 && !isProcessing && (")) {
  throw new Error("Fashion try-on retry must only appear when the selected user photo and garments remain available.");
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "Fashion try-on retry clears stale result state.",
    "Fashion try-on retry reuses the existing request lifecycle and selected media.",
    "Fashion try-on retry is accessible and context-aware.",
  ],
}, null, 2));
