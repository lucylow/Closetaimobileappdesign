import { normalizeSkinSnapshot, demoSkinSnapshot } from "../shared/skin";
import { normalizeAbsFilterMode, normalizeAbsFilterIntensity, normalizeProviderAbsFilterSimulation } from "../shared/abs-filter-simulation";

console.log("Validating skincare & AR simulation contracts...");

const snapshot = normalizeSkinSnapshot(demoSkinSnapshot, "test-id-1");
if (!snapshot || snapshot.id !== "test-id-1") {
  throw new Error("Skin snapshot normalization failed");
}

if (normalizeAbsFilterMode("Six-pack") !== "Six-pack" || normalizeAbsFilterMode("invalid") !== null) {
  throw new Error("Abs filter mode normalization failed");
}

if (normalizeAbsFilterIntensity(1) !== 1 || normalizeAbsFilterIntensity(99) !== null) {
  throw new Error("Abs filter intensity normalization failed");
}

const fallback = normalizeProviderAbsFilterSimulation({ url: "https://example.com/abs.jpg" }, "Six-pack", 1);
if (!fallback || !fallback.resultUrl.includes("example.com")) {
  throw new Error("Abs filter simulation normalization failed");
}

console.log("All skincare & AR simulation contracts validated successfully!");
