import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const paywall = readFileSync(resolve(process.cwd(), "components/MonetizationPaywall.tsx"), "utf8");
const agents = readFileSync(resolve(process.cwd(), "app/agents.tsx"), "utf8");
const dashboard = readFileSync(resolve(process.cwd(), "app/business-dashboard.tsx"), "utf8");
const subscription = readFileSync(resolve(process.cwd(), "app/subscription.tsx"), "utf8");

for (const required of [
  "const TIER_RANK: Record<string, number> = { free: 0, pro: 1, enterprise: 2 }",
  "export function hasRequiredTier(currentTier: string, requiredTier: PremiumTier): boolean",
  "router.push({ pathname: '/subscription', params: { source } })",
  "Payment is not collected or confirmed from this paywall.",
  "It does not collect card, wallet, address, or payment details, and it does not confirm a charge.",
  "accessibilityLabel={`Review ${tierLabel} plans`}",
]) {
  if (!paywall.includes(required)) throw new Error(`Paywall safety or access contract missing: ${required}`);
}

for (const required of [
  "const hasProAccess = hasRequiredTier(subscriptionTier, \"pro\")",
  "if (!hasProAccess)",
  "requiredTier=\"pro\"",
  "source=\"agent_studio\"",
  "Use free outfit tools",
]) {
  if (!agents.includes(required)) throw new Error(`Agent premium-gate contract missing: ${required}`);
}

for (const required of [
  "const hasEnterpriseAccess = hasRequiredTier(subscriptionTier, 'enterprise')",
  "if (!hasEnterpriseAccess)",
  "requiredTier=\"enterprise\"",
  "source=\"brand_analytics\"",
  "Return to wardrobe",
]) {
  if (!dashboard.includes(required)) throw new Error(`Enterprise analytics paywall contract missing: ${required}`);
}

for (const required of [
  "const { source } = useLocalSearchParams<{ source?: string }>()",
  "if (upgradeInFlightRef.current) return",
  "accessibilityState={{ disabled: isProcessing, busy: isProcessing }}",
]) {
  if (!subscription.includes(required)) throw new Error(`Subscription plan-review contract missing: ${required}`);
}

if (!subscription.includes("Plan preview updated") && !subscription.includes("Plan updated")) {
  throw new Error("Subscription plan-review contract missing success notification check.");
}

for (const forbidden of ["TextInput", "card number", "CVV", "submitPayment", "confirmPayment"]) {
  if (paywall.includes(forbidden)) throw new Error(`Paywall must not contain client-side payment collection or confirmation: ${forbidden}`);
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "Pro and Enterprise feature routes enforce tier-aware client presentation gates.",
    "Paywall controls only open plan review and never collect, submit, or confirm payment data.",
    "Agent Studio and brand analytics retain accessible free-tool escape routes.",
    "Subscription plan review clearly labels local demo entitlement preview behavior and guards duplicate actions.",
  ],
}, null, 2));
