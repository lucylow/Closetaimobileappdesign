import fs from 'node:fs';
import path from 'node:path';

const file = path.resolve(process.cwd(), 'app/(tabs)/index.tsx');
const source = fs.readFileSync(file, 'utf8');

for (const marker of [
  'WHY THIS MATTERS',
  'AR that starts with the closet, not the catalog.',
  'For people who own plenty but still default to the same few looks',
  'preview only with a photo you choose',
  'Distinctive idea: YouCam visualization is connected to personal wardrobe context',
  'accessibilityRole="summary"',
]) {
  if (!source.includes(marker)) throw new Error(`Missing Home impact-and-idea marker: ${marker}`);
}

if (!source.includes('no stock model is substituted for you')) {
  throw new Error('Home narrative must retain the user-photo-only boundary.');
}

if (!source.includes("demoMode ? 'Demo / offline' : 'Live / retryable'")) {
  throw new Error('Home narrative must preserve explicit Demo/Live mode labeling.');
}

console.log('Home impact-and-idea contract passed.');
