import { readFileSync } from "node:fs";
import { AI_SHOES_TRYON_DISCLOSURE, normalizeAiShoesRenderingSetting, normalizeAiShoesRenderStyle, normalizeProviderAiShoesTryOn } from "../shared/ai-shoes-tryon";

if (normalizeAiShoesRenderStyle("random") !== "random" || normalizeAiShoesRenderStyle("style_retro_fashion") !== "style_retro_fashion" || normalizeAiShoesRenderStyle("style_unknown") !== null) {
  throw new Error("Only documented AI Shoes render styles may be selected.");
}
if (normalizeAiShoesRenderingSetting("female") !== "female" || normalizeAiShoesRenderingSetting("male") !== "male" || normalizeAiShoesRenderingSetting("unknown") !== null) {
  throw new Error("Provider rendering setting must be an explicit documented selection and fail closed for other values.");
}
const normalized = normalizeProviderAiShoesTryOn({ results: { url: "https://example.com/temporary-shoe-preview.jpg" }, inferredGender: "female" }, "style_minimalist", "female");
if (!normalized || normalized.resultUrl !== "https://example.com/temporary-shoe-preview.jpg" || normalized.style !== "style_minimalist" || normalized.renderingSetting !== "female" || normalized.expiresInHours !== 2) {
  throw new Error("Only a temporary secure URL and user-selected documented rendering controls may normalize.");
}
if (JSON.stringify(normalized).includes("inferredGender") || normalizeProviderAiShoesTryOn({ url: "http://unsafe.example.com/shoes.jpg" }, "random", "male") !== null) {
  throw new Error("Provider inference data and insecure result URLs must never enter app state.");
}
if (!AI_SHOES_TRYON_DISCLOSURE.includes("never infers it from an image") || !AI_SHOES_TRYON_DISCLOSURE.includes("not saved to history") || !AI_SHOES_TRYON_DISCLOSURE.includes("No stock model or fallback")) {
  throw new Error("Shoe try-on disclosure must preserve no-inference, temporary, user-photo-only, and no-fallback boundaries.");
}

const taskClient = readFileSync("server/youcam-shoes.ts", "utf8");
const routeSource = readFileSync("server/routes.ts", "utf8");
const screenSource = readFileSync("app/tryon/shoes.tsx", "utf8");
const tabSource = readFileSync("app/(tabs)/tryon.tsx", "utf8");
if (!taskClient.includes('"/s2s/v2.0/task/shoes"') || !taskClient.includes("src_file_id") || !taskClient.includes("ref_file_id") || !taskClient.includes("gender: renderingSetting") || !taskClient.includes("/s2s/v2.0/task/shoes/${encodeURIComponent(taskId)}")) {
  throw new Error("AI Shoes task client must use documented target/reference file IDs, explicit provider setting, and task endpoints.");
}
if (!routeSource.includes('app.post("/api/fashion/shoes-tryon"') || !routeSource.includes("targetPhotoConfirmed !== true") || !routeSource.includes("referenceConfirmed !== true") || !routeSource.includes("consent !== true")) {
  throw new Error("AI Shoes route must require target ownership, single-user, reference, and explicit try-on consent gates.");
}
if (!screenSource.includes("No stock model is ever substituted") || !screenSource.includes("does not infer it from your photo") || !screenSource.includes("No image was shown") || !screenSource.includes("not a fit, size, comfort, purchase")) {
  throw new Error("Expo screen must retain user-photo-only, no-inference, no-fallback, and no-fit-guarantee boundaries.");
}
if (!tabSource.includes("router.push('/tryon/shoes')")) throw new Error("AI Shoes flow must be reachable from the primary Try-On tab.");

console.log(JSON.stringify({ result: "PASS", normalized, assertions: [
  "Only official styles and a user-selected provider rendering setting are accepted.",
  "The result model omits provider inference fields and only permits temporary HTTPS provider output.",
  "The server requires user-owned target confirmation, shoe-reference confirmation, and explicit try-on consent.",
  "The dedicated experience is reachable from fashion Try-On and never substitutes a stock model or fallback image.",
] }, null, 2));
