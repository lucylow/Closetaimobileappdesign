import { readFileSync } from "node:fs";
import { resolve } from "node:path";

import {
  cloneFictionalAdultWomenDemoExample,
  fictionalAdultWomenDemoExamples,
  FICTIONAL_ADULT_WOMEN_DEMO_DISCLOSURE,
  FICTIONAL_DEMO_GARMENT_REFERENCE_IMAGES,
} from "../lib/demo-data";
import { buildWardrobeRecommendations } from "../shared/outfit-recommendations";

const root = process.cwd();
const contextSource = readFileSync(resolve(root, "contexts/AppContext.tsx"), "utf8");
const wardrobeSource = readFileSync(resolve(root, "app/(tabs)/wardrobe.tsx"), "utf8");
const tryOnSource = readFileSync(resolve(root, "app/(tabs)/tryon.tsx"), "utf8");
const assetSourceRegister = readFileSync(resolve(root, "assets/demo-garments/ASSET_SOURCES.md"), "utf8");

if (fictionalAdultWomenDemoExamples.length < 5) {
  throw new Error("The fictional adult women’s demo catalog must offer at least five example wardrobes.");
}
if (FICTIONAL_DEMO_GARMENT_REFERENCE_IMAGES.length < 11 || !assetSourceRegister.includes("generic garment-only")) {
  throw new Error("The expanded garment-only image catalog and its source register must both be retained.");
}
if (!FICTIONAL_ADULT_WOMEN_DEMO_DISCLOSURE.includes("Fictional adult women’s style examples") || !FICTIONAL_ADULT_WOMEN_DEMO_DISCLOSURE.includes("not user photos")) {
  throw new Error("The demo catalog disclosure must clearly identify the examples as fictional and distinguish garment media from user photos.");
}

for (const example of fictionalAdultWomenDemoExamples) {
  if (example.audienceLabel !== "Fictional adult women’s style example") {
    throw new Error(`Example ${example.id} is missing the explicit fictional adult women’s label.`);
  }
  if (!example.styleContext || example.wardrobe.length < 9) {
    throw new Error(`Example ${example.id} must include a meaningful style context and a complete wardrobe.`);
  }
  if (example.wardrobe.some((item) => !item.tags.includes("fictional-demo") || !item.notes.includes("Fictional Demo Mode"))) {
    throw new Error(`Every item in ${example.id} must preserve per-item fictional-demo labeling.`);
  }
  if (example.wardrobe.some((item) => !item.imageUrl.startsWith("https://images.unsplash.com/") && !FICTIONAL_DEMO_GARMENT_REFERENCE_IMAGES.includes(item.imageUrl as (typeof FICTIONAL_DEMO_GARMENT_REFERENCE_IMAGES)[number]))) {
    throw new Error(`Example ${example.id} contains an unsupported garment reference image source.`);
  }
  const recommendations = buildWardrobeRecommendations(example.wardrobe.map((item) => ({
    id: item.id,
    name: item.name,
    category: item.category,
    color: item.color,
    tags: item.tags,
    usageCount: item.usageCount,
    lastWornAt: item.lastWorn,
  })));
  if (recommendations.length === 0 || recommendations.some((look) => look.itemIds.some((id) => !example.wardrobe.some((item) => item.id === id)))) {
    throw new Error(`Example ${example.id} must support outfit suggestions that only use its own labeled wardrobe items.`);
  }
}

const expandedImageExamples = fictionalAdultWomenDemoExamples.filter((example) => example.wardrobe.some((item) => FICTIONAL_DEMO_GARMENT_REFERENCE_IMAGES.includes(item.imageUrl as (typeof FICTIONAL_DEMO_GARMENT_REFERENCE_IMAGES)[number])));
if (expandedImageExamples.length < 2) {
  throw new Error("At least two fictional example wardrobes must use the expanded generic garment-image catalog.");
}

const original = fictionalAdultWomenDemoExamples[0];
const cloned = cloneFictionalAdultWomenDemoExample(original.id);
if (!cloned || cloned === original || cloned.wardrobe === original.wardrobe || cloned.wardrobe[0] === original.wardrobe[0]) {
  throw new Error("Loading an example must clone catalog records before placing them in the local demo collection.");
}
cloned.wardrobe[0].tags.push("mutation-check");
if (original.wardrobe[0].tags.includes("mutation-check")) {
  throw new Error("A loaded demo example must not mutate the source fixture.");
}

if (!contextSource.includes("if (!demoMode)") || !contextSource.includes("Fictional example wardrobes are available only while Demo Mode is active")) {
  throw new Error("The example loader must be restricted to Demo Mode.");
}
if (!contextSource.includes("loadFictionalAdultWomenDemoExample") || !contextSource.includes("persistWardrobe(example.wardrobe)")) {
  throw new Error("The selected fictional example must be explicitly loaded into local wardrobe state.");
}
if (!wardrobeSource.includes("isCatalogEmpty && demoMode") || !wardrobeSource.includes("Fictional adult women’s demo examples") || !wardrobeSource.includes('accessibilityRole="radio"') || !wardrobeSource.includes('accessibilityRole="radiogroup"')) {
  throw new Error("Wardrobe must show an explicitly labeled accessible radio-group chooser only for an empty Demo Mode collection.");
}
if (!wardrobeSource.includes("handleDemoChoiceKeyDown") || !wardrobeSource.includes("ArrowRight") || !wardrobeSource.includes("ArrowLeft") || !wardrobeSource.includes("'Home'") || !wardrobeSource.includes("'End'")) {
  throw new Error("The web demo chooser must retain arrow-key and Home/End selection navigation.");
}
if (!wardrobeSource.includes('accessibilityLiveRegion="polite"') || !wardrobeSource.includes("selected. ${selectedDemoExample.styleContext}") || !wardrobeSource.includes("Tab to this control and press Enter or Space")) {
  throw new Error("The demo chooser must announce selection changes and document keyboard activation for its load action.");
}
if (!tryOnSource.includes("never substitutes a stock model")) {
  throw new Error("Adding fictional wardrobe examples must not weaken the user-photo-only Try-On guarantee.");
}

console.log(JSON.stringify({
  result: "PASS",
  examples: fictionalAdultWomenDemoExamples.map((example) => ({ id: example.id, itemCount: example.wardrobe.length })),
  assertions: [
    "Five opt-in, clearly fictional adult women’s wardrobe examples are available.",
    "Each example uses labeled generic garment reference media; the expanded catalog has a recorded source register and supports wardrobe-only outfit recommendations.",
    "The chooser is Demo Mode-only, announces selection changes, supports arrow/Home/End navigation on web, and does not alter the user-photo-only virtual Try-On boundary.",
  ],
}, null, 2));
