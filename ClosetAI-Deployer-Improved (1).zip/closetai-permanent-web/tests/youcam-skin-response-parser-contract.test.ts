import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

const source = readFileSync(resolve(process.cwd(), 'server/youcam.ts'), 'utf8');

for (const required of [
  'const YOUCAM_RESPONSE_MAX_BYTES = 512 * 1024;',
  'async function readYouCamResponseBody(response: Response)',
  'contentLength > YOUCAM_RESPONSE_MAX_BYTES',
  'totalBytes > YOUCAM_RESPONSE_MAX_BYTES',
  'await reader.cancel();',
  'function parseYouCamResponseObject(body: string): Record<string, any> | null',
  'parsed && typeof parsed === "object" && !Array.isArray(parsed)',
  'const responseBody = await readYouCamResponseBody(res);',
  'if (responseBody.tooLarge || responseBody.body === null)',
  'if (!data) return { status: res.status, ok: false, data: {} };',
  'const completedSkinTaskCache = new BoundedTtlCache<Record<string, unknown>>(40);',
]) {
  if (!source.includes(required)) throw new Error(`Bounded YouCam skin response handling missing: ${required}`);
}

const authStart = source.indexOf('async function authenticate()');
const requestStart = source.indexOf('async function apiRequest(');
if ([authStart, requestStart].some((index) => index === -1) || authStart > requestStart) {
  throw new Error('Expected legacy YouCam authentication and request wrappers are missing.');
}

const authSource = source.slice(authStart, requestStart);
const requestSource = source.slice(requestStart, source.indexOf('export async function testApiKey()', requestStart));
for (const unsafe of ['await res.text()', 'JSON.stringify(json)', 'data: { raw: text }']) {
  if (authSource.includes(unsafe) || requestSource.includes(unsafe)) {
    throw new Error(`Legacy YouCam response parsing still retains unsafe provider payload text: ${unsafe}`);
  }
}

const reader = source.indexOf('async function readYouCamResponseBody(response: Response)');
const parser = source.indexOf('function parseYouCamResponseObject(body: string)', reader);
const authBoundedRead = source.indexOf('const responseBody = await readYouCamResponseBody(res);', authStart);
const requestBoundedRead = source.indexOf('const responseBody = await readYouCamResponseBody(res);', requestStart);
const malformedFallback = source.indexOf('if (!data) return { status: res.status, ok: false, data: {} };', requestBoundedRead);
if ([reader, parser, authBoundedRead, requestBoundedRead, malformedFallback].some((index) => index === -1)
  || reader > parser
  || parser > authStart
  || authStart > authBoundedRead
  || requestStart > requestBoundedRead
  || requestBoundedRead > malformedFallback) {
  throw new Error('YouCam skin responses must be bounded and object-validated before authentication or skin task handling consumes them.');
}

console.log(JSON.stringify({
  result: 'PASS',
  assertions: [
    'Legacy YouCam skin-response bodies are size-bounded before parsing to protect server memory.',
    'Malformed, empty, array, and oversized provider responses become stable unavailable outcomes without retaining raw payload text.',
    'Skin-task cache capacity is bounded and upstream provider response details cannot become client-facing error messages.',
  ],
}, null, 2));
