import fs from 'node:fs';
import path from 'node:path';

const file = path.resolve(process.cwd(), 'app/(tabs)/tryon.tsx');
const source = fs.readFileSync(file, 'utf8');

for (const marker of [
  'What would you like to decide next?',
  'Plan this look',
  'Review a gap',
  "router.replace('/outfits')",
  "params: { intent: 'retail-gap' }",
  'does not claim fit, stock, price, or purchase certainty',
  'accessibilityRole="summary"',
]) {
  if (!source.includes(marker)) throw new Error(`Missing consumer decision bar marker: ${marker}`);
}

if (!source.includes('your existing wardrobe context')) {
  throw new Error('The planning action must preserve the user wardrobe context.');
}

if (!source.includes('without fabricated products or purchase claims')) {
  throw new Error('The bounded retail action must avoid fabricated commerce claims.');
}

console.log('Try-on consumer decision bar contract passed.');
