import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const source = readFileSync(resolve(process.cwd(), "components/skin/LiveSkinCamera.tsx"), "utf8");

for (const required of [
  "useFocusEffect",
  "Camera.getCameraPermissionsAsync()",
  "Open camera settings",
  "const captureRunRef = React.useRef(0);",
  "const isCurrentCapture = () => captureRunRef.current === runId;",
  "if (!isCurrentCapture()) return;",
  "const cancelCapture = () =>",
  "Cancel live AR capture",
  "Capture cancelled. The camera stream remains local and no frame was sent for review.",
  "cameraPermissionGranted",
]) {
  if (!source.includes(required)) throw new Error(`Live AR recovery safeguard missing: ${required}`);
}

for (const boundary of [
  "The camera stream is not stored.",
  "Only the photo you approve continues to the optional scan flow.",
  "It does not analyse your skin or change the captured photo.",
  "The live camera stream is not stored. You review the captured photo before it can continue.",
]) {
  if (!source.includes(boundary)) throw new Error(`Live AR privacy boundary missing: ${boundary}`);
}

if (!source.includes("FaceDetector.FaceDetectorMode.fast") || !source.includes("selfie-review")) {
  throw new Error("Live AR must retain on-device face-presence review before continuing to the selfie flow.");
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "Live AR refreshes permission state on focus and offers device Settings recovery.",
    "Capture and face-detection results are identity-guarded against cancellation and unmount.",
    "The camera remains optional, local, user-photo-only, and non-diagnostic.",
  ],
}, null, 2));
