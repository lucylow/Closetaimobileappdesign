import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const source = readFileSync(resolve(process.cwd(), "app/skin/ai-smile.tsx"), "utf8");

for (const required of [
  "const requestIdRef = React.useRef(0);",
  "const selectedExpressionType = expressionType;",
  "asset.uri !== selectedAssetUri",
  "expressionType !== selectedExpressionType",
  "const cancelPreview = () =>",
  "Cancel AI smile preview",
  "Smile visualization cancelled. No generated image was shown or saved.",
  "Retry AI smile preview",
  "same selected photo, expression style, and consent",
  "accessibilityRole=\"progressbar\"",
]) {
  if (!source.includes(required)) throw new Error(`AI Smile AR recovery safeguard missing: ${required}`);
}

for (const boundary of [
  "containing only you",
  "will not infer your mood or substitute a stock image",
  "not an assessment of my emotions, mood, identity, health, or attractiveness",
  "not written to your skin-scan history",
  "not an emotion assessment or a promise of a real-world outcome",
]) {
  if (!source.includes(boundary)) throw new Error(`AI Smile AR safety boundary missing: ${boundary}`);
}

if (!source.includes("disabled={busy || !consent}") || !source.includes("No image was shown.")) {
  throw new Error("AI Smile generation must remain consent-gated and fail without fabricating a preview.");
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "AI Smile generation is identity-guarded against cancellation, unmount, changed selfie, and changed expression style.",
    "Provider failures expose an accessible in-screen retry using the same selected context.",
    "The feature remains user-photo-only, consent-gated, non-diagnostic, and non-inferential.",
  ],
}, null, 2));
