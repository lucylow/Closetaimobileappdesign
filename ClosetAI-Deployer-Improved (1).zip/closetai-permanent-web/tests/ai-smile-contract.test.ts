import { readFileSync } from "node:fs";
import { AI_SMILE_DISCLOSURE, normalizeAiSmileExpressionType, normalizeProviderAiSmile } from "../shared/ai-smile";

if (normalizeAiSmileExpressionType("smile_with_teeth_visible") !== "smile_with_teeth_visible" || normalizeAiSmileExpressionType("closed_mouth_smile") !== "closed_mouth_smile") {
  throw new Error("Both documented AI Smile expression types must be supported.");
}
if (normalizeAiSmileExpressionType("wide_smile") !== null || normalizeAiSmileExpressionType(1) !== null) {
  throw new Error("Undocumented smile expression types must fail closed.");
}
const normalized = normalizeProviderAiSmile({ url: "https://example.com/temporary-smile-preview.jpg", emotion: "sad" }, "closed_mouth_smile");
if (!normalized || normalized.resultUrl !== "https://example.com/temporary-smile-preview.jpg" || normalized.expressionType !== "closed_mouth_smile" || normalized.expiresInHours !== 2) {
  throw new Error("Only a secure temporary provider result URL and selected documented expression type may be normalized.");
}
if (JSON.stringify(normalized).includes("sad") || normalizeProviderAiSmile({ url: "http://unsafe.example.com/preview.jpg" }, "closed_mouth_smile") !== null) {
  throw new Error("Emotion data and insecure provider URLs must not enter application state.");
}
if (!AI_SMILE_DISCLOSURE.includes("does not assess your emotions") || !AI_SMILE_DISCLOSURE.includes("not saved to history") || !AI_SMILE_DISCLOSURE.includes("No stock or fallback")) {
  throw new Error("AI Smile disclosure must preserve no-emotion-assessment, temporary, and no-fallback boundaries.");
}

const taskClient = readFileSync("server/youcam-ai-smile.ts", "utf8");
const routeSource = readFileSync("server/routes.ts", "utf8");
const screenSource = readFileSync("app/skin/ai-smile.tsx", "utf8");
const hubSource = readFileSync("components/skin/SkinCareHub.tsx", "utf8");
if (!taskClient.includes('"/s2s/v2.0/task/ai-smile"') || !taskClient.includes("expression_type") || !taskClient.includes("src_file_id") || !taskClient.includes("/s2s/v2.0/task/ai-smile/${encodeURIComponent(taskId)}")) {
  throw new Error("AI Smile client must use the documented creation/status endpoints, source file ID, and expression type.");
}
if (!routeSource.includes('app.post("/api/skin/ai-smile"') || !routeSource.includes("consent !== true") || !routeSource.includes("normalizeAiSmileExpressionType")) {
  throw new Error("AI Smile route must require explicit consent and validate the documented expression type.");
}
if (!screenSource.includes("not an assessment of my emotions, mood, identity, health, or attractiveness") || !screenSource.includes("will not infer your mood") || !screenSource.includes("No image was shown")) {
  throw new Error("Expo screen must retain user-photo-only, non-inference, and no-fallback presentation boundaries.");
}
if (!hubSource.includes('router.push("/skin/ai-smile")')) throw new Error("AI Smile screen must be reachable from the canonical Skin Care hub.");

console.log(JSON.stringify({ result: "PASS", normalized, assertions: [
  "Only the two documented expression styles are accepted.",
  "Temporary provider output retains no emotion, mood, identity, or attractiveness inference.",
  "Explicit consent is server-enforced and the app displays no stock or fabricated fallback image.",
  "The canonical Skin Care hub exposes the user-photo-only AI Smile workflow.",
] }, null, 2));
