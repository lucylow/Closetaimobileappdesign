import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const source = readFileSync(resolve(process.cwd(), "app/skin/texture-preview.tsx"), "utf8");

for (const required of [
  "useFocusEffect",
  "ImagePicker.getCameraPermissionsAsync()",
  "ImagePicker.getMediaLibraryPermissionsAsync()",
  "const [photoPermissions, setPhotoPermissions]",
  "const [lastPermissionSource, setLastPermissionSource]",
  "Photo access is currently unavailable",
  "Open photo access settings",
  "Open Settings",
  "No stock model is substituted.",
  "No user photo selected",
  "Waiting for visual-preview consent",
  "Original photo view active",
  "Local visual overlay ready",
  "No product formula or treatment result is simulated.",
]) {
  if (!source.includes(required)) throw new Error(`Texture-preview AR recovery safeguard missing: ${required}`);
}

for (const boundary of [
  "A photo is optional.",
  "The selected image stays in this local preview",
  "ClosetAI does not upload it or save a history entry.",
  "this is a cosmetic-style visualization only",
  "This does not compare treatment results.",
]) {
  if (!source.includes(boundary)) throw new Error(`Texture-preview AR privacy boundary missing: ${boundary}`);
}

if (!source.includes("setPhotoPermissions((current) => ({ ...current, [source]: permission.granted }))")) {
  throw new Error("Texture-preview AR must refresh permission state after an access request.");
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "Texture preview refreshes camera and library permissions on focus.",
    "Denied access exposes an accessible device Settings recovery path and keeps photo selection optional.",
    "The local AR overlay remains user-photo-only, non-uploading, non-diagnostic, and non-predictive.",
  ],
}, null, 2));
