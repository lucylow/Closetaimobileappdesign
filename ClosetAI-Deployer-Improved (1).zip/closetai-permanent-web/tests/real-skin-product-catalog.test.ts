import { rankRealSkinProducts, realSkinProductCatalog } from "../lib/skin-product-catalog";

const result = rankRealSkinProducts({
  skinType: "Combination",
  metrics: [
    { key: "hydration", label: "Hydration", score: 48, status: "Available", available: true, source: "youcam" },
    { key: "pores", label: "Pores", score: 72, status: "Available", available: true, source: "youcam" },
    { key: "radiance", label: "Radiance", score: 79, status: "Available", available: true, source: "youcam" },
  ],
});

if (realSkinProductCatalog.length < 5) throw new Error("Expected an initial five-product real catalog.");
for (const product of realSkinProductCatalog) {
  if (!product.officialUrl.startsWith("https://") || product.primaryIngredients.length === 0 || product.sourceLabel !== "Manufacturer product page") throw new Error(`Invalid catalog source data for ${product.id}.`);
  if (Object.prototype.hasOwnProperty.call(product, "price") || Object.prototype.hasOwnProperty.call(product, "inventory") || Object.prototype.hasOwnProperty.call(product, "stock")) throw new Error(`Catalog record must not fabricate commerce data for ${product.id}.`);
}
if (!result.some((product) => product.id === "cerave-hydrating-facial-cleanser")) throw new Error("Routine foundation product was not ranked.");
if (!result.some((product) => product.id === "ordinary-niacinamide-zinc" && product.matchedSignals.includes("pores"))) throw new Error("Ingredient-to-signal compatibility did not rank the real niacinamide product.");

console.log(JSON.stringify({
  result: "PASS",
  catalogRecords: realSkinProductCatalog.map((product) => ({ id: product.id, brand: product.brand, category: product.category, officialCartAvailable: product.officialCartAvailable })),
  ranked: result.map((product) => ({ id: product.id, matchedSignals: product.matchedSignals })),
  guarantee: "Catalog records reference manufacturer pages and omit unverified price, inventory, and delivery claims.",
}, null, 2));
