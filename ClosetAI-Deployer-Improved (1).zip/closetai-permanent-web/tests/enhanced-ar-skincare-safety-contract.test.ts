import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

import { AR_ENVIRONMENT_CUES, AR_OVERLAY_INTENSITIES, AR_VISUAL_MODES, AR_VISUAL_PREVIEW_DISCLOSURE } from '../lib/ar-skin-preview';

const root = process.cwd();
const liveCamera = readFileSync(resolve(root, 'components/skin/LiveSkinCamera.tsx'), 'utf8');
const texturePreview = readFileSync(resolve(root, 'app/skin/texture-preview.tsx'), 'utf8');
const productCatalog = readFileSync(resolve(root, 'lib/skin-product-catalog.ts'), 'utf8');

const modeIds = ['guide', 'dewy-light', 'satin-veil', 'soft-focus'];
const environmentIds = ['indoor-dry', 'warm-humid', 'outdoor-daylight', 'calm-day'];

if (AR_VISUAL_MODES.length !== 4 || modeIds.some((id) => !AR_VISUAL_MODES.some((mode) => mode.id === id))) {
  throw new Error('Enhanced AR must retain guide plus three clearly labeled cosmetic visual modes.');
}
if (AR_ENVIRONMENT_CUES.length !== 4 || environmentIds.some((id) => !AR_ENVIRONMENT_CUES.some((cue) => cue.id === id))) {
  throw new Error('Enhanced AR must retain the four local environmental context cues.');
}
if (AR_OVERLAY_INTENSITIES.length !== 3 || ['subtle', 'balanced', 'full'].some((id) => !AR_OVERLAY_INTENSITIES.some((intensity) => intensity.id === id))) {
  throw new Error('Enhanced AR must retain the three local visual-comparison intensity options.');
}
for (const prohibitedClaim of ['predict', 'diagnos', 'efficacy', 'replicate']) {
  if (!AR_VISUAL_PREVIEW_DISCLOSURE.toLowerCase().includes(prohibitedClaim)) {
    throw new Error(`The AR visual disclosure must explicitly prevent ${prohibitedClaim} claims.`);
  }
}

const requiredLiveCameraBoundaries = [
  'AR_VISUAL_PREVIEW_DISCLOSURE',
  'Camera visual overlay',
  'Switch value={visualPreviewConsent}',
  'LinearGradient',
  'AR_OVERLAY_INTENSITIES',
  'Camera visual overlay intensity',
  'FaceDetector.FaceDetectorClassifications.none',
  'The camera view is not stored.',
];
for (const boundary of requiredLiveCameraBoundaries) {
  if (!liveCamera.includes(boundary)) throw new Error(`Live AR camera must retain: ${boundary}`);
}
if (liveCamera.includes('FaceDetector.FaceDetectorClassifications.all') || /\bgender\b/i.test(liveCamera) || /\bage\b/i.test(liveCamera)) {
  throw new Error('Live AR camera must not classify age, gender, or other identity attributes.');
}

const requiredPreviewBoundaries = [
  'AR_ENVIRONMENT_CUES',
  'AR_OVERLAY_INTENSITIES',
  'COMFORT_CUES',
  'Compare original and overlay',
  'Show local cosmetic overlay for comparison',
  'This does not compare treatment results.',
  'These are optional session-only cues, not live weather measurement or a health assessment.',
  'Official product-category references',
  'They are not personalized product recommendations, treatment guidance, suitability decisions, or live availability data.',
  'does not upload it or save a history entry',
  'setPhotoUri(null)',
];
for (const boundary of requiredPreviewBoundaries) {
  if (!texturePreview.includes(boundary)) throw new Error(`Texture preview must retain: ${boundary}`);
}
if (texturePreview.includes('fetch(') || texturePreview.includes('apiRequest(') || texturePreview.includes('analyzeSkin') || texturePreview.includes('imageBase64')) {
  throw new Error('Enhanced AR texture preview must remain local and cannot send selected photos to an API or analysis route.');
}
if (!productCatalog.includes('production should refresh these records through an authorized catalog/commerce provider')) {
  throw new Error('Official category references must retain their non-live-commerce catalog boundary.');
}

console.log(JSON.stringify({
  result: 'PASS',
  visualModeCount: AR_VISUAL_MODES.length,
  environmentCueCount: AR_ENVIRONMENT_CUES.length,
  assertions: [
    'Live camera overlays require an explicit local visual-preview consent and retain no identity classification.',
    'User-photo texture preview remains local and does not upload, analyse, diagnose, predict, or claim efficacy.',
    'Environment and daily-comfort cues only adjust category-reference display and remain non-medical, non-live-measurement inputs.',
  ],
}, null, 2));
