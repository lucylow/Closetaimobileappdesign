import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const source = readFileSync(resolve(process.cwd(), "app/(tabs)/tryon.tsx"), "utf8");

for (const required of [
  "<MediaStatusCard",
  "kind={demoMode ? 'local-only' : 'temporary-result'}",
  "Fictional Demo Mode result",
  "Live YouCam result",
  "Photo-safe assisted result",
  "not a live provider result",
  "never substitutes a stock model",
  "Temporary provider-rendered result",
  "Temporary photo-safe assisted preview",
  "No fabricated or stock result is substituted.",
]) {
  if (!source.includes(required)) throw new Error(`Fashion AR source-status safeguard missing: ${required}`);
}

if (!source.includes("using your selected photo and garments") || !source.includes("Review it before saving or sharing.")) {
  throw new Error("Fashion AR result status must disclose selected-photo provenance and temporary review behavior.");
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "Fashion AR results distinguish live YouCam, photo-safe assisted, and fictional Demo Mode provenance.",
    "Every result state keeps the selected-photo-only and no-stock-model boundary visible.",
    "Temporary provider and assisted results are disclosed as reviewable outputs rather than verified outcomes.",
  ],
}, null, 2));
