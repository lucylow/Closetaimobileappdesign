import { readFileSync } from "node:fs";
import {
  BREAST_SHAPE_SIMULATION_DISCLOSURE,
  normalizeBreastShapeIntensity,
  normalizeProviderBreastShapeSimulation,
} from "../shared/breast-shape-simulation";

if (normalizeBreastShapeIntensity(1) !== 1 || normalizeBreastShapeIntensity(2) !== 2 || normalizeBreastShapeIntensity(3) !== 3) {
  throw new Error("All three documented cosmetic visualization intensities must remain supported.");
}
if (normalizeBreastShapeIntensity(0) !== null || normalizeBreastShapeIntensity(4) !== null || normalizeBreastShapeIntensity("2") !== null) {
  throw new Error("Only documented integer intensities 1 through 3 may enter the contract.");
}
const normalized = normalizeProviderBreastShapeSimulation({ url: "https://example.com/temporary-result.jpg", body_score: 99 }, 1);
if (!normalized || normalized.resultUrl !== "https://example.com/temporary-result.jpg" || normalized.intensity !== 1 || normalized.expiresInHours !== 2) {
  throw new Error("Only an HTTPS provider result URL and selected intensity may be normalized.");
}
if (JSON.stringify(normalized).includes("score") || normalizeProviderBreastShapeSimulation({ url: "http://unsafe.example.com/result.jpg" }, 2) !== null) {
  throw new Error("Body scoring data and insecure provider output must never enter app state.");
}
if (!BREAST_SHAPE_SIMULATION_DISCLOSURE.includes("Adult-only") || !BREAST_SHAPE_SIMULATION_DISCLOSURE.includes("not medical advice") || !BREAST_SHAPE_SIMULATION_DISCLOSURE.includes("not saved to history") || !BREAST_SHAPE_SIMULATION_DISCLOSURE.includes("no stock or fallback")) {
  throw new Error("The disclosure must retain adult-only, non-medical, temporary, and no-fallback boundaries.");
}

const taskClient = readFileSync("server/youcam-breast-shape.ts", "utf8");
const routeSource = readFileSync("server/routes.ts", "utf8");
const screenSource = readFileSync("app/skin/breast-shape.tsx", "utf8");
const hubSource = readFileSync("components/skin/SkinCareHub.tsx", "utf8");
if (!taskClient.includes('"/s2s/v2.0/task/breast-shape"') || !taskClient.includes("src_file_id") || !taskClient.includes("intensity") || !taskClient.includes("/s2s/v2.0/task/breast-shape/${encodeURIComponent(taskId)}")) {
  throw new Error("The task client must use documented create/status endpoints with a private source file ID and intensity.");
}
if (!routeSource.includes('app.post("/api/skin/breast-shape"') || !routeSource.includes("adultConfirmed !== true") || !routeSource.includes("consent !== true") || !routeSource.includes("normalizeBreastShapeIntensity")) {
  throw new Error("Server route must require adult acknowledgement, explicit consent, and bounded intensity validation.");
}
if (!screenSource.includes("18 or older") || !screenSource.includes("not medical advice, diagnosis, or surgical planning") || !screenSource.includes("does not require or request nude images") || !screenSource.includes("No image was shown")) {
  throw new Error("Mobile screen must preserve adult-only, non-medical, clothed-photo, and no-fallback presentation boundaries.");
}
if (!hubSource.includes('router.push("/skin/breast-shape")') || !hubSource.includes("Cosmetic body preview · 18+")) {
  throw new Error("The canonical Skin Care hub must expose a clearly labeled adult-only entry point.");
}

console.log(JSON.stringify({ result: "PASS", normalized, assertions: [
  "Only provider-issued HTTPS results and documented intensity values are retained.",
  "No body score, medical assessment, or stock/fallback image can enter app output.",
  "Adult acknowledgement and explicit cosmetic-visualization consent are server enforced.",
  "The Expo experience requests a clothed photo and is clearly labeled 18+ and non-medical.",
] }, null, 2));
