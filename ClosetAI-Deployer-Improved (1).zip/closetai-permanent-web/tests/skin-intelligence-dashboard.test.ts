import { buildSkinIntelligenceDashboard } from "../lib/skin-intelligence-dashboard";
import type { SkinAnalysisResult } from "../lib/skin-analysis-controller";

const previous: SkinAnalysisResult = {
  id: "scan-previous", createdAt: "2026-08-01T12:00:00.000Z", source: "youcam", overallScore: 66, skinType: "Combination", routine: [], disclaimer: "General guidance only.",
  metrics: [
    { key: "hydration", label: "Hydration", score: 57, status: "Available", available: true, source: "youcam" },
    { key: "radiance", label: "Radiance", score: 71, status: "Available", available: true, source: "youcam" },
    { key: "pores", label: "Pores", score: 60, status: "Available", available: true, source: "youcam" },
  ],
};
const current: SkinAnalysisResult = {
  ...previous,
  id: "scan-current", createdAt: "2026-08-11T12:00:00.000Z", overallScore: 70,
  metrics: [
    { key: "hydration", label: "Hydration", score: 50, status: "Available", available: true, source: "youcam" },
    { key: "radiance", label: "Radiance", score: 78, status: "Available", available: true, source: "youcam" },
    { key: "pores", label: "Pores", score: 68, status: "Available", available: true, source: "youcam" },
  ],
};

const dashboard = buildSkinIntelligenceDashboard(current, [current, previous]);
if (dashboard.sourceLabel !== "Live visual analysis" || dashboard.coveragePercent !== 100) throw new Error(`Unexpected source or coverage: ${JSON.stringify(dashboard)}`);
if (!dashboard.priorities.some((card) => card.key === "hydration" && card.priority === "focus")) throw new Error("Expected hydration to be a gentle focus card.");
if (!dashboard.priorities.some((card) => card.key === "pores" && card.priority === "focus")) throw new Error("Expected pores to be a gentle focus card.");
if (!dashboard.cards.some((card) => card.key === "radiance" && card.priority === "sustain" && card.trend === "up")) throw new Error("Expected radiance to be a sustaining upward visual signal.");
if (JSON.stringify(dashboard).match(/imageUri|faceMask|provider_payload|rawResponse/i)) throw new Error("Dashboard must not surface raw image, mask, or provider payload fields.");

console.log(JSON.stringify({
  result: "PASS",
  source: dashboard.sourceLabel,
  coveragePercent: dashboard.coveragePercent,
  priorities: dashboard.priorities.map((card) => ({ key: card.key, priority: card.priority })),
  trendLabel: dashboard.trendLabel,
  guarantee: "The dashboard contains normalized visual summaries only; no raw API payload or medical claim is exposed.",
}, null, 2));
