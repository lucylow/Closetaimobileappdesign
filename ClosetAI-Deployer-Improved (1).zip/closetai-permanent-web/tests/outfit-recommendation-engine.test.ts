import { buildWardrobeRecommendations } from "../shared/outfit-recommendations";

const wardrobe = [
  { id: "top-cream", name: "Cream Knit", category: "top", color: "Cream", tags: ["minimal"], usageCount: 4, lastWornAt: "2026-08-01T00:00:00.000Z" },
  { id: "top-slate", name: "Slate Tee", category: "top", color: "Slate", tags: ["casual"], usageCount: 1, lastWornAt: "2026-07-15T00:00:00.000Z" },
  { id: "bottom-navy", name: "Navy Trouser", category: "bottom", color: "Navy", tags: ["tailored"], usageCount: 2, lastWornAt: "2026-07-30T00:00:00.000Z" },
  { id: "jacket-camel", name: "Camel Blazer", category: "outerwear", color: "Camel", tags: ["layer"], usageCount: 0, lastWornAt: null },
  { id: "shoe-black", name: "Black Loafer", category: "shoes", color: "Black", tags: ["classic"], usageCount: 3, lastWornAt: "2026-07-21T00:00:00.000Z" },
];

const recommendations = buildWardrobeRecommendations(wardrobe, "Office", "cold rainy 48F");
if (recommendations.length === 0) throw new Error("Expected wardrobe-based recommendations.");
if (recommendations.length > 3) throw new Error("Expected no more than three compact recommendations.");

const allowedIds = new Set(wardrobe.map((item) => item.id));
for (const recommendation of recommendations) {
  if (recommendation.itemIds.length < 2 || recommendation.itemIds.length > 4) {
    throw new Error(`Expected 2–4 items, received ${recommendation.itemIds.length}.`);
  }
  if (recommendation.itemIds.some((id) => !allowedIds.has(id))) {
    throw new Error(`Recommendation includes an item outside the user's wardrobe: ${recommendation.itemIds.join(", ")}`);
  }
}

const first = recommendations[0];
if (!first.itemIds.includes("jacket-camel")) {
  throw new Error("Cold weather recommendation should include the user's outerwear when available.");
}

console.log(JSON.stringify({
  result: "PASS",
  recommendationCount: recommendations.length,
  firstRecommendation: first,
  guarantee: "Every recommended item ID came from the supplied wardrobe inventory.",
}, null, 2));
