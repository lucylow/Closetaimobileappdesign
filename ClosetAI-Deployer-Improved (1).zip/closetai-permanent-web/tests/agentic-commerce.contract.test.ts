import { readFileSync } from "fs";
import { resolve } from "path";
import { searchCommerceCandidates, createCommercePlan } from "../lib/commerce-agent";
import { COMMERCE_PLAN_TIERS, COMMERCE_MONETIZATION_DISCLOSURE } from "../shared/commerce-monetization";
import { COMMERCE_CREDIT_PACKS } from "../shared/commerce-entitlements";
import { trackAffiliateClick, getAffiliateClicks } from "../lib/commerce-attribution";
import { fetchExternalProductDiscovery } from "../lib/external-commerce-provider";
import { FICTIONAL_DEMO_CANDIDATES, FICTIONAL_COMMERCE_DEMO_DISCLOSURE } from "../lib/fictional-demo-commerce";
import { prepareCheckoutSession, approveAndCompleteCheckout } from "../lib/checkout-session";
import { addPriceWatchRule, getPriceWatchRules } from "../lib/price-watch";

export async function runAgenticCommerceContractTest() {
  const root = resolve(__dirname, "..");
  
  // Verify files exist
  const screenCode = readFileSync(resolve(root, "app/commerce-agent.tsx"), "utf8");
  const contractCode = readFileSync(resolve(root, "shared/agentic-commerce-contracts.ts"), "utf8");
  const disclosureCode = readFileSync(resolve(root, "shared/commerce-disclosures.ts"), "utf8");

  if (!disclosureCode.includes("AGENTIC_COMMERCE_PROTOTYPE_DISCLOSURE")) {
    throw new Error("Commerce disclosures missing prototype disclosure string.");
  }
  if (!screenCode.includes("Agentic Commerce Simulation")) {
    throw new Error("Commerce agent screen missing visible disclosure banner.");
  }
  if (!screenCode.includes("provenanceText")) {
    throw new Error("Commerce agent screen missing evidence provenance row.");
  }

  if (!contractCode.includes("CommerceCandidate") || !contractCode.includes("CheckoutSession")) {
    throw new Error("Agentic commerce contracts missing required types.");
  }
  if (FICTIONAL_DEMO_CANDIDATES.length === 0 || !FICTIONAL_COMMERCE_DEMO_DISCLOSURE) {
    throw new Error("Fictional demo commerce fixtures missing.");
  }
  if (COMMERCE_PLAN_TIERS.length === 0 || !COMMERCE_MONETIZATION_DISCLOSURE) {
    throw new Error("Commerce monetization definitions missing.");
  }
  if (COMMERCE_CREDIT_PACKS.length === 0) {
    throw new Error("Commerce credit packs missing.");
  }
  if (typeof trackAffiliateClick !== "function" || typeof getAffiliateClicks !== "function") {
    throw new Error("Commerce affiliate attribution helpers missing.");
  }
  if (typeof fetchExternalProductDiscovery !== "function") {
    throw new Error("External commerce provider helper missing.");
  }

  if (!screenCode.includes("Agentic Shopping Copilot") || !screenCode.includes("Prepare Checkout")) {
    throw new Error("Agentic commerce screen missing required UI elements.");
  }

  // Test core library logic
  const plan = createCommercePlan("Find a lightweight moisturizer", "skincare", 35);
  if (plan.goal !== "Find a lightweight moisturizer") {
    throw new Error("Commerce plan creation failed.");
  }

  const candidates = searchCommerceCandidates("moisturizer", "skincare", true);
  if (candidates.length === 0) {
    throw new Error("Commerce search returned no candidates.");
  }

  const candidate = candidates[0];
  const session = prepareCheckoutSession(candidate, 1);
  if (session.status !== "awaiting_user_approval" || session.userApproved) {
    throw new Error("Checkout session initial state must require user approval.");
  }

  const completed = approveAndCompleteCheckout(session);
  if (completed.status !== "completed" || !completed.userApproved) {
    throw new Error("Checkout session approval failed.");
  }

  const updatedRules = await addPriceWatchRule(candidate.productId, candidate.title, candidate.price);
  if (updatedRules.length === 0 || !updatedRules[0].active) {
    throw new Error("Price watch rule creation failed.");
  }

  console.log("Agentic Commerce Contract Test: PASSED");
}

if (require.main === module) {
  runAgenticCommerceContractTest().catch(err => {
    console.error(err);
    process.exit(1);
  });
}
