import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const root = process.cwd();
const queue = readFileSync(resolve(root, "lib/tryon-retry-queue.ts"), "utf8");
const screen = readFileSync(resolve(root, "app/(tabs)/tryon.tsx"), "utf8");

for (const required of [
  '@closetai_tryon_retry_queue_v1',
  'MAX_QUEUE_AGE_MS',
  'saveTryOnRetryQueue',
  'loadTryOnRetryQueue',
  'clearTryOnRetryQueue',
]) {
  if (!queue.includes(required)) throw new Error(`The local retry queue must retain: ${required}`);
}

for (const required of [
  'const [queuedRetry, setQueuedRetry] = useState<TryOnRetryQueueEntry | null>(null);',
  'loadTryOnRetryQueue()',
  'saveTryOnRetryQueue(entry)',
  'Live try-on retry saved locally',
  'cloud-offline-outline',
  'Retry saved fashion try-on',
  'Your selected photo and garments remain available; no stock model or fabricated result was added.',
  'void clearTryOnRetryQueue();',
  'setQueuedRetry(null);',
  'setSelectedGarments([]);',
]) {
  if (!screen.includes(required)) throw new Error(`The native fashion try-on screen must retain: ${required}`);
}

if (!screen.includes('provider === \'photo-preview\' && !demoMode && isAuthenticated')) {
  throw new Error('Only live authenticated provider fallbacks may create a local retry entry; Demo Mode must remain clearly fictional and local.');
}
if (!screen.includes('setQueuedRetry(null);\n          void clearTryOnRetryQueue();') || !screen.includes('setQueuedRetry(null);\n    void clearTryOnRetryQueue();')) {
  throw new Error('Changing the selected photo or garment context must clear stale queued retry metadata.');
}
if (!queue.includes('entry.garmentIds.length > MAX_GARMENTS') || !queue.includes('Date.now() - queuedAt <= MAX_QUEUE_AGE_MS')) {
  throw new Error('The local retry queue must bound stored garment IDs and expire stale entries.');
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "Retry metadata is stored locally with a bounded age and no image bytes or provider credentials.",
    "The native screen exposes accessible Retry now and Dismiss controls for provider-unavailable requests.",
    "The retry indicator preserves selected-photo-only and no-fabrication boundaries.",
  ],
}, null, 2));
