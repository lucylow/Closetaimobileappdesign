import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const source = readFileSync(join(root, "app/(tabs)/tryon.tsx"), "utf8");

if (!source.includes("useFocusEffect(React.useCallback")) {
  throw new Error("Fashion try-on must refresh photo permission when the screen regains focus.");
}
if (!source.includes("ImagePicker.getMediaLibraryPermissionsAsync()")) {
  throw new Error("Fashion try-on must query the current photo-library permission state.");
}
if (!source.includes("const openPhotoSettings = async () =>")) {
  throw new Error("Fashion try-on must provide a direct Settings recovery action.");
}
if (!source.includes("accessibilityLabel=\"Open photo settings\"")) {
  throw new Error("The fashion try-on Settings action must be accessible.");
}
if (!source.includes("Photo access is currently off. Enable it in Settings to use your own photo for virtual try-on.")) {
  throw new Error("Fashion try-on must disclose blocked photo access in-app.");
}
if (!source.includes("Your photo only · never a stock model substitution.")) {
  throw new Error("Fashion try-on must preserve the user-photo-only boundary.");
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "Fashion try-on refreshes photo permission on focus.",
    "Blocked access offers accessible device Settings recovery.",
    "The user-photo-only boundary remains explicit.",
  ],
}, null, 2));
