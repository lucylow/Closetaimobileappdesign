import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

const source = readFileSync(resolve(process.cwd(), 'server/youcam.ts'), 'utf8');

for (const required of [
  'export async function startFashionTryOnTask(input: {',
  '!/^[A-Za-z0-9._:-]{1,256}$/.test(input.sourceFileId)',
  'A valid uploaded user-photo file is required for live fashion try-on.',
  'if (!isSafeFashionResultUrl(input.referenceImageUrl))',
  'A secure public HTTPS wardrobe-image URL is required for live fashion try-on.',
  '(["upper_body", "lower_body", "full_body", "outerwear", "shoes", "auto"] as const).includes(input.garmentCategory)',
  'A supported clothing category is required for live fashion try-on.',
  'if (!result.ok) throw new Error("Live YouCam clothing task could not be created.");',
  'typeof taskId !== "string" || !/^[A-Za-z0-9._:-]{1,256}$/.test(taskId)',
  'Live YouCam clothing task did not return a usable task identifier.',
]) {
  if (!source.includes(required)) throw new Error(`Safe YouCam fashion task-creation requirement missing: ${required}`);
}

for (const prohibited of [
  'if (!/^https?:\\/\\//i.test(input.referenceImageUrl))',
  'YouCam fashion task creation failed (${result.status})',
  'YouCam fashion task did not return a task ID.',
]) {
  if (source.includes(prohibited)) throw new Error(`Unsafe or raw provider task-creation handling remains: ${prohibited}`);
}

const sourceId = source.indexOf('if (!/^[A-Za-z0-9._:-]{1,256}$/.test(input.sourceFileId))');
const reference = source.indexOf('if (!isSafeFashionResultUrl(input.referenceImageUrl))', sourceId);
const category = source.indexOf('if (!(["upper_body", "lower_body", "full_body", "outerwear", "shoes", "auto"] as const).includes(input.garmentCategory))', reference);
const providerRequest = source.indexOf('const result = await fashionApiRequest("/s2s/v2.0/task/cloth-v4"', category);
const taskId = source.indexOf('if (typeof taskId !== "string" || !/^[A-Za-z0-9._:-]{1,256}$/.test(taskId))', providerRequest);
if ([sourceId, reference, category, providerRequest, taskId].some((index) => index === -1)
  || sourceId > reference
  || reference > category
  || category > providerRequest
  || providerRequest > taskId) {
  throw new Error('Task creation must validate user-photo ID, HTTPS reference, and garment category before the provider request, then validate the returned task identifier.');
}

console.log(JSON.stringify({
  result: 'PASS',
  assertions: [
    'Only safe uploaded-photo IDs, credential-free HTTPS garment references, and supported clothing categories reach YouCam task creation.',
    'Malformed or absent provider task identifiers are rejected before polling begins.',
    'Task creation errors use stable source-aware messages instead of provider response details.',
  ],
}, null, 2));
