import { buildSkinProgressMetricSummary, buildSkinProgressOverview, getSkinProgressMetricPoints, progressDirectionLabel } from "../lib/skin-progress-trends";
import type { SkinMetricHistoryPoint } from "../lib/skin-metric-history";

function point(overrides: Partial<SkinMetricHistoryPoint> & Pick<SkinMetricHistoryPoint, "scanId" | "capturedAt" | "metricKey" | "score">): SkinMetricHistoryPoint {
  return { source: "youcam", ...overrides };
}

const chronologyAndDuplicates = [
  point({ scanId: "scan-late", capturedAt: "2026-08-08T12:00:00Z", metricKey: "hydration", score: 60 }),
  point({ scanId: "scan-early", capturedAt: "2026-08-01T12:00:00Z", metricKey: "hydration", score: 50 }),
  point({ scanId: "scan-late", capturedAt: "2026-08-08T12:01:00Z", metricKey: "hydration", score: 61 }),
  point({ scanId: "scan-early", capturedAt: "2026-08-01T12:00:00Z", metricKey: "radiance", score: 50 }),
  point({ scanId: "scan-late", capturedAt: "2026-08-08T12:00:00Z", metricKey: "radiance", score: 52 }),
];
const ordered = getSkinProgressMetricPoints(chronologyAndDuplicates, "hydration");
if (ordered.length !== 2 || ordered[0]?.scanId !== "scan-early" || ordered[1]?.score !== 61) {
  throw new Error("Unit: metric points must be deduplicated by scan/metric and then sorted chronologically.");
}

const up = buildSkinProgressMetricSummary(chronologyAndDuplicates, "hydration");
const steady = buildSkinProgressMetricSummary(chronologyAndDuplicates, "radiance");
const down = buildSkinProgressMetricSummary([
  point({ scanId: "down-1", capturedAt: "2026-08-01T12:00:00Z", metricKey: "texture", score: 72 }),
  point({ scanId: "down-2", capturedAt: "2026-08-08T12:00:00Z", metricKey: "texture", score: 65 }),
], "texture");
if (up.direction !== "up" || up.delta !== 11 || steady.direction !== "steady" || down.direction !== "down") {
  throw new Error("Unit: direction calculation must use the documented conservative +/-3 display band without medical claims.");
}
if (progressDirectionLabel("up") !== "Up" || progressDirectionLabel("down") !== "Down" || progressDirectionLabel("steady") !== "Steady" || progressDirectionLabel("mixed") !== "Mixed sources" || progressDirectionLabel("insufficient") !== "More snapshots needed") {
  throw new Error("Unit: every progress direction must expose an explicit user-facing label.");
}

const demo = buildSkinProgressMetricSummary([
  point({ scanId: "demo-1", capturedAt: "2026-08-01T12:00:00Z", source: "demo", metricKey: "pores", score: 44 }),
  point({ scanId: "demo-2", capturedAt: "2026-08-08T12:00:00Z", source: "demo", metricKey: "pores", score: 48 }),
], "pores");
const cached = buildSkinProgressMetricSummary([
  point({ scanId: "cached-1", capturedAt: "2026-08-01T12:00:00Z", source: "cached", metricKey: "fineLines", score: 40 }),
  point({ scanId: "cached-2", capturedAt: "2026-08-08T12:00:00Z", source: "cached", metricKey: "fineLines", score: 44 }),
], "fineLines");
const mixed = buildSkinProgressMetricSummary([
  point({ scanId: "mixed-live", capturedAt: "2026-08-01T12:00:00Z", source: "youcam", metricKey: "redness", score: 44 }),
  point({ scanId: "mixed-demo", capturedAt: "2026-08-08T12:00:00Z", source: "demo", metricKey: "redness", score: 50 }),
], "redness");
if (demo.source !== "demo" || !demo.note.includes("Fictional Demo Mode") || cached.source !== "cached" || !cached.note.includes("cached") || mixed.direction !== "mixed" || mixed.delta !== undefined) {
  throw new Error("Unit: demo, cached, and mixed history must remain source-aware and mixed values must not yield a combined delta.");
}

const emptyOverview = buildSkinProgressOverview([]);
const sparse = buildSkinProgressMetricSummary([point({ scanId: "only", capturedAt: "2026-08-01T12:00:00Z", metricKey: "blemishes", score: 35 })], "blemishes");
if (emptyOverview.snapshotCount !== 0 || emptyOverview.captureDayCount !== 0 || !emptyOverview.note.includes("No local normalized snapshots") || sparse.direction !== "insufficient") {
  throw new Error("Unit: empty and sparse histories must fail closed with an informative non-fabricated state.");
}

const many = Array.from({ length: 40 }, (_, index) => point({ scanId: `many-${index}`, capturedAt: `2026-08-${String((index % 28) + 1).padStart(2, "0")}T12:00:00Z`, metricKey: "hydration", score: 45 + (index % 30) }));
if (getSkinProgressMetricPoints(many, "hydration", 999).length !== 30 || getSkinProgressMetricPoints(many, "hydration", 0).length !== 1) {
  throw new Error("Unit: snapshot trend windows must remain bounded between one and thirty points.");
}

console.log(JSON.stringify({ result: "PASS", type: "unit", assertions: [
  "Deduplicates normalized metric points and orders chronology deterministically.",
  "Uses conservative up/down/steady direction labels without clinical interpretation.",
  "Separates live, fictional Demo Mode, cached, mixed, sparse, and empty history states.",
  "Bounds chart windows to protect mobile readability and rendering performance.",
] }, null, 2));
