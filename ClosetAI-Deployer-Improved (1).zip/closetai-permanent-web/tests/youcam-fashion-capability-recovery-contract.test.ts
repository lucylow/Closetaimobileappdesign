import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

const shared = readFileSync(resolve(process.cwd(), 'shared/youcam-fashion-experience.ts'), 'utf8');
const screen = readFileSync(resolve(process.cwd(), 'app/(tabs)/tryon.tsx'), 'utf8');

for (const required of [
  'export function normalizeYouCamFashionCapability(value: unknown): YouCamFashionCapability | null',
  'capability.provider !== "youcam-ai-clothes-v4"',
  '!isStringArray(capability.liveCategoryIds)',
  '!isStringArray(capability.assistedCategoryIds)',
  'capability.userPhotoOnly !== true',
  'capability.maxImageBytes <= 0',
  'return null;',
]) {
  if (!shared.includes(required)) throw new Error(`Strict fashion capability validation missing: ${required}`);
}

for (const required of [
  'normalizeYouCamFashionCapability',
  "const [fashionCapabilityFeedback, setFashionCapabilityFeedback] = useState<string | null>(null);",
  'const capability = normalizeYouCamFashionCapability(response);',
  "setFashionCapability('unavailable');",
  'Live YouCam availability could not be verified.',
  'Live YouCam availability is temporarily unavailable.',
  'will not substitute another person.',
  'accessibilityLiveRegion="polite"',
]) {
  if (!screen.includes(required)) throw new Error(`Fashion capability recovery surface missing: ${required}`);
}

const normalized = screen.indexOf('const capability = normalizeYouCamFashionCapability(response);');
const malformedFallback = screen.indexOf('if (!capability) {', normalized);
const networkFallback = screen.indexOf('.catch(() => {', malformedFallback);
const feedbackSurface = screen.indexOf('!!fashionCapabilityFeedback', networkFallback);
if ([normalized, malformedFallback, networkFallback, feedbackSurface].some((index) => index === -1)
  || normalized > malformedFallback
  || malformedFallback > networkFallback
  || networkFallback > feedbackSurface) {
  throw new Error('Capability discovery must reject malformed responses and expose source-aware recovery feedback before the user starts try-on.');
}

console.log(JSON.stringify({
  result: 'PASS',
  assertions: [
    'Only the expected YouCam capability contract is accepted by the mobile screen.',
    'Malformed and unavailable capability responses force a source-labeled selected-photo-only recovery state.',
    'Capability fallback feedback is accessible without claiming a live YouCam result or substituting another person.',
  ],
}, null, 2));
