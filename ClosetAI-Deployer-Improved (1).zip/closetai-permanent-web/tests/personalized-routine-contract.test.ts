import { readFileSync } from "node:fs";
import { getCatalogProduct } from "../lib/skin-product-catalog";
import { buildPersonalizedRoutine, countRoutineCompletions, keepTodayRoutineCompletions, localRoutineDateKey, PERSONALIZED_ROUTINE_DISCLOSURE, routineCompletionKey } from "../lib/personalized-skin-routine";

const fixedDate = new Date(2026, 7, 12, 9, 30, 0);
const live = buildPersonalizedRoutine({
  source: "youcam",
  metrics: [
    { key: "hydration", label: "Hydration", score: 48, status: "Focus area", available: true, source: "youcam" },
    { key: "oiliness", label: "Oiliness", score: 68, status: "Balanced", available: true, source: "youcam" },
  ],
  selectedGoals: ["hydration", "tone"],
});
const demo = buildPersonalizedRoutine({ source: "demo", metrics: [], selectedGoals: ["calm"] });
const starter = buildPersonalizedRoutine({ source: "none", metrics: [], selectedGoals: [] });

if (live.source !== "youcam" || !live.sourceLabel.includes("live visual signals") || demo.source !== "demo" || !demo.sourceLabel.includes("Fictional Demo Mode") || starter.source !== "none" || !starter.sourceLabel.includes("Starter routine")) {
  throw new Error("Routine source labeling must clearly distinguish live, fictional demo, and no-scan starter plans.");
}
if (live.focusLabels[0] !== "Hydration support" || live.morning.length !== 3 || live.evening.length !== 3 || live.morning[2]?.id !== "am-protect" || live.evening[2]?.id !== "pm-moisturise") {
  throw new Error("Personalized plan must respect selected goals and preserve a compact ordered AM/PM foundation.");
}
for (const step of [...live.morning, ...live.evening]) {
  if (step.productId && !getCatalogProduct(step.productId)) throw new Error("Routine steps may reference only verified catalog IDs.");
  if (!step.sourceReason || !step.guidance || !["daily", "optional"].includes(step.frequency)) throw new Error("Routine steps must retain source reason, general-care guidance, and bounded frequency metadata.");
}
if (!PERSONALIZED_ROUTINE_DISCLOSURE.includes("not medical advice") || !PERSONALIZED_ROUTINE_DISCLOSURE.includes("ingredient-compatibility guarantee")) {
  throw new Error("Routine disclosure must keep non-medical and non-guarantee boundaries visible.");
}
const amKey = routineCompletionKey("AM", "am-cleanse", fixedDate);
const pmKey = routineCompletionKey("PM", "pm-cleanse", fixedDate);
if (!amKey.startsWith(`${localRoutineDateKey(fixedDate)}:AM:`) || keepTodayRoutineCompletions([amKey, pmKey, "2026-08-11:AM:am-cleanse"], fixedDate).length !== 2) {
  throw new Error("Routine completion state must be date-scoped and discard stale-day checkmarks.");
}
const completed = [routineCompletionKey("AM", "am-cleanse", fixedDate), routineCompletionKey("AM", "am-support", fixedDate)];
if (countRoutineCompletions(live, completed, fixedDate) !== 2) throw new Error("Routine progress must count local completion keys only.");

const contextSource = readFileSync("contexts/SkinCareContext.tsx", "utf8");
const routeSource = readFileSync("components/skin/SkinJourneyPage.tsx", "utf8");
if (!contextSource.includes("routineCompletionKey") || !contextSource.includes("keepTodayRoutineCompletions")) {
  throw new Error("Skin Care context must persist date-scoped local routine completions.");
}
if (!routeSource.includes("buildPersonalizedRoutine") || !routeSource.includes("routinePlan.sourceLabel") || !routeSource.includes("Today’s routine progress") || !routeSource.includes("Adjust local care goals") || !routeSource.includes("View manufacturer details")) {
  throw new Error("Routine planner must render the personalized source-aware plan, progress, goal adjustment, and optional verified catalog navigation.");
}

console.log(JSON.stringify({ result: "PASS", assertions: [
  "Live, fictional Demo Mode, and starter AM/PM plans are explicitly source-labeled.",
  "Selected goals adjust focus while AM/PM sequences remain compact and ordered.",
  "Only verified catalog IDs may be linked from routine steps.",
  "Completion keys reset by local calendar day and remain local planning state.",
  "The Expo routine planner exposes source context, optional catalog details, goal adjustment, and non-medical disclosure.",
] }, null, 2));
