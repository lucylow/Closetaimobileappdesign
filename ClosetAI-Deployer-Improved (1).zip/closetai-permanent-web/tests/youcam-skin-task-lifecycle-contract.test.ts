import { readFileSync } from "node:fs";

const legacy = readFileSync("server/youcam.ts", "utf8");
const v2 = readFileSync("server/youcam-skin-v2.ts", "utf8");

for (const required of [
  "const SKIN_TASK_ID_PATTERN = /^[A-Za-z0-9._:-]{1,256}$/;",
  "function isSafeSkinTaskId(value: unknown): value is string",
  "function normalizeSkinPollingInterval(value: unknown): number",
  "if (!isSafeSkinTaskId(taskId))",
  "completedSkinTaskCache.delete(taskId);",
  "encodeURIComponent(taskId)",
  "const task = isSkinTaskRecord(taskValue) ? taskValue : {};",
]) {
  if (!legacy.includes(required)) throw new Error(`Legacy skin task lifecycle guard missing: ${required}`);
}

for (const required of [
  "const SKIN_V2_RESPONSE_MAX_BYTES = 512 * 1024;",
  "const SKIN_V2_TASK_ID_PATTERN = /^[A-Za-z0-9._:-]{1,256}$/;",
  "async function readSkinV2ResponseBody(response: Response)",
  "function parseSkinV2ResponseObject(body: string): Record<string, any> | null",
  "if (!isSafeSkinV2TaskId(fileId))",
  "if (!response.ok || !isSafeSkinV2TaskId(taskId))",
  "function normalizeSkinV2PollingInterval(value: unknown): number",
  "export function normalizeSkinV2TaskStatus(value: unknown): SkinV2TaskStatus",
  "const completedSkinV2TaskCache = new BoundedTtlCache<Record<string, unknown>>(40);",
  "const cached = completedSkinV2TaskCache.get(taskId);",
  "if (cached.value && isObjectRecord(cached.value)) return cached.value;",
  "if (cached.value) completedSkinV2TaskCache.delete(taskId);",
  "completedSkinV2TaskCache.set(taskId, task, 10 * 60 * 1000);",
  "if (!isSafeSkinV2TaskId(taskId)) throw new Error(\"YouCam v2 skin task is unavailable.\");",
  "const task = isObjectRecord(taskValue) ? taskValue : {};",
  "return task;",
]) {
  if (!v2.includes(required)) throw new Error(`v2 skin task lifecycle guard missing: ${required}`);
}

const legacySkinTaskSource = legacy.slice(
  legacy.indexOf("export async function startSkinAnalysisTask"),
  legacy.indexOf("export async function uploadImageToUrl"),
);
const v2RequestSource = v2.slice(
  v2.indexOf("export async function requestYouCamSkinV2"),
  v2.indexOf("export function isYouCamSkinV2Configured"),
);
const v2TaskSource = v2.slice(v2.indexOf("export async function startSkinV2Task"));
for (const unsafe of [
  "JSON.stringify(result.data)",
  "const text = await response.text();",
  "data = { raw: text }",
]) {
  if (legacySkinTaskSource.includes(unsafe) || v2RequestSource.includes(unsafe) || v2TaskSource.includes(unsafe)) {
    throw new Error(`Provider task lifecycle still exposes unbounded or raw response handling: ${unsafe}`);
  }
}

const v2TaskCacheRead = v2.indexOf("const cached = completedSkinV2TaskCache.get(taskId);");
const v2TaskCacheValidation = v2.indexOf("if (cached.value && isObjectRecord(cached.value)) return cached.value;", v2TaskCacheRead);
const v2TaskCacheEviction = v2.indexOf("if (cached.value) completedSkinV2TaskCache.delete(taskId);", v2TaskCacheValidation);
const v2TaskLiveRead = v2.indexOf("const response = await requestYouCamSkinV2(`/s2s/v2.0/task/skin-analysis/${encodeURIComponent(taskId)}`);", v2TaskCacheEviction);
if ([v2TaskCacheRead, v2TaskCacheValidation, v2TaskCacheEviction, v2TaskLiveRead].some((index) => index === -1)
  || v2TaskCacheRead > v2TaskCacheValidation
  || v2TaskCacheValidation > v2TaskCacheEviction
  || v2TaskCacheEviction > v2TaskLiveRead) {
  throw new Error("v2 skin task cache entries must be validated and evicted before live polling.");
}

const v2RouteSource = readFileSync("server/routes.ts", "utf8");
for (const required of [
  "normalizeSkinV2TaskStatus(status.status ?? status.task_status)",
  "let unrecognizedStatusAttempts = 0;",
  "if (normalizedStatus === \"queued\" || normalizedStatus === \"processing\") continue;",
  "if (unrecognizedStatusAttempts >= 3)",
]) {
  if (!v2RouteSource.includes(required)) throw new Error(`v2 skin route recovery guard missing: ${required}`);
}

const legacyTaskCreation = legacy.indexOf("export async function startSkinAnalysisTask");
const legacyTaskRead = legacy.indexOf("export async function getSkinAnalysisTask");
const legacyCacheRead = legacy.indexOf("const cached = completedSkinTaskCache.get(taskId);", legacyTaskRead);
const legacyLiveRead = legacy.indexOf("const result = await apiRequest(`/s2s/v1.0/task/skin-analysis/${encodeURIComponent(taskId)}`", legacyCacheRead);
if ([legacyTaskCreation, legacyTaskRead, legacyCacheRead, legacyLiveRead].some((index) => index === -1)
  || legacyTaskCreation > legacyTaskRead
  || legacyCacheRead > legacyLiveRead) {
  throw new Error("Legacy skin task identifiers and cache entries must be validated before live polling.");
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "Legacy and v2 skin task IDs are validated before provider paths or cache reads use them.",
    "Provider polling intervals are bounded to a short, predictable window.",
    "Malformed cached and live task records fail closed to safe empty records without diagnostic or provider-detail leakage.",
    "v2 polling accepts only queued or processing as nonterminal states and fails closed after repeated unknown statuses.",
    "Completed v2 task records are cached only after object and terminal-success validation.",
  ],
}, null, 2));
