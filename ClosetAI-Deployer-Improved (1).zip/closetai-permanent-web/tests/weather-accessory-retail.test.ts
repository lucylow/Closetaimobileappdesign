import { buildWardrobeRecommendations } from "../shared/outfit-recommendations";
import { buildRetailRecommendations } from "../shared/retail-recommendations";

const inventory = [
  { id: "top-cream", name: "Cream Knit", category: "top", color: "Cream", tags: [], usageCount: 0 },
  { id: "bottom-navy", name: "Navy Trouser", category: "bottom", color: "Navy", tags: [], usageCount: 0 },
  { id: "scarf-camel", name: "Camel Scarf", category: "scarf", color: "Camel", tags: ["winter"], usageCount: 0 },
  { id: "shoe-black", name: "Black Loafer", category: "shoes", color: "Black", tags: [], usageCount: 0 },
];

const weatherRecommendations = buildWardrobeRecommendations(inventory, "Office", "rainy 42F windy", ["Camel"]);
if (!weatherRecommendations.length) throw new Error("Expected a weather-aware wardrobe recommendation.");
if (!weatherRecommendations[0].itemIds.includes("scarf-camel")) {
  throw new Error("Expected the user-owned scarf to be included as a weather-aware finishing piece.");
}
if (!weatherRecommendations[0].tags.some((tag) => tag.includes("rainy 42f windy"))) {
  throw new Error("Expected weather context tags in the generated recommendation.");
}

const retailRecommendations = buildRetailRecommendations(inventory, { occasion: "Office", weather: "rainy 42F windy", colorPalette: ["Camel"] });
if (!retailRecommendations.some((item) => item.category === "outerwear")) {
  throw new Error("Expected an outerwear search for a cold rainy wardrobe gap.");
}
if (!retailRecommendations.every((item) => item.source === "retailer-search" && item.searchUrl.startsWith("https://www.google.com/search?tbm=shop"))) {
  throw new Error("Retail recommendations must remain explicit retailer searches, not fictional catalog items.");
}

console.log(JSON.stringify({
  result: "PASS",
  weatherOutfit: weatherRecommendations[0].itemIds,
  retailCategories: retailRecommendations.map((item) => item.category),
  guarantee: "Only user-owned wardrobe IDs and transparent retailer-search URLs were produced.",
}, null, 2));
