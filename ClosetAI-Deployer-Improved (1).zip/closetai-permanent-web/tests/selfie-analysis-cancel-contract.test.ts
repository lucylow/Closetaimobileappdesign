import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const source = readFileSync(join(root, "components/skin/SelfieFlowScreen.tsx"), "utf8");

if (!source.includes("const analysisRunIdRef = useRef(0);")) {
  throw new Error("Selfie analysis must track a run identity for cancellation and stale-result protection.");
}
if (!source.includes("const runId = ++analysisRunIdRef.current;")) {
  throw new Error("Each analysis attempt must receive a unique run identity.");
}
if (!source.includes("analysisRunIdRef.current !== runId")) {
  throw new Error("Late analysis results and errors must be ignored after cancellation or unmount.");
}
if (!source.includes("const cancelAnalysis = () =>") || !source.includes("analysisRunIdRef.current += 1;")) {
  throw new Error("The selfie flow must expose a cancellation path that invalidates the active analysis run.");
}
if (!source.includes('label="Cancel analysis"')) {
  throw new Error("The analysing state must expose an accessible cancel action.");
}
if (!source.includes('setStage("review")')) {
  throw new Error("Cancelling analysis must return the user to the review state without discarding the selected photo.");
}
if (!source.includes("setStatusMessage(\"Analysis cancelled. Your selected selfie is still available for review and was not replaced.\")") || !source.includes('accessibilityLiveRegion="polite"')) {
  throw new Error("Cancellation must announce a polite recovery message and confirm that the selected photo was preserved.");
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "Analysis runs have cancellation-safe identities.",
    "Late provider results and errors are ignored after invalidation.",
    "Users can cancel a slow analysis and return to review without losing the selfie.",
    "Cancellation exposes a polite accessible recovery announcement.",
  ],
}, null, 2));
