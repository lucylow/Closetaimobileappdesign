import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

const root = process.cwd();
const checkout = readFileSync(resolve(root, 'app/skin/mock-checkout.tsx'), 'utf8');
const cart = readFileSync(resolve(root, 'app/skin/mock-cart.tsx'), 'utf8');

const requiredCheckoutStates = [
  "type CheckoutStep = 1 | 2 | 3 | 4",
  "Prototype studio handoff",
  "Digital order summary",
  "Mock card ending 4242",
  "Mock wallet",
  "Simulate mock payment",
  "Mock payment simulated",
  "No payment, address, email, personal data, order, reservation, live price, live inventory, or brand/store contact is created by this flow.",
  "MOCK_COMMERCE_DISCLOSURE",
  "Static screenshot preview: fictional sample cart lines are shown only for route review.",
];
for (const required of requiredCheckoutStates) {
  if (!checkout.includes(required)) throw new Error(`Multi-step mock checkout must retain: ${required}`);
}

const prohibitedPaymentCollection = ['TextInput', 'cardNumber', 'cvv', 'billingAddress', 'checkoutUrl', 'WebView', 'fetch(', 'apiRequest('];
for (const prohibited of prohibitedPaymentCollection) {
  if (checkout.includes(prohibited)) throw new Error(`Mock checkout must not collect or send real payment/order data: ${prohibited}`);
}
if (!checkout.includes("line.availability === 'out_of_stock'") || !checkout.includes('Mock checkout paused')) {
  throw new Error('Mock checkout must stop when a fictional cart line is unavailable.');
}
if (!cart.includes("router.push(\"/skin/mock-checkout\")") || !cart.includes('Simulate Mock Checkout')) {
  throw new Error('Mock cart must route eligible simulated carts into the multi-step checkout flow.');
}
if (!checkout.includes('Your cart remains local') && !checkout.includes('local prototype confirmation')) {
  throw new Error('Mock checkout confirmation must explicitly remain local-only.');
}

console.log(JSON.stringify({
  result: 'PASS',
  steps: 4,
  assertions: [
    'The checkout contains fictional delivery, payment, review, and confirmation steps.',
    'No personal, address, card, CVV, wallet, network-payment, or external-store data is collected or sent.',
    'Unavailable fictional inventory blocks checkout and the confirmation remains local-only.',
    'The cart uses the current native Simulate Mock Checkout label while retaining the multi-step route.',
  ],
}, null, 2));
