import { readFileSync } from "node:fs";

const journey = readFileSync("components/skin/SkinJourneyPage.tsx", "utf8");
const appContext = readFileSync("contexts/AppContext.tsx", "utf8");
const serverRoutes = readFileSync("server/routes.ts", "utf8");
const wardrobeEngine = readFileSync("shared/outfit-recommendations.ts", "utf8");

const assertions: Array<[boolean, string]> = [
  [journey.includes('await generateOutfits(styleOccasion)') || journey.includes('await generateOutfits("Skin × Style")'), "Skin × Style action calls the shared outfit-generation method with the current occasion context."],
  [journey.includes('router.push("/(tabs)/outfits")'), "Successful Skin × Style action opens the active Outfits tab."],
  [journey.includes('router.push("/(tabs)/wardrobe")'), "Empty wardrobe state sends the user to the active Wardrobe tab."],
  [appContext.includes("/api/outfits/suggest"), "The shared outfit-generation method uses the live outfit suggestion endpoint when available."],
  [appContext.includes("buildWardrobeRecommendations") && wardrobeEngine.includes("Every recommended item ID came from") === false && wardrobeEngine.includes("from the caller's actual wardrobe"), "The offline fallback uses the shared engine to compose only items from the current user wardrobe."],
  [serverRoutes.includes('app.post("/api/outfits/suggest"'), "The server exposes the live outfit suggestion endpoint."],
];

const failures = assertions.filter(([passed]) => !passed).map(([, message]) => message);
if (failures.length) throw new Error(`Skin × Style wiring failures: ${failures.join(" | ")}`);

console.log(JSON.stringify({ result: "PASS", assertions: assertions.map(([, message]) => message) }, null, 2));
