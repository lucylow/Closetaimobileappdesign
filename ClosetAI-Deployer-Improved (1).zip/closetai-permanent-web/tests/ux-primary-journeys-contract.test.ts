import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const root = process.cwd();
const addItem = readFileSync(resolve(root, "app/add-item.tsx"), "utf8");
const wardrobe = readFileSync(resolve(root, "app/(tabs)/wardrobe.tsx"), "utf8");
const outfits = readFileSync(resolve(root, "app/(tabs)/outfits.tsx"), "utf8");
const tryOn = readFileSync(resolve(root, "app/(tabs)/tryon.tsx"), "utf8");

if (addItem.includes("images.unsplash.com")) {
  throw new Error("The Add Item flow must not silently substitute a generic remote garment image for the user's wardrobe item.");
}
if (!addItem.includes("imageUrl: imageUri")) {
  throw new Error("The Add Item flow must save the photo selected by the user.");
}
if (!addItem.includes("Boolean(imageUri && name.trim()")) {
  throw new Error("The Add Item flow must require both a photo and a name before saving.");
}
if (!addItem.includes("requestMediaLibraryPermissionsAsync") || !addItem.includes("Photo access is needed")) {
  throw new Error("The Add Item flow must provide a recoverable photo-permission path.");
}
if (!addItem.includes('accessibilityLiveRegion="assertive"')) {
  throw new Error("Add Item validation feedback must be announced to assistive technology.");
}

if (!wardrobe.includes("const isCatalogEmpty = wardrobeItems.length === 0")) {
  throw new Error("Wardrobe must distinguish an entirely empty closet from an empty category filter.");
}
if (!wardrobe.includes("setSelectedCategory(null)") || !wardrobe.includes("Show all items")) {
  throw new Error("Wardrobe must provide a direct recovery action for an empty category filter.");
}
if (!wardrobe.includes("No generic garment image is added in your place.")) {
  throw new Error("Wardrobe's first-run state must communicate the user-owned inventory expectation.");
}

if (!outfits.includes("const itemsNeeded = Math.max(0, 2 - wardrobeItems.length)")) {
  throw new Error("Outfits must explain the actual remaining wardrobe requirement.");
}
if (!outfits.includes("router.push('/add-item')") || !outfits.includes("Add a wardrobe item")) {
  throw new Error("Outfits must directly hand insufficient-inventory users into wardrobe creation.");
}
if (!outfits.includes("setTab('suggested')") || !outfits.includes("View suggestions")) {
  throw new Error("The saved-outfit empty state must route users back to useful suggested outfits.");
}

if (!tryOn.includes("router.push('/add-item')") || !tryOn.includes("Add an item")) {
  throw new Error("Try-On must provide an in-context wardrobe-add handoff when no garments are available.");
}
if (!tryOn.includes('accessibilityLiveRegion="polite"') || !tryOn.includes('accessibilityRole="progressbar"')) {
  throw new Error("Try-On processing status must be announced as an accessible progress state.");
}
if (!tryOn.includes('accessibilityLiveRegion="assertive"') || !tryOn.includes('accessibilityRole="alert"')) {
  throw new Error("Try-On errors must be announced as accessible alerts.");
}
if (!tryOn.includes("Creates a result using your selected photo only.")) {
  throw new Error("Try-On readiness guidance must retain the user-photo-only guarantee.");
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "Wardrobe additions require a user-selected photo and recognizable name, with permission recovery and no stock-image substitution.",
    "Wardrobe, Outfits, and Try-On empty states provide contextual next actions instead of dead ends.",
    "Try-On loading and error feedback remain accessible and the user-photo-only guarantee remains explicit.",
  ],
}, null, 2));
