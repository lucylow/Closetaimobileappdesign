import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

const source = readFileSync(resolve(process.cwd(), 'contexts/AppContext.tsx'), 'utf8');

for (const required of [
  'function getTryOnPollingStatus(value: unknown): string | null',
  "if (!value || typeof value !== 'object') return null;",
  "if (typeof status !== 'string' || status.trim().length === 0) return null;",
  'let invalidOrUnrecognizedStatusResponses = 0;',
  'const response = await statusRes.json() as unknown;',
  'const pollingStatus = getTryOnPollingStatus(response);',
  'if (!pollingStatus) {',
  'if (invalidOrUnrecognizedStatusResponses >= 3) {',
  "!['queued', 'processing'].includes(pollingStatus)",
  'invalidOrUnrecognizedStatusResponses = 0;',
  'Live virtual try-on returned incomplete status updates.',
  'Live virtual try-on returned an unrecognized status repeatedly.',
  'no stock model or unrelated image was used.',
]) {
  if (!source.includes(required)) throw new Error(`Bounded YouCam fashion polling recovery missing: ${required}`);
}

const parser = source.indexOf('function getTryOnPollingStatus(value: unknown): string | null');
const response = source.indexOf('const response = await statusRes.json() as unknown;', parser);
const parsedStatus = source.indexOf('const pollingStatus = getTryOnPollingStatus(response);', response);
const malformedRecovery = source.indexOf('if (!pollingStatus) {', parsedStatus);
const completedNormalization = source.indexOf('const completedResult = normalizeCompletedTryOnJob(status, selfieUri, garmentIds);', malformedRecovery);
const unrecognizedRecovery = source.indexOf("if (!['queued', 'processing'].includes(pollingStatus))", completedNormalization);

if ([parser, response, parsedStatus, malformedRecovery, completedNormalization, unrecognizedRecovery].some((index) => index === -1)
  || parser > response
  || response > parsedStatus
  || parsedStatus > malformedRecovery
  || malformedRecovery > completedNormalization
  || completedNormalization > unrecognizedRecovery) {
  throw new Error('Polling responses must be structurally validated before normalization, then receive bounded malformed or unrecognized-status recovery.');
}

console.log(JSON.stringify({
  result: 'PASS',
  assertions: [
    'Malformed polling payloads are retried briefly before resolving to a source-labeled user-photo preview.',
    'Only queued and processing are treated as valid nonterminal progress states.',
    'Persistent unrecognized statuses cannot leave the mobile interface polling indefinitely or imply a live result.',
    'Every polling recovery fallback preserves the selected user photo and excludes stock or unrelated imagery.',
  ],
}, null, 2));
