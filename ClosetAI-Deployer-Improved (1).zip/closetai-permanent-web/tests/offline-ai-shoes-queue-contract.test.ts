import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const root = process.cwd();
const queue = readFileSync(resolve(root, "lib/ai-shoes-retry-queue.ts"), "utf8");
const screen = readFileSync(resolve(root, "app/tryon/shoes.tsx"), "utf8");

for (const required of [
  '@closetai_ai_shoes_retry_queue_v1',
  'MAX_QUEUE_AGE_MS',
  'saveAiShoesRetryQueue',
  'loadAiShoesRetryQueue',
  'clearAiShoesRetryQueue',
  'targetPhotoConfirmed: true',
  'referenceConfirmed: true',
  'consent: true',
]) {
  if (!queue.includes(required)) throw new Error(`The AI Shoes local retry queue must retain: ${required}`);
}

for (const required of [
  'const [queuedRetry, setQueuedRetry] = React.useState<AiShoesRetryQueueEntry | null>(null);',
  'loadAiShoesRetryQueue()',
  'saveAiShoesRetryQueue(entry)',
  'AI Shoes retry saved locally',
  'cloud-offline-outline',
  'Retry saved AI Shoes preview',
  'Retries the same two selected images and settings.',
  'no stock or fabricated preview was added.',
  'const retryQueuedPreview = () =>',
  'setStyle(entry.style);',
  'setRenderingSetting(entry.renderingSetting);',
]) {
  if (!screen.includes(required)) throw new Error(`The native AI Shoes flow must retain: ${required}`);
}

if (!screen.includes('setQueuedRetry(null);\n        void clearAiShoesRetryQueue();')) {
  throw new Error('Changing a selected AI Shoes image must clear stale queued retry metadata.');
}
if (!screen.includes('setQueuedRetry(null);\n      void clearAiShoesRetryQueue();')) {
  throw new Error('Successful AI Shoes completion must clear local retry metadata.');
}
if (!queue.includes('Date.now() - queuedAt <= MAX_QUEUE_AGE_MS')) {
  throw new Error('AI Shoes retry metadata must expire instead of persisting indefinitely.');
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "AI Shoes retry metadata is local, bounded, and includes only explicit user-selected settings.",
    "AI Shoes exposes accessible Retry now and Dismiss recovery controls without fabricated imagery.",
    "Changing input or completing successfully clears stale local retry metadata.",
  ],
}, null, 2));
