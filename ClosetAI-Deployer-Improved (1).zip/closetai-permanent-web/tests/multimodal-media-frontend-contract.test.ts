import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const root = process.cwd();
const mediaStatus = readFileSync(resolve(root, "components/ui/MediaStatusCard.tsx"), "utf8");
const addItem = readFileSync(resolve(root, "app/add-item.tsx"), "utf8");
const selfieFlow = readFileSync(resolve(root, "components/skin/SelfieFlowScreen.tsx"), "utf8");
const liveCamera = readFileSync(resolve(root, "components/skin/LiveSkinCamera.tsx"), "utf8");
const tryOn = readFileSync(resolve(root, "app/(tabs)/tryon.tsx"), "utf8");
const shoes = readFileSync(resolve(root, "app/tryon/shoes.tsx"), "utf8");
const resultScreen = readFileSync(resolve(root, "app/tryon-result.tsx"), "utf8");

if (!mediaStatus.includes('"user-photo"') || !mediaStatus.includes('"reference"') || !mediaStatus.includes('"temporary-result"')) {
  throw new Error("The reusable media-status component must distinguish user media, reference media, and temporary generated output.");
}
if (!mediaStatus.includes("provenance")) {
  throw new Error("The media-status component must explicitly document source provenance intent.");
}

if (addItem.includes("images.unsplash.com") || !addItem.includes("imageUrl: imageUri")) {
  throw new Error("Wardrobe creation must save the user-selected garment photo and must not substitute a stock image.");
}
if (!addItem.includes("kind=\"user-photo\"") || !addItem.includes("Your garment photo is selected")) {
  throw new Error("Wardrobe photo selection must visibly identify the selected user media.");
}

if (!selfieFlow.includes("Only this photo can be sent") || !selfieFlow.includes('accessibilityLiveRegion="polite"')) {
  throw new Error("The selfie review flow must identify the selected media and announce optional analysis progress.");
}
if (!selfieFlow.includes('accessibilityLabel="Consent to general skin guidance"') || !selfieFlow.includes('accessibilityRole="alert"')) {
  throw new Error("The selfie consent and error states must be accessible.");
}
if (!liveCamera.includes("camera stream is not stored") || !liveCamera.includes('"Capture camera frame for review"')) {
  throw new Error("Live camera capture must retain a clear non-retention guarantee and accessible capture control.");
}

if (!tryOn.includes("ClosetAI uses only this selected photo") || !tryOn.includes("wardrobe item${selectedGarments.length")) {
  throw new Error("Primary Try-On must label both the selected user photo and selected wardrobe-media context.");
}
if (!tryOn.includes("never substitutes a stock model")) {
  throw new Error("Primary Try-On must retain its no-stock-model guarantee.");
}

if (!shoes.includes("Your target photo is selected") || !shoes.includes("Your shoe reference is selected")) {
  throw new Error("AI Shoes must distinguish the user target image from the shoe reference image.");
}
if (!shoes.includes("Temporary provider-rendered preview") || !shoes.includes('accessibilityRole="progressbar"')) {
  throw new Error("AI Shoes must label temporary generated output and announce generation progress.");
}
if (!shoes.includes('accessibilityRole="alert"') || !shoes.includes("no stock, demo, stale, or fabricated preview")) {
  throw new Error("AI Shoes must announce errors and prohibit fabricated fallback media.");
}

if (!resultScreen.includes("Temporary try-on result") || !resultScreen.includes("Try another look")) {
  throw new Error("Standalone try-on results must identify temporary generated media and offer a productive recovery action.");
}
if (!resultScreen.includes("fit, size, comfort, or purchase guarantee")) {
  throw new Error("Standalone try-on results must retain the appropriate non-guarantee context.");
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "Selected user photos, reference media, and temporary generated results are visibly and accessibly distinguished.",
    "Wardrobe, selfie, camera, Try-On, and AI Shoes workflows retain user-owned-media and no-stock-substitution boundaries.",
    "Media processing, error, consent, and recovery states provide accessible feedback without fabricated fallback output.",
  ],
}, null, 2));
