import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const source = readFileSync(join(root, "app/tryon/shoes.tsx"), "utf8");

if (!source.includes("useFocusEffect(React.useCallback")) {
  throw new Error("AI Shoes must refresh permission state when the screen regains focus.");
}
if (!source.includes("ImagePicker.getMediaLibraryPermissionsAsync()")) {
  throw new Error("AI Shoes must query current photo-library permission state.");
}
if (!source.includes("const openPhotoSettings = async () =>")) {
  throw new Error("AI Shoes must provide a direct Settings recovery action.");
}
if (!source.includes("accessibilityLabel=\"Open photo settings\"")) {
  throw new Error("The AI Shoes Settings action must be accessible.");
}
if (!source.includes("Photo access is currently off. Enable it in Settings")) {
  throw new Error("AI Shoes must disclose blocked photo access in-app.");
}
if (!source.includes("The selected-photo workflow remains optional.")) {
  throw new Error("Settings recovery must preserve the optional selected-photo boundary.");
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "AI Shoes refreshes photo permission state on focus.",
    "Blocked access offers accessible device Settings recovery.",
    "The selected-photo workflow remains optional and clearly disclosed.",
  ],
}, null, 2));
