import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const source = readFileSync(resolve(process.cwd(), "app/onboarding.tsx"), "utf8");

for (const required of [
  "const EMOTIONAL_MOMENTS = [",
  "Start with what feels like you",
  "A little clarity can feel lighter",
  "You stay in the picture",
  "Make space for your point of view",
  "There is no perfect closet or perfect pace.",
  "Try-on starts with your own photo and your permission—never a substitute person.",
  "const FIRST_WINS = [",
  "Add one piece you already love",
  "Plan one outfit around your day",
  "Preview only with a photo you choose",
  "Keep your style notes for yourself or share later",
]) {
  if (!source.includes(required)) throw new Error(`Supportive onboarding content missing: ${required}`);
}

for (const required of [
  "YOUR FIRST WIN",
  "A gentle starter goal only—no credit, discount, purchase, or commitment.",
  "not a credit, discount, or purchase offer.",
  "accessibilityLabel={`${emotionalMoment.title}. ${emotionalMoment.body}`}",
  "accessibilityLabel={`Your first win: ${FIRST_WINS[currentIndex]}. This is an optional starter goal, not a credit, discount, or purchase offer.`}",
]) {
  if (!source.includes(required)) throw new Error(`Onboarding incentive transparency or accessibility missing: ${required}`);
}

for (const forbidden of [
  "Free credits",
  "Claim reward",
  "Limited time offer",
  "Buy now",
  "Pay now",
]) {
  if (source.includes(forbidden)) throw new Error(`Coercive or fabricated incentive remains in onboarding: ${forbidden}`);
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "Every onboarding step includes a supportive, autonomy-respecting emotional moment.",
    "The first-win prompt is an optional behavioral starter goal, not a fabricated financial incentive.",
    "The emotional and incentive content preserves the user-photo-only and voluntary-sharing boundaries.",
  ],
}, null, 2));
