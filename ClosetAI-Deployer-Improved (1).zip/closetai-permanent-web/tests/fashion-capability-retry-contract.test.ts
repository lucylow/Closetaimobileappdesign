import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const source = readFileSync(join(root, "app/(tabs)/tryon.tsx"), "utf8");

if (!source.includes("const [capabilityRetryNonce, setCapabilityRetryNonce] = useState(0);")) {
  throw new Error("Fashion capability discovery must have a retry trigger.");
}
if (!source.includes("const retryFashionCapability = () =>")) {
  throw new Error("Fashion capability discovery must expose a retry action.");
}
if (!source.includes("setFashionCapability('checking')")) {
  throw new Error("Retry must return the capability UI to a checking state.");
}
if (!source.includes("setCapabilityRetryNonce(value => value + 1)")) {
  throw new Error("Retry must cause the capability request effect to run again.");
}
if (!source.includes("accessibilityLabel=\"Retry live fashion capability check\"")) {
  throw new Error("The capability retry action must be accessible.");
}
if (!source.includes("selected photo as the only fallback preview")) {
  throw new Error("Capability failure must preserve the selected-photo-only fallback boundary.");
}

console.log(JSON.stringify({
  result: "PASS",
  assertions: [
    "Unavailable live capability can be retried in-app.",
    "Retry resets the UI to a checking state.",
    "Photo-safe fallback messaging remains explicit.",
  ],
}, null, 2));
