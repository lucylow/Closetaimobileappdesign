# ClosetAI Multimodal Media Frontend: Implementation Walkthrough

**Scope:** This walkthrough documents the completed accessibility, live-feedback, and media-provenance improvements applied to ClosetAI’s Expo mobile frontend. It covers the private live camera flow, selfie review, primary virtual try-on, AI Shoes try-on, wardrobe photo creation, standalone result presentation, and the reusable `MediaStatusCard` component.

> **Design principle:** A user should always be able to answer three questions before proceeding: *Which media did I select? What is happening now? What will happen to the result?*

## 1. Camera Accessibility and Live Feedback

The live camera component at `components/skin/LiveSkinCamera.tsx` now treats the camera flow as an explicit, reviewable sequence rather than a black-box capture action. The permission screen labels camera access as optional and exposes two clear paths: enable the camera or return to another photo option. The controls use `accessibilityRole="button"`, plain-language labels, and hints that describe the permission outcome. This follows the React Native guidance that labels identify controls and hints explain consequences not obvious from the label alone.[1]

| Camera state | Implemented feedback | Accessibility behavior | User outcome |
|---|---|---|---|
| Permission unavailable | “Camera access is optional” with an alternative route | Button labels and hints explain permission vs. photo-library choice | No forced permission request or dead end |
| Live preview | Persistent “Live camera guidance” status | The status label states that the camera stream is not stored | The user receives a retention boundary before capture |
| Capture not ready | Capture control has `disabled: true` | `accessibilityState` exposes disabled state | Prevents an action before the camera is ready |
| Frame capture in progress | Spinner plus “Checking frame…” label | Button becomes `busy: true`; name changes to “Checking captured camera frame” | Communicates that capture has been received |
| Face guidance changes | Detector notice changes after capture | `accessibilityLiveRegion="polite"` announces the new guidance | Reports no face, multiple faces, validation success, or manual-review fallback without moving focus |
| Capture failure | Native alert with actionable retry text | The visible failure is presented immediately | Allows recovery without changing the selected flow |

### Why `polite` live feedback is used for detector notices

The detector notice is a non-blocking status update. It reports whether the image has zero faces, multiple faces, one face, or no device-level detector support. A polite live region lets an assistive technology announce the change without unnecessarily interrupting the user’s current interaction. React Native defines `polite` as an announcement mode for changing content, while `assertive` interrupts current speech.[1] WCAG’s status-message guidance likewise distinguishes waiting/progress updates from urgent error messages and advises programmatic notification without forcing focus changes.[2]

### Camera-specific privacy cues

The implementation deliberately keeps the strongest privacy copy next to the relevant interactions. The status pill announces, “The camera stream is not stored.” The capture hint says that the captured photo is reviewed before it can continue, and the bottom privacy message repeats that only the approved photo continues to the optional scan. The capture call sets `exif: false` and `base64: false`; this minimizes capture metadata and avoids creating an unnecessary base64 string at capture time. The existing review flow remains the gate before optional analysis.

## 2. Selfie Review: Consent, Processing, and Error States

`components/skin/SelfieFlowScreen.tsx` presents the selected image, quality checks, consent controls, and analysis progress as separate, understandable steps.

The preview image carries an explicit screen-reader description: “Selected selfie preview. This is the photo you chose for optional review.” A `MediaStatusCard` directly below it states that only this selected photo can be sent after consent and that choosing another selfie replaces it. The visual face guide is hidden from assistive technologies because it is decorative; this prevents redundant announcements.

The two `Switch` controls now declare a `switch` role with meaningful labels and hints. The general-guidance consent switch states that it is required before optional analysis. The normalized-summary switch explains that it saves guidance only and does not retain the original selfie in history. These states prevent a user from needing to infer how a stateful control affects the workflow. React Native exposes `disabled`, `busy`, `checked`, `selected`, and related states through `accessibilityState` so assistive technologies can communicate UI state.[1]

During analysis, the visible progress card uses `accessibilityRole="progressbar"`, `accessibilityState={{ busy: true }}`, and `accessibilityLiveRegion="polite"`. The card is named “Preparing optional skin guidance from your selected selfie.” This creates a clear announcement at the beginning of asynchronous work. If the operation fails, the error text is an `alert` with an `assertive` live region. This is intentional: a failure changes what the user must do next and should not be silently relegated to visual-only feedback.

## 3. Generation-State Enhancements for Virtual Try-On

The primary Try-On flow and the dedicated AI Shoes flow make media readiness and generation status visible before, during, and after a request.

### Primary Try-On

The primary `app/(tabs)/tryon.tsx` flow now shows source-aware cards after the user selects a selfie and after one or more wardrobe garments are selected. The selfie card states that ClosetAI uses only the selected photo and never substitutes a stock model. The wardrobe card reports the selected item count and explains that the selected wardrobe photos form the garment context for the preview.

The main generation button exposes a specific label based on capability mode, a disabled state when photo or garment selection is incomplete, and a hint that describes the remaining prerequisite. Its existing busy/error states are announced through a `progressbar` region for work in progress and an `alert` region for failures. This makes a visual loading spinner, a disabled action, and an error banner understandable without sight.

### AI Shoes Try-On

`app/tryon/shoes.tsx` now explicitly separates two media roles before generation:

| Media role | UI treatment | Reason |
|---|---|---|
| Target photo | `user-photo` status card | Identifies the user-selected person image used for the render |
| Shoe reference | `reference` status card | Identifies the supplied product image and its limited rendering purpose |
| Provider output | `temporary-result` status card | States that the generated visual is temporary and not a fit, size, comfort, or purchase guarantee |

The create button uses `accessibilityState={{ disabled, busy }}`. Its hint changes depending on readiness: it tells users either that the render will use their selected images only, or that they must choose both images and complete confirmations. When the request begins, a polite `progressbar` announces “Creating temporary AI Shoes preview.” When it fails, the error card uses `accessibilityRole="alert"` and `accessibilityLiveRegion="assertive"`. The fallback policy remains unchanged: if processing fails, the UI shows no stock, demo, stale, or fabricated preview.

The result card’s source copy is also deliberately scoped. It labels the output “Temporary provider-rendered preview,” says it is not stored in history, and repeats that it is not a fit or purchase guarantee. The source card is descriptive; it does not imply a medical, identity, product-availability, or performance claim.

## 4. Reusable `MediaStatusCard` Implementation

The reusable component is located at `components/ui/MediaStatusCard.tsx`. Its purpose is to turn media provenance into a consistent UI primitive instead of repeatedly embedding one-off disclosure text in each screen.

### API surface

```ts
export type MediaStatusKind =
  | "user-photo"
  | "reference"
  | "temporary-result"
  | "local-only";

type MediaStatusCardProps = {
  kind: MediaStatusKind;
  title: string;
  detail: string;
  tint: string;
  surface: string;
  border: string;
};
```

The `kind` parameter selects a semantic category. It does not alter data, upload behavior, storage policy, or provider requests. It only determines the icon and leading spoken prefix. `title` and `detail` are passed by the owning screen, so each workflow can state its actual context rather than relying on generic copy. Theme-aware `tint`, `surface`, and `border` values keep the card visually aligned with the screen’s light or dark theme.

### Provenance mapping

```ts
const STATUS_CONFIG = {
  "user-photo": { icon: "person-circle-outline", prefix: "Selected user photo" },
  reference: { icon: "image-outline", prefix: "Selected reference image" },
  "temporary-result": { icon: "sparkles-outline", prefix: "Temporary generated result" },
  "local-only": { icon: "phone-portrait-outline", prefix: "Local media status" },
};
```

The mapping has two jobs. Visually, it uses a stable icon for each role. Semantically, it prefixes the accessible label so an assistive-technology user hears the provenance before the screen-specific title and detail. The component creates one grouped announcement in the form:

> “Selected user photo. Your try-on photo is selected. ClosetAI uses only this selected photo for the preview and never substitutes a stock model.”

The wrapper `View` is marked `accessible`, and its `accessibilityLabel` composes the prefix, title, and detail. The icon wrapper uses `accessibilityElementsHidden` and `importantForAccessibility="no-hide-descendants"`; the screen reader hears the meaningful grouped statement once rather than repeating the decorative icon.

### Current usage

| Screen | `kind` | Example purpose |
|---|---|---|
| Add Item | `user-photo` | Confirms the exact garment photo that will be saved |
| Selfie review | `user-photo` | Confirms which selfie may continue after consent |
| Primary Try-On | `user-photo` | States that no stock model will replace the selected photo |
| Primary Try-On | `local-only` | Describes selected wardrobe photos as garment context |
| AI Shoes | `user-photo` | Identifies the target photo |
| AI Shoes | `reference` | Identifies the shoe product reference |
| AI Shoes result | `temporary-result` | Describes provider output and non-persistence |
| Standalone try-on result | `temporary-result` | Explains result scope and exposes “Try another look” recovery |

## 5. Validation and Regression Coverage

The new `tests/multimodal-media-frontend-contract.test.ts` asserts that:

1. The reusable component distinguishes user photos, references, and temporary results.
2. Add Item stores the selected photo and does not include a stock-image fallback.
3. Selfie review announces consent, progress, and errors.
4. Live camera continues to state that the stream is not stored and exposes an accessible capture control.
5. Primary Try-On preserves the user-photo-only and no-stock-model guarantee.
6. AI Shoes distinguishes target and reference images, announces progress, identifies temporary provider output, and does not use fabricated fallback media.
7. The standalone result view labels generated media and provides a productive recovery action.

The final release gate passed strict TypeScript checking, **40 of 40** independently executed regression contracts, and an Expo web export. This confirms the new frontend states did not regress the existing privacy, try-on, Skin Care, commerce, and navigation contracts.

## 6. Practical Testing Notes

The implementation creates a strong source-level and web-export validation baseline. For release preparation, the remaining recommended manual check is to verify the gestures and announcements on a physical iOS device with VoiceOver and an Android device with TalkBack. React Native documents platform differences in the underlying accessibility implementations, and `accessibilityLiveRegion` is specifically documented for Android; therefore device testing remains appropriate before a production store release.[1]

## References

[1]: https://reactnative.dev/docs/accessibility "React Native Accessibility"
[2]: https://www.w3.org/WAI/WCAG22/Understanding/status-messages.html "WCAG 2.2 Understanding Success Criterion 4.1.3: Status Messages"
