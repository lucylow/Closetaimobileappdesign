# AI Face Lift Provider Source Notes

## Official sources

- [Perfect Corp. AI Face Lift overview](https://docs.perfectcorp.com/reference/ai_face_lift)
- [Perfect Corp. AI Face Lift OpenAPI schema](https://docs.perfectcorp.com/_bundle/reference/ai_face_lift.yaml?download)

| Item | Verified provider detail | ClosetAI implementation choice |
|---|---|---|
| Pre-process create | `POST /s2s/v2.0/task/face-lift/pre-process` | Always used after private upload to make a single-face gate enforceable server-side. |
| Pre-process status | `GET /s2s/v2.0/task/face-lift/pre-process/{task_id}` | Bounded server polling; results never expose face bounding boxes to the mobile app. |
| Effect create | `POST /s2s/v2.0/task/face-lift` | Server-only request using `src_file_id`, `version: "1.0"`, `type: "custom"`, index `0`, and validated features. |
| Effect status | `GET /s2s/v2.0/task/face-lift/{task_id}` | Bounded server polling; only an HTTPS temporary provider URL reaches Expo. |
| Features | `eye_bag`, `cheek`, `forehead`, `shape`, `mouth`, and global smoothing values, all 0–100 | Support five documented feature-level controls only. Do not send global skin smoothing; an all-zero custom payload is rejected. |
| Source image | `src_file_id` or public source URL | Private file upload plus `src_file_id`; no public user-photo URL is required. |
| Output URL | Provider documents a URL valid for two hours | Do not persist the URL, original photo, raw detection results, task IDs, or provider response. |
| Provider image specification | JPEG/JPG/PNG under 10MB, long side up to 1920, visible face | UI provides quality guidance and server bounds payload and MIME type. |

## ClosetAI product boundary

This feature is an optional **cosmetic face-photo visualization** only. It is not a medical procedure plan, health or skin diagnosis, age/gender/identity inference, attractiveness or beauty assessment, or a promise of an actual outcome. The app requires explicit consent, accepts only the user-selected photo, enforces a single detected face, refuses all-zero custom adjustments, does not show source-photo face boxes, and never substitutes a stock, demo, or fabricated output after a failure.
