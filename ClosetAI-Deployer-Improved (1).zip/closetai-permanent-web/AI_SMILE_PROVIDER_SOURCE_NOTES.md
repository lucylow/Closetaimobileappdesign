# AI Smile Provider Source Notes

## Official sources

- [Perfect Corp. AI Smile overview](https://docs.perfectcorp.com/reference/ai_smile)
- [Perfect Corp. AI Smile OpenAPI schema](https://docs.perfectcorp.com/_bundle/reference/ai_smile.yaml?download)

| Item | Verified provider detail | ClosetAI implementation choice |
|---|---|---|
| Task creation | `POST /s2s/v2.0/task/ai-smile` | Server-only call with the existing YouCam v2 credential helper. |
| Task status | `GET /s2s/v2.0/task/ai-smile/{task_id}` | Bounded server polling; no task ID or provider credential reaches Expo. |
| Source image | `src_file_id` or a public source URL | Private file upload plus `src_file_id`; ClosetAI never needs a public user-photo URL. |
| Required control | `expression_type` | Only the two documented values are permitted: `smile_with_teeth_visible` and `closed_mouth_smile`. |
| Output | Single provider result URL valid for two hours | Return only a valid HTTPS temporary URL and selected expression style; do not persist it. |
| Input guidance | Single-person image; JPEG/JPG/PNG/HEIC, below 10MB, maximum long side 4096px | UI asks for a clear photo containing only the user; route applies payload and MIME bounds. |
| Provider error conditions | File size, malformed parameters, download, no face, inference, internal errors | Route uses transparent retry guidance and never creates a stock or mock output. |

## ClosetAI product boundary

This optional feature is a **creative smile photo visualization**. It is not a diagnosis, mental-health or emotion assessment, identity inference, attractiveness rating, treatment recommendation, or promise of an actual outcome. The app requires explicit consent, accepts only the user-selected photo, does not claim that it detects the user’s original mood or expression, does not save the source photo or temporary result URL in history, and never substitutes stock, demo, stale, or fabricated imagery after a failure.
