# Legacy Figma Web Source

The original `src/app` directory was preserved here because Expo Router prioritises `src/app` over the React Native `app` directory. The React Native mobile application now uses the repository root `app/` directory as its active Expo Router source. The legacy files are retained unchanged for design-reference or separate web-workflow use.
