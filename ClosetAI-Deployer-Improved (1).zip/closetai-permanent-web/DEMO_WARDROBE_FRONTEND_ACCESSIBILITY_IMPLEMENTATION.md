# Fictional Demo Wardrobe Frontend and Accessibility Implementation

**Scope.** This guide documents the opt-in fictional adult women’s Demo Mode wardrobe feature in the ClosetAI Expo frontend. It covers the data structures, generic garment-reference image provenance register, local-state loading path, accessible chooser semantics, and keyboard behavior. The feature is intentionally separate from user-owned selfies, virtual try-on person media, live product inventory, and provider-generated results.

> **Disclosure boundary:** The UI presents these records as fictional prototype data. A selected demo wardrobe is a local collection of generic garment-reference items; it is not a real person’s closet, a user profile, a live retailer catalog, a fit recommendation, or a virtual try-on result.

## 1. Frontend architecture at a glance

The implementation has four deliberately separated layers. The catalog layer defines immutable fictional examples and their item metadata. The asset layer keeps a human-readable provenance register for the added garment images. The state layer clones an explicitly selected example into local Demo Mode state. Finally, the Wardrobe screen renders an accessible chooser only when the local wardrobe is empty and Demo Mode is enabled.

| Layer | File | Responsibility | Boundary preserved |
|---|---|---|---|
| Domain types and fixtures | `lib/demo-data.ts` | Defines `WardrobeItem`, `FictionalAdultWomenDemoExample`, five example wardrobes, a disclosure constant, and clone helper. | Fixtures cannot silently become user-owned media. |
| Asset source register | `assets/demo-garments/ASSET_SOURCES.md` | Maps local filename, search context, and published CDN URL for six garment-only assets. | Image provenance remains auditable and separate from user uploads. |
| State and persistence | `contexts/AppContext.tsx` | Loads a chosen cloned example only in Demo Mode, clears generated/saved outfits, derives a local style profile, and persists the local collection. | No live backend write or AI provider request is required. |
| User interface | `app/(tabs)/wardrobe.tsx` | Provides a visible disclosure, accessible radio choices, selection feedback, keyboard navigation, load state, and error recovery. | The user makes an explicit choice; no seed data is injected invisibly. |

## 2. Demo wardrobe and metadata structure

The shared `WardrobeItem` model contains the normal wardrobe fields: stable `id`, visible `name`, constrained `category`, `color`, `brand`, `imageUrl`, `tags`, fictional usage metadata, `notes`, and `createdAt`. Each fixture item is constructed by `fictionalDemoItem(exampleId, index, input)`. That helper creates a namespaced ID such as `fictional-adult-women-leila-color-capsule-3`, uses a fixed fixture timestamp, and inserts a visible-in-data note:

```ts
notes: 'Fictional Demo Mode · Adult women’s example wardrobe. Not a user item, live inventory record, or product recommendation.'
```

The example-level type is intentionally small. It holds a stable `id`, display name, a literal `audienceLabel` of `Fictional adult women’s style example`, a concise `styleContext`, and an eight-item `wardrobe` array.

```ts
type FictionalAdultWomenDemoExample = {
  id: string;
  displayName: string;
  audienceLabel: 'Fictional adult women’s style example';
  styleContext: string;
  wardrobe: WardrobeItem[];
};
```

The catalog contains five opt-in contexts: Maya for creative city styling, Sofia for active travel, Aisha for elevated weekend styling, Leila for a color capsule, and Nora for layered weekend looks. Each contains eight garment or accessory records so the existing wardrobe-only outfit composer has enough real local references to work with. It never requires a stock person image or a fabricated outfit render.

### Clone-before-load rule

`cloneFictionalAdultWomenDemoExample(id)` returns a new example object and clones each item’s `tags` array before any local mutation. The AppContext loader uses that clone rather than the immutable catalog export. This protects the source fixture from changes caused by wearing, editing, deleting, or otherwise modifying a local Demo Mode wardrobe.

```ts
wardrobe: example.wardrobe.map((item) => ({
  ...item,
  tags: [...item.tags],
}))
```

## 3. Garment image source register

`FICTIONAL_DEMO_GARMENT_REFERENCE_IMAGES` is a typed, six-URL list for the additional generic garment-only images. `ASSET_SOURCES.md` is the matching metadata source register, providing one row per image with the following fields.

| Register field | Meaning | Operational purpose |
|---|---|---|
| Local asset | Repository copy stored under `assets/demo-garments/` | Provides a reviewable project artifact. |
| Search result context | Human-readable description of the garment-only search result | Records why the image was selected and confirms the intended non-person use. |
| Published demo URL | URL used by `imageUrl` in the fixture records | Lets Expo render the generic reference image in the demo wardrobe. |

The catalog comments and register specify that these are generic garment or accessories references only. The records are not used as `selfieUri`, never enter the user-photo virtual try-on path, do not indicate live inventory, and do not represent fit, purchase, identity, or health information.

## 4. Explicit local Demo Mode loading

The AppContext method `loadFictionalAdultWomenDemoExample(id)` is guarded by `demoMode`. It fails closed outside Demo Mode and fails clearly when an unknown catalog ID is passed.

```ts
if (!demoMode) {
  throw new Error('Fictional example wardrobes are available only while Demo Mode is active.');
}
const example = cloneFictionalAdultWomenDemoExample(id);
if (!example) {
  throw new Error('That fictional demo wardrobe is unavailable. Please choose another example.');
}
```

Once a valid selection is made, the method replaces the local wardrobe with the cloned example, clears prior generated and saved outfits, derives a local style profile from the selected items, stores a source-aware notice, and persists only local state. It does not call a provider, upload a picture, or create a live retailer record.

```ts
setWardrobeItems(example.wardrobe);
setOutfits([]);
setSavedOutfits([]);
setStyleProfile(derivePersonalStyleProfile(example.wardrobe));
await Promise.all([
  persistWardrobe(example.wardrobe),
  persistSaved([]),
  AsyncStorage.setItem(STORAGE_KEYS.STYLE_PROFILE, JSON.stringify(...)),
]);
```

The Wardrobe screen shows the chooser only when `isCatalogEmpty && demoMode`. This preserves a primary manual route—adding the user’s own photographed garment—while allowing a demonstrator to choose a disclosed fictional sample deliberately.

## 5. Specific accessible labels, roles, states, and feedback

React Native recommends accessible labels to identify controls, hints for outcomes that are not obvious from the label alone, roles to communicate purpose, and state to communicate selection, disabled, and busy status.[1] The chooser implements those patterns as follows.

| Element | Implemented semantics | User-facing / assistive-technology result |
|---|---|---|
| Chooser container | `accessibilityRole="radiogroup"`, label `Fictional adult women’s demo wardrobe examples` | Announces the collection as one mutually exclusive choice set. |
| Chooser container hint | Explains that it is fictional prototype data and lists browser keyboard navigation plus load activation. | Establishes the outcome before a user acts. |
| Individual example | `accessibilityRole="radio"`, `accessibilityState={{ selected }}` | Announces an example as a selectable radio choice and exposes its active state. |
| Individual example label | `Maya, Fictional adult women’s style example, selected` (with the final phrase only when selected) | Gives name, disclosure class, and current state in one announcement. |
| Individual example hint | Its `styleContext` followed by arrow/Home/End guidance. | Provides context without treating style as an identity, size, or beauty assessment. |
| Selected-example status | A text update with `accessibilityLiveRegion="polite"` | Requests a non-interrupting update such as `Leila selected. Color capsule, design studio, and polished daytime context.` Dynamic live-region behavior depends on the platform and assistive technology.[1] |
| Load control | Dynamic label: `Load Leila fictional adult women’s demo wardrobe`; hint explains local Demo Mode scope and Tab/Enter/Space activation. | Makes the selected action specific rather than generic. |
| Loading state | `accessibilityState={{ disabled: true, busy: true }}` and visible spinner/text. | Prevents duplicate activation and communicates that work is in progress. |
| Error state | `accessibilityRole="alert"` and `accessibilityLiveRegion="assertive"` | Announces an unavailable example or failed load immediately, with an actionable retry path. |

The container itself also displays `FICTIONAL_ADULT_WOMEN_DEMO_DISCLOSURE` in visible text. The disclosure states that the names, wardrobes, activities, and usage details are prototype data and that garment images are not user photos, live inventory, fit advice, or identity assessments.

## 6. Implemented keyboard behavior on Expo web

The chooser uses normal document order for entry and exit. On Expo web, `Pressable` retains its normal keyboard activation path: **Tab** and **Shift+Tab** move to and away from the choices and load button, while **Enter** or **Space** activates the currently focused pressable. The custom web handler supplements that with radio-group navigation.

| Key | Implementation | Result |
|---|---|---|
| `Right Arrow` or `Down Arrow` | Calls `handleDemoChoiceKeyDown`, selects the next example, loops after Nora to Maya, then focuses the new choice. | Advances selection without requiring a pointer. |
| `Left Arrow` or `Up Arrow` | Selects the previous example, loops before Maya to Nora, then focuses the new choice. | Moves backward through the same single-choice set. |
| `Home` | Selects and focuses the first example. | Provides a quick first-option shortcut. |
| `End` | Selects and focuses the last example. | Provides a quick last-option shortcut. |
| `Tab` / `Shift+Tab` | Relies on native browser focus order. | Moves into or out of the radio-choice region and to the load action. |
| `Enter` / `Space` on a choice or load button | Relies on the standard `Pressable` activation behavior. | Chooses a focused option or loads the currently selected local demo wardrobe. |

The implementation cancels the browser’s default behavior only for the handled navigation keys, calls `chooseDemoExample()` to clear prior loading errors and update selection, and schedules focus on the newly selected `Pressable` via `requestAnimationFrame`.

```ts
chooseDemoExample(fictionalAdultWomenDemoExamples[nextIndex].id);
requestAnimationFrame(() => demoChoiceRefs.current[nextIndex]?.focus?.());
```

This matches the central WAI-ARIA radio-group expectation that arrow keys move between choices and change selection, while `Tab` moves into and out of the group and `Space` selects a focused option.[2] `Home` and `End` are additionally implemented as convenience shortcuts; they are not required by the cited radio-group pattern.

## 7. Validation and remaining device checks

The `fictional-adult-women-demo-contract.test.ts` contract now verifies the following: five opt-in examples, at least eight items per example, explicit fictional labeling, allowed image hosts, a maintained image-source register, fresh clone behavior, Demo Mode-only loading, accessible `radiogroup` and `radio` roles, selection live feedback, and `Arrow`, `Home`, and `End` handler presence. Existing virtual try-on regressions continue to assert that the product never substitutes a stock model image.

The current automated suite and Expo export validate source structure and runtime compilation. Before a store release, test this chooser with an actual keyboard in a browser and, separately, with VoiceOver and TalkBack on a physical device. In particular, confirm focus visibly follows arrow navigation, the polite selection status does not over-announce, and the assertive error is announced once.

## References

[1] [React Native, “Accessibility.”](https://reactnative.dev/docs/accessibility)

[2] [W3C WAI-ARIA Authoring Practices Guide, “Radio Group Pattern.”](https://www.w3.org/WAI/ARIA/apg/patterns/radio/)
