# Provider Research Notes — Fitzpatrick Feature

## Sources consulted

| Source | Finding | URL |
|---|---|---|
| Perfect Corp. Fitzpatrick product page | States that its Fitzpatrick offering classifies an uploaded or camera-captured face photo into six Fitzpatrick skin types and is available across mobile and e-commerce contexts. This commercial page did not expose a public API request schema or endpoint. | https://www.perfectcorp.com/business/products/fitzpatrick-skin-types |
| YouCam AI API index | Lists AI Fitzpatrick Skin Type Analysis as an available Perfect Corp. technology. | https://yce.perfectcorp.com/ai-api |
| Perfect Corp. AI Skin Simulation API reference | Documents server-to-server bearer authentication, File API upload, asynchronous v2 task creation, and status polling for related cosmetic workflows. It is not an API schema for Fitzpatrick classification. | https://docs.perfectcorp.com/reference/ai_skin_simulation |

## Implementation implication

The current public sources do not provide a verified Fitzpatrick API endpoint or request/response schema. ClosetAI should therefore ship a **provider-ready adapter contract** with an explicit `notConfigured` capability state, while avoiding guessed endpoint paths or fabricated AI classifications. When Perfect Corp. provides an account-specific endpoint/schema, the adapter can be implemented server-side without changing the Expo UI or client data model.

The user-facing feature must describe any classification as an optional cosmetic skin-tone profile and not as a diagnosis, ethnicity inference, UV-safety assessment, or sunscreen prescription.
