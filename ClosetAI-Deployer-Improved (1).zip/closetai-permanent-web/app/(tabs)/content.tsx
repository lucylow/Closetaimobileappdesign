import React, { useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  ScrollView,
  Platform,
  FlatList,
  ActivityIndicator,
  Modal,
  Share,
  TextInput,
} from 'react-native';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import * as Clipboard from 'expo-clipboard';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';
import Animated, { FadeInUp, FadeIn } from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { useApp } from '@/contexts/AppContext';
import { useTheme } from '@/lib/useTheme';
import { CaptionResult, demoCaptions, Outfit, WardrobeItem } from '@/lib/demo-data';
import { shadows } from '@/constants/colors';

const TONES = [
  { key: 'casual', label: 'Casual', icon: 'chatbubble-outline' as const },
  { key: 'playful', label: 'Playful', icon: 'happy-outline' as const },
  { key: 'professional', label: 'Pro', icon: 'briefcase-outline' as const },
  { key: 'trendy', label: 'Trendy', icon: 'flame-outline' as const },
  { key: 'minimal', label: 'Minimal', icon: 'remove-outline' as const },
];

const PLATFORMS = [
  { key: 'instagram', label: 'Instagram', icon: 'logo-instagram' as const, color: '#E1306C' },
  { key: 'tiktok', label: 'TikTok', icon: 'musical-notes-outline' as const, color: '#00C9B7' },
  { key: 'twitter', label: 'X / Twitter', icon: 'logo-twitter' as const, color: '#1DA1F2' },
  { key: 'pinterest', label: 'Pinterest', icon: 'pin-outline' as const, color: '#E60023' },
];

type SelectionMode = 'outfit' | 'item';
type StudioSelection = {
  kind: SelectionMode;
  id: string;
  name: string;
  items: WardrobeItem[];
};

function selectionFromOutfit(outfit: Outfit): StudioSelection {
  return { kind: 'outfit', id: outfit.id, name: outfit.name, items: outfit.items };
}

function selectionFromItem(item: WardrobeItem): StudioSelection {
  return { kind: 'item', id: item.id, name: item.name, items: [item] };
}

function trackStudioEvent(event: string, details: Record<string, string> = {}) {
  // Keep analytics privacy-safe: never send image URLs or caption contents.
  console.info(`[Content Studio] ${event}`, details);
}

export default function ContentScreen() {
  const { colors, isDark } = useTheme();
  const insets = useSafeAreaInsets();
  const {
    outfits,
    savedOutfits,
    wardrobeItems,
    generateCaption,
    demoMode,
    credits,
    creditsUsed,
    monthlyCredits,
  } = useApp();
  const [selectionMode, setSelectionMode] = useState<SelectionMode>('outfit');
  const [selectedContent, setSelectedContent] = useState<StudioSelection | null>(null);
  const [selectedTone, setSelectedTone] = useState('casual');
  const [selectedPlatform, setSelectedPlatform] = useState('instagram');
  const [captionResult, setCaptionResult] = useState<CaptionResult | null>(null);
  const [copied, setCopied] = useState<'caption' | 'hashtags' | 'all' | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [draftCaption, setDraftCaption] = useState('');
  const [previewVisible, setPreviewVisible] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [usedDemoFallback, setUsedDemoFallback] = useState(false);

  const webTopInset = Platform.OS === 'web' ? 67 : 0;
  const allOutfits = [...outfits, ...savedOutfits.filter(s => !outfits.some(o => o.id === s.id))];
  const contentOptions = useMemo(
    () => selectionMode === 'outfit'
      ? allOutfits.map(selectionFromOutfit)
      : wardrobeItems.map(selectionFromItem),
    [allOutfits, selectionMode, wardrobeItems],
  );
  const remainingCredits = Math.max(0, monthlyCredits - creditsUsed);

  useEffect(() => {
    trackStudioEvent('studio_opened');
  }, []);

  useEffect(() => {
    if (selectedContent || isGenerating) return;
    const firstOption = contentOptions[0];
    if (firstOption) {
      setSelectedContent(firstOption);
    } else if (selectionMode === 'outfit' && wardrobeItems.length > 0 && allOutfits.length === 0) {
      setSelectionMode('item');
    }
  }, [allOutfits.length, contentOptions, isGenerating, selectedContent, selectionMode, wardrobeItems.length]);

  const handleSelectContent = (selection: StudioSelection) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setSelectedContent(selection);
    setCaptionResult(null);
    setCopied(null);
    setErrorMessage(null);
    setDraftCaption('');
    trackStudioEvent('outfit_selected', { contentType: selection.kind });
  };

  const buildDemoResult = (selection: StudioSelection): CaptionResult => {
    const seed = selection.id.split('').reduce((sum, char) => sum + char.charCodeAt(0), 0);
    const base = demoCaptions[seed % demoCaptions.length];
    const itemSummary = selection.items.slice(0, 2).map(item => `${item.color} ${item.name}`).join(' + ');
    const platformLabel = platformConfig?.label || 'social';
    return {
      ...base,
      caption: `${selection.name}: ${itemSummary || 'a look worth sharing'} — styled for ${platformLabel}.`,
      source: 'demo',
      fallbackReason: 'A local caption was used because live AI is unavailable.',
    };
  };

  const handleGenerate = async () => {
    if (!selectedContent || isGenerating) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setIsGenerating(true);
    setCaptionResult(null);
    setErrorMessage(null);
    setUsedDemoFallback(false);
    trackStudioEvent('caption_started', { contentType: selectedContent.kind });
    try {
      let result: CaptionResult;
      try {
        result = selectedContent.kind === 'outfit'
          ? await generateCaption(selectedContent.id, selectedTone, selectedPlatform)
          : buildDemoResult(selectedContent);
      } catch {
        result = buildDemoResult(selectedContent);
      }
      const isDemoResult = demoMode || result.source !== 'live-ai' || selectedContent.kind === 'item';
      const normalizedResult = isDemoResult && result.source !== 'demo'
        ? { ...result, source: 'demo' as const, fallbackReason: 'Demo Mode is active.' }
        : result;
      setCaptionResult(normalizedResult);
      setDraftCaption(normalizedResult.caption);
      setUsedDemoFallback(isDemoResult);
      trackStudioEvent('caption_completed', { source: isDemoResult ? 'demo' : 'live-ai' });
    } catch (err) {
      console.warn('[Content Studio] Generation fallback error:', err);
      const fallback = buildDemoResult(selectedContent);
      setCaptionResult(fallback);
      setDraftCaption(fallback.caption);
      setUsedDemoFallback(true);
      trackStudioEvent('caption_fallback_recovered', { contentType: selectedContent.kind });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleUseDemo = () => {
    if (!selectedContent || isGenerating) return;
    const result = buildDemoResult(selectedContent);
    setCaptionResult(result);
    setDraftCaption(result.caption);
    setUsedDemoFallback(true);
    setErrorMessage(null);
    trackStudioEvent('caption_completed', { source: 'demo' });
  };

  const currentCaption = draftCaption.trim() || captionResult?.caption || '';

  const handleCopy = async (type: 'caption' | 'hashtags' | 'all') => {
    if (!captionResult) return;
    try {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch {}
    let text = '';
    if (type === 'caption') text = currentCaption;
    else if (type === 'hashtags') text = captionResult.hashtags.join(' ');
    else text = `${currentCaption}\n\n${captionResult.hashtags.join(' ')}`;
    try {
      await Clipboard.setStringAsync(text);
      setCopied(type);
      trackStudioEvent('caption_copied', { type });
      setTimeout(() => setCopied(null), 2000);
    } catch (err) {
      console.warn('[Content Studio] Clipboard error:', err);
      setErrorMessage('Unable to copy to clipboard automatically. You can select and copy the text manually.');
    }
  };

  const platformConfig = PLATFORMS.find(p => p.key === selectedPlatform);

  const handleShare = async () => {
    if (!captionResult || !selectedContent) return;
    const message = `${currentCaption}\n\n${captionResult.hashtags.join(' ')}`;
    trackStudioEvent('share_started', { platform: selectedPlatform });
    try {
      if (Platform.OS === 'web') {
        await Clipboard.setStringAsync(message);
        setCopied('all');
        trackStudioEvent('share_completed', { result: 'copied_on_web' });
        return;
      }
      const result = await Share.share({ message, title: `${selectedContent.name} · ClosetAI` });
      trackStudioEvent('share_completed', { result: result.action || 'dismissed' });
    } catch {
      setErrorMessage('Sharing is unavailable on this device. Your post text is still ready to copy.');
    }
  };

  const openPreview = () => {
    setPreviewVisible(true);
    trackStudioEvent('preview_opened', { platform: selectedPlatform });
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView
        contentContainerStyle={[
          styles.scrollContent,
          { paddingTop: (insets.top || webTopInset) + 12 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <Animated.View entering={FadeInUp.duration(400)} style={styles.header}>
          <View>
            <Text style={[styles.title, { color: colors.text }]}>Content Studio</Text>
            <Text style={[styles.subtitle, { color: colors.textSecondary }]}>Create share-ready captions from your ClosetAI looks.</Text>
          </View>
          <View style={{ alignItems: 'flex-end', gap: 4 }}>
            <LinearGradient
              colors={['#00C9B7', '#00E5D0']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={styles.aiBadge}
            >
              <MaterialCommunityIcons name="pencil-outline" size={12} color="#FFF" />
              <Text style={styles.aiBadgeText}>AI Writer</Text>
            </LinearGradient>
            <Text style={{ fontFamily: 'Outfit_500Medium', fontSize: 11, color: colors.textTertiary }}>
              AI captions remaining: {remainingCredits}
            </Text>
          </View>
        </Animated.View>

        <Animated.View entering={FadeInUp.delay(100).duration(400)}>
          <View style={styles.modeTabsRow}>
            <Pressable
              onPress={() => {
                Haptics.selectionAsync();
                setSelectionMode('outfit');
                const first = [...outfits, ...savedOutfits][0];
                if (first) handleSelectContent(selectionFromOutfit(first));
              }}
              style={[
                styles.modeTab,
                {
                  backgroundColor: selectionMode === 'outfit' ? colors.tint + '15' : colors.surfaceSecondary,
                  borderColor: selectionMode === 'outfit' ? colors.tint : colors.border,
                },
              ]}
            >
              <Ionicons name="shirt-outline" size={14} color={selectionMode === 'outfit' ? colors.tint : colors.textSecondary} />
              <Text style={[styles.modeTabText, { color: selectionMode === 'outfit' ? colors.tint : colors.textSecondary }]}>
                Outfits ({allOutfits.length})
              </Text>
            </Pressable>
            <Pressable
              onPress={() => {
                Haptics.selectionAsync();
                setSelectionMode('item');
                const firstItem = wardrobeItems[0];
                if (firstItem) handleSelectContent(selectionFromItem(firstItem));
              }}
              style={[
                styles.modeTab,
                {
                  backgroundColor: selectionMode === 'item' ? colors.tint + '15' : colors.surfaceSecondary,
                  borderColor: selectionMode === 'item' ? colors.tint : colors.border,
                },
              ]}
            >
              <Ionicons name="albums-outline" size={14} color={selectionMode === 'item' ? colors.tint : colors.textSecondary} />
              <Text style={[styles.modeTabText, { color: selectionMode === 'item' ? colors.tint : colors.textSecondary }]}>
                Wardrobe Items ({wardrobeItems.length})
              </Text>
            </Pressable>
          </View>

          <Text style={[styles.sectionLabel, { color: colors.textSecondary }]}>
            {selectionMode === 'outfit' ? 'Select Outfit' : 'Select Wardrobe Item'}
          </Text>

          <FlatList
            data={contentOptions}
            horizontal
            showsHorizontalScrollIndicator={false}
            scrollEnabled={contentOptions.length > 0}
            keyExtractor={item => item.id}
            renderItem={({ item }) => {
              const isSelected = selectedContent?.id === item.id;
              return (
                <Pressable
                  onPress={() => handleSelectContent(item)}
                  style={({ pressed }) => [
                    styles.outfitChip,
                    {
                      borderColor: isSelected ? colors.tint : colors.border,
                      backgroundColor: isSelected ? colors.tint + '10' : colors.surface,
                      transform: [{ scale: pressed ? 0.96 : 1 }],
                    },
                    isSelected ? shadows.soft : {},
                  ]}
                >
                  <View style={styles.chipImages}>
                    {item.items.slice(0, 2).map((g, idx) => (
                      <Image
                        key={g.id + idx}
                        source={{ uri: g.imageUrl }}
                        style={[styles.chipImage, idx > 0 && { marginLeft: -10 }]}
                        contentFit="cover"
                      />
                    ))}
                  </View>
                  <Text
                    style={[styles.chipText, { color: isSelected ? colors.tint : colors.text }]}
                    numberOfLines={1}
                  >
                    {item.name}
                  </Text>
                  {isSelected && (
                    <Ionicons name="checkmark-circle" size={16} color={colors.tint} />
                  )}
                </Pressable>
              );
            }}
            contentContainerStyle={{ gap: 10, paddingRight: 20 }}
            ListEmptyComponent={
              <View style={styles.emptyHint}>
                <Text style={[styles.emptyHintText, { color: colors.textSecondary }]}>
                  {selectionMode === 'outfit' ? 'No outfits found. Try selecting an individual wardrobe item.' : 'No wardrobe items found.'}
                </Text>
              </View>
            }
          />
        </Animated.View>

        {selectedContent && (
          <Animated.View entering={FadeIn.duration(300)} style={{ marginTop: 20 }}>
            <Text style={[styles.sectionLabel, { color: colors.textSecondary }]}>Tone</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 16 }}>
              <View style={styles.chipRow}>
                {TONES.map(tone => {
                  const selected = selectedTone === tone.key;
                  return (
                    <Pressable
                      key={tone.key}
                      onPress={() => {
                        Haptics.selectionAsync();
                        setSelectedTone(tone.key);
                        setCaptionResult(null);
                      }}
                      style={[
                        styles.toneChip,
                        {
                          backgroundColor: selected ? colors.tint + '15' : colors.surfaceSecondary,
                          borderColor: selected ? colors.tint + '40' : 'transparent',
                        },
                      ]}
                    >
                      <Ionicons
                        name={tone.icon}
                        size={14}
                        color={selected ? colors.tint : colors.textSecondary}
                      />
                      <Text
                        style={[
                          styles.toneChipText,
                          { color: selected ? colors.tint : colors.textSecondary },
                        ]}
                      >
                        {tone.label}
                      </Text>
                    </Pressable>
                  );
                })}
              </View>
            </ScrollView>

            <Text style={[styles.sectionLabel, { color: colors.textSecondary }]}>Platform</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 20 }}>
              <View style={styles.chipRow}>
                {PLATFORMS.map(platform => {
                  const selected = selectedPlatform === platform.key;
                  return (
                    <Pressable
                      key={platform.key}
                      onPress={() => {
                        Haptics.selectionAsync();
                        setSelectedPlatform(platform.key);
                        setCaptionResult(null);
                      }}
                      style={[
                        styles.platformChip,
                        {
                          backgroundColor: selected ? platform.color + '15' : colors.surfaceSecondary,
                          borderColor: selected ? platform.color + '40' : 'transparent',
                        },
                      ]}
                    >
                      <Ionicons
                        name={platform.icon}
                        size={16}
                        color={selected ? platform.color : colors.textSecondary}
                      />
                      <Text
                        style={[
                          styles.platformChipText,
                          { color: selected ? platform.color : colors.textSecondary },
                        ]}
                      >
                        {platform.label}
                      </Text>
                    </Pressable>
                  );
                })}
              </View>
            </ScrollView>
          </Animated.View>
        )}

        {selectedContent && !captionResult && !isGenerating && (
          <Animated.View entering={FadeIn.duration(400)}>
            <Pressable
              onPress={handleGenerate}
              style={({ pressed }) => [
                styles.generateButton,
                { transform: [{ scale: pressed ? 0.97 : 1 }] },
              ]}
            >
              <LinearGradient
                colors={['#00C9B7', '#00E5D0']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={styles.generateButtonGradient}
              >
                <Ionicons name="sparkles" size={20} color="#FFF" />
                <Text style={styles.generateButtonText}>Generate Caption</Text>
              </LinearGradient>
            </Pressable>
            <Text style={[styles.creditNote, { color: colors.textTertiary }]}>
              Uses 3 credits
            </Text>
          </Animated.View>
        )}

        {isGenerating && (
          <Animated.View entering={FadeIn.duration(300)} style={[styles.generatingCard, { backgroundColor: colors.surface }, shadows.soft]}>
            <ActivityIndicator size="small" color="#00C9B7" />
            <Text style={[styles.generatingText, { color: colors.text }]}>
              Writing your {selectedTone} caption for {platformConfig?.label}...
            </Text>
          </Animated.View>
        )}

        {captionResult && (
          <Animated.View entering={FadeIn.duration(500)}>
            <View style={[styles.previewCard, { backgroundColor: colors.surface }, shadows.medium]}>
              <View style={styles.previewHeader}>
                <View style={styles.previewPlatform}>
                  <View style={[styles.previewPlatformIcon, { backgroundColor: (platformConfig?.color || '#00C9B7') + '15' }]}>
                    <Ionicons name={platformConfig?.icon || 'logo-instagram'} size={14} color={platformConfig?.color || '#00C9B7'} />
                  </View>
                  <Text style={[styles.previewPlatformText, { color: colors.text }]}>
                    {platformConfig?.label} Post
                  </Text>
                </View>
                <View style={[styles.toneBadge, { backgroundColor: colors.tint + '12' }]}>
                  <Text style={[styles.toneBadgeText, { color: colors.tint }]}>{selectedTone}</Text>
                </View>
              </View>

              {selectedContent && (
                <View style={[styles.previewOutfit, { borderColor: colors.border }]}>
                  {selectedContent.items.slice(0, 3).map((item, idx) => (
                    <Image
                      key={item.id + idx}
                      source={{ uri: item.imageUrl }}
                      style={[styles.previewOutfitImg, idx > 0 && { marginLeft: -8 }]}
                      contentFit="cover"
                    />
                  ))}
                  <Text style={[styles.previewOutfitName, { color: colors.textSecondary }]} numberOfLines={1}>
                    {selectedContent.name}
                  </Text>
                </View>
              )}

              <View style={[styles.captionBox, { backgroundColor: isDark ? 'rgba(255,255,255,0.04)' : 'rgba(0,0,0,0.02)' }]}>
                <Text style={[styles.captionText, { color: colors.text }]}>{captionResult.caption}</Text>
              </View>

              <View style={styles.hashtagsRow}>
                {captionResult.hashtags.map(tag => (
                  <Pressable
                    key={tag}
                    onPress={() => {
                      Haptics.selectionAsync();
                      Clipboard.setStringAsync(tag);
                    }}
                    style={[styles.hashtagChip, { backgroundColor: (platformConfig?.color || colors.tint) + '10' }]}
                  >
                    <Text style={[styles.hashtagText, { color: platformConfig?.color || colors.tint }]}>{tag}</Text>
                  </Pressable>
                ))}
              </View>

              <View style={[styles.captionActions, { borderTopColor: isDark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.05)' }]}>
                <Pressable
                  onPress={() => handleCopy('all')}
                  style={({ pressed }) => [
                    styles.copyButton,
                    { transform: [{ scale: pressed ? 0.96 : 1 }] },
                  ]}
                >
                  <LinearGradient
                    colors={copied === 'all' ? ['#27AE60', '#2ECC71'] : ['#00C9B7', '#00E5D0']}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 0 }}
                    style={styles.copyButtonGradient}
                  >
                    <Ionicons name={copied === 'all' ? 'checkmark' : 'copy-outline'} size={16} color="#FFF" />
                    <Text style={styles.copyButtonText}>{copied === 'all' ? 'Copied!' : 'Copy All'}</Text>
                  </LinearGradient>
                </Pressable>
                <Pressable
                  onPress={() => handleCopy('caption')}
                  style={({ pressed }) => [
                    styles.smallCopyBtn,
                    { borderColor: colors.border, backgroundColor: copied === 'caption' ? '#27AE6012' : 'transparent', opacity: pressed ? 0.85 : 1 },
                  ]}
                >
                  <Text style={[styles.smallCopyText, { color: copied === 'caption' ? '#27AE60' : colors.textSecondary }]}>
                    {copied === 'caption' ? 'Copied' : 'Caption'}
                  </Text>
                </Pressable>
                <Pressable
                  onPress={() => handleCopy('hashtags')}
                  style={({ pressed }) => [
                    styles.smallCopyBtn,
                    { borderColor: colors.border, backgroundColor: copied === 'hashtags' ? '#27AE6012' : 'transparent', opacity: pressed ? 0.85 : 1 },
                  ]}
                >
                  <Text style={[styles.smallCopyText, { color: copied === 'hashtags' ? '#27AE60' : colors.textSecondary }]}>
                    {copied === 'hashtags' ? 'Copied' : 'Tags'}
                  </Text>
                </Pressable>
                <View style={{ flex: 1 }} />
                <Pressable
                  onPress={handleGenerate}
                  hitSlop={8}
                >
                  <Ionicons name="refresh" size={20} color={colors.textSecondary} />
                </Pressable>
              </View>
            </View>
          </Animated.View>
        )}

        <View style={{ height: 120 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollContent: { paddingHorizontal: 20 },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 24,
    flexWrap: 'wrap',
    gap: 12,
  },
  title: { fontFamily: 'Outfit_700Bold', fontSize: 24, flexShrink: 1 },
  subtitle: { fontFamily: 'Outfit_400Regular', fontSize: 13, marginTop: 2, flexShrink: 1, flexWrap: 'wrap' },
  aiBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 12,
  },
  aiBadgeText: { fontFamily: 'Outfit_500Medium', fontSize: 11, color: '#FFF' },
  sectionLabel: {
    fontFamily: 'Outfit_600SemiBold',
    fontSize: 12,
    marginBottom: 8,
    textTransform: 'uppercase',
    letterSpacing: 0.8,
  },
  outfitChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 14,
    borderWidth: 1.5,
  },
  chipImages: { flexDirection: 'row' },
  chipImage: {
    width: 36,
    height: 36,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#FFF',
  },
  chipText: { fontFamily: 'Outfit_500Medium', fontSize: 13, maxWidth: 90 },
  emptyHint: { paddingVertical: 20 },
  emptyHintText: { fontFamily: 'Outfit_400Regular', fontSize: 14 },
  chipRow: { flexDirection: 'row', gap: 8 },
  toneChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 14,
    borderWidth: 1,
  },
  toneChipText: { fontFamily: 'Outfit_500Medium', fontSize: 12 },
  modeTabsRow: { flexDirection: 'row', gap: 10, marginBottom: 14 },
  modeTab: { flex: 1, height: 44, borderRadius: 12, borderWidth: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6 },
  modeTabText: { fontFamily: 'Outfit_600SemiBold', fontSize: 13 },
  platformChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 14,
    borderWidth: 1,
  },
  platformChipText: { fontFamily: 'Outfit_500Medium', fontSize: 13 },
  generateButton: {
    borderRadius: 28,
    overflow: 'hidden',
    shadowColor: '#00C9B7',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 6,
  },
  generateButtonGradient: {
    height: 56,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
  },
  generateButtonText: { fontFamily: 'Outfit_600SemiBold', fontSize: 17, color: '#FFF' },
  creditNote: { fontFamily: 'Outfit_400Regular', fontSize: 11, textAlign: 'center', marginTop: 8 },
  generatingCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    borderRadius: 16,
    padding: 20,
    flexWrap: 'wrap',
  },
  generatingText: { fontFamily: 'Outfit_500Medium', fontSize: 14, flex: 1, flexWrap: 'wrap' },
  previewCard: {
    borderRadius: 20,
    overflow: 'hidden',
  },
  previewHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    paddingBottom: 0,
  },
  previewPlatform: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  previewPlatformIcon: {
    width: 28,
    height: 28,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  previewPlatformText: { fontFamily: 'Outfit_600SemiBold', fontSize: 14 },
  toneBadge: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
  },
  toneBadgeText: { fontFamily: 'Outfit_500Medium', fontSize: 11, textTransform: 'capitalize' },
  previewOutfit: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: 12,
    borderBottomWidth: 0,
  },
  previewOutfitImg: {
    width: 28,
    height: 28,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#FFF',
  },
  previewOutfitName: { fontFamily: 'Outfit_400Regular', fontSize: 12, flex: 1 },
  captionBox: {
    marginHorizontal: 16,
    marginBottom: 12,
    padding: 14,
    borderRadius: 14,
  },
  captionText: { fontFamily: 'Outfit_400Regular', fontSize: 15, lineHeight: 22 },
  hashtagsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 6,
    paddingHorizontal: 16,
    marginBottom: 16,
  },
  hashtagChip: { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 10 },
  hashtagText: { fontFamily: 'Outfit_500Medium', fontSize: 12 },
  captionActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    padding: 16,
    paddingTop: 14,
    borderTopWidth: 1,
  },
  copyButton: {
    borderRadius: 20,
    overflow: 'hidden',
  },
  copyButtonGradient: {
    height: 40,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 16,
  },
  copyButtonText: { fontFamily: 'Outfit_600SemiBold', fontSize: 13, color: '#FFF' },
  smallCopyBtn: {
    height: 34,
    paddingHorizontal: 10,
    borderRadius: 10,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  smallCopyText: { fontFamily: 'Outfit_500Medium', fontSize: 11 },
});
