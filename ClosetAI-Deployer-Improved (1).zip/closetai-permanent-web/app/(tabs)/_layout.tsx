import { isLiquidGlassAvailable } from "expo-glass-effect";
import { Tabs } from "expo-router";
import { NativeTabs, Icon, Label } from "expo-router/unstable-native-tabs";
import { BlurView } from "expo-blur";
import { Platform, StyleSheet, View } from "react-native";
import React from "react";
import { Ionicons } from "@expo/vector-icons";
import { useTheme } from "@/lib/useTheme";

function NativeTabLayout() {
  return (
    <NativeTabs>
      <NativeTabs.Trigger name="index">
        <Icon sf={{ default: "house", selected: "house.fill" }} />
        <Label>Home</Label>
      </NativeTabs.Trigger>
      <NativeTabs.Trigger name="wardrobe">
        <Icon sf={{ default: "tshirt", selected: "tshirt.fill" }} />
        <Label>Wardrobe</Label>
      </NativeTabs.Trigger>
      <NativeTabs.Trigger name="outfits">
        <Icon sf={{ default: "sparkles", selected: "sparkles" }} />
        <Label>Outfits</Label>
      </NativeTabs.Trigger>
      <NativeTabs.Trigger name="skin">
        <Icon sf={{ default: "drop", selected: "drop.fill" }} />
        <Label>Skin</Label>
      </NativeTabs.Trigger>
      <NativeTabs.Trigger name="tryon">
        <Icon sf={{ default: "person.crop.rectangle", selected: "person.crop.rectangle.fill" }} />
        <Label>Try-On</Label>
      </NativeTabs.Trigger>
      <NativeTabs.Trigger name="content">
        <Icon sf={{ default: "square.and.arrow.up", selected: "square.and.arrow.up.fill" }} />
        <Label>Studio</Label>
      </NativeTabs.Trigger>
    </NativeTabs>
  );
}

function TabIcon({ name, focused, color }: { name: string; focused: boolean; color: string }) {
  const { colors } = useTheme();
  return (
    <View style={[tabStyles.iconWrap, focused && { backgroundColor: `${colors.tint}16` }]}>
      <Ionicons name={name as any} size={20} color={color} />
      {focused && <View style={[tabStyles.activeDot, { backgroundColor: colors.tint }]} />}
    </View>
  );
}

const tabStyles = StyleSheet.create({
  iconWrap: {
    width: 34,
    height: 28,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 1,
  },
  activeDot: {
    position: 'absolute',
    bottom: 2,
    width: 3,
    height: 3,
    borderRadius: 2,
  },
});

function ClassicTabLayout() {
  const { colors, isDark } = useTheme();
  const isWeb = Platform.OS === "web";
  const isIOS = Platform.OS === "ios";

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.tint,
        tabBarInactiveTintColor: colors.tabIconDefault,
        tabBarLabelStyle: {
          fontFamily: 'Outfit_600SemiBold',
          fontSize: 9,
          marginTop: 0,
        },
        tabBarItemStyle: {
          paddingTop: 5,
        },
        tabBarStyle: {
          position: "absolute",
          height: isWeb ? 80 : 72,
          paddingTop: 5,
          backgroundColor: isIOS ? "transparent" : isDark ? '#0D0D0D' : '#FAF7F2',
          borderTopWidth: 1,
          borderTopColor: colors.border,
          elevation: 0,
          ...(isWeb ? {
            backgroundColor: isDark ? '#0D0D0D' : '#FAF7F2',
          } : {}),
          ...(!isWeb && !isIOS ? {
            shadowColor: '#000',
            shadowOffset: { width: 0, height: -4 },
            shadowOpacity: 0.06,
            shadowRadius: 14,
          } : {}),
        },
        tabBarBackground: () =>
          isIOS ? (
            <BlurView
              intensity={80}
              tint={isDark ? "dark" : "light"}
              style={StyleSheet.absoluteFill}
            />
          ) : isWeb ? (
            <View style={[StyleSheet.absoluteFill, { backgroundColor: isDark ? '#0D0D0D' : '#FAF7F2' }]} />
          ) : null,
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: "Home",
          tabBarIcon: ({ color, focused }) => (
            <TabIcon name={focused ? "home" : "home-outline"} focused={focused} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="wardrobe"
        options={{
          title: "Wardrobe",
          tabBarIcon: ({ color, focused }) => (
            <TabIcon name={focused ? "shirt" : "shirt-outline"} focused={focused} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="outfits"
        options={{
          title: "Outfits",
          tabBarIcon: ({ color, focused }) => (
            <TabIcon name={focused ? "sparkles" : "sparkles-outline"} focused={focused} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="skin"
        options={{
          title: "Skin",
          tabBarIcon: ({ color, focused }) => (
            <TabIcon name={focused ? "sparkles" : "sparkles-outline"} focused={focused} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="tryon"
        options={{
          title: "Try-On",
          tabBarIcon: ({ color, focused }) => (
            <TabIcon name={focused ? "person" : "person-outline"} focused={focused} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="content"
        options={{
          title: "Studio",
          tabBarIcon: ({ color, focused }) => (
            <TabIcon name={focused ? "share-social" : "share-social-outline"} focused={focused} color={color} />
          ),
        }}
      />
    </Tabs>
  );
}

export default function TabLayout() {
  if (Platform.OS === "ios" && isLiquidGlassAvailable()) {
    return <NativeTabLayout />;
  }
  return <ClassicTabLayout />;
}
