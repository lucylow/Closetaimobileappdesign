import React, { useState, useMemo, useCallback, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  FlatList,
  Alert,
  Platform,
  Dimensions,
  RefreshControl,
  ActivityIndicator,
  Linking,
  TextInput,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import * as Haptics from 'expo-haptics';
import Animated, { FadeInUp, FadeIn } from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { useApp } from '@/contexts/AppContext';
import { useTheme } from '@/lib/useTheme';
import { CATEGORIES, fictionalAdultWomenDemoExamples, FICTIONAL_ADULT_WOMEN_DEMO_DISCLOSURE } from '@/lib/demo-data';
import { LUXURY_DISCOVERY_DISCLOSURE, LUXURY_DISCOVERY_RECORDS, type LuxuryHouse } from '@/lib/luxury-discovery-catalog';
import { interaction, shadows } from '@/constants/colors';

const SCREEN_WIDTH = Dimensions.get('window').width;
const ITEM_GAP = 12;
const ITEM_WIDTH = (SCREEN_WIDTH - 40 - ITEM_GAP) / 2;

function WardrobeGridItem({ item, colors, isDark, onRemove, index }: { item: any; colors: any; isDark: boolean; onRemove: (id: string) => void; index: number }) {
  return (
    <Animated.View entering={FadeInUp.delay(index * 50).duration(350)}>
      <Pressable
        onPress={() => {
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
          router.push({ pathname: '/item-detail', params: { id: item.id } });
        }}
        onLongPress={() => {
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
          Alert.alert('Remove Item', `Remove "${item.name}" from your wardrobe?`, [
            { text: 'Cancel', style: 'cancel' },
            { text: 'Remove', style: 'destructive', onPress: () => onRemove(item.id) },
          ]);
        }}
        style={({ pressed }) => [
          styles.gridItem,
          { backgroundColor: colors.surface, transform: [{ scale: pressed ? interaction.cardPressScale : 1 }] },
          shadows.medium,
        ]}
        accessibilityRole="button"
        accessibilityLabel={`Open ${item.name}`}
        accessibilityHint={`View details for this ${item.category || 'wardrobe'} item. Long press to remove it.`}
      >
        <View style={styles.imageContainer}>
          <Image
            source={{ uri: item.imageUrl }}
            style={styles.gridImage}
            contentFit="cover"
            transition={300}
          />
          <LinearGradient
            colors={['transparent', 'rgba(0,0,0,0.5)']}
            style={styles.imageOverlay}
          >
            {item.category && (
              <View style={styles.categoryBadge}>
                <Text style={styles.categoryBadgeText}>
                  {item.category.charAt(0).toUpperCase() + item.category.slice(1)}
                </Text>
              </View>
            )}
          </LinearGradient>
          {(item.usageCount || 0) > 0 && (
            <View style={styles.usageBadge}>
              <Ionicons name="repeat-outline" size={10} color="#FFF" />
              <Text style={styles.usageBadgeText}>{item.usageCount}</Text>
            </View>
          )}
        </View>
        <View style={styles.gridItemInfo}>
          <Text style={[styles.gridItemName, { color: colors.text }]} numberOfLines={1}>
            {item.name}
          </Text>
          <View style={styles.gridItemMetaRow}>
            {item.color && (
              <View style={[styles.colorDot, { backgroundColor: getColorHex(item.color) }]} />
            )}
            <Text style={[styles.gridItemMeta, { color: colors.textSecondary }]} numberOfLines={1}>
              {item.brand ? item.brand : ''}{item.brand && item.color ? ' \u00B7 ' : ''}{item.color || ''}
            </Text>
          </View>
        </View>
      </Pressable>
    </Animated.View>
  );
}

function LuxuryDiscoveryPanel({ colors, isDark }: { colors: any; isDark: boolean }) {
  const houses = Array.from(new Set(LUXURY_DISCOVERY_RECORDS.map((record) => record.house))) as LuxuryHouse[];
  const [selectedHouse, setSelectedHouse] = useState<LuxuryHouse>(houses[0]);
  const records = LUXURY_DISCOVERY_RECORDS.filter((record) => record.house === selectedHouse);

  const openOfficialDestination = async (record: typeof LUXURY_DISCOVERY_RECORDS[number]) => {
    try {
      const supported = await Linking.canOpenURL(record.officialUrl);
      if (!supported) throw new Error('Unsupported external destination');
      await Linking.openURL(record.officialUrl);
    } catch {
      Alert.alert('Official link unavailable', 'We could not open this official brand destination on this device. Please try again later.');
    }
  };

  return (
    <View style={[styles.luxuryPanel, { backgroundColor: colors.surface, borderColor: colors.border }]}>
      <View style={styles.luxuryHeading}>
        <View style={[styles.luxuryIcon, { backgroundColor: `${colors.tint}14` }]}>
          <Ionicons name="diamond-outline" size={17} color={colors.tint} />
        </View>
        <View style={styles.luxuryHeadingCopy}>
          <Text style={[styles.luxuryKicker, { color: colors.tint }]}>DEMO MODE · EXTERNAL DISCOVERY</Text>
          <Text style={[styles.luxuryTitle, { color: colors.text }]}>Luxury house references</Text>
        </View>
      </View>
      <Text style={[styles.luxuryDisclosure, { color: colors.textSecondary }]}>{LUXURY_DISCOVERY_DISCLOSURE}</Text>
      <FlatList
        data={houses}
        horizontal
        keyExtractor={(house) => house}
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.luxuryHouseRow}
        renderItem={({ item: house }) => {
          const selected = selectedHouse === house;
          return (
            <Pressable
              onPress={() => setSelectedHouse(house)}
              accessibilityRole="radio"
              accessibilityState={{ selected }}
              accessibilityLabel={`${house} luxury discovery references${selected ? ', selected' : ''}`}
              style={({ pressed }) => [styles.luxuryHouseChip, { borderColor: selected ? colors.tint : colors.border, backgroundColor: selected ? `${colors.tint}12` : colors.surfaceSecondary, opacity: pressed ? 0.78 : 1 }]}
            >
              <Text style={[styles.luxuryHouseText, { color: selected ? colors.tint : colors.textSecondary }]}>{house}</Text>
            </Pressable>
          );
        }}
      />
      <FlatList
        data={records}
        horizontal
        keyExtractor={(record) => record.id}
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.luxuryCardRow}
        renderItem={({ item: record }) => (
          <Pressable
            onPress={() => openOfficialDestination(record)}
            accessibilityRole="link"
            accessibilityLabel={`Open ${record.officialSourceLabel} on the official ${record.house} website`}
            accessibilityHint="Opens an external official brand destination. Prices, inventory, and checkout are not provided by ClosetAI."
            style={({ pressed }) => [styles.luxuryCard, { backgroundColor: isDark ? 'rgba(255,255,255,0.045)' : colors.surfaceSecondary, borderColor: colors.border, opacity: pressed ? 0.8 : 1 }]}
          >
            <Image source={{ uri: record.genericReferenceImageUrl }} style={styles.luxuryImage} contentFit="cover" />
            <View style={styles.luxuryCardCopy}>
              <Text style={[styles.luxuryHouseLabel, { color: colors.tint }]}>{record.house}</Text>
              <Text style={[styles.luxuryPieceName, { color: colors.text }]} numberOfLines={2}>{record.pieceName}</Text>
              <Text style={[styles.luxuryStyleDirection, { color: colors.textSecondary }]} numberOfLines={2}>{record.styleDirection}</Text>
              <View style={styles.luxuryLinkRow}>
                <Text style={[styles.luxuryLinkText, { color: colors.tint }]}>Official destination</Text>
                <Ionicons name="open-outline" size={13} color={colors.tint} />
              </View>
            </View>
          </Pressable>
        )}
      />
    </View>
  );
}

function getColorHex(color: string): string {
  const map: Record<string, string> = {
    black: '#1A1A1A', white: '#F5F0EB', red: '#E74C3C', blue: '#3498DB',
    green: '#27AE60', navy: '#2C3E50', beige: '#D4A574', gray: '#9B9590',
    grey: '#9B9590', pink: '#EC4899', brown: '#8B7355', yellow: '#F5C842',
    orange: '#F39C12', purple: '#6E4AE0', cream: '#FAF7F2',
  };
  return map[color.toLowerCase()] || '#9B9590';
}

export default function WardrobeScreen() {
  const { colors, isDark } = useTheme();
  const insets = useSafeAreaInsets();
  const { wardrobeItems, removeWardrobeItem, refreshWardrobe, demoMode, loadFictionalAdultWomenDemoExample } = useApp();
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedDemoExampleId, setSelectedDemoExampleId] = useState(fictionalAdultWomenDemoExamples[0]?.id ?? '');
  const [isLoadingDemoExample, setIsLoadingDemoExample] = useState(false);
  const [demoLoadError, setDemoLoadError] = useState<string | null>(null);
  const demoChoiceRefs = useRef<any[]>([]);

  const webTopInset = Platform.OS === 'web' ? 67 : 0;

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    try {
      await refreshWardrobe();
    } finally {
      setRefreshing(false);
    }
  }, [refreshWardrobe]);

  const [searchQuery, setSearchQuery] = useState('');

  const filteredItems = useMemo(() => {
    let list = wardrobeItems;
    if (selectedCategory) {
      list = list.filter(i => i.category === selectedCategory);
    }
    const q = searchQuery.trim().toLowerCase();
    if (q) {
      list = list.filter(i =>
        (i.name && i.name.toLowerCase().includes(q)) ||
        (i.color && i.color.toLowerCase().includes(q)) ||
        (i.brand && i.brand.toLowerCase().includes(q)) ||
        (i.notes && i.notes.toLowerCase().includes(q)) ||
        (i.tags && i.tags.some(t => t.toLowerCase().includes(q))) ||
        (i.category && i.category.toLowerCase().includes(q))
      );
    }
    return list;
  }, [wardrobeItems, selectedCategory, searchQuery]);
  const isCatalogEmpty = wardrobeItems.length === 0;
  const selectedDemoExample = fictionalAdultWomenDemoExamples.find((example) => example.id === selectedDemoExampleId) ?? fictionalAdultWomenDemoExamples[0];

  const chooseDemoExample = useCallback((id: string) => {
    setSelectedDemoExampleId(id);
    setDemoLoadError(null);
    Haptics.selectionAsync();
  }, []);

  const handleDemoChoiceKeyDown = useCallback((event: any, currentIndex: number) => {
    if (Platform.OS !== 'web') return;
    const key = event?.nativeEvent?.key ?? event?.key;
    const lastIndex = fictionalAdultWomenDemoExamples.length - 1;
    let nextIndex: number | undefined;
    if (key === 'ArrowRight' || key === 'ArrowDown') nextIndex = currentIndex === lastIndex ? 0 : currentIndex + 1;
    if (key === 'ArrowLeft' || key === 'ArrowUp') nextIndex = currentIndex === 0 ? lastIndex : currentIndex - 1;
    if (key === 'Home') nextIndex = 0;
    if (key === 'End') nextIndex = lastIndex;
    if (nextIndex === undefined) return;
    event?.preventDefault?.();
    chooseDemoExample(fictionalAdultWomenDemoExamples[nextIndex].id);
    requestAnimationFrame(() => demoChoiceRefs.current[nextIndex]?.focus?.());
  }, [chooseDemoExample]);

  const demoChoiceKeyboardProps = useCallback((index: number) => {
    if (Platform.OS !== 'web') return {};
    // React Native Web supports this DOM keyboard event; the native Pressable type omits it.
    return { onKeyDown: (event: any) => handleDemoChoiceKeyDown(event, index) } as any;
  }, [handleDemoChoiceKeyDown]);

  const handleRemove = useCallback((id: string) => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    removeWardrobeItem(id);
  }, [removeWardrobeItem]);

  const handleLoadFictionalExample = useCallback(async () => {
    if (!selectedDemoExampleId || isLoadingDemoExample) return;
    setDemoLoadError(null);
    setIsLoadingDemoExample(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    try {
      await loadFictionalAdultWomenDemoExample(selectedDemoExampleId);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (error) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      setDemoLoadError(error instanceof Error ? error.message : 'We could not load that fictional example. Please try again.');
    } finally {
      setIsLoadingDemoExample(false);
    }
  }, [isLoadingDemoExample, loadFictionalAdultWomenDemoExample, selectedDemoExampleId]);

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <LinearGradient
        colors={isDark ? ['#1A1612', '#0D0D0D'] : ['#F0E6DB', '#FAF7F2']}
        style={[styles.headerGradient, { paddingTop: (insets.top || webTopInset) + 12 }]}
      >
        <Animated.View entering={FadeInUp.duration(400)} style={styles.header}>
          <View>
            <Text style={[styles.title, { color: colors.text }]}>My Wardrobe</Text>
            <Text style={[styles.subtitle, { color: colors.textSecondary }]}>
              {wardrobeItems.length} item{wardrobeItems.length !== 1 ? 's' : ''} cataloged
            </Text>
          </View>
          <Pressable
            onPress={() => {
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
              router.push('/add-item');
            }}
            accessibilityRole="button"
            accessibilityLabel="Add wardrobe item"
            accessibilityHint="Open the photo-first item form."
            style={({ pressed }) => [{ transform: [{ scale: pressed ? interaction.compactPressScale : 1 }], opacity: pressed ? 0.78 : 1 }]}
          >
            <LinearGradient
              colors={['#C17F59', '#D4A574']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={styles.addBtn}
            >
              <Ionicons name="add" size={22} color="#FFF" />
            </LinearGradient>
          </Pressable>
        </Animated.View>

        {wardrobeItems.length > 0 && (
          <Animated.View entering={FadeIn.delay(200).duration(300)} style={styles.summaryRow}>
            {Object.entries(
              wardrobeItems.reduce((acc: Record<string, number>, item) => {
                acc[item.category] = (acc[item.category] || 0) + 1;
                return acc;
              }, {}),
            ).slice(0, 4).map(([cat, count]) => (
              <View key={cat} style={[styles.summaryPill, { backgroundColor: isDark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.04)' }]}>
                <Text style={[styles.summaryCount, { color: colors.tint }]}>{count}</Text>
                <Text style={[styles.summaryCat, { color: colors.textSecondary }]}>{cat}</Text>
              </View>
            ))}
          </Animated.View>
        )}
      </LinearGradient>

      {wardrobeItems.length > 0 && (
        <View style={styles.searchWrap}>
          <View style={[styles.searchBox, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Ionicons name="search-outline" size={16} color={colors.textTertiary} />
            <TextInput
              style={[styles.searchInput, { color: colors.text }]}
              placeholder="AI Search: try 'white tee', 'office', 'luxury'..."
              placeholderTextColor={colors.textTertiary}
              value={searchQuery}
              onChangeText={setSearchQuery}
              returnKeyType="search"
            />
            {searchQuery.length > 0 && (
              <Pressable onPress={() => setSearchQuery('')} hitSlop={8}>
                <Ionicons name="close-circle" size={16} color={colors.textSecondary} />
              </Pressable>
            )}
          </View>
        </View>
      )}

      <View style={styles.filtersRow}>
        <Pressable
          onPress={() => setSelectedCategory(null)}
          accessibilityRole="radio"
          accessibilityState={{ selected: !selectedCategory }}
          accessibilityLabel={`All wardrobe items, ${wardrobeItems.length} total`}
          style={({ pressed }) => [
            styles.filterChip,
            {
              backgroundColor: !selectedCategory ? colors.tint : isDark ? 'rgba(255,255,255,0.06)' : colors.surfaceSecondary,
              transform: [{ scale: pressed ? interaction.compactPressScale : 1 }],
            },
          ]}
        >
          <Text style={[styles.filterText, { color: !selectedCategory ? '#FFF' : colors.textSecondary }]}>
            All ({wardrobeItems.length})
          </Text>
        </Pressable>
        <FlatList
          data={CATEGORIES}
          horizontal
          showsHorizontalScrollIndicator={false}
          keyExtractor={item => item}
          renderItem={({ item }) => {
            const count = wardrobeItems.filter(w => w.category === item).length;
            const selected = selectedCategory === item;
            return (
              <Pressable
                onPress={() => {
                  Haptics.selectionAsync();
                  setSelectedCategory(selected ? null : item);
                }}
                accessibilityRole="radio"
                accessibilityState={{ selected }}
                accessibilityLabel={`${item} category, ${count} item${count === 1 ? '' : 's'}`}
                accessibilityHint={selected ? 'Currently filtering wardrobe items by this category. Tap to show all.' : `Filter wardrobe items to show only ${item}.`}
                style={({ pressed }) => [
                  styles.filterChip,
                  {
                    backgroundColor: selected ? colors.tint : isDark ? 'rgba(255,255,255,0.06)' : colors.surfaceSecondary,
                    transform: [{ scale: pressed ? interaction.compactPressScale : 1 }],
                  },
                ]}
              >
                <Text style={[styles.filterText, { color: selected ? '#FFF' : colors.textSecondary }]}>
                  {item.charAt(0).toUpperCase() + item.slice(1)} ({count})
                </Text>
              </Pressable>
            );
          }}
          contentContainerStyle={{ gap: 8 }}
        />
      </View>

      {filteredItems.length === 0 ? (
        <Animated.View entering={FadeIn.duration(400)} style={[styles.emptyState, isCatalogEmpty && demoMode && styles.emptyStateWithDemo]}>
          <LinearGradient
            colors={isDark ? ['rgba(193,127,89,0.1)', 'rgba(193,127,89,0.02)'] : ['rgba(193,127,89,0.08)', 'rgba(193,127,89,0.01)']}
            style={styles.emptyIconWrap}
          >
            <Ionicons name={isCatalogEmpty ? "shirt-outline" : "funnel-outline"} size={40} color={colors.tint} />
          </LinearGradient>
          <Text style={[styles.emptyTitle, { color: colors.text }]}>{isCatalogEmpty ? 'Your wardrobe starts with one piece.' : `No ${selectedCategory} items yet`}</Text>
          <Text style={[styles.emptySubtitle, { color: colors.textSecondary }]}> 
            {isCatalogEmpty ? 'Add a clear photo and a name. Category and color will make future outfit suggestions more useful.' : 'Try another category, or return to all items to keep browsing your wardrobe.'}
          </Text>
          <Pressable
            onPress={() => isCatalogEmpty ? router.push('/add-item') : setSelectedCategory(null)}
            style={({ pressed }) => [styles.emptyButton, { transform: [{ scale: pressed ? interaction.compactPressScale : 1 }] }]}
            accessibilityRole="button"
            accessibilityLabel={isCatalogEmpty ? 'Add your first wardrobe item' : 'Show all wardrobe items'}
          >
            <LinearGradient colors={['#C17F59', '#D4A574']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.emptyButtonGradient}>
              <Ionicons name={isCatalogEmpty ? "camera-outline" : "grid-outline"} size={18} color="#FFF" />
              <Text style={styles.emptyButtonText}>{isCatalogEmpty ? 'Add your first piece' : 'Show all items'}</Text>
            </LinearGradient>
          </Pressable>
          {isCatalogEmpty && demoMode && (
            <View
              style={[styles.demoExamplePanel, { backgroundColor: colors.surface, borderColor: colors.border }]}
              accessibilityRole="radiogroup"
              accessibilityLabel="Fictional adult women’s demo wardrobe examples"
              accessibilityHint="Choose one fictional prototype wardrobe. On web, use Left and Right Arrow, Up and Down Arrow, Home, or End to change the selected example. Then tab to Load selected example and press Enter or Space."
            >
              <View style={styles.demoExampleHeading}>
                <Ionicons name="sparkles-outline" size={17} color={colors.tint} />
                <Text style={[styles.demoExampleTitle, { color: colors.text }]}>Fictional adult women’s demo examples</Text>
              </View>
              <Text style={[styles.demoExampleDisclosure, { color: colors.textSecondary }]}>{FICTIONAL_ADULT_WOMEN_DEMO_DISCLOSURE}</Text>
              <FlatList
                data={fictionalAdultWomenDemoExamples}
                horizontal
                keyExtractor={(example) => example.id}
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.demoExampleChoices}
                renderItem={({ item: example, index }) => {
                  const selected = selectedDemoExampleId === example.id;
                  return (
                    <Pressable
                      ref={(node) => { demoChoiceRefs.current[index] = node; }}
                      onPress={() => chooseDemoExample(example.id)}
                      {...demoChoiceKeyboardProps(index)}
                      accessibilityRole="radio"
                      accessibilityState={{ selected }}
                      accessibilityLabel={`${example.displayName}, ${example.audienceLabel}${selected ? ', selected' : ''}`}
                      accessibilityHint={`${example.styleContext} On web, use arrow keys to move between examples; Home selects the first and End selects the last.`}
                      style={({ pressed }) => [styles.demoExampleChoice, { borderColor: selected ? colors.tint : colors.border, backgroundColor: selected ? `${colors.tint}12` : colors.surfaceSecondary, opacity: pressed ? 0.75 : 1 }]}
                    >
                      <Text style={[styles.demoExampleName, { color: selected ? colors.tint : colors.text }]}>{example.displayName}</Text>
                      <Text style={[styles.demoExampleContext, { color: colors.textSecondary }]} numberOfLines={2}>{example.styleContext}</Text>
                    </Pressable>
                  );
                }}
              />
              <Text style={[styles.demoSelectionStatus, { color: colors.textSecondary }]} accessibilityLiveRegion="polite">
                {selectedDemoExample ? `${selectedDemoExample.displayName} selected. ${selectedDemoExample.styleContext}` : 'Choose a fictional demo wardrobe.'}
              </Text>
              <Pressable
                onPress={handleLoadFictionalExample}
                disabled={isLoadingDemoExample}
                accessibilityRole="button"
                accessibilityState={{ disabled: isLoadingDemoExample, busy: isLoadingDemoExample }}
                accessibilityLabel={`Load ${selectedDemoExample?.displayName ?? 'selected'} fictional adult women’s demo wardrobe`}
                accessibilityHint="Adds only clearly labeled fictional prototype items to this local Demo Mode session. On web, Tab to this control and press Enter or Space to load it."
                style={({ pressed }) => [styles.demoLoadButton, { backgroundColor: colors.text, opacity: isLoadingDemoExample ? interaction.disabledOpacity : pressed ? 0.82 : 1, transform: [{ scale: pressed && !isLoadingDemoExample ? interaction.compactPressScale : 1 }] }]}
              >
                {isLoadingDemoExample ? <ActivityIndicator size="small" color={colors.background} /> : <Ionicons name="download-outline" size={17} color={colors.background} />}
                <Text style={[styles.demoLoadButtonText, { color: colors.background }]}>{isLoadingDemoExample ? 'Loading example…' : 'Load selected example'}</Text>
              </Pressable>
              {!!demoLoadError && <Text style={[styles.demoLoadError, { color: colors.error }]} accessibilityRole="alert" accessibilityLiveRegion="assertive">{demoLoadError}</Text>}
            </View>
          )}
          {isCatalogEmpty && <Text style={[styles.emptyHelper, { color: colors.textTertiary }]}>No generic garment image is added in your place.</Text>}
          {demoMode && <LuxuryDiscoveryPanel colors={colors} isDark={isDark} />}
        </Animated.View>
      ) : (
        <FlatList
          data={filteredItems}
          numColumns={2}
          keyExtractor={item => item.id}
          columnWrapperStyle={styles.row}
          contentContainerStyle={styles.gridContent}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              tintColor={colors.tint}
              colors={[colors.tint]}
            />
          }
          renderItem={({ item, index }) => (
            <WardrobeGridItem item={item} colors={colors} isDark={isDark} onRemove={handleRemove} index={index} />
          )}
          ListFooterComponent={
            <View style={styles.gridFooter}>
              {demoMode && <LuxuryDiscoveryPanel colors={colors} isDark={isDark} />}
              <View style={{ height: 120 }} />
            </View>
          }
        />
      )}

      {!isCatalogEmpty && <Pressable
        onPress={() => {
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
          router.push('/add-item');
        }}
        accessibilityRole="button"
        accessibilityLabel="Add wardrobe item"
        style={({ pressed }) => [
          styles.fab,
          { bottom: (insets.bottom || (Platform.OS === 'web' ? 34 : 0)) + 90, transform: [{ scale: pressed ? interaction.compactPressScale : 1 }], opacity: pressed ? 0.82 : 1 },
        ]}
      >
        <LinearGradient
          colors={['#C17F59', '#D4A574']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.fabGradient}
        >
          <Ionicons name="add" size={28} color="#FFF" />
        </LinearGradient>
      </Pressable>}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  searchWrap: { paddingHorizontal: 20, marginBottom: 12 },
  searchBox: { flexDirection: 'row', alignItems: 'center', height: 44, borderRadius: 14, borderWidth: 1, paddingHorizontal: 12, gap: 8 },
  searchInput: { flex: 1, fontFamily: 'Outfit_400Regular', fontSize: 13, paddingVertical: 0 },
  headerGradient: {
    paddingBottom: 16,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingBottom: 12,
  },
  title: { fontFamily: 'Outfit_700Bold', fontSize: 26 },
  subtitle: { fontFamily: 'Outfit_400Regular', fontSize: 13, marginTop: 2 },
  addBtn: {
    width: 40,
    height: 40,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  summaryRow: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    gap: 8,
    flexWrap: 'wrap',
  },
  summaryPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 10,
  },
  summaryCount: { fontFamily: 'Outfit_700Bold', fontSize: 13 },
  summaryCat: { fontFamily: 'Outfit_400Regular', fontSize: 11, textTransform: 'capitalize' },
  filtersRow: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingVertical: 12,
    gap: 8,
  },
  filterChip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
  },
  filterText: { fontFamily: 'Outfit_500Medium', fontSize: 13 },
  row: { gap: ITEM_GAP, paddingHorizontal: 20 },
  gridContent: { gap: ITEM_GAP },
  gridItem: {
    width: ITEM_WIDTH,
    borderRadius: 18,
    overflow: 'hidden',
  },
  imageContainer: {
    position: 'relative',
  },
  gridImage: { width: '100%', height: ITEM_WIDTH * 1.2 },
  imageOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 50,
    justifyContent: 'flex-end',
    alignItems: 'flex-start',
    paddingHorizontal: 8,
    paddingBottom: 6,
  },
  categoryBadge: {
    backgroundColor: 'rgba(255,255,255,0.22)',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
  },
  categoryBadgeText: {
    fontFamily: 'Outfit_500Medium',
    fontSize: 10,
    color: '#FFF',
  },
  usageBadge: {
    position: 'absolute',
    top: 8,
    right: 8,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    backgroundColor: 'rgba(0,0,0,0.5)',
    paddingHorizontal: 6,
    paddingVertical: 3,
    borderRadius: 8,
  },
  usageBadgeText: {
    fontFamily: 'Outfit_600SemiBold',
    fontSize: 10,
    color: '#FFF',
  },
  gridItemInfo: { padding: 10, gap: 3 },
  gridItemName: { fontFamily: 'Outfit_600SemiBold', fontSize: 14 },
  gridItemMetaRow: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  colorDot: { width: 8, height: 8, borderRadius: 4 },
  gridItemMeta: { fontFamily: 'Outfit_400Regular', fontSize: 12 },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: 40,
  },
  emptyStateWithDemo: { justifyContent: 'flex-start', paddingTop: 16 },
  emptyIconWrap: {
    width: 88,
    height: 88,
    borderRadius: 28,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 4,
  },
  emptyTitle: { fontFamily: 'Outfit_700Bold', fontSize: 22 },
  emptySubtitle: { fontFamily: 'Outfit_400Regular', fontSize: 14, textAlign: 'center', lineHeight: 20 },
  emptyButton: {
    borderRadius: 24,
    overflow: 'hidden',
    marginTop: 8,
    shadowColor: '#C17F59',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 6,
  },
  emptyButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 28,
    paddingVertical: 16,
  },
  emptyButtonText: { fontFamily: 'Outfit_600SemiBold', fontSize: 16, color: '#FFF' },
  emptyHelper: { fontFamily: 'Outfit_400Regular', fontSize: 10, lineHeight: 15, textAlign: 'center', marginTop: -3 },
  demoExamplePanel: { width: '100%', borderWidth: 1, borderRadius: 16, padding: 12, gap: 9 },
  demoExampleHeading: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  demoExampleTitle: { flex: 1, fontFamily: 'Outfit_700Bold', fontSize: 13 },
  demoExampleDisclosure: { fontFamily: 'Outfit_400Regular', fontSize: 10, lineHeight: 14 },
  demoExampleChoices: { gap: 8 },
  demoExampleChoice: { width: 134, minHeight: 62, borderWidth: 1, borderRadius: 12, padding: 9 },
  demoExampleName: { fontFamily: 'Outfit_700Bold', fontSize: 12 },
  demoExampleContext: { fontFamily: 'Outfit_400Regular', fontSize: 9, lineHeight: 12, marginTop: 4 },
  demoSelectionStatus: { fontFamily: 'Outfit_500Medium', fontSize: 10, lineHeight: 14 },
  demoLoadButton: { minHeight: 40, borderRadius: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 7 },
  demoLoadButtonText: { fontFamily: 'Outfit_700Bold', fontSize: 12 },
  demoLoadError: { fontFamily: 'Outfit_500Medium', fontSize: 10, lineHeight: 14 },
  gridFooter: { paddingHorizontal: 20, paddingTop: 12 },
  luxuryPanel: { width: '100%', borderWidth: 1, borderRadius: 18, padding: 12, gap: 10, marginTop: 4 },
  luxuryHeading: { flexDirection: 'row', alignItems: 'center', gap: 9 },
  luxuryIcon: { width: 34, height: 34, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  luxuryHeadingCopy: { flex: 1 },
  luxuryKicker: { fontFamily: 'Outfit_600SemiBold', fontSize: 10, letterSpacing: 0.8 },
  luxuryTitle: { fontFamily: 'Outfit_700Bold', fontSize: 16, marginTop: 1 },
  luxuryDisclosure: { fontFamily: 'Outfit_400Regular', fontSize: 11, lineHeight: 16 },
  luxuryHouseRow: { gap: 7 },
  luxuryHouseChip: { borderWidth: 1, borderRadius: 16, paddingHorizontal: 10, paddingVertical: 7 },
  luxuryHouseText: { fontFamily: 'Outfit_600SemiBold', fontSize: 11 },
  luxuryCardRow: { gap: 10, paddingTop: 1 },
  luxuryCard: { width: 196, borderWidth: 1, borderRadius: 14, overflow: 'hidden' },
  luxuryImage: { width: '100%', height: 100 },
  luxuryCardCopy: { padding: 10, gap: 4 },
  luxuryHouseLabel: { fontFamily: 'Outfit_600SemiBold', fontSize: 10, textTransform: 'uppercase', letterSpacing: 0.4 },
  luxuryPieceName: { fontFamily: 'Outfit_700Bold', fontSize: 14, lineHeight: 18 },
  luxuryStyleDirection: { fontFamily: 'Outfit_400Regular', fontSize: 11, lineHeight: 15, minHeight: 30 },
  luxuryLinkRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 3 },
  luxuryLinkText: { fontFamily: 'Outfit_600SemiBold', fontSize: 11 },
  fab: {
    position: 'absolute',
    right: 20,
    borderRadius: 28,
    shadowColor: '#C17F59',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.35,
    shadowRadius: 12,
    elevation: 8,
  },
  fabGradient: {
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
