import React, { useEffect, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  Platform,
  Dimensions,
  ActivityIndicator,
} from 'react-native';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import * as Haptics from 'expo-haptics';
import Animated, { FadeInUp, FadeInRight, FadeIn, ZoomIn } from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { useApp } from '@/contexts/AppContext';
import { useTheme } from '@/lib/useTheme';
import { interaction, shadows } from '@/constants/colors';
import { CreditBanner } from '@/components/CreditGate';

const SCREEN_WIDTH = Dimensions.get('window').width;

function getGreeting(): string {
  const hour = new Date().getHours();
  if (hour < 12) return 'Good morning';
  if (hour < 17) return 'Good afternoon';
  return 'Good evening';
}

function getStyleTip(): string {
  const tips = [
    'Layer neutral tones for an effortless look',
    'A statement piece can transform any outfit',
    'Mix textures for added visual interest',
    'Accessorize to elevate your basics',
    'Monochrome outfits always make an impact',
  ];
  const idx = new Date().getDate() % tips.length;
  return tips[idx];
}

export default function HomeScreen() {
  const { colors, isDark } = useTheme();
  const insets = useSafeAreaInsets();
  const {
    wardrobeItems, outfits, savedOutfits, demoMode,
    hasSeenOnboarding, isLoading, credits, getStyleInsight,
  } = useApp();

  const [styleInsight, setStyleInsight] = useState<{
    insight: string;
    dominantStyle: string;
    suggestion: string;
  } | null>(null);
  const [insightLoading, setInsightLoading] = useState(false);

  const webTopInset = Platform.OS === 'web' ? 67 : 0;

  useEffect(() => {
    if (!isLoading && !hasSeenOnboarding) {
      router.replace('/onboarding');
    }
  }, [isLoading, hasSeenOnboarding]);

  const loadInsight = useCallback(async () => {
    if (wardrobeItems.length < 3) return;
    setInsightLoading(true);
    try {
      const result = await getStyleInsight();
      setStyleInsight(result);
    } catch {
    } finally {
      setInsightLoading(false);
    }
  }, [getStyleInsight, wardrobeItems.length]);

  useEffect(() => {
    if (wardrobeItems.length >= 3 && !styleInsight && !insightLoading) {
      loadInsight();
    }
  }, [insightLoading, loadInsight, styleInsight, wardrobeItems.length]);

  const totalItems = wardrobeItems.length;
  const wornItems = wardrobeItems.filter(i => (i.usageCount || 0) > 0).length;
  const utilizationPct = totalItems > 0 ? Math.round((wornItems / totalItems) * 100) : 0;
  const categoryCounts: Record<string, number> = {};
  wardrobeItems.forEach(i => {
    categoryCounts[i.category] = (categoryCounts[i.category] || 0) + 1;
  });
  const topCategory = Object.entries(categoryCounts).sort((a, b) => b[1] - a[1])[0];
  const todayOutfit = outfits[0];
  const topScoredOutfit = [...outfits].sort((a, b) => (b.score || 0) - (a.score || 0))[0];
  const dailyFocus = totalItems === 0
    ? { eyebrow: 'YOUR NEXT STEP', title: 'Start with one great piece.', copy: 'Add a favorite item and let ClosetAI begin organizing the wardrobe around you.', action: 'Add your first item', route: '/add-item', icon: 'add-circle-outline' as const, gradient: ['#B87450', '#D4A574'] as [string, string] }
    : !todayOutfit
      ? { eyebrow: 'YOUR NEXT STEP', title: 'Turn your wardrobe into a look.', copy: 'Use your saved pieces to create an outfit for the day ahead.', action: 'Create an outfit', route: '/(tabs)/outfits', icon: 'sparkles-outline' as const, gradient: ['#6E4AE0', '#9B6DFF'] as [string, string] }
      : { eyebrow: 'READY FOR TODAY', title: 'Your wardrobe is in motion.', copy: 'Review today’s pick or build another look around the occasion.', action: 'View today’s pick', route: `/outfit-detail?id=${todayOutfit.id}`, icon: 'arrow-forward-circle-outline' as const, gradient: ['#2C9C91', '#00C9B7'] as [string, string] };

  const quickActions = [
    { icon: 'add-circle-outline' as const, label: 'Add Item', desc: 'Snap & organize', route: '/add-item', gradient: ['#C17F59', '#D4A574'] as [string, string] },
    { icon: 'sparkles-outline' as const, label: 'Get Outfits', desc: 'AI suggestions', route: '/(tabs)/outfits', gradient: ['#6E4AE0', '#9B6DFF'] as [string, string] },
    { icon: 'person-outline' as const, label: 'Try-On', desc: 'Virtual fitting', route: '/(tabs)/tryon', gradient: ['#EC4899', '#F472B6'] as [string, string] },
    { icon: 'share-social-outline' as const, label: 'Studio', desc: 'Content creator', route: '/(tabs)/content', gradient: ['#00C9B7', '#00E5D0'] as [string, string] },
  ];

  if (isLoading) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.tint} />
        </View>
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <LinearGradient
          colors={isDark ? ['#1A1612', '#0D0D0D'] : ['#F0E6DB', '#FAF7F2']}
          style={[styles.heroSection, { paddingTop: (insets.top || webTopInset) + 16 }]}
        >
          <Animated.View entering={FadeInUp.duration(500)} style={styles.headerRow}>
            <View>
              <Text style={[styles.greeting, { color: colors.textSecondary }]}>{getGreeting()}</Text>
              <Text style={[styles.title, { color: colors.text }]}>CLOSET A.I.</Text>
            </View>
            <View style={styles.headerRight}>
              {credits !== undefined && (
                <Animated.View entering={ZoomIn.delay(200).duration(400)}>
                  <LinearGradient
                    colors={isDark ? ['rgba(212,165,116,0.2)', 'rgba(212,165,116,0.08)'] : ['rgba(193,127,89,0.12)', 'rgba(193,127,89,0.04)']}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 0 }}
                    style={styles.creditBadge}
                  >
                    <Ionicons name="flash" size={13} color={colors.tint} />
                    <Text style={[styles.creditCount, { color: colors.tint }]}>{credits}</Text>
                  </LinearGradient>
                </Animated.View>
              )}
              <Pressable
                onPress={() => {
                  Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                  router.push('/settings');
                }}
                hitSlop={12}
                accessibilityRole="button"
                accessibilityLabel="Open settings"
                accessibilityHint="Manage your ClosetAI preferences and account settings."
                style={({ pressed }) => [styles.settingsBtn, { backgroundColor: isDark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.04)', opacity: pressed ? 0.72 : 1, transform: [{ scale: pressed ? interaction.compactPressScale : 1 }] }]}
              >
                <Ionicons name="settings-outline" size={20} color={colors.textSecondary} />
              </Pressable>
            </View>
          </Animated.View>

          <Animated.View
            entering={FadeInUp.delay(70).duration(420)}
            style={[styles.valueProposition, { backgroundColor: isDark ? 'rgba(255,255,255,0.055)' : 'rgba(255,255,255,0.68)', borderColor: colors.tint + '24' }]}
            accessibilityLabel="ClosetAI value proposition. Organize the pieces you own, turn them into a clearer outfit choice, and preview only with a photo you choose. Add one item to begin, then plan a look. Demo context is labeled and no stock model is substituted for you."
          >
            <View style={[styles.valuePropositionIcon, { backgroundColor: colors.tint + '16' }]}>
              <Ionicons name="sparkles-outline" size={17} color={colors.tint} />
            </View>
            <View style={styles.valuePropositionCopy}>
              <Text style={[styles.valuePropositionKicker, { color: colors.tint }]}>YOUR CLOSET, CLEARER</Text>
              <Text style={[styles.valuePropositionTitle, { color: colors.text }]}>Organize what you own. Choose a look with less guesswork.</Text>
              <Text style={[styles.valuePropositionText, { color: colors.textSecondary }]}>Start with one item, plan around your day, and preview only with a photo you choose.</Text>
              <Text style={[styles.valuePropositionBoundary, { color: colors.textTertiary }]}>Demo context is labeled. No stock model is substituted for you.</Text>
            </View>
          </Animated.View>

          {demoMode && (
            <Animated.View
              entering={FadeInUp.delay(100).duration(400)}
              style={[styles.demoBanner, { borderColor: colors.tint + '30' }]}
            >
              <LinearGradient
                colors={[colors.tint + '15', colors.tint + '05']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={styles.demoBannerGradient}
              >
                <Ionicons name="flask-outline" size={14} color={colors.tint} />
                <Text style={[styles.demoText, { color: colors.tint }]}>Demo Mode active</Text>
                {totalItems === 0 && (
                  <Pressable
                    onPress={() => {
                      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
                      router.push('/(tabs)/wardrobe');
                    }}
                    style={{ marginLeft: 'auto', backgroundColor: colors.tint, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 10 }}
                  >
                    <Text style={{ color: colors.background, fontSize: 11, fontWeight: '700' }}>Restore demo wardrobe</Text>
                  </Pressable>
                )}
              </LinearGradient>
            </Animated.View>
          )}

          <Animated.View entering={FadeInUp.delay(150).duration(500)} style={styles.statsRow}>
            {[
              { icon: 'shirt-outline' as const, value: totalItems, label: 'Items', color: '#C17F59', gradient: ['#C17F59', '#D4A574'] as const },
              { icon: 'sparkles-outline' as const, value: outfits.length, label: 'Outfits', color: '#6E4AE0', gradient: ['#6E4AE0', '#9B6DFF'] as const },
              { icon: 'bookmark-outline' as const, value: savedOutfits.length, label: 'Saved', color: '#EC4899', gradient: ['#EC4899', '#F472B6'] as const },
            ].map((stat, idx) => (
              <Animated.View key={stat.label} entering={FadeInUp.delay(200 + idx * 80).duration(400)}>
                <Pressable
                  onPress={() => {
                    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                    if (idx === 0) router.push('/(tabs)/wardrobe');
                    else router.push('/(tabs)/outfits');
                  }}
                  accessibilityRole="button"
                  accessibilityLabel={`View ${stat.value} ${stat.label.toLowerCase()}`}
                  accessibilityHint={idx === 0 ? 'Opens your wardrobe.' : idx === 1 ? 'Opens your outfit suggestions.' : 'Opens your saved outfits.'}
                  style={({ pressed }) => [
                    styles.statCard,
                    { backgroundColor: colors.surface, transform: [{ scale: pressed ? interaction.compactPressScale : 1 }] },
                    shadows.soft,
                  ]}
                >
                  <LinearGradient
                    colors={stat.gradient}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 1 }}
                    style={styles.statIconWrap}
                  >
                    <Ionicons name={stat.icon} size={16} color="#FFF" />
                  </LinearGradient>
                  <Text style={[styles.statNumber, { color: colors.text }]}>{stat.value}</Text>
                  <Text style={[styles.statLabel, { color: colors.textSecondary }]}>{stat.label}</Text>
                </Pressable>
              </Animated.View>
            ))}
          </Animated.View>
        </LinearGradient>

        <View style={styles.mainContent}>
          <Animated.View entering={FadeInUp.delay(150).duration(400)}>
            <LinearGradient
              colors={isDark ? ['rgba(212,165,116,0.08)', 'rgba(212,165,116,0.02)'] : ['rgba(193,127,89,0.06)', 'rgba(193,127,89,0.02)']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={[styles.tipCard, { borderColor: colors.tint + '12' }]}
            >
              <View style={[styles.tipIcon, { backgroundColor: colors.tint + '15' }]}>
                <MaterialCommunityIcons name="lightbulb-outline" size={16} color={colors.tint} />
              </View>
              <Text style={[styles.tipText, { color: colors.text }]}>{getStyleTip()}</Text>
            </LinearGradient>
          </Animated.View>

          <Animated.View entering={FadeInUp.delay(180).duration(420)}>
            <View
              style={[styles.decisionLoopCard, { backgroundColor: colors.surface, borderColor: colors.border }]}
              accessible
              accessibilityRole="summary"
              accessibilityLabel={`ClosetAI decision loop. ${totalItems} wardrobe items and ${outfits.length} outfit suggestions. ${demoMode ? 'Demo visualization is clearly labeled.' : 'Live provider requests remain retryable and do not silently substitute mock results.'}`}
            >
              <View style={styles.decisionLoopHeader}>
                <View style={styles.decisionLoopTitleWrap}>
                  <Text style={[styles.decisionLoopEyebrow, { color: colors.tint }]}>THE CLOSETAI LOOP</Text>
                  <Text style={[styles.decisionLoopTitle, { color: colors.text }]}>From closet inventory to a more confident decision.</Text>
                </View>
                <View style={[styles.decisionLoopMode, { backgroundColor: demoMode ? '#6E4AE012' : '#00C9B712' }]}>
                  <View style={[styles.decisionLoopModeDot, { backgroundColor: demoMode ? '#6E4AE0' : '#00C9B7' }]} />
                  <Text style={[styles.decisionLoopModeText, { color: demoMode ? '#6E4AE0' : '#008F83' }]}>{demoMode ? 'Demo / offline' : 'Live / retryable'}</Text>
                </View>
              </View>
              <Text style={[styles.decisionLoopCopy, { color: colors.textSecondary }]}>A wardrobe-first workflow: organize what you own, use YouCam only when you choose a photo, then act on a look with clearer context.</Text>
              <View style={styles.decisionLoopSteps}>
                {[
                  { icon: 'shirt-outline' as const, label: 'Inventory', value: `${totalItems} ${totalItems === 1 ? 'item' : 'items'}`, route: '/(tabs)/wardrobe', hint: 'Open your wardrobe inventory.' },
                  { icon: 'sparkles-outline' as const, label: 'Plan', value: `${outfits.length} ${outfits.length === 1 ? 'look' : 'looks'}`, route: '/(tabs)/outfits', hint: 'Open outfit planning.' },
                  { icon: 'person-outline' as const, label: 'Visualize', value: 'Your photo only', route: '/(tabs)/tryon', hint: 'Open user-photo-only virtual try-on.' },
                  { icon: 'bag-handle-outline' as const, label: 'Decide', value: 'Less guesswork', route: '/(tabs)/outfits', hint: 'Review outfit context and retail-aware recommendations.' },
                ].map((step, index) => (
                  <View key={step.label} style={styles.decisionLoopStepRow}>
                    <Pressable
                      onPress={() => {
                        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                        router.push(step.route as any);
                      }}
                      style={({ pressed }) => [styles.decisionLoopStep, { opacity: pressed ? 0.72 : 1 }]}
                      accessibilityRole="button"
                      accessibilityLabel={`${step.label}: ${step.value}`}
                      accessibilityHint={step.hint}
                    >
                      <View style={[styles.decisionLoopIcon, { backgroundColor: colors.tint + '14' }]}>
                        <Ionicons name={step.icon} size={14} color={colors.tint} />
                      </View>
                      <View style={styles.decisionLoopStepCopy}>
                        <Text style={[styles.decisionLoopStepLabel, { color: colors.text }]}>{step.label}</Text>
                        <Text style={[styles.decisionLoopStepValue, { color: colors.textSecondary }]}>{step.value}</Text>
                      </View>
                    </Pressable>
                    {index < 3 && <Ionicons name="arrow-forward" size={12} color={colors.textTertiary} />}
                  </View>
                ))}
              </View>
              <View style={[styles.decisionLoopBoundary, { backgroundColor: demoMode ? '#6E4AE008' : '#00C9B708' }]}>
                <Ionicons name="shield-checkmark-outline" size={13} color={demoMode ? '#6E4AE0' : '#008F83'} />
                <Text style={[styles.decisionLoopBoundaryText, { color: colors.textSecondary }]}>{demoMode ? 'Fictional demo context stays labeled; no stock model is substituted.' : 'Live requests use explicit consent, user-selected media, and retryable provider errors.'}</Text>
              </View>
            </View>
          </Animated.View>

          <Animated.View entering={FadeInUp.delay(205).duration(420)}>
            <View
              style={[styles.impactIdeaCard, { backgroundColor: isDark ? 'rgba(110,74,224,0.1)' : 'rgba(110,74,224,0.055)', borderColor: colors.border }]}
              accessible
              accessibilityRole="summary"
              accessibilityLabel="Why ClosetAI matters. For people with clothing they own but struggle to use, ClosetAI turns wardrobe context into an actionable outfit decision. YouCam is distinctive here because visualization is connected to the user's own closet and selected photo, not a generic catalog model."
            >
              <View style={styles.impactIdeaHeader}>
                <View style={[styles.impactIdeaIcon, { backgroundColor: colors.tint + '18' }]}>
                  <Ionicons name="bulb-outline" size={16} color={colors.tint} />
                </View>
                <View style={styles.impactIdeaHeaderCopy}>
                  <Text style={[styles.impactIdeaEyebrow, { color: colors.tint }]}>WHY THIS MATTERS</Text>
                  <Text style={[styles.impactIdeaTitle, { color: colors.text }]}>AR that starts with the closet, not the catalog.</Text>
                </View>
              </View>
              <Text style={[styles.impactIdeaCopy, { color: colors.textSecondary }]}>For people who own plenty but still default to the same few looks, ClosetAI turns wardrobe context into a more actionable decision: use what you own, preview only with a photo you choose, then explore a bounded gap if something is missing.</Text>
              <View style={[styles.impactIdeaBoundary, { backgroundColor: colors.surface }]}>
                <Ionicons name="sparkles-outline" size={13} color={colors.tint} />
                <Text style={[styles.impactIdeaBoundaryText, { color: colors.textSecondary }]}>Distinctive idea: YouCam visualization is connected to personal wardrobe context instead of a generic stock-model catalog.</Text>
              </View>
            </View>
          </Animated.View>

          {/* Quick Access Bar for Agent Studio & Discovery Search */}
          <Animated.View entering={FadeInUp.delay(180).duration(420)} style={styles.quickAccessRow}>
            <Pressable
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                router.push('/commerce-agent' as any);
              }}
              style={({ pressed }) => [
                styles.quickAccessButton,
                { backgroundColor: colors.surface, borderColor: colors.border, transform: [{ scale: pressed ? 0.97 : 1 }] },
                shadows.soft,
              ]}
              accessibilityRole="button"
              accessibilityLabel="Open Agentic Shopping Copilot"
            >
              <Ionicons name="bag-check" size={16} color="#EC4899" />
              <Text style={[styles.quickAccessText, { color: colors.text }]}>Shop with AI</Text>
            </Pressable>

            <Pressable
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                router.push('/agents' as any);
              }}
              style={({ pressed }) => [
                styles.quickAccessButton,
                { backgroundColor: colors.surface, borderColor: colors.border, transform: [{ scale: pressed ? 0.97 : 1 }] },
                shadows.soft,
              ]}
              accessibilityRole="button"
              accessibilityLabel="Open ClosetAI Agent Studio"
            >
              <Ionicons name="sparkles" size={16} color="#6E4AE0" />
              <Text style={[styles.quickAccessText, { color: colors.text }]}>Agent Studio</Text>
            </Pressable>

            <Pressable
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                router.push('/(tabs)/wardrobe' as any);
              }}
              style={({ pressed }) => [
                styles.quickAccessButton,
                { backgroundColor: colors.surface, borderColor: colors.border, transform: [{ scale: pressed ? 0.97 : 1 }] },
                shadows.soft,
              ]}
              accessibilityRole="button"
              accessibilityLabel="Open Wardrobe"
            >
              <Ionicons name="shirt-outline" size={16} color="#C17F59" />
              <Text style={[styles.quickAccessText, { color: colors.text }]}>View Wardrobe</Text>
            </Pressable>
          </Animated.View>

          <Animated.View entering={FadeInUp.delay(220).duration(450)}>
            <Pressable
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                router.push('/skin');
              }}
              style={({ pressed }) => [
                styles.skinCard,
                { backgroundColor: colors.surface, transform: [{ scale: pressed ? interaction.cardPressScale : 1 }] },
                shadows.medium,
              ]}
              accessibilityRole="button"
              accessibilityLabel="Open Skin Care"
              accessibilityHint="Explore optional skin guidance, routines, and style connections."
            >
              <LinearGradient
                colors={isDark ? ['#39251F', '#201713'] : ['#F4D9C7', '#FFF7F1']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={styles.skinCardGradient}
              >
                <View style={styles.skinCardIcon}>
                  <Ionicons name="sparkles" size={20} color="#A85F48" />
                </View>
                <View style={styles.skinCardCopy}>
                  <Text style={[styles.skinCardEyebrow, { color: colors.tint }]}>NEW • SKIN AI</Text>
                  <Text style={[styles.skinCardTitle, { color: colors.text }]}>Style your whole look</Text>
                  <Text style={[styles.skinCardText, { color: colors.textSecondary }]}>
                    Scan your skin, get a gentle routine, then turn the insight into outfit inspiration.
                  </Text>
                </View>
                <View style={[styles.skinCardArrow, { backgroundColor: colors.surface + 'B8' }]}>
                  <Ionicons name="arrow-forward" size={17} color={colors.tint} />
                </View>
              </LinearGradient>
            </Pressable>
          </Animated.View>

          <Animated.View entering={FadeInUp.delay(250).duration(450)}>
            <Pressable
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                router.push({ pathname: '/agents', params: { mode: 'fashion' } } as any);
              }}
              style={({ pressed }) => [
                styles.agentCard,
                { backgroundColor: colors.surface, borderColor: colors.border, transform: [{ scale: pressed ? interaction.cardPressScale : 1 }] },
                shadows.soft,
              ]}
              accessibilityRole="button"
              accessibilityLabel="Open Fashion Look Planner agent"
              accessibilityHint="Creates a reviewable outfit plan from your selected occasion, colors, and local wardrobe context."
            >
              <View style={[styles.agentIcon, { backgroundColor: '#6E4AE014' }]}><MaterialCommunityIcons name="account-search-outline" size={20} color="#6E4AE0" /></View>
              <View style={styles.agentCopy}>
                <Text style={[styles.agentEyebrow, { color: '#6E4AE0' }]}>NEW · AGENT STUDIO</Text>
                <Text style={[styles.agentTitle, { color: colors.text }]}>Plan a look with your wardrobe</Text>
                <Text style={[styles.agentText, { color: colors.textSecondary }]}>Choose the context; a bounded Fashion Look Planner explains a user-reviewed next look.</Text>
              </View>
              <Ionicons name="arrow-forward" size={17} color={colors.tint} />
            </Pressable>
          </Animated.View>

          <Animated.View entering={FadeInUp.delay(275).duration(450)}>
            <Pressable
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                if (todayOutfit && totalItems > 0 && todayOutfit.id && dailyFocus.route.startsWith('/outfit-detail')) {
                  router.push({ pathname: '/outfit-detail', params: { id: todayOutfit.id } });
                } else {
                  router.push(dailyFocus.route as any);
                }
              }}
              style={({ pressed }) => [
                styles.dailyFocusCard,
                { transform: [{ scale: pressed ? interaction.primaryPressScale : 1 }] },
                shadows.medium,
              ]}
              accessibilityRole="button"
              accessibilityLabel={dailyFocus.action}
              accessibilityHint={dailyFocus.copy}
            >
              <LinearGradient colors={dailyFocus.gradient} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.dailyFocusGradient}>
                <View style={styles.dailyFocusTopRow}>
                  <View style={styles.dailyFocusIcon}><Ionicons name={dailyFocus.icon} size={19} color="#FFF" /></View>
                  <Text style={styles.dailyFocusEyebrow}>{dailyFocus.eyebrow}</Text>
                </View>
                <Text style={styles.dailyFocusTitle}>{dailyFocus.title}</Text>
                <Text style={styles.dailyFocusCopy}>{dailyFocus.copy}</Text>
                <View style={styles.dailyFocusAction}>
                  <Text style={styles.dailyFocusActionText}>{dailyFocus.action}</Text>
                  <Ionicons name="arrow-forward" size={15} color="#FFF" />
                </View>
              </LinearGradient>
            </Pressable>
          </Animated.View>

          {styleInsight && (
            <Animated.View entering={FadeIn.delay(300).duration(400)}>
              <View style={[styles.insightCard, { backgroundColor: colors.surface }, shadows.medium]}>
                <LinearGradient
                  colors={isDark ? ['rgba(110,74,224,0.12)', 'rgba(110,74,224,0.02)'] : ['rgba(110,74,224,0.06)', 'rgba(110,74,224,0.01)']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                  style={styles.insightGradient}
                >
                  <View style={styles.insightHeader}>
                    <LinearGradient
                      colors={['#6E4AE0', '#9B6DFF']}
                      style={styles.insightIconWrap}
                    >
                      <MaterialCommunityIcons name="brain" size={14} color="#FFF" />
                    </LinearGradient>
                    <Text style={[styles.insightTitle, { color: colors.text }]}>Style Insight</Text>
                    <View style={[styles.insightBadge, { backgroundColor: '#6E4AE012' }]}>
                      <Text style={[styles.insightBadgeText, { color: '#6E4AE0' }]}>{styleInsight.dominantStyle}</Text>
                    </View>
                  </View>
                  <Text style={[styles.insightText, { color: colors.textSecondary }]}>{styleInsight.insight}</Text>
                  <View style={[styles.insightSuggestion, { backgroundColor: isDark ? 'rgba(110,74,224,0.08)' : 'rgba(110,74,224,0.04)' }]}>
                    <Ionicons name="bulb-outline" size={14} color="#6E4AE0" />
                    <Text style={[styles.insightSuggestionText, { color: colors.text }]}>{styleInsight.suggestion}</Text>
                  </View>
                </LinearGradient>
              </View>
            </Animated.View>
          )}

          {todayOutfit && (
            <Animated.View entering={FadeInUp.delay(300).duration(500)}>
              <View style={styles.sectionHeader}>
                <Text style={[styles.sectionTitle, { color: colors.text }]}>Today&apos;s Pick</Text>
                {topScoredOutfit && topScoredOutfit.score > 0 && (
                  <View style={[styles.scoreMini, { backgroundColor: '#27AE6015' }]}>
                    <View style={[styles.scoreDot, { backgroundColor: '#27AE60' }]} />
                    <Text style={[styles.scoreText, { color: '#27AE60' }]}>{Math.round(topScoredOutfit.score * 100)}%</Text>
                  </View>
                )}
              </View>
              <Pressable
                onPress={() => {
                  Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                  router.push({ pathname: '/outfit-detail', params: { id: todayOutfit.id } });
                }}
                style={({ pressed }) => [
                  styles.outfitCard,
                  { backgroundColor: colors.surface, transform: [{ scale: pressed ? interaction.cardPressScale : 1 }] },
                  shadows.medium,
                ]}
                accessibilityRole="button"
                accessibilityLabel={`Open today’s outfit: ${todayOutfit.name}`}
                accessibilityHint={todayOutfit.reason}
              >
                <View style={styles.outfitImages}>
                  {todayOutfit.items.slice(0, 3).map((item, idx) => (
                    <Image
                      key={item.id}
                      source={{ uri: item.imageUrl }}
                      style={[
                        styles.outfitItemImage,
                        { marginLeft: idx > 0 ? -18 : 0, zIndex: 3 - idx, borderColor: colors.surface },
                      ]}
                      contentFit="cover"
                      transition={300}
                    />
                  ))}
                </View>
                <View style={styles.outfitInfo}>
                  <Text style={[styles.outfitName, { color: colors.text }]}>{todayOutfit.name}</Text>
                  <Text style={[styles.outfitReason, { color: colors.textSecondary }]} numberOfLines={2}>{todayOutfit.reason}</Text>
                  <View style={styles.outfitMeta}>
                    {todayOutfit.occasion && (
                      <View style={[styles.outfitOccasion, { backgroundColor: colors.tint + '12' }]}>
                        <Text style={[styles.outfitOccasionText, { color: colors.tint }]}>{todayOutfit.occasion}</Text>
                      </View>
                    )}
                    <View style={[styles.aiMark, { backgroundColor: isDark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.04)' }]}>
                      <MaterialCommunityIcons name="auto-fix" size={10} color={colors.textSecondary} />
                      <Text style={[styles.aiMarkText, { color: colors.textSecondary }]}>AI</Text>
                    </View>
                  </View>
                </View>
                <View style={[styles.outfitArrow, { backgroundColor: colors.tint + '12' }]}>
                  <Ionicons name="chevron-forward" size={16} color={colors.tint} />
                </View>
              </Pressable>
            </Animated.View>
          )}

          <Animated.View entering={FadeInUp.delay(400).duration(500)}>
            <Text style={[styles.sectionTitle, { color: colors.text }]}>Quick Actions</Text>
            <View style={styles.actionsGrid}>
              {quickActions.map((action, idx) => (
                <Animated.View key={action.label} entering={FadeInRight.delay(400 + idx * 80).duration(400)}>
                  <Pressable
                    onPress={() => {
                      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                      router.push(action.route as any);
                    }}
                    style={({ pressed }) => [
                      styles.actionCard,
                      { backgroundColor: colors.surface, transform: [{ scale: pressed ? interaction.compactPressScale : 1 }] },
                      shadows.soft,
                    ]}
                    accessibilityRole="button"
                    accessibilityLabel={action.label}
                    accessibilityHint={action.desc}
                  >
                    <LinearGradient
                      colors={action.gradient}
                      start={{ x: 0, y: 0 }}
                      end={{ x: 1, y: 1 }}
                      style={styles.actionIconGradient}
                    >
                      <Ionicons name={action.icon} size={20} color="#FFF" />
                    </LinearGradient>
                    <View>
                      <Text style={[styles.actionLabel, { color: colors.text }]}>{action.label}</Text>
                      <Text style={[styles.actionDesc, { color: colors.textSecondary }]}>{action.desc}</Text>
                    </View>
                  </Pressable>
                </Animated.View>
              ))}
            </View>
          </Animated.View>

          <Animated.View entering={FadeInUp.delay(450).duration(400)}>
            <CreditBanner />
          </Animated.View>

          {topCategory && totalItems > 0 && (
            <Animated.View entering={FadeIn.delay(500).duration(400)}>
              <View style={[styles.wardrobeGlance, { backgroundColor: colors.surface }, shadows.medium]}>
                <LinearGradient
                  colors={isDark ? ['rgba(0,201,183,0.08)', 'transparent'] : ['rgba(0,201,183,0.04)', 'transparent']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                  style={styles.glanceInner}
                >
                  <View style={styles.glanceHeader}>
                    <LinearGradient
                      colors={['#00C9B7', '#00E5D0']}
                      style={styles.glanceIconWrap}
                    >
                      <Ionicons name="analytics-outline" size={14} color="#FFF" />
                    </LinearGradient>
                    <Text style={[styles.glanceTitle, { color: colors.text }]}>Wardrobe Glance</Text>
                  </View>
                  <View style={styles.glanceRow}>
                    <View style={styles.glanceStat}>
                      <Text style={[styles.glanceValue, { color: colors.tint }]}>{totalItems}</Text>
                      <Text style={[styles.glanceLabel, { color: colors.textSecondary }]}>Pieces</Text>
                    </View>
                    <View style={[styles.glanceDivider, { backgroundColor: colors.border }]} />
                    <View style={styles.glanceStat}>
                      <Text style={[styles.glanceValue, { color: '#00C9B7' }]}>{utilizationPct}%</Text>
                      <Text style={[styles.glanceLabel, { color: colors.textSecondary }]}>Worn</Text>
                    </View>
                    <View style={[styles.glanceDivider, { backgroundColor: colors.border }]} />
                    <View style={styles.glanceStat}>
                      <Text style={[styles.glanceValue, { color: '#6E4AE0' }]}>{Object.keys(categoryCounts).length}</Text>
                      <Text style={[styles.glanceLabel, { color: colors.textSecondary }]}>Types</Text>
                    </View>
                    <View style={[styles.glanceDivider, { backgroundColor: colors.border }]} />
                    <View style={styles.glanceStat}>
                      <Text style={[styles.glanceValue, { color: '#EC4899' }]}>{topCategory[0]}</Text>
                      <Text style={[styles.glanceLabel, { color: colors.textSecondary }]}>Top</Text>
                    </View>
                  </View>
                </LinearGradient>
              </View>
            </Animated.View>
          )}

          <View style={{ height: 120 }} />
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  scrollContent: {},
  heroSection: {
    paddingHorizontal: 20,
    paddingBottom: 24,
  },
  mainContent: {
    paddingHorizontal: 20,
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 20,
  },
  headerRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  creditBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  creditCount: { fontFamily: 'Outfit_700Bold', fontSize: 14 },
  settingsBtn: {
    width: 36,
    height: 36,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  greeting: { fontFamily: 'Outfit_400Regular', fontSize: 14, marginBottom: 2 },
  title: { fontFamily: 'Outfit_700Bold', fontSize: 28, letterSpacing: 1 },
  valueProposition: { flexDirection: 'row', alignItems: 'flex-start', gap: 12, borderWidth: 1.5, borderRadius: 18, padding: 16, marginBottom: 14 },
  valuePropositionIcon: { width: 34, height: 34, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  valuePropositionCopy: { flex: 1 },
  valuePropositionKicker: { fontFamily: 'Outfit_700Bold', fontSize: 9, letterSpacing: 1.05 },
  valuePropositionTitle: { fontFamily: 'Outfit_700Bold', fontSize: 14, lineHeight: 19, marginTop: 2 },
  valuePropositionText: { fontFamily: 'Outfit_400Regular', fontSize: 11, lineHeight: 16, marginTop: 3 },
  valuePropositionBoundary: { fontFamily: 'Outfit_400Regular', fontSize: 10, lineHeight: 14, marginTop: 4 },
  demoBanner: {
    alignSelf: 'flex-start',
    borderRadius: 12,
    borderWidth: 1,
    overflow: 'hidden',
    marginBottom: 16,
  },
  demoBannerGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 7,
  },
  demoText: { fontFamily: 'Outfit_500Medium', fontSize: 12 },
  statsRow: { flexDirection: 'row', gap: 10, marginBottom: 4 },
  statCard: {
    width: (SCREEN_WIDTH - 60) / 3,
    borderRadius: 20,
    padding: 14,
    alignItems: 'center',
    gap: 6,
  },
  statIconWrap: {
    width: 36,
    height: 36,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  statNumber: { fontFamily: 'Outfit_700Bold', fontSize: 26 },
  statLabel: { fontFamily: 'Outfit_400Regular', fontSize: 11, textTransform: 'uppercase', letterSpacing: 0.5 },
  tipCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 14,
    borderRadius: 16,
    marginBottom: 18,
    borderWidth: 1,
  },
  tipIcon: {
    width: 32,
    height: 32,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tipText: { fontFamily: 'Outfit_400Regular', fontSize: 13, flex: 1, lineHeight: 18 },
  quickAccessRow: { flexDirection: 'row', gap: 10, marginBottom: 18 },
  quickAccessButton: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingVertical: 12, paddingHorizontal: 14, borderRadius: 16, borderWidth: 1 },
  quickAccessText: { fontFamily: 'Outfit_600SemiBold', fontSize: 13 },
  skinCard: { borderRadius: 22, overflow: 'hidden', marginBottom: 22 },
  skinCardGradient: { flexDirection: 'row', alignItems: 'center', padding: 16, gap: 12 },
  skinCardIcon: { width: 44, height: 44, borderRadius: 15, backgroundColor: 'rgba(255,255,255,0.72)', alignItems: 'center', justifyContent: 'center' },
  skinCardCopy: { flex: 1, gap: 3 },
  skinCardEyebrow: { fontFamily: 'Outfit_700Bold', fontSize: 10, letterSpacing: 1.1 },
  skinCardTitle: { fontFamily: 'Outfit_700Bold', fontSize: 17 },
  skinCardText: { fontFamily: 'Outfit_400Regular', fontSize: 12, lineHeight: 17 },
  skinCardArrow: { width: 32, height: 32, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  agentCard: { flexDirection: 'row', alignItems: 'center', gap: 11, borderWidth: 1, borderRadius: 20, padding: 14, marginBottom: 22 },
  agentIcon: { width: 42, height: 42, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  agentCopy: { flex: 1, gap: 2 },
  agentEyebrow: { fontFamily: 'Outfit_700Bold', fontSize: 9, letterSpacing: 1 },
  agentTitle: { fontFamily: 'Outfit_700Bold', fontSize: 15 },
  agentText: { fontFamily: 'Outfit_400Regular', fontSize: 11, lineHeight: 16 },
  dailyFocusCard: { borderRadius: 22, overflow: 'hidden', marginBottom: 22 },
  dailyFocusGradient: { padding: 17, minHeight: 176, justifyContent: 'space-between' },
  dailyFocusTopRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  dailyFocusIcon: { width: 31, height: 31, borderRadius: 10, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(255,255,255,0.18)' },
  dailyFocusEyebrow: { fontFamily: 'Outfit_700Bold', fontSize: 9, letterSpacing: 1.1, color: 'rgba(255,255,255,0.78)' },
  dailyFocusTitle: { fontFamily: 'Outfit_700Bold', fontSize: 21, color: '#FFF', letterSpacing: -0.3, marginTop: 14 },
  dailyFocusCopy: { fontFamily: 'Outfit_400Regular', fontSize: 12, lineHeight: 17, color: 'rgba(255,255,255,0.86)', marginTop: 5, maxWidth: '90%' },
  dailyFocusAction: { alignSelf: 'flex-start', flexDirection: 'row', alignItems: 'center', gap: 7, paddingHorizontal: 11, paddingVertical: 7, borderRadius: 10, backgroundColor: 'rgba(255,255,255,0.16)', marginTop: 14 },
  dailyFocusActionText: { fontFamily: 'Outfit_700Bold', fontSize: 11, color: '#FFF' },
  insightCard: {
    borderRadius: 20,
    marginBottom: 22,
    overflow: 'hidden',
  },
  insightGradient: {
    padding: 16,
    gap: 12,
  },
  insightHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  insightIconWrap: {
    width: 28,
    height: 28,
    borderRadius: 9,
    alignItems: 'center',
    justifyContent: 'center',
  },
  insightTitle: { fontFamily: 'Outfit_600SemiBold', fontSize: 15, flex: 1 },
  insightBadge: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
  },
  insightBadgeText: { fontFamily: 'Outfit_500Medium', fontSize: 11 },
  insightText: { fontFamily: 'Outfit_400Regular', fontSize: 13, lineHeight: 20 },
  insightSuggestion: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 8,
    padding: 12,
    borderRadius: 12,
  },
  insightSuggestionText: { fontFamily: 'Outfit_400Regular', fontSize: 12, flex: 1, lineHeight: 18 },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 14,
  },
  sectionTitle: { fontFamily: 'Outfit_700Bold', fontSize: 18, marginBottom: 14, letterSpacing: -0.3 },
  scoreMini: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 12,
  },
  scoreDot: { width: 6, height: 6, borderRadius: 3 },
  scoreText: { fontFamily: 'Outfit_600SemiBold', fontSize: 12 },
  outfitCard: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 20,
    padding: 14,
    marginBottom: 22,
  },
  outfitImages: { flexDirection: 'row', marginRight: 12 },
  outfitItemImage: {
    width: 52,
    height: 52,
    borderRadius: 16,
    borderWidth: 2.5,
  },
  outfitInfo: { flex: 1 },
  outfitName: { fontFamily: 'Outfit_600SemiBold', fontSize: 15, marginBottom: 3 },
  outfitReason: { fontFamily: 'Outfit_400Regular', fontSize: 12, marginBottom: 6, lineHeight: 16 },
  outfitMeta: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  outfitOccasion: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
  },
  outfitOccasionText: { fontFamily: 'Outfit_500Medium', fontSize: 10 },
  aiMark: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 6,
  },
  aiMarkText: { fontFamily: 'Outfit_500Medium', fontSize: 9 },
  outfitArrow: {
    width: 30,
    height: 30,
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 4,
  },
  actionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  actionCard: {
    width: (SCREEN_WIDTH - 50) / 2,
    borderRadius: 20,
    padding: 16,
    gap: 10,
  },
  actionIconGradient: {
    width: 44,
    height: 44,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
  },
  actionLabel: { fontFamily: 'Outfit_600SemiBold', fontSize: 14 },
  actionDesc: { fontFamily: 'Outfit_400Regular', fontSize: 11, marginTop: 1 },
  decisionLoopCard: {
    borderRadius: 20,
    borderWidth: 1,
    padding: 16,
    marginBottom: 18,
  },
  decisionLoopHeader: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', gap: 10 },
  decisionLoopTitleWrap: { flex: 1 },
  decisionLoopEyebrow: { fontFamily: 'Outfit_700Bold', fontSize: 9, letterSpacing: 1.05 },
  decisionLoopTitle: { fontFamily: 'Outfit_700Bold', fontSize: 15, lineHeight: 20, marginTop: 3 },
  decisionLoopMode: { flexDirection: 'row', alignItems: 'center', gap: 5, borderRadius: 10, paddingHorizontal: 8, paddingVertical: 5 },
  decisionLoopModeDot: { width: 6, height: 6, borderRadius: 3 },
  decisionLoopModeText: { fontFamily: 'Outfit_600SemiBold', fontSize: 9 },
  decisionLoopCopy: { fontFamily: 'Outfit_400Regular', fontSize: 11, lineHeight: 16, marginTop: 8 },
  decisionLoopSteps: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 4, marginTop: 15 },
  decisionLoopStepRow: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 4 },
  decisionLoopStep: { flex: 1, minHeight: 60, justifyContent: 'center' },
  decisionLoopIcon: { width: 28, height: 28, borderRadius: 9, alignItems: 'center', justifyContent: 'center', marginBottom: 5 },
  decisionLoopStepCopy: { minWidth: 0 },
  decisionLoopStepLabel: { fontFamily: 'Outfit_600SemiBold', fontSize: 10 },
  decisionLoopStepValue: { fontFamily: 'Outfit_400Regular', fontSize: 9, lineHeight: 12, marginTop: 2 },
  decisionLoopBoundary: { flexDirection: 'row', alignItems: 'flex-start', gap: 7, borderRadius: 10, paddingHorizontal: 9, paddingVertical: 8, marginTop: 14 },
  decisionLoopBoundaryText: { flex: 1, fontFamily: 'Outfit_400Regular', fontSize: 10, lineHeight: 14 },
  impactIdeaCard: { borderRadius: 18, borderWidth: 1, padding: 14, marginBottom: 18 },
  impactIdeaHeader: { flexDirection: 'row', alignItems: 'center', gap: 9 },
  impactIdeaIcon: { width: 30, height: 30, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  impactIdeaHeaderCopy: { flex: 1 },
  impactIdeaEyebrow: { fontFamily: 'Outfit_700Bold', fontSize: 8, letterSpacing: 1.05 },
  impactIdeaTitle: { fontFamily: 'Outfit_700Bold', fontSize: 13, lineHeight: 17, marginTop: 2 },
  impactIdeaCopy: { fontFamily: 'Outfit_400Regular', fontSize: 10, lineHeight: 15, marginTop: 9 },
  impactIdeaBoundary: { flexDirection: 'row', alignItems: 'flex-start', gap: 7, borderRadius: 10, paddingHorizontal: 9, paddingVertical: 8, marginTop: 10 },
  impactIdeaBoundaryText: { flex: 1, fontFamily: 'Outfit_400Regular', fontSize: 9, lineHeight: 13 },
  wardrobeGlance: {
    borderRadius: 20,
    marginTop: 22,
    overflow: 'hidden',
  },
  glanceInner: {
    padding: 18,
  },
  glanceHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  glanceIconWrap: {
    width: 28,
    height: 28,
    borderRadius: 9,
    alignItems: 'center',
    justifyContent: 'center',
  },
  glanceTitle: { fontFamily: 'Outfit_600SemiBold', fontSize: 15 },
  glanceRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  glanceStat: {
    flex: 1,
    alignItems: 'center',
    gap: 3,
  },
  glanceValue: { fontFamily: 'Outfit_700Bold', fontSize: 22 },
  glanceLabel: { fontFamily: 'Outfit_400Regular', fontSize: 10, textTransform: 'uppercase', letterSpacing: 0.5 },
  glanceDivider: { width: 1, height: 32 },
});
