import React, { useEffect, useState } from 'react';
import {
  Alert,
  Linking,
  View,
  Text,
  StyleSheet,
  Pressable,
  ScrollView,
  ActivityIndicator,
  Platform,
  FlatList,
} from 'react-native';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import * as ImagePicker from 'expo-image-picker';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';
import Animated, { FadeInUp, FadeIn } from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { router, useFocusEffect } from 'expo-router';
import { useApp } from '@/contexts/AppContext';
import { useTheme } from '@/lib/useTheme';
import { interaction, shadows } from '@/constants/colors';
import { MediaStatusCard } from '@/components/ui/MediaStatusCard';
import { apiRequest } from '@/lib/query-client';
import { FASHION_TRY_ON_CATEGORIES, getFashionTryOnCategory } from '@shared/fashion-tryon-categories';
import { buildYouCamFashionReadiness, normalizeYouCamFashionCapability, type YouCamFashionCapability } from '@shared/youcam-fashion-experience';
import { fashionTryOnResultPresentation, type FashionTryOnResultProvider } from '@shared/fashion-tryon-result';
import { clearTryOnRetryQueue, createTryOnRetryQueueEntry, loadTryOnRetryQueue, saveTryOnRetryQueue, type TryOnRetryQueueEntry } from '@/lib/tryon-retry-queue';

const PROCESSING_STEPS = [
  'Validating your selected photo...',
  'Preparing the wardrobe reference...',
  'Requesting YouCam or a photo-safe fallback...',
  'Finalizing a source-aware result...',
];

export default function TryOnScreen() {
  const { colors, isDark } = useTheme();
  const insets = useSafeAreaInsets();
  const { wardrobeItems, createTryOn, demoMode, isAuthenticated } = useApp();
  const [selfieUri, setSelfieUri] = useState<string | null>(null);
  const [selectedGarments, setSelectedGarments] = useState<string[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isPickingSelfie, setIsPickingSelfie] = useState(false);
  const [resultUri, setResultUri] = useState<string | null>(null);
  const [processingStep, setProcessingStep] = useState(0);
  const [showComparison, setShowComparison] = useState(false);
  const [tryOnError, setTryOnError] = useState<string | null>(null);
  const [tryOnStatus, setTryOnStatus] = useState<string | null>(null);
  const [fashionCapability, setFashionCapability] = useState<'checking' | 'available' | 'unavailable'>('checking');
  const [fashionCapabilityInfo, setFashionCapabilityInfo] = useState<YouCamFashionCapability | null>(null);
  const [fashionCapabilityFeedback, setFashionCapabilityFeedback] = useState<string | null>(null);
  const [capabilityRetryNonce, setCapabilityRetryNonce] = useState(0);
  const [photoPermissionState, setPhotoPermissionState] = useState<'unknown' | 'granted' | 'blocked'>('unknown');
  const [tryOnProvider, setTryOnProvider] = useState<FashionTryOnResultProvider | null>(null);
  const [queuedRetry, setQueuedRetry] = useState<TryOnRetryQueueEntry | null>(null);
  const [selectedTryOnCategory, setSelectedTryOnCategory] = useState<'all' | (typeof FASHION_TRY_ON_CATEGORIES)[number]['id']>('all');
  const isMountedRef = React.useRef(true);
  const pickerInFlightRef = React.useRef(false);
  const tryOnInFlightRef = React.useRef(false);
  const tryOnRunRef = React.useRef(0);
  const queueActionRef = React.useRef(false);
  const processingIntervalRef = React.useRef<ReturnType<typeof setInterval> | null>(null);
  const isInteractionLocked = isProcessing || isPickingSelfie;

  const webTopInset = Platform.OS === 'web' ? 67 : 0;

  useFocusEffect(React.useCallback(() => {
    let active = true;
    void ImagePicker.getMediaLibraryPermissionsAsync().then(permission => {
      if (active) setPhotoPermissionState(permission.granted ? 'granted' : 'blocked');
    }).catch(() => {
      if (active) setPhotoPermissionState('unknown');
    });
    void loadTryOnRetryQueue().then(entry => {
      if (active) setQueuedRetry(entry);
    }).catch(err => {
      console.warn('[TryOn] Failed to load retry queue:', err);
    });
    return () => { active = false; };
  }, []));

  useEffect(() => {
    let isActive = true;
    apiRequest('GET', '/api/youcam/fashion-capability')
      .then(response => response.json())
      .then((response: unknown) => {
        const capability = normalizeYouCamFashionCapability(response);
        if (!capability) {
          if (isActive) {
            setFashionCapabilityInfo(null);
            setFashionCapability('unavailable');
            setFashionCapabilityFeedback('Live YouCam availability could not be verified. ClosetAI will keep your selected photo as the only fallback preview and will not substitute another person.');
          }
          return;
        }
        if (isActive) {
          setFashionCapabilityInfo(capability);
          setFashionCapability(capability.configured ? 'available' : 'unavailable');
          setFashionCapabilityFeedback(capability.configured ? null : 'Live YouCam clothing rendering is not configured for this session. A selected-photo-only preview remains available.');
        }
      })
      .catch(() => {
        if (isActive) {
          setFashionCapabilityInfo(null);
          setFashionCapability('unavailable');
          setFashionCapabilityFeedback('Live YouCam availability is temporarily unavailable. ClosetAI will keep your selected photo as the only fallback preview and will not substitute another person.');
        }
      });
    return () => { isActive = false; };
  }, [capabilityRetryNonce]);

  useEffect(() => () => {
    isMountedRef.current = false;
    if (processingIntervalRef.current) clearInterval(processingIntervalRef.current);
  }, []);

  const retryFashionCapability = () => {
    setFashionCapability('checking');
    setFashionCapabilityFeedback(null);
    setCapabilityRetryNonce(value => value + 1);
  };

  const openPhotoSettings = async () => {
    try {
      await Linking.openSettings();
    } catch {
      Alert.alert('Open settings manually', 'Photo access can be changed in your device settings. Demo Mode and the rest of the app remain available without photo access.');
    }
  };

  const pickSelfie = async () => {
    if (pickerInFlightRef.current || tryOnInFlightRef.current) return;
    pickerInFlightRef.current = true;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setIsPickingSelfie(true);
    setTryOnError(null);
    try {
      const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!permission.granted) {
        if (isMountedRef.current) {
          setPhotoPermissionState('blocked');
          setTryOnError('Photo access is needed to use your own image. You can enable it in device settings and try again.');
        }
        return;
      }
      if (isMountedRef.current) setPhotoPermissionState('granted');
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ['images'],
        allowsEditing: true,
        aspect: [3, 4],
        quality: 0.8,
        exif: false,
      });
      if (!result.canceled && result.assets[0]) {
        if (isMountedRef.current) {
          setSelfieUri(result.assets[0].uri);
          setResultUri(null);
          setShowComparison(false);
          setTryOnProvider(null);
          setQueuedRetry(null);
          void clearTryOnRetryQueue();
        }
      }
    } catch (error) {
      if (isMountedRef.current) setTryOnError(error instanceof Error ? error.message : 'We could not open your photos. Please try again.');
    } finally {
      pickerInFlightRef.current = false;
      if (isMountedRef.current) setIsPickingSelfie(false);
    }
  };

  const toggleGarment = (id: string) => {
    if (isInteractionLocked) return;
    Haptics.selectionAsync();
    setSelectedGarments(prev =>
      prev.includes(id) ? prev.filter(g => g !== id) : [...prev, id]
    );
    setResultUri(null);
    setTryOnProvider(null);
    setQueuedRetry(null);
    void clearTryOnRetryQueue();
  };

  const handleTryOn = async (requestedSelfieUri = selfieUri, requestedGarmentIds = selectedGarments) => {
    if (!selfieUri || selectedGarments.length === 0 || tryOnInFlightRef.current || pickerInFlightRef.current) return;
    const activeSelfie = requestedSelfieUri || selfieUri;
    const activeGarments = requestedGarmentIds.length > 0 ? requestedGarmentIds : selectedGarments;
    if (!activeSelfie || activeGarments.length === 0) return;
    const runId = tryOnRunRef.current + 1;
    tryOnRunRef.current = runId;
    const isCurrentRun = () => tryOnRunRef.current === runId;
    tryOnInFlightRef.current = true;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setIsProcessing(true);
    setProcessingStep(0);
    setTryOnError(null);
    setTryOnStatus(null);

    processingIntervalRef.current = setInterval(() => {
      if (!isMountedRef.current || !isCurrentRun()) return;
      setProcessingStep(prev => {
        if (prev >= PROCESSING_STEPS.length - 1) return prev;
        return prev + 1;
      });
    }, 2500);

    try {
      const result = await createTryOn(activeSelfie, activeGarments);
      if (!isCurrentRun()) return;
      const provider = result.provider || (Boolean(result.isUserPhotoPreview) || result.resultImageUrl === activeSelfie ? 'photo-preview' : 'youcam-ai-clothes-v4');
      if (isMountedRef.current && isCurrentRun()) {
        setResultUri(result.resultImageUrl);
        setTryOnProvider(provider);
        setTryOnError(result.disclosure || (provider === 'photo-preview' ? 'Live garment editing is unavailable in this session, so this is your uploaded photo preview with the selected outfit listed below.' : null));
        if (provider === 'photo-preview' && !demoMode && isAuthenticated) {
          const entry = createTryOnRetryQueueEntry(activeSelfie, activeGarments);
          void saveTryOnRetryQueue(entry).then(() => {
            if (isMountedRef.current && isCurrentRun()) setQueuedRetry(entry);
          }).catch(() => {
            // The result remains usable when local queue persistence is unavailable.
          });
        } else {
          setQueuedRetry(null);
          void clearTryOnRetryQueue();
        }
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
    } catch (error) {
      if (isMountedRef.current && isCurrentRun()) {
        setTryOnError(error instanceof Error ? error.message : 'We could not create a try-on result. Your uploaded photo remains available—please try again.');
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      }
    } finally {
      if (!isCurrentRun()) return;
      if (processingIntervalRef.current) clearInterval(processingIntervalRef.current);
      processingIntervalRef.current = null;
      tryOnInFlightRef.current = false;
      if (isMountedRef.current) setIsProcessing(false);
      tryOnRunRef.current = 0;
    }
  };

  const cancelTryOn = () => {
    tryOnRunRef.current += 1;
    if (processingIntervalRef.current) clearInterval(processingIntervalRef.current);
    processingIntervalRef.current = null;
    tryOnInFlightRef.current = false;
    setIsProcessing(false);
    setTryOnError(null);
    setQueuedRetry(null);
    void clearTryOnRetryQueue();
    setTryOnStatus('Try-on cancelled. Your selected photo and garments remain available for review.');
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };

  const retryTryOnAfterError = () => {
    if (!selfieUri || selectedGarments.length === 0 || isInteractionLocked) return;
    setResultUri(null);
    setTryOnProvider(null);
    setShowComparison(false);
    setTryOnError(null);
    setTryOnStatus(null);
    Haptics.selectionAsync();
    void handleTryOn();
  };

  const retryQueuedTryOn = () => {
    if (!queuedRetry || isInteractionLocked || queueActionRef.current) return;
    queueActionRef.current = true;
    const entry = queuedRetry;
    setSelfieUri(entry.selfieUri);
    setSelectedGarments(entry.garmentIds);
    setQueuedRetry(null);
    void clearTryOnRetryQueue();
    Haptics.selectionAsync();
    void handleTryOn(entry.selfieUri, entry.garmentIds).finally(() => {
      queueActionRef.current = false;
    });
  };

  const dismissQueuedTryOn = () => {
    setQueuedRetry(null);
    void clearTryOnRetryQueue();
    Haptics.selectionAsync();
  };

  const reset = () => {
    if (isInteractionLocked) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setSelfieUri(null);
    setSelectedGarments([]);
    setResultUri(null);
    setShowComparison(false);
    setTryOnProvider(null);
    setTryOnError(null);
    setTryOnStatus(null);
    tryOnRunRef.current += 1;
  };

  const selectedItems = wardrobeItems.filter(i => selectedGarments.includes(i.id));
  const filteredWardrobeItems = selectedTryOnCategory === 'all'
    ? wardrobeItems
    : wardrobeItems.filter(item => getFashionTryOnCategory(item.category)?.id === selectedTryOnCategory);
  const selectedCategoryLabel = selectedTryOnCategory === 'all'
    ? 'All categories'
    : getFashionTryOnCategory(selectedTryOnCategory)?.label || selectedTryOnCategory;
  const fashionReadiness = buildYouCamFashionReadiness({
    configured: fashionCapabilityInfo?.configured ?? fashionCapability === 'available',
    selectedItems,
  });
  const resultPresentation = tryOnProvider ? fashionTryOnResultPresentation(tryOnProvider) : null;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView
        contentContainerStyle={[
          styles.scrollContent,
          { paddingTop: (insets.top || webTopInset) + 12 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <Animated.View entering={FadeInUp.duration(400)} style={styles.header}>
          <View>
            <Text style={[styles.title, { color: colors.text }]}>Virtual Try-On</Text>
            <Text style={[styles.subtitle, { color: colors.textSecondary }]}>See how outfits look on you</Text>
          </View>
          <LinearGradient
            colors={['#EC4899', '#F472B6']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={styles.aiBadge}
          >
            <MaterialCommunityIcons name={fashionCapability === 'available' ? 'tshirt-crew-outline' : 'image-outline'} size={12} color="#FFF" />
            <Text style={styles.aiBadgeText}>{fashionCapability === 'available' ? 'YouCam AI Clothes' : fashionCapability === 'checking' ? 'Checking AI' : 'Photo-safe Preview'}</Text>
          </LinearGradient>
        </Animated.View>

        {photoPermissionState === 'blocked' && (
          <View style={[styles.errorBanner, { backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]} accessibilityLiveRegion="polite">
            <Ionicons name="lock-closed-outline" size={17} color={colors.tint} />
            <Text style={[styles.errorText, { color: colors.textSecondary }]}>Photo access is currently off. Enable it in Settings to use your own photo for virtual try-on.</Text>
            <Pressable onPress={() => { void openPhotoSettings(); }} accessibilityRole="button" accessibilityLabel="Open photo settings" style={[styles.settingsButton, { borderColor: colors.border }]}>
              <Text style={[styles.settingsButtonText, { color: colors.text }]}>Settings</Text>
            </Pressable>
          </View>
        )}

        {!!fashionCapabilityFeedback && (
          <View style={[styles.errorBanner, { backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]} accessibilityLiveRegion="polite" accessibilityRole="alert">
            <Ionicons name="information-circle-outline" size={17} color={colors.tint} />
            <Text style={[styles.errorText, { color: colors.textSecondary, flex: 1 }]}>{fashionCapabilityFeedback}</Text>
            {fashionCapability === 'unavailable' && <Pressable onPress={retryFashionCapability} accessibilityRole="button" accessibilityLabel="Retry live fashion capability check" style={[styles.settingsButton, { borderColor: colors.border }]}><Text style={[styles.settingsButtonText, { color: colors.text }]}>Retry</Text></Pressable>}
          </View>
        )}

        <View
          style={[styles.providerEvidenceCard, { backgroundColor: colors.surface, borderColor: colors.border }]}
          accessible
          accessibilityRole="summary"
          accessibilityLabel={`YouCam fashion implementation path. ${demoMode ? 'Demo mode uses a fictional offline preview and no provider result.' : fashionCapability === 'available' ? 'Live YouCam AI Clothes workflow is available for the selected photo and wardrobe references.' : 'Live provider availability is not confirmed; ClosetAI will not present a fake live result.'}`}
        >
          <View style={styles.providerEvidenceHeader}>
            <View style={[styles.providerEvidenceIcon, { backgroundColor: demoMode ? '#6E4AE012' : '#EC489912' }]}>
              <Ionicons name="git-network-outline" size={16} color={demoMode ? '#6E4AE0' : '#EC4899'} />
            </View>
            <View style={styles.providerEvidenceTitleWrap}>
              <Text style={[styles.providerEvidenceEyebrow, { color: demoMode ? '#6E4AE0' : '#EC4899' }]}>IMPLEMENTATION PATH</Text>
              <Text style={[styles.providerEvidenceTitle, { color: colors.text }]}>YouCam fashion rendering, made inspectable</Text>
            </View>
          </View>
          <Text style={[styles.providerEvidenceCopy, { color: colors.textSecondary }]}>{demoMode ? 'Demo mode keeps the pipeline offline and clearly fictional. It is useful for walkthroughs, but it is not presented as a provider result.' : fashionCapability === 'available' ? 'The live path sends your selected photo and wardrobe references through the configured YouCam AI Clothes workflow, then returns a temporary result for review.' : 'Live provider availability is not confirmed for this session. ClosetAI keeps the selected-photo boundary and shows a retryable or photo-safe path instead of inventing a live render.'}</Text>
          <View style={styles.providerEvidenceRows}>
            <View style={styles.providerEvidenceRow}>
              <Text style={[styles.providerEvidenceLabel, { color: colors.textTertiary }]}>Provider</Text>
              <Text style={[styles.providerEvidenceValue, { color: colors.text }]}>{demoMode ? 'Fictional Demo Mode' : fashionCapability === 'available' ? 'Perfect Corp. YouCam AI Clothes' : 'Selected-photo-safe path'}</Text>
            </View>
            <View style={styles.providerEvidenceRow}>
              <Text style={[styles.providerEvidenceLabel, { color: colors.textTertiary }]}>Inputs</Text>
              <Text style={[styles.providerEvidenceValue, { color: colors.text }]}>Your photo + wardrobe garment references</Text>
            </View>
            <View style={styles.providerEvidenceRow}>
              <Text style={[styles.providerEvidenceLabel, { color: colors.textTertiary }]}>Output</Text>
              <Text style={[styles.providerEvidenceValue, { color: colors.text }]}>Temporary visualization, not a fit or size guarantee</Text>
            </View>
          </View>
          <View style={[styles.providerEvidenceImpact, { backgroundColor: demoMode ? '#6E4AE008' : '#EC489908' }]}>
            <Ionicons name="sparkles-outline" size={13} color={demoMode ? '#6E4AE0' : '#EC4899'} />
            <Text style={[styles.providerEvidenceImpactText, { color: colors.textSecondary }]}>Consumer value: preview a candidate look on the media you chose before deciding what to save, share, or explore next.</Text>
          </View>
        </View>

        {!!tryOnError && (
          <View style={[styles.errorBanner, { backgroundColor: '#E74C3C15', borderColor: '#E74C3C30' }]} accessibilityLiveRegion="assertive" accessibilityRole="alert">
            <Ionicons name="alert-circle-outline" size={17} color="#E74C3C" />
            <View style={styles.errorContent}>
              <Text style={[styles.errorText, { color: colors.text }]}>{tryOnError}</Text>
              {!demoMode && <Text style={[styles.errorBoundaryText, { color: colors.textSecondary }]}>Live provider path stopped here. Retry is available; no fictional result or stock model was substituted.</Text>}
            </View>
            <Pressable
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                setTryOnError(null);
                if (selfieUri && selectedGarments.length > 0) {
                  void handleTryOn();
                }
              }}
              accessibilityRole="button"
              accessibilityLabel="Retry virtual try-on request"
              style={[styles.settingsButton, { borderColor: '#E74C3C40', backgroundColor: '#E74C3C20' }]}
            >
              <Text style={[styles.settingsButtonText, { color: colors.text }]}>Retry</Text>
            </Pressable>
          </View>
        )}

        <Pressable
          onPress={() => router.push('/tryon/shoes')}
          disabled={isInteractionLocked}
          style={({ pressed }) => [styles.readinessCard, { backgroundColor: colors.surfaceSecondary, borderColor: colors.border, opacity: isInteractionLocked ? 0.55 : pressed ? 0.78 : 1, transform: [{ scale: pressed && !isInteractionLocked ? interaction.cardPressScale : 1 }] }]}
          accessibilityRole="button"
          accessibilityState={{ disabled: isInteractionLocked }}
          accessibilityLabel="Open AI Shoes Virtual Try-On"
          accessibilityHint={isInteractionLocked ? "Wait until the current try-on action finishes." : "Opens a dedicated workflow using your selected photo and a shoe reference."}
        >
          <View style={styles.readinessHeader}>
            <Ionicons name="footsteps-outline" size={18} color={colors.tint} />
            <Text style={[styles.readinessTitle, { color: colors.text }]}>AI Shoes Virtual Try-On</Text>
          </View>
          <Text style={[styles.readinessText, { color: colors.textSecondary }]}>Use your selected photo and one shoe product reference in a dedicated live YouCam workflow. No stock model substitution.</Text>
        </Pressable>

        {selectedItems.length > 0 && (
          <View style={[styles.readinessCard, { backgroundColor: colors.surfaceSecondary, borderColor: fashionReadiness.mode === 'live-ready' ? colors.success : colors.border }]}>
            <View style={styles.readinessHeader}>
              <Ionicons name={fashionReadiness.mode === 'live-ready' ? 'sparkles-outline' : fashionReadiness.mode === 'provider-unavailable' ? 'image-outline' : 'information-circle-outline'} size={17} color={fashionReadiness.mode === 'live-ready' ? colors.success : colors.tint} />
              <Text style={[styles.readinessTitle, { color: colors.text }]}>{fashionReadiness.headline}</Text>
            </View>
            <Text style={[styles.readinessText, { color: colors.textSecondary }]}>{fashionReadiness.detail}</Text>
            <View style={styles.readinessChecklist}>{fashionReadiness.checklist.map((item) => <View key={item} style={styles.readinessCheck}><Ionicons name="checkmark-circle-outline" size={13} color={fashionReadiness.mode === 'live-ready' ? colors.success : colors.tint} /><Text style={[styles.readinessCheckText, { color: colors.textSecondary }]}>{item}</Text></View>)}</View>
            <Text style={[styles.userPhotoGuarantee, { color: colors.textTertiary }]}>Your photo only · never a stock model substitution.</Text>
          </View>
        )}

        {isProcessing ? (
          <Animated.View entering={FadeIn.duration(400)}>
            <LinearGradient
              colors={isDark ? ['rgba(236,72,153,0.08)', 'rgba(236,72,153,0.02)'] : ['rgba(236,72,153,0.06)', 'rgba(236,72,153,0.01)']}
              start={{ x: 0, y: 0 }}
              end={{ x: 0, y: 1 }}
              style={[styles.processingCard, shadows.medium]}
              accessibilityLiveRegion="polite"
              accessibilityRole="progressbar"
              accessibilityState={{ busy: true }}
              accessibilityLabel="Creating your virtual try-on result"
            >
              <View style={styles.processingIconWrap}>
                <LinearGradient
                  colors={['#EC4899', '#F472B6']}
                  style={styles.processingIconGradient}
                >
                  <ActivityIndicator size="large" color="#FFF" />
                </LinearGradient>
              </View>
              <Text style={[styles.processingTitle, { color: colors.text }]}>Creating Your Look</Text>
              <Text style={[styles.processingStep, { color: colors.textSecondary }]}>
                {PROCESSING_STEPS[processingStep]}
              </Text>
              <View style={styles.stepsRow}>
                {PROCESSING_STEPS.map((_, idx) => (
                  <View
                    key={idx}
                    style={[
                      styles.stepDot,
                      {
                        backgroundColor: idx <= processingStep ? '#EC4899' : colors.surfaceSecondary,
                        width: idx === processingStep ? 24 : 8,
                      },
                    ]}
                  />
                ))}
              </View>
              <View style={styles.processingItems}>
                {selectedItems.slice(0, 3).map((item, idx) => (
                  <Image key={item.id} source={{ uri: item.imageUrl }} style={[styles.processingItemImg, idx > 0 && { marginLeft: -8 }]} contentFit="cover" />
                ))}
                <Text style={[styles.processingItemCount, { color: colors.textSecondary }]}>
                  {selectedItems.length} item{selectedItems.length !== 1 ? 's' : ''}
                </Text>
              </View>
              <Pressable onPress={cancelTryOn} style={[styles.cancelProcessingButton, { borderColor: colors.border }]} accessibilityRole="button" accessibilityLabel="Cancel virtual try-on" accessibilityHint="Stops the current request and keeps your selected photo and garments available for review.">
                <Ionicons name="close-circle-outline" size={18} color={colors.textSecondary} />
                <Text style={[styles.actionButtonSecondaryText, { color: colors.text }]}>Cancel try-on</Text>
              </Pressable>
            </LinearGradient>
          </Animated.View>
        ) : resultUri ? (
          <Animated.View entering={FadeIn.duration(500)}>
            <View style={styles.resultHeader}>
              <View><Text style={[styles.stepLabel, { color: colors.textSecondary }]}>{resultPresentation?.label || 'Try-On Result'}</Text><Text style={[styles.previewDisclosure, { color: tryOnProvider === 'youcam-ai-clothes-v4' ? colors.success : colors.textTertiary }]}>{resultPresentation?.detail || 'Review the rendered result and selected wardrobe items.'}</Text></View>
              <Pressable
                onPress={() => {
                  Haptics.selectionAsync();
                  setShowComparison(!showComparison);
                }}
                accessibilityRole="button"
                accessibilityState={{ selected: showComparison }}
                accessibilityLabel={showComparison ? 'Hide original photo comparison' : 'Compare with original photo'}
                style={({ pressed }) => [styles.compareToggle, { backgroundColor: showComparison ? colors.tint + '15' : colors.surfaceSecondary, opacity: pressed ? 0.76 : 1 }]}
              >
                <Ionicons name="git-compare-outline" size={14} color={showComparison ? colors.tint : colors.textSecondary} />
                <Text style={[styles.compareText, { color: showComparison ? colors.tint : colors.textSecondary }]}>
                  {showComparison ? 'Hide Original' : 'Compare'}
                </Text>
              </Pressable>
            </View>

            <MediaStatusCard
              kind={demoMode ? 'local-only' : 'temporary-result'}
              title={demoMode ? 'Fictional Demo Mode result' : tryOnProvider === 'youcam-ai-clothes-v4' ? 'Live YouCam result' : 'Photo-safe assisted result'}
              detail={demoMode ? 'Fictional preview using your selected photo and garments only. It is not a live provider result and never substitutes a stock model.' : tryOnProvider === 'youcam-ai-clothes-v4' ? 'Temporary provider-rendered result using your selected photo and garments. Review it before saving or sharing.' : 'Temporary photo-safe assisted preview using your selected photo and garments. No fabricated or stock result is substituted.'}
              tint={demoMode ? colors.textTertiary : tryOnProvider === 'youcam-ai-clothes-v4' ? colors.success : colors.tint}
              surface={colors.surfaceSecondary}
              border={colors.border}
            />
            <Pressable
              onPress={() => {
                Haptics.selectionAsync();
                router.push({
                  pathname: '/tryon-result',
                  params: {
                    resultUri,
                    provider: tryOnProvider || 'youcam-ai-clothes-v4',
                    demo: String(demoMode),
                  },
                } as any);
              }}
              accessibilityRole="button"
              accessibilityLabel="Open dedicated standalone try-on result and provenance view"
              style={({ pressed }) => [styles.standaloneButton, { backgroundColor: colors.surfaceSecondary, borderColor: colors.border, borderWidth: 1, opacity: pressed ? 0.8 : 1 }]}
            >
              <Ionicons name="open-outline" size={16} color={colors.tint} />
              <Text style={[styles.standaloneButtonText, { color: colors.text }]}>View Full Provenance & Standalone Result</Text>
            </Pressable>

            <View
              style={[styles.resultLineageCard, { backgroundColor: colors.surface, borderColor: colors.border }]}
              accessible
              accessibilityRole="summary"
              accessibilityLabel={`Try-on source lineage. Provider: ${demoMode ? 'Fictional Demo Mode' : tryOnProvider === 'youcam-ai-clothes-v4' ? 'Perfect Corp. YouCam AI Clothes' : 'Photo-safe assisted path'}. Inputs: your selected photo and ${selectedItems.length} wardrobe garment${selectedItems.length === 1 ? '' : 's'}. Output: temporary visualization with no fit or purchase guarantee.`}
            >
              <View style={styles.resultLineageHeader}>
                <Ionicons name="git-branch-outline" size={15} color={demoMode ? colors.textTertiary : colors.tint} />
                <Text style={[styles.resultLineageTitle, { color: colors.text }]}>Source lineage</Text>
                <Text style={[styles.resultLineageBadge, { color: demoMode ? colors.textTertiary : colors.tint }]}>{demoMode ? 'DEMO' : tryOnProvider === 'youcam-ai-clothes-v4' ? 'LIVE' : 'ASSISTED'}</Text>
              </View>
              <View style={styles.resultLineageRows}>
                <View style={styles.resultLineageRow}><Text style={[styles.resultLineageLabel, { color: colors.textTertiary }]}>Provider</Text><Text style={[styles.resultLineageValue, { color: colors.text }]}>{demoMode ? 'Fictional Demo Mode' : tryOnProvider === 'youcam-ai-clothes-v4' ? 'Perfect Corp. YouCam AI Clothes' : 'Photo-safe assisted path'}</Text></View>
                <View style={styles.resultLineageRow}><Text style={[styles.resultLineageLabel, { color: colors.textTertiary }]}>Inputs</Text><Text style={[styles.resultLineageValue, { color: colors.text }]}>Your selected photo + {selectedItems.length} wardrobe garment{selectedItems.length === 1 ? '' : 's'}</Text></View>
                <View style={styles.resultLineageRow}><Text style={[styles.resultLineageLabel, { color: colors.textTertiary }]}>Boundary</Text><Text style={[styles.resultLineageValue, { color: colors.text }]}>Temporary visualization; no fit, size, or purchase guarantee</Text></View>
              </View>
            </View>

            {showComparison ? (
              <View style={styles.comparisonRow}>
                <View style={styles.comparisonCol}>
                  <View style={[styles.comparisonLabel, { backgroundColor: colors.surfaceSecondary }]}>
                    <Text style={[styles.comparisonLabelText, { color: colors.textSecondary }]}>Before</Text>
                  </View>
                  <View style={[styles.comparisonBox, { borderColor: colors.border }, shadows.soft]}>
                    <Image source={{ uri: selfieUri! }} style={styles.comparisonImage} contentFit="cover" />
                  </View>
                </View>
                <View style={styles.comparisonCol}>
                  <View style={[styles.comparisonLabel, { backgroundColor: '#EC489915' }]}>
                    <Text style={[styles.comparisonLabelText, { color: '#EC4899' }]}>After</Text>
                  </View>
                  <View style={[styles.comparisonBox, { borderColor: '#EC4899' }, shadows.soft]}>
                    <Image source={{ uri: resultUri }} style={styles.comparisonImage} contentFit="cover" transition={400} />
                  </View>
                </View>
              </View>
            ) : (
              <View style={[styles.resultBox, { borderColor: '#EC4899' }, shadows.medium]}>
                <Image source={{ uri: resultUri }} style={styles.resultImage} contentFit="cover" transition={400} />
                <LinearGradient
                  colors={['transparent', 'rgba(0,0,0,0.55)']}
                  style={styles.resultOverlay}
                >
                  <View style={styles.resultInfo}>
                    {selectedItems.slice(0, 3).map((item) => (
                      <View key={item.id} style={styles.resultItemBadge}>
                        <Image source={{ uri: item.imageUrl }} style={styles.resultItemImg} contentFit="cover" />
                      </View>
                    ))}
                    <Text style={styles.resultItemNames} numberOfLines={1}>
                      {selectedItems.map(i => i.name).join(' + ')}
                    </Text>
                  </View>
                </LinearGradient>
              </View>
            )}

            <View style={styles.resultActions}>
              <Pressable
                onPress={() => { void handleTryOn(); }}
                accessibilityRole="button"
                accessibilityLabel="Regenerate try-on result"
                accessibilityHint="Creates a new result using your selected photo and garments."
                style={({ pressed }) => [styles.actionButton, { transform: [{ scale: pressed ? interaction.compactPressScale : 1 }] }]}
              >
                <LinearGradient
                  colors={['#EC4899', '#F472B6']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                  style={styles.actionButtonGradient}
                >
                  <Ionicons name="refresh" size={18} color="#FFF" />
                  <Text style={styles.actionButtonText}>Regenerate</Text>
                </LinearGradient>
              </Pressable>
              <Pressable
                onPress={reset}
                accessibilityRole="button"
                accessibilityLabel="Start a new virtual try-on"
                style={({ pressed }) => [
                  styles.actionButtonSecondary,
                  { backgroundColor: colors.surfaceSecondary, transform: [{ scale: pressed ? interaction.compactPressScale : 1 }] },
                ]}
              >
                <Ionicons name="close" size={18} color={colors.text} />
                <Text style={[styles.actionButtonSecondaryText, { color: colors.text }]}>Start Over</Text>
              </Pressable>
            </View>

            <View
              style={[styles.consumerDecisionBar, { backgroundColor: colors.surface, borderColor: colors.border }]}
              accessible
              accessibilityRole="summary"
              accessibilityLabel="Next decision. Plan this look from your own wardrobe, or review a bounded retail gap. These actions do not claim fit, stock, price, or purchase certainty."
            >
              <View style={styles.consumerDecisionHeader}>
                <Ionicons name="compass-outline" size={16} color={colors.tint} />
                <Text style={[styles.consumerDecisionTitle, { color: colors.text }]}>What would you like to decide next?</Text>
              </View>
              <Text style={[styles.consumerDecisionCopy, { color: colors.textSecondary }]}>Turn the visualization into a practical next step. ClosetAI keeps the decision yours and does not claim fit, stock, price, or purchase certainty.</Text>
              <View style={styles.consumerDecisionActions}>
                <Pressable
                  onPress={() => router.replace('/outfits')}
                  accessibilityRole="button"
                  accessibilityLabel="Plan this look from your wardrobe"
                  accessibilityHint="Opens outfit planning using your existing wardrobe context."
                  style={({ pressed }) => [styles.consumerDecisionButton, { backgroundColor: colors.text, opacity: pressed ? 0.82 : 1 }]}
                >
                  <Ionicons name="calendar-outline" size={14} color={colors.background} />
                  <Text style={[styles.consumerDecisionButtonText, { color: colors.background }]}>Plan this look</Text>
                </Pressable>
                <Pressable
                  onPress={() => router.replace({ pathname: '/outfits', params: { intent: 'retail-gap' } } as any)}
                  accessibilityRole="button"
                  accessibilityLabel="Review a bounded retail gap"
                  accessibilityHint="Opens outfit context where you can explore a category gap without fabricated products or purchase claims."
                  style={({ pressed }) => [styles.consumerDecisionButton, { borderColor: colors.border, borderWidth: 1, opacity: pressed ? 0.76 : 1 }]}
                >
                  <Ionicons name="search-outline" size={14} color={colors.tint} />
                  <Text style={[styles.consumerDecisionButtonText, { color: colors.text }]}>Review a gap</Text>
                </Pressable>
              </View>
            </View>
          </Animated.View>
        ) : (
          <>
            <Animated.View entering={FadeInUp.delay(100).duration(400)}>
              <View style={styles.stepRow}>
                <View style={[styles.stepNumber, { backgroundColor: selfieUri ? '#27AE60' : '#EC4899' }]}>
                  {selfieUri ? (
                    <Ionicons name="checkmark" size={14} color="#FFF" />
                  ) : (
                    <Text style={styles.stepNumberText}>1</Text>
                  )}
                </View>
                <Text style={[styles.stepLabel, { color: colors.textSecondary }]}>Your Photo</Text>
              </View>
              <Pressable
                onPress={pickSelfie}
                disabled={isInteractionLocked}
                style={({ pressed }) => [
                  styles.selfieBox,
                  {
                    backgroundColor: colors.surface,
                    borderColor: selfieUri ? '#EC4899' : colors.border,
                    opacity: isInteractionLocked ? 0.55 : 1,
                    transform: [{ scale: pressed && !isInteractionLocked ? interaction.cardPressScale : 1 }],
                  },
                  shadows.soft,
                ]}
                accessibilityRole="button"
                accessibilityState={{ disabled: isInteractionLocked, busy: isPickingSelfie }}
                accessibilityLabel={isPickingSelfie ? 'Opening photo library for your try-on photo' : selfieUri ? 'Change your try-on photo' : 'Select your try-on photo'}
                accessibilityHint={isInteractionLocked ? 'Wait until the current photo or try-on action finishes.' : "Uses only the photo you select. ClosetAI never substitutes a stock model."}
              >
                {selfieUri ? (
                  <View>
                    <Image source={{ uri: selfieUri }} style={styles.selfieImage} contentFit="cover" />
                    <View style={[styles.changeBadge, { backgroundColor: colors.surface }, shadows.soft]}>
                      <Ionicons name="camera-outline" size={14} color="#EC4899" />
                      <Text style={[styles.changeBadgeText, { color: '#EC4899' }]}>Change</Text>
                    </View>
                  </View>
                ) : (
                  <View style={styles.selfieEmpty}>
                    <LinearGradient
                      colors={['#EC489920', '#EC489908']}
                      style={styles.selfieIconWrap}
                    >
                      <Ionicons name="camera-outline" size={32} color="#EC4899" />
                    </LinearGradient>
                    <Text style={[styles.selfieEmptyTitle, { color: colors.text }]}>Add your photo</Text>
                    <Text style={[styles.selfieEmptyText, { color: colors.textSecondary }]}>
                      Tap to select from your gallery
                    </Text>
                  </View>
                )}
              </Pressable>
              {selfieUri && <MediaStatusCard kind="user-photo" title="Your try-on photo is selected" detail="ClosetAI uses only this selected photo for the preview and never substitutes a stock model." tint="#EC4899" surface={colors.surfaceSecondary} border={colors.border} />}
            </Animated.View>

            <Animated.View entering={FadeInUp.delay(200).duration(400)}>
              <View style={styles.stepRow}>
                <View style={[styles.stepNumber, { backgroundColor: selectedGarments.length > 0 ? '#27AE60' : '#EC4899' }]}>
                  {selectedGarments.length > 0 ? (
                    <Ionicons name="checkmark" size={14} color="#FFF" />
                  ) : (
                    <Text style={styles.stepNumberText}>2</Text>
                  )}
                </View>
                <Text style={[styles.stepLabel, { color: colors.textSecondary }]}>
                  Select Garments {selectedGarments.length > 0 ? `(${selectedGarments.length})` : ''}
                </Text>
              </View>
              <Text style={[styles.categoryFilterLabel, { color: colors.textTertiary }]}>Choose one of 10 fashion categories · {selectedCategoryLabel}</Text>
              <FlatList
                data={[{ id: 'all', label: 'All', icon: 'apps-outline' as const }, ...FASHION_TRY_ON_CATEGORIES]}
                horizontal
                showsHorizontalScrollIndicator={false}
                keyExtractor={item => item.id}
                renderItem={({ item }) => {
                  const active = selectedTryOnCategory === item.id;
                  return (
                    <Pressable
                      disabled={isInteractionLocked}
                      onPress={() => {
                        if (isInteractionLocked) return;
                        Haptics.selectionAsync();
                        setSelectedTryOnCategory(item.id as typeof selectedTryOnCategory);
                        setSelectedGarments([]);
                        setResultUri(null);
                        setTryOnError(null);
                        setQueuedRetry(null);
                        void clearTryOnRetryQueue();
                      }}
                      accessibilityRole="radio"
                      accessibilityState={{ checked: active, disabled: isInteractionLocked }}
                      accessibilityLabel={`${item.label} try-on category`}
                      accessibilityHint={isInteractionLocked ? "Category selection is unavailable while ClosetAI processes your current try-on." : "Filters your wardrobe items for try-on selection."}
                      style={({ pressed }) => [styles.categoryChip, { backgroundColor: active ? '#EC489915' : colors.surfaceSecondary, borderColor: active ? '#EC4899' : colors.border, opacity: isInteractionLocked ? 0.55 : 1, transform: [{ scale: pressed && !isInteractionLocked ? interaction.compactPressScale : 1 }] }]}
                    >
                      <Ionicons name={item.icon as any} size={13} color={active ? '#EC4899' : colors.textSecondary} />
                      <Text style={[styles.categoryChipText, { color: active ? '#EC4899' : colors.textSecondary }]}>{item.label}</Text>
                    </Pressable>
                  );
                }}
                contentContainerStyle={styles.categoryFilterContent}
              />
              <FlatList
                data={filteredWardrobeItems}
                horizontal
                showsHorizontalScrollIndicator={false}
                keyExtractor={item => item.id}
                scrollEnabled={wardrobeItems.length > 0}
                renderItem={({ item }) => {
                  const selected = selectedGarments.includes(item.id);
                  return (
                    <Pressable
                      onPress={() => toggleGarment(item.id)}
                      disabled={isInteractionLocked}
                      accessibilityRole="checkbox"
                      accessibilityState={{ checked: selected, disabled: isInteractionLocked }}
                      accessibilityLabel={`Select ${item.name} for try-on`}
                      accessibilityHint={isInteractionLocked ? "Garment selection is unavailable while ClosetAI processes your current try-on." : "Adds or removes this item from the selected try-on look."}
                      style={({ pressed }) => [
                        styles.garmentCard,
                        {
                          borderColor: selected ? '#EC4899' : colors.border,
                          backgroundColor: colors.surface,
                          opacity: isInteractionLocked ? 0.55 : 1,
                          transform: [{ scale: pressed && !isInteractionLocked ? interaction.compactPressScale : 1 }],
                        },
                        shadows.soft,
                      ]}
                    >
                      <Image source={{ uri: item.imageUrl }} style={styles.garmentImage} contentFit="cover" accessibilityLabel={`${item.name} wardrobe photo`} />
                      {selected && (
                        <LinearGradient
                          colors={['#EC4899', '#F472B6']}
                          style={styles.garmentCheck}
                        >
                          <Ionicons name="checkmark" size={14} color="#FFF" />
                        </LinearGradient>
                      )}
                      <Text style={[styles.garmentName, { color: colors.text }]} numberOfLines={1}>
                        {item.name}
                      </Text>
                      <Text style={[styles.garmentCategory, { color: colors.textSecondary }]} numberOfLines={1}>
                        {item.category}
                      </Text>
                    </Pressable>
                  );
                }}
                contentContainerStyle={{ gap: 10, paddingRight: 20 }}
                ListEmptyComponent={
                  <View style={styles.emptyGarments}>
                    <Ionicons name={wardrobeItems.length === 0 ? "shirt-outline" : "funnel-outline"} size={24} color={colors.tabIconDefault} />
                    <Text style={[styles.emptyGarmentsText, { color: colors.textSecondary }]}>
                      {wardrobeItems.length === 0 ? 'Add a wardrobe item to select it for try-on.' : `No ${selectedCategoryLabel.toLowerCase()} items are available in this category yet.`}
                    </Text>
                    <Pressable
                      onPress={() => wardrobeItems.length === 0 ? router.push('/add-item') : setSelectedTryOnCategory('all')}
                      accessibilityRole="button"
                      accessibilityLabel={wardrobeItems.length === 0 ? 'Add a wardrobe item for try-on' : 'Show all wardrobe categories'}
                      style={({ pressed }) => [styles.emptyGarmentAction, { backgroundColor: colors.surfaceSecondary, borderColor: colors.border, opacity: pressed ? 0.72 : 1 }]}
                    >
                      <Ionicons name={wardrobeItems.length === 0 ? "add-circle-outline" : "grid-outline"} size={14} color={colors.tint} />
                      <Text style={[styles.emptyGarmentActionText, { color: colors.text }]}>{wardrobeItems.length === 0 ? 'Add an item' : 'Show all items'}</Text>
                    </Pressable>
                  </View>
                }
              />
              {selectedGarments.length > 0 && <MediaStatusCard kind="local-only" title={`${selectedGarments.length} wardrobe item${selectedGarments.length === 1 ? "" : "s"} selected`} detail="Your chosen wardrobe photos are used as the garment context for this preview." tint="#EC4899" surface={colors.surfaceSecondary} border={colors.border} />}
            </Animated.View>

            <Animated.View entering={FadeInUp.delay(300).duration(400)} style={{ marginTop: 24 }}>
              <Pressable
                onPress={() => { void handleTryOn(); }}
                disabled={!selfieUri || selectedGarments.length === 0 || isInteractionLocked}
                accessibilityRole="button"
                accessibilityState={{ disabled: !selfieUri || selectedGarments.length === 0 || isInteractionLocked, busy: isProcessing }}
                accessibilityLabel={isProcessing ? 'Creating your virtual try-on result' : fashionReadiness.mode === 'live-ready' ? 'Try on selected garments with YouCam' : 'Preview selected look'}
                accessibilityHint={isInteractionLocked ? 'Wait until the current photo or try-on action finishes.' : !selfieUri ? 'Add your photo first.' : selectedGarments.length === 0 ? 'Select at least one wardrobe garment first.' : 'Creates a result using your selected photo only.'}
                style={({ pressed }) => [
                  styles.tryOnButton,
                  {
                    opacity: (!selfieUri || selectedGarments.length === 0 || isInteractionLocked) ? 0.4 : 1,
                    transform: [{ scale: pressed && !isInteractionLocked ? 0.97 : 1 }],
                  },
                ]}
              >
                <LinearGradient
                  colors={['#EC4899', '#F472B6']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                  style={styles.tryOnButtonGradient}
                >
                  <Ionicons name="sparkles" size={20} color="#FFF" />
                  <Text style={styles.tryOnButtonText}>{fashionReadiness.mode === 'live-ready' ? 'Try On with YouCam' : fashionReadiness.mode === 'assisted-edit' ? 'Try On with Photo-safe Assist' : fashionReadiness.mode === 'provider-unavailable' ? 'Preview Selected Look' : 'Try On Selected Item'}</Text>
                </LinearGradient>
              </Pressable>
              <Text style={[styles.creditNote, { color: colors.textTertiary }]}>
                Live try-on uses 10 credits when connected. Demo mode preserves your selected photo.
              </Text>
            </Animated.View>
          </>
        )}

        {!!queuedRetry && !isProcessing && (
          <View style={[styles.retryQueueCard, { backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]} accessibilityLiveRegion="polite" accessibilityLabel="Live try-on retry saved locally. YouCam or the network did not complete the request. Your selected photo and garments remain available. No stock model or fabricated result was added.">
            <Ionicons name="cloud-offline-outline" size={18} color={colors.warning} />
            <View style={styles.errorContent}>
              <Text style={[styles.retryQueueTitle, { color: colors.text }]}>Live try-on retry saved locally</Text>
              <Text style={[styles.errorText, { color: colors.textSecondary }]}>YouCam or the network did not complete this request. Your selected photo and garments remain available; no stock model or fabricated result was added.</Text>
              <View style={styles.retryQueueActions}>
                <Pressable onPress={retryQueuedTryOn} accessibilityRole="button" accessibilityLabel="Retry saved fashion try-on" accessibilityHint="Retries the same selected-photo request when the live service is ready." style={({ pressed }) => [styles.retryErrorButton, { borderColor: colors.border, backgroundColor: colors.surface, opacity: pressed ? 0.72 : 1 }]}>
                  <Ionicons name="refresh-outline" size={15} color={colors.tint} />
                  <Text style={[styles.retryErrorButtonText, { color: colors.tint }]}>Retry now</Text>
                </Pressable>
                <Pressable onPress={dismissQueuedTryOn} accessibilityRole="button" accessibilityLabel="Dismiss saved fashion try-on retry" style={({ pressed }) => [styles.dismissRetryButton, { opacity: pressed ? 0.72 : 1 }]}>
                  <Text style={[styles.dismissRetryText, { color: colors.textSecondary }]}>Dismiss</Text>
                </Pressable>
              </View>
            </View>
          </View>
        )}
        {!!tryOnStatus && <View style={[styles.errorBanner, { backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]} accessibilityLiveRegion="polite"><Ionicons name="checkmark-circle-outline" size={17} color={colors.success} /><Text style={[styles.errorText, { color: colors.textSecondary }]}>{tryOnStatus}</Text></View>}
        {!!tryOnError && (
          <View style={[styles.errorBanner, { backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]} accessibilityLiveRegion="assertive" accessibilityRole="alert">
            <Ionicons name="information-circle-outline" size={17} color={colors.tint} />
            <View style={styles.errorContent}>
              <Text style={[styles.errorText, { color: colors.textSecondary }]}>{tryOnError}</Text>
              {!!selfieUri && selectedGarments.length > 0 && !isProcessing && (
                <Pressable
                  onPress={retryTryOnAfterError}
                  accessibilityRole="button"
                  accessibilityLabel="Retry fashion try-on"
                  accessibilityHint="Retries the selected-photo try-on without changing your photo or garments."
                  style={({ pressed }) => [styles.retryErrorButton, { borderColor: colors.border, backgroundColor: colors.surface, opacity: pressed ? 0.72 : 1 }]}
                >
                  <Ionicons name="refresh-outline" size={15} color={colors.tint} />
                  <Text style={[styles.retryErrorButtonText, { color: colors.tint }]}>Retry</Text>
                </Pressable>
              )}
            </View>
          </View>
        )}
        {demoMode && !resultUri && <Text style={[styles.demoDisclosure, { color: colors.textTertiary }]}>Demo mode keeps your uploaded photo on device and will never substitute a stock model image.</Text>}
        <View style={{ height: 120 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollContent: { paddingHorizontal: 20 },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 24,
  },
  title: { fontFamily: 'Outfit_700Bold', fontSize: 26 },
  subtitle: { fontFamily: 'Outfit_400Regular', fontSize: 13, marginTop: 2 },
  aiBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 12,
  },
  aiBadgeText: { fontFamily: 'Outfit_500Medium', fontSize: 11, color: '#FFF' },
  stepRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 10,
  },
  stepNumber: {
    width: 24,
    height: 24,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepNumberText: { fontFamily: 'Outfit_600SemiBold', fontSize: 12, color: '#FFF' },
  stepLabel: { fontFamily: 'Outfit_600SemiBold', fontSize: 14, textTransform: 'uppercase', letterSpacing: 0.5 },
  selfieBox: {
    height: 220,
    borderRadius: 18,
    borderWidth: 2,
    borderStyle: 'dashed',
    overflow: 'hidden',
    marginBottom: 24,
  },
  selfieImage: { width: '100%', height: '100%' },
  selfieEmpty: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 8 },
  selfieIconWrap: {
    width: 68,
    height: 68,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 4,
  },
  selfieEmptyTitle: { fontFamily: 'Outfit_600SemiBold', fontSize: 16 },
  selfieEmptyText: { fontFamily: 'Outfit_400Regular', fontSize: 13 },
  changeBadge: {
    position: 'absolute',
    bottom: 10,
    right: 10,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 14,
  },
  changeBadgeText: { fontFamily: 'Outfit_500Medium', fontSize: 12 },
  categoryFilterLabel: { fontFamily: 'Outfit_400Regular', fontSize: 11, marginBottom: 8 },
  categoryFilterContent: { gap: 8, paddingBottom: 12, paddingRight: 20 },
  categoryChip: { flexDirection: 'row', alignItems: 'center', gap: 5, borderWidth: 1, borderRadius: 14, paddingHorizontal: 10, paddingVertical: 7 },
  categoryChipText: { fontFamily: 'Outfit_500Medium', fontSize: 11 },
  garmentCard: {
    width: 100,
    borderRadius: 14,
    borderWidth: 1.5,
    overflow: 'hidden',
  },
  garmentImage: { width: '100%', height: 90 },
  garmentCheck: {
    position: 'absolute',
    top: 6,
    right: 6,
    width: 22,
    height: 22,
    borderRadius: 11,
    justifyContent: 'center',
    alignItems: 'center',
  },
  garmentName: { fontFamily: 'Outfit_500Medium', fontSize: 11, paddingHorizontal: 6, paddingTop: 5 },
  garmentCategory: { fontFamily: 'Outfit_400Regular', fontSize: 10, paddingHorizontal: 6, paddingBottom: 6 },
  emptyGarments: { paddingVertical: 20, alignItems: 'center', gap: 8, paddingHorizontal: 20 },
  emptyGarmentsText: { fontFamily: 'Outfit_400Regular', fontSize: 13, textAlign: 'center' },
  emptyGarmentAction: { minHeight: 34, borderWidth: 1, borderRadius: 11, paddingHorizontal: 11, flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 2 },
  emptyGarmentActionText: { fontFamily: 'Outfit_600SemiBold', fontSize: 11 },
  tryOnButton: {
    borderRadius: 28,
    overflow: 'hidden',
    shadowColor: '#EC4899',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 6,
  },
  tryOnButtonGradient: {
    height: 56,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
  },
  tryOnButtonText: { fontFamily: 'Outfit_600SemiBold', fontSize: 17, color: '#FFF' },
  creditNote: { fontFamily: 'Outfit_400Regular', fontSize: 11, textAlign: 'center', marginTop: 8 },
  processingCard: {
    borderRadius: 22,
    padding: 32,
    alignItems: 'center',
    gap: 16,
    marginBottom: 20,
  },
  processingIconWrap: {
    marginBottom: 4,
  },
  processingIconGradient: {
    width: 80,
    height: 80,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  processingTitle: { fontFamily: 'Outfit_600SemiBold', fontSize: 20 },
  processingStep: { fontFamily: 'Outfit_400Regular', fontSize: 14, textAlign: 'center' },
  stepsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 4,
  },
  stepDot: {
    height: 6,
    borderRadius: 3,
  },
  processingItems: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 8,
  },
  processingItemImg: {
    width: 32,
    height: 32,
    borderRadius: 8,
    borderWidth: 2,
    borderColor: '#FFF',
  },
  processingItemCount: { fontFamily: 'Outfit_400Regular', fontSize: 12 },
  cancelProcessingButton: { alignSelf: 'center', marginTop: 18, borderWidth: 1, borderRadius: 14, paddingHorizontal: 16, paddingVertical: 10, flexDirection: 'row', alignItems: 'center', gap: 8 },
  resultLineageCard: { borderWidth: 1, borderRadius: 16, padding: 12, marginTop: 12, marginBottom: 14 },
  resultLineageHeader: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  resultLineageTitle: { flex: 1, fontFamily: 'Outfit_700Bold', fontSize: 12 },
  resultLineageBadge: { fontFamily: 'Outfit_700Bold', fontSize: 8, letterSpacing: 1 },
  resultLineageRows: { gap: 7, marginTop: 10 },
  resultLineageRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 10 },
  resultLineageLabel: { width: 52, fontFamily: 'Outfit_600SemiBold', fontSize: 9, textTransform: 'uppercase', letterSpacing: 0.4 },
  resultLineageValue: { flex: 1, fontFamily: 'Outfit_500Medium', fontSize: 10, lineHeight: 14 },
  resultHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  compareToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 12,
  },
  compareText: { fontFamily: 'Outfit_500Medium', fontSize: 12 },
  previewDisclosure: { fontFamily: 'Outfit_400Regular', fontSize: 10, marginTop: 2 },
  fashionHint: { flexDirection: 'row', alignItems: 'flex-start', gap: 8, borderWidth: 1, borderRadius: 14, padding: 12, marginBottom: 14 },
  fashionHintText: { flex: 1, fontFamily: 'Outfit_400Regular', fontSize: 11, lineHeight: 16 },
  providerEvidenceCard: { borderWidth: 1, borderRadius: 16, padding: 13, marginTop: 14, marginBottom: 14 },
  providerEvidenceHeader: { flexDirection: 'row', alignItems: 'center', gap: 9 },
  providerEvidenceIcon: { width: 30, height: 30, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  providerEvidenceTitleWrap: { flex: 1 },
  providerEvidenceEyebrow: { fontFamily: 'Outfit_700Bold', fontSize: 8, letterSpacing: 1.05 },
  providerEvidenceTitle: { fontFamily: 'Outfit_700Bold', fontSize: 13, lineHeight: 17, marginTop: 2 },
  providerEvidenceCopy: { fontFamily: 'Outfit_400Regular', fontSize: 10, lineHeight: 15, marginTop: 9 },
  providerEvidenceRows: { gap: 7, marginTop: 12 },
  providerEvidenceRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 10 },
  providerEvidenceLabel: { width: 46, fontFamily: 'Outfit_600SemiBold', fontSize: 9, textTransform: 'uppercase', letterSpacing: 0.45 },
  providerEvidenceValue: { flex: 1, fontFamily: 'Outfit_500Medium', fontSize: 10, lineHeight: 14 },
  providerEvidenceImpact: { flexDirection: 'row', alignItems: 'flex-start', gap: 7, borderRadius: 10, paddingHorizontal: 9, paddingVertical: 8, marginTop: 12 },
  providerEvidenceImpactText: { flex: 1, fontFamily: 'Outfit_400Regular', fontSize: 10, lineHeight: 14 },
  readinessCard: { borderWidth: 1, borderRadius: 15, padding: 12, marginBottom: 14 },
  readinessHeader: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  readinessTitle: { fontFamily: 'Outfit_700Bold', fontSize: 12 },
  readinessText: { fontFamily: 'Outfit_400Regular', fontSize: 10, lineHeight: 15, marginTop: 5 },
  readinessChecklist: { gap: 4, marginTop: 9 },
  readinessCheck: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  readinessCheckText: { fontFamily: 'Outfit_500Medium', fontSize: 9 },
  userPhotoGuarantee: { fontFamily: 'Outfit_500Medium', fontSize: 9, marginTop: 9 },
  settingsButton: { borderWidth: 1, borderRadius: 10, paddingHorizontal: 9, paddingVertical: 7 }, settingsButtonText: { fontFamily: 'Outfit_600SemiBold', fontSize: 10 },
  errorBanner: { flexDirection: 'row', alignItems: 'flex-start', gap: 8, borderWidth: 1, borderRadius: 14, padding: 12, marginTop: 14 },
  errorContent: { flex: 1, gap: 9 },
  errorText: { fontFamily: 'Outfit_400Regular', fontSize: 11, lineHeight: 16 },
  errorBoundaryText: { fontFamily: 'Outfit_400Regular', fontSize: 9, lineHeight: 13 },
  retryErrorButton: { alignSelf: 'flex-start', flexDirection: 'row', alignItems: 'center', gap: 6, borderWidth: 1, borderRadius: 10, paddingHorizontal: 10, paddingVertical: 7 },
  retryErrorButtonText: { fontFamily: 'Outfit_600SemiBold', fontSize: 11 },
  retryQueueCard: { flexDirection: 'row', alignItems: 'flex-start', gap: 8, borderWidth: 1, borderRadius: 14, padding: 12, marginTop: 14 },
  retryQueueTitle: { fontFamily: 'Outfit_700Bold', fontSize: 11 },
  retryQueueActions: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  dismissRetryButton: { paddingVertical: 7, paddingHorizontal: 2 },
  dismissRetryText: { fontFamily: 'Outfit_500Medium', fontSize: 11 },
  demoDisclosure: { fontFamily: 'Outfit_400Regular', fontSize: 10, lineHeight: 15, textAlign: 'center', marginTop: 14 },
  comparisonRow: {
    flexDirection: 'row',
    gap: 10,
  },
  comparisonCol: {
    flex: 1,
  },
  comparisonLabel: {
    alignSelf: 'center',
    paddingHorizontal: 10,
    paddingVertical: 3,
    borderRadius: 8,
    marginBottom: 6,
  },
  comparisonLabelText: { fontFamily: 'Outfit_500Medium', fontSize: 11 },
  comparisonBox: {
    borderRadius: 16,
    borderWidth: 1.5,
    overflow: 'hidden',
  },
  comparisonImage: { width: '100%', height: 280 },
  resultBox: {
    borderRadius: 18,
    borderWidth: 2,
    overflow: 'hidden',
    marginBottom: 16,
  },
  resultImage: { width: '100%', height: 380 },
  resultOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: 16,
    paddingTop: 40,
  },
  resultInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  resultItemBadge: {
    width: 28,
    height: 28,
    borderRadius: 8,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: '#FFF',
  },
  resultItemImg: { width: '100%', height: '100%' },
  resultItemNames: { fontFamily: 'Outfit_500Medium', fontSize: 13, color: '#FFF', flex: 1 },
  consumerDecisionBar: { borderWidth: 1, borderRadius: 16, padding: 12, marginTop: 14, marginBottom: 10 },
  consumerDecisionHeader: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  consumerDecisionTitle: { flex: 1, fontFamily: 'Outfit_700Bold', fontSize: 12 },
  consumerDecisionCopy: { fontFamily: 'Outfit_400Regular', fontSize: 10, lineHeight: 14, marginTop: 7 },
  consumerDecisionActions: { flexDirection: 'row', gap: 8, marginTop: 10 },
  consumerDecisionButton: { flex: 1, minHeight: 38, borderRadius: 11, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5, paddingHorizontal: 8 },
  consumerDecisionButtonText: { fontFamily: 'Outfit_700Bold', fontSize: 10 },
  resultActions: {
    flexDirection: 'row',
    gap: 10,
  },
  actionButton: {
    flex: 1,
    borderRadius: 24,
    overflow: 'hidden',
  },
  actionButtonGradient: {
    height: 48,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 6,
  },
  actionButtonText: { fontFamily: 'Outfit_600SemiBold', fontSize: 15, color: '#FFF' },
  actionButtonSecondary: {
    flex: 1,
    height: 48,
    borderRadius: 24,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 6,
  },
  actionButtonSecondaryText: { fontFamily: 'Outfit_600SemiBold', fontSize: 15 },
  standaloneButton: { minHeight: 46, borderRadius: 14, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 7, marginBottom: 10 },
  standaloneButtonText: { fontFamily: 'Outfit_600SemiBold', fontSize: 12 },
});
