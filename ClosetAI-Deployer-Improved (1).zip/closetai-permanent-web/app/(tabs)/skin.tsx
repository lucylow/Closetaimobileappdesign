import { SkinCareHub } from "@/components/skin/SkinCareHub";

export default function SkinTabRoute() {
  return <SkinCareHub />;
}
