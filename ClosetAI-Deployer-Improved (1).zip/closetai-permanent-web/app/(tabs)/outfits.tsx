import React, { useState, useCallback, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  FlatList,
  Platform,
  ActivityIndicator,
  ScrollView,
  TextInput,
  Linking,
  Dimensions,
} from 'react-native';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import * as Haptics from 'expo-haptics';
import Animated, { FadeInUp, FadeIn, FadeInDown } from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import * as Location from 'expo-location';
import { useApp } from '@/contexts/AppContext';
import { useTheme } from '@/lib/useTheme';
import { Outfit, COLORS } from '@/lib/demo-data';
import { interaction, shadows } from '@/constants/colors';
import { apiRequest } from '@/lib/query-client';

type RetailRecommendation = {
  id: string;
  title: string;
  reason: string;
  searchQuery: string;
  searchUrl: string;
  category: string;
  source: 'retailer-search';
};

const SCREEN_WIDTH = Dimensions.get('window').width;

const OCCASIONS = [
  { key: 'all', label: 'All', icon: 'grid-outline' as const },
  { key: 'casual', label: 'Casual', icon: 'cafe-outline' as const },
  { key: 'office', label: 'Office', icon: 'briefcase-outline' as const },
  { key: 'date', label: 'Date Night', icon: 'heart-outline' as const },
  { key: 'party', label: 'Party', icon: 'musical-notes-outline' as const },
  { key: 'business', label: 'Business', icon: 'business-outline' as const },
];

function getScoreColor(score: number) {
  if (score >= 0.9) return '#27AE60';
  if (score >= 0.75) return '#8BC34A';
  if (score >= 0.6) return '#F39C12';
  return '#E74C3C';
}

function getScoreLabel(score: number) {
  if (score >= 0.9) return 'Perfect';
  if (score >= 0.75) return 'Great';
  if (score >= 0.6) return 'Good';
  return 'Try';
}

function ScoreBadge({ score }: { score: number }) {
  const color = getScoreColor(score);
  const label = getScoreLabel(score);
  const pct = Math.round(score * 100);

  return (
    <View style={[scoreBadgeStyles.container, { backgroundColor: color + '15', borderColor: color + '25' }]}>
      <View style={[scoreBadgeStyles.dot, { backgroundColor: color }]} />
      <Text style={[scoreBadgeStyles.text, { color }]}>{pct}%</Text>
      <Text style={[scoreBadgeStyles.label, { color: color + 'CC' }]}>{label}</Text>
    </View>
  );
}

const scoreBadgeStyles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 12,
    gap: 4,
    borderWidth: 1,
  },
  dot: { width: 6, height: 6, borderRadius: 3 },
  text: { fontFamily: 'Outfit_700Bold', fontSize: 12 },
  label: { fontFamily: 'Outfit_400Regular', fontSize: 10 },
});

function OutfitCard({ outfit, colors, isDark, onRate, onSave, onPress, index, source }: {
  outfit: Outfit;
  colors: any;
  isDark: boolean;
  onRate: (id: string, r: 'like' | 'dislike') => void;
  onSave: (id: string) => void;
  onPress: (id: string) => void;
  index: number;
  source: 'live-ai' | 'hybrid' | 'youcam-live-ai' | 'youcam-wardrobe' | 'wardrobe-fallback' | 'saved' | 'idle' | 'unavailable';
}) {
  const sourceLabel = source === 'youcam-live-ai' ? 'YouCam + AI' : source === 'youcam-wardrobe' ? 'YouCam + Wardrobe' : source === 'live-ai' ? 'Live AI' : source === 'hybrid' ? 'AI + Wardrobe' : source === 'wardrobe-fallback' ? 'Wardrobe' : source === 'saved' ? 'Saved' : 'Outfit';
  return (
    <Animated.View entering={FadeInUp.delay(index * 60).duration(400)}>
      <Pressable
        onPress={() => {
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
          onPress(outfit.id);
        }}
        style={({ pressed }) => [
          styles.outfitCard,
          { backgroundColor: colors.surface, transform: [{ scale: pressed ? interaction.cardPressScale : 1 }] },
          shadows.medium,
        ]}
        accessibilityRole="button"
        accessibilityLabel={`Open outfit: ${outfit.name}`}
        accessibilityHint={outfit.reason}
      >
        <View style={styles.cardHeader}>
          <View style={styles.cardImages}>
            {outfit.items.slice(0, 4).map((item, idx) => (
              <View key={item.id + idx} style={[styles.cardImageWrap, idx > 0 && { marginLeft: -14 }, { zIndex: 4 - idx, borderColor: colors.surface }]}>
                <Image
                  source={{ uri: item.imageUrl }}
                  style={styles.cardImage}
                  contentFit="cover"
                  transition={300}
                />
              </View>
            ))}
            {outfit.items.length > 4 && (
              <View style={[styles.cardImageWrap, { marginLeft: -14, backgroundColor: colors.surfaceSecondary, borderColor: colors.surface }]}>
                <Text style={[styles.moreItemsText, { color: colors.textSecondary }]}>+{outfit.items.length - 4}</Text>
              </View>
            )}
          </View>
          {outfit.score > 0 && <ScoreBadge score={outfit.score} />}
        </View>

        <View style={styles.cardBody}>
          <Text style={[styles.cardTitle, { color: colors.text }]}>{outfit.name}</Text>
          <Text style={[styles.cardReason, { color: colors.textSecondary }]} numberOfLines={2}>
            {outfit.reason}
          </Text>

          <View style={styles.cardMeta}>
            {outfit.occasion ? (
              <LinearGradient
                colors={[colors.tint + '18', colors.tint + '08']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={styles.occasionBadge}
              >
                <Ionicons name="flag-outline" size={11} color={colors.tint} />
                <Text style={[styles.occasionText, { color: colors.tint }]}>{outfit.occasion}</Text>
              </LinearGradient>
            ) : null}
            {outfit.tags.slice(0, 2).map(tag => (
              <View key={tag} style={[styles.tag, { backgroundColor: isDark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.04)' }]}>
                <Text style={[styles.tagText, { color: colors.textSecondary }]}>{tag}</Text>
              </View>
            ))}
          </View>
        </View>

        <View style={[styles.cardActions, { borderTopColor: isDark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.05)' }]}>
          <Pressable
            onPress={() => {
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
              onRate(outfit.id, 'like');
            }}
            hitSlop={8}
            accessibilityRole="button"
            accessibilityLabel={outfit.rating === 'like' ? `Remove like from ${outfit.name}` : `Like ${outfit.name}`}
            accessibilityState={{ selected: outfit.rating === 'like' }}
            style={({ pressed }) => [styles.actionBtn, { backgroundColor: outfit.rating === 'like' ? '#E74C3C12' : 'transparent', borderRadius: 12, paddingHorizontal: 10, paddingVertical: 6, transform: [{ scale: pressed ? interaction.compactPressScale : 1 }] }]}
          >
            <Ionicons
              name={outfit.rating === 'like' ? 'heart' : 'heart-outline'}
              size={18}
              color={outfit.rating === 'like' ? '#E74C3C' : colors.textSecondary}
            />
          </Pressable>
          <Pressable
            onPress={() => {
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
              onSave(outfit.id);
            }}
            hitSlop={8}
            accessibilityRole="button"
            accessibilityLabel={outfit.saved ? `Remove ${outfit.name} from saved outfits` : `Save ${outfit.name}`}
            accessibilityState={{ selected: outfit.saved }}
            style={({ pressed }) => [styles.actionBtn, { backgroundColor: outfit.saved ? colors.tint + '12' : 'transparent', borderRadius: 12, paddingHorizontal: 10, paddingVertical: 6, transform: [{ scale: pressed ? interaction.compactPressScale : 1 }] }]}
          >
            <Ionicons
              name={outfit.saved ? 'bookmark' : 'bookmark-outline'}
              size={18}
              color={outfit.saved ? colors.tint : colors.textSecondary}
            />
          </Pressable>
          <Pressable
            onPress={() => {
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
              onPress(outfit.id);
            }}
            hitSlop={8}
            accessibilityRole="button"
            accessibilityLabel={`Why ${outfit.name} was suggested`}
            style={({ pressed }) => [styles.actionBtn, { borderRadius: 12, paddingHorizontal: 10, paddingVertical: 6, transform: [{ scale: pressed ? interaction.compactPressScale : 1 }] }]}
          >
            <Ionicons name="chatbubble-ellipses-outline" size={16} color={colors.textSecondary} />
            <Text style={[styles.actionBtnLabel, { color: colors.textSecondary }]}>Why?</Text>
          </Pressable>
          <View style={{ flex: 1 }} />
          <View style={[styles.aiLabel, { backgroundColor: isDark ? 'rgba(110,74,224,0.12)' : 'rgba(110,74,224,0.06)' }]}>
            <MaterialCommunityIcons name={source === 'youcam-live-ai' || source === 'youcam-wardrobe' ? 'palette-outline' : source === 'wardrobe-fallback' ? 'hanger' : 'auto-fix'} size={11} color="#6E4AE0" />
            <Text style={[styles.aiLabelText, { color: '#6E4AE0' }]}>{sourceLabel}</Text>
          </View>
        </View>
      </Pressable>
    </Animated.View>
  );
}

export default function OutfitsScreen() {
  const { colors, isDark } = useTheme();
  const insets = useSafeAreaInsets();
  const { intent } = useLocalSearchParams<{ intent?: string }>();
  const isRetailGapIntent = intent === 'retail-gap';
  const { outfits, savedOutfits, rateOutfit, saveOutfit, unsaveOutfit, generateOutfits, wardrobeItems, recommendationSource, recommendationNotice } = useApp();
  const [tab, setTab] = useState<'suggested' | 'saved'>('suggested');
  const [selectedOccasion, setSelectedOccasion] = useState('all');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [weather, setWeather] = useState('');
  const [colorPalette, setColorPalette] = useState<string[]>([]);
  const [weatherStatus, setWeatherStatus] = useState<'idle' | 'loading' | 'live' | 'cached' | 'manual' | 'unavailable'>('idle');
  const [weatherMessage, setWeatherMessage] = useState<string | null>(null);
  const [retailRecommendations, setRetailRecommendations] = useState<RetailRecommendation[]>([]);
  const [retailLoading, setRetailLoading] = useState(false);
  const [retailMessage, setRetailMessage] = useState<string | null>(null);

  const webTopInset = Platform.OS === 'web' ? 67 : 0;
  const sourceOutfits = tab === 'suggested' ? outfits : savedOutfits;

  const displayOutfits = selectedOccasion === 'all'
    ? sourceOutfits
    : sourceOutfits.filter(o =>
        o.occasion?.toLowerCase().includes(selectedOccasion) ||
        o.tags.some(t => t.toLowerCase().includes(selectedOccasion))
      );

  const handleRefresh = useCallback(async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setIsRefreshing(true);
    try {
      await generateOutfits(
        selectedOccasion === 'all' ? undefined : selectedOccasion,
        weather.trim() || undefined,
        colorPalette,
      );
    } finally {
      setIsRefreshing(false);
    }
  }, [generateOutfits, selectedOccasion, weather, colorPalette]);

  const refreshLiveWeather = useCallback(async () => {
    setWeatherStatus('loading');
    setWeatherMessage(null);
    try {
      const permission = await Location.requestForegroundPermissionsAsync();
      if (permission.status !== 'granted') {
        setWeatherStatus('unavailable');
        setWeatherMessage('Location permission was not granted. You can still enter weather manually.');
        return;
      }
      const location = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const response = await apiRequest('GET', `/api/weather/current?lat=${location.coords.latitude}&lon=${location.coords.longitude}`);
      const payload = await response.json();
      if (!response.ok || typeof payload?.stylingText !== 'string') throw new Error(payload?.error || 'Live weather is unavailable.');
      setWeather(payload.stylingText);
      setWeatherStatus(payload.cached ? 'cached' : 'live');
      setWeatherMessage(payload.cached ? 'Recent live weather is being used for styling.' : 'Live local weather is ready for styling.');
    } catch (error) {
      setWeatherStatus('unavailable');
      setWeatherMessage(error instanceof Error ? error.message : 'Live weather is unavailable. Enter weather manually to continue.');
    }
  }, []);

  const loadRetailRecommendations = useCallback(async () => {
    setRetailLoading(true);
    setRetailMessage(null);
    try {
      const response = await apiRequest('POST', '/api/retail/recommendations', {
        occasion: selectedOccasion === 'all' ? undefined : selectedOccasion,
        weather: weather.trim() || undefined,
        colorPalette,
      });
      const payload = await response.json();
      if (!response.ok || !Array.isArray(payload)) throw new Error(payload?.error || 'Retail recommendations are unavailable.');
      setRetailRecommendations(payload as RetailRecommendation[]);
    } catch (error) {
      setRetailRecommendations([]);
      setRetailMessage(error instanceof Error ? error.message : 'Retail recommendations are unavailable.');
    } finally {
      setRetailLoading(false);
    }
  }, [selectedOccasion, weather, colorPalette]);

  const hasEnoughItems = wardrobeItems.length >= 2;
  const itemsNeeded = Math.max(0, 2 - wardrobeItems.length);

  useEffect(() => {
    if (!isRetailGapIntent) return;
    setTab('suggested');
    setRetailMessage('You came from a try-on result. Review bounded retailer searches based on your wardrobe context.');
  }, [isRetailGapIntent]);
  const togglePaletteColor = (color: string) => {
    Haptics.selectionAsync();
    setColorPalette(previous => previous.includes(color)
      ? previous.filter(value => value !== color)
      : [...previous, color].slice(-6));
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <LinearGradient
        colors={isDark ? ['#16141E', '#0D0D0D'] : ['#EDE6F5', '#FAF7F2']}
        style={[styles.headerGradient, { paddingTop: (insets.top || webTopInset) + 12 }]}
      >
        <Animated.View entering={FadeInUp.duration(400)} style={styles.header}>
          <View>
            <Text style={[styles.title, { color: colors.text }]}>Outfits</Text>
            <Text style={[styles.subtitle, { color: colors.textSecondary }]}>
              {outfits.length} suggestion{outfits.length !== 1 ? 's' : ''} {savedOutfits.length > 0 ? `\u00B7 ${savedOutfits.length} saved` : ''}
            </Text>
          </View>
          <Pressable
            onPress={handleRefresh}
            disabled={isRefreshing || !hasEnoughItems}
            hitSlop={12}
            accessibilityRole="button"
            accessibilityLabel="Refresh outfit suggestions"
            accessibilityState={{ disabled: isRefreshing || !hasEnoughItems, busy: isRefreshing }}
            accessibilityHint={hasEnoughItems ? 'Uses your current wardrobe and selected preferences.' : 'Add at least two wardrobe items to unlock suggestions.'}
            style={({ pressed }) => [
              { opacity: (isRefreshing || !hasEnoughItems) ? interaction.disabledOpacity : 1, transform: [{ scale: pressed ? interaction.compactPressScale : 1 }] },
            ]}
          >
            <LinearGradient
              colors={['#6E4AE0', '#9B6DFF']}
              style={styles.refreshBtnGradient}
            >
              {isRefreshing ? (
                <ActivityIndicator size="small" color="#FFF" />
              ) : (
                <Ionicons name="sparkles" size={18} color="#FFF" />
              )}
            </LinearGradient>
          </Pressable>
        </Animated.View>

        <View style={styles.tabRow}>
          {(['suggested', 'saved'] as const).map(t => {
            const active = tab === t;
            return (
              <Pressable
                key={t}
                onPress={() => {
                  Haptics.selectionAsync();
                  setTab(t);
                }}
                accessibilityRole="tab"
                accessibilityState={{ selected: active }}
                accessibilityLabel={t === 'suggested' ? 'Suggested outfits' : `Saved outfits, ${savedOutfits.length}`}
                style={({ pressed }) => [
                  styles.tabButton,
                  {
                    backgroundColor: active ? (t === 'suggested' ? '#6E4AE0' : colors.tint) : isDark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.04)',
                    transform: [{ scale: pressed ? interaction.compactPressScale : 1 }],
                  },
                ]}
              >
                <Ionicons
                  name={t === 'suggested' ? 'sparkles-outline' : 'bookmark-outline'}
                  size={14}
                  color={active ? '#FFF' : colors.textSecondary}
                />
                <Text style={[styles.tabButtonText, { color: active ? '#FFF' : colors.textSecondary }]}>
                  {t === 'suggested' ? 'Suggested' : `Saved (${savedOutfits.length})`}
                </Text>
              </Pressable>
            );
          })}
        </View>
      </LinearGradient>

        {tab === 'suggested' && recommendationNotice && (
          <View style={[styles.recommendationBanner, { backgroundColor: recommendationSource === 'unavailable' ? '#E74C3C12' : '#6E4AE012', borderColor: recommendationSource === 'unavailable' ? '#E74C3C30' : '#6E4AE030' }]}> 
            <MaterialCommunityIcons name={recommendationSource === 'youcam-live-ai' || recommendationSource === 'youcam-wardrobe' ? 'palette-outline' : recommendationSource === 'live-ai' || recommendationSource === 'hybrid' ? 'auto-fix' : 'hanger'} size={16} color={recommendationSource === 'unavailable' ? '#E74C3C' : '#6E4AE0'} />
            <Text style={[styles.recommendationBannerText, { color: colors.textSecondary }]}>{recommendationNotice}</Text>
          </View>
        )}

        <Animated.View entering={FadeIn.delay(150).duration(300)}>
          <View style={[styles.weatherRow, { backgroundColor: isDark ? 'rgba(0,201,183,0.06)' : 'rgba(0,201,183,0.04)', borderColor: isDark ? 'rgba(0,201,183,0.12)' : 'rgba(0,201,183,0.08)' }]}>
          <LinearGradient
            colors={['#00C9B7', '#00E5D0']}
            style={styles.weatherIcon}
          >
            <Ionicons name="partly-sunny-outline" size={14} color="#FFF" />
          </LinearGradient>
          <TextInput
            style={[styles.weatherInput, { color: colors.text }]}
            placeholder="Weather? e.g. 72F sunny, rainy, cold..."
            placeholderTextColor={colors.textTertiary}
            value={weather}
            onChangeText={(value) => { setWeather(value); setWeatherStatus(value ? 'manual' : 'idle'); setWeatherMessage(null); }}
            returnKeyType="done"
          />
          <Pressable onPress={refreshLiveWeather} disabled={weatherStatus === 'loading'} hitSlop={8} accessibilityRole="button" accessibilityLabel="Use live local weather">
            {weatherStatus === 'loading' ? <ActivityIndicator size="small" color={colors.tint} /> : <Ionicons name="location-outline" size={18} color={colors.tint} />}
          </Pressable>
          {weather.length > 0 && (
            <Pressable onPress={() => { setWeather(''); setWeatherStatus('idle'); setWeatherMessage(null); }} hitSlop={8}>
              <Ionicons name="close-circle" size={18} color={colors.textSecondary} />
            </Pressable>
          )}
        </View>
        {weatherMessage && <Text style={[styles.weatherMessage, { color: weatherStatus === 'unavailable' ? colors.textSecondary : colors.tint }]}>{weatherMessage}</Text>}
      </Animated.View>

        <Animated.View entering={FadeIn.delay(175).duration(300)}>
          <View style={styles.paletteSection}>
            <View style={styles.paletteHeader}>
              <Text style={[styles.paletteLabel, { color: colors.textSecondary }]}>Color palette {colorPalette.length > 0 ? `(${colorPalette.length})` : '(optional)'}</Text>
              {colorPalette.length > 0 && <Pressable onPress={() => setColorPalette([])} hitSlop={8}><Text style={[styles.paletteClear, { color: colors.tint }]}>Clear</Text></Pressable>}
            </View>
            <FlatList
              data={COLORS}
              horizontal
              showsHorizontalScrollIndicator={false}
              keyExtractor={item => item.name}
              contentContainerStyle={styles.paletteList}
              renderItem={({ item }) => {
                const selected = colorPalette.includes(item.name);
                return (
                  <Pressable
                    onPress={() => togglePaletteColor(item.name)}
                    style={({ pressed }) => [styles.paletteChip, { backgroundColor: selected ? item.hex + '20' : colors.surfaceSecondary, borderColor: selected ? item.hex : colors.border, transform: [{ scale: pressed ? 0.96 : 1 }] }]}
                  >
                    <View style={[styles.paletteDot, { backgroundColor: item.hex, borderColor: item.name === 'White' ? colors.border : item.hex }]} />
                    <Text style={[styles.paletteChipText, { color: selected ? colors.text : colors.textSecondary }]}>{item.name}</Text>
                  </Pressable>
                );
              }}
            />
          </View>
        </Animated.View>

        <Animated.View entering={FadeIn.delay(200).duration(300)}>
          <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.occasionRow}
        >
          {OCCASIONS.map(occ => {
            const active = selectedOccasion === occ.key;
            return (
              <Pressable
                key={occ.key}
                onPress={() => {
                  Haptics.selectionAsync();
                  setSelectedOccasion(occ.key);
                }}
                accessibilityRole="button"
                accessibilityState={{ selected: active }}
                accessibilityLabel={`${occ.label} occasion filter`}
                accessibilityHint={active ? 'Currently filtering outfit suggestions by this occasion.' : `Filter outfit suggestions by ${occ.label.toLowerCase()}`}
                style={({ pressed }) => [
                  styles.occasionChip,
                  {
                    backgroundColor: active ? '#6E4AE015' : isDark ? 'rgba(255,255,255,0.04)' : colors.surfaceSecondary,
                    borderColor: active ? '#6E4AE030' : 'transparent',
                    transform: [{ scale: pressed ? 0.96 : 1 }],
                  },
                ]}
              >
                <Ionicons
                  name={occ.icon}
                  size={14}
                  color={active ? '#6E4AE0' : colors.textSecondary}
                />
                <Text
                  style={[
                    styles.occasionChipText,
                    { color: active ? '#6E4AE0' : colors.textSecondary },
                  ]}
                >
                  {occ.label}
                </Text>
              </Pressable>
            );
          })}
        </ScrollView>
        </Animated.View>

        <View style={[styles.retailSection, { borderColor: colors.border, backgroundColor: colors.surface }]}> 
          <View style={styles.retailHeader}>
            <View style={styles.retailTitleRow}><Ionicons name="storefront-outline" size={18} color={colors.tint} /><Text style={[styles.retailTitle, { color: colors.text }]}>AI Commerce</Text></View>
            <Pressable onPress={loadRetailRecommendations} disabled={retailLoading} accessibilityRole="button" accessibilityLabel={isRetailGapIntent ? 'Find retailer gaps from try-on context' : retailRecommendations.length ? 'Refresh retailer searches' : 'Find wardrobe gaps'} accessibilityHint="Uses your wardrobe context to open bounded retailer searches. It does not claim product availability, fit, price, or purchase suitability." style={[styles.retailButton, { backgroundColor: colors.tint, opacity: retailLoading ? 0.6 : 1 }]}> 
              {retailLoading ? <ActivityIndicator size="small" color="#FFF" /> : <Text style={styles.retailButtonText}>{isRetailGapIntent ? 'Review gaps' : retailRecommendations.length ? 'Refresh' : 'Find gaps'}</Text>}
            </Pressable>
          </View>
          <Text style={[styles.retailSubtitle, { color: colors.textSecondary }]}>Profile- and wardrobe-grounded retailer searches. No products, prices, discounts, or availability are invented.</Text>
          {isRetailGapIntent && (
            <View
              style={[styles.retailIntentBanner, { backgroundColor: isDark ? 'rgba(110,74,224,0.12)' : 'rgba(110,74,224,0.07)' }]}
              accessible
              accessibilityRole="summary"
              accessibilityLabel="Retail gap handoff from try-on. This screen keeps your wardrobe context and asks you to choose whether to find bounded retailer searches."
            >
              <Ionicons name="arrow-down-circle-outline" size={16} color={colors.tint} />
              <View style={styles.retailIntentCopy}>
                <Text style={[styles.retailIntentTitle, { color: colors.text }]}>Try-on handoff ready</Text>
                <Text style={[styles.retailIntentText, { color: colors.textSecondary }]}>Your rendered look brought you here. Choose Find gaps only if you want to explore a category; no product or purchase claim is implied.</Text>
              </View>
            </View>
          )}
          <View
            style={[styles.retailBridge, { backgroundColor: isDark ? 'rgba(0,201,183,0.06)' : 'rgba(0,201,183,0.04)' }]}
            accessible
            accessibilityRole="summary"
            accessibilityLabel={`Consumer to retail decision bridge. Compare ${wardrobeItems.length} wardrobe items, identify a bounded gap, and open an official retailer search. ${retailRecommendations.length} retailer searches are currently available.`}
          >
            <View style={styles.retailBridgeHeader}>
              <Ionicons name="git-compare-outline" size={14} color={colors.tint} />
              <Text style={[styles.retailBridgeTitle, { color: colors.text }]}>From wardrobe context to a bounded search</Text>
            </View>
            <View style={styles.retailBridgeSteps}>
              {[
                { icon: 'shirt-outline' as const, label: 'Use what you own' },
                { icon: 'search-outline' as const, label: 'Name a gap' },
                { icon: 'open-outline' as const, label: 'Explore a retailer' },
              ].map((step, index) => (
                <View key={step.label} style={styles.retailBridgeStep}>
                  <View style={[styles.retailBridgeIcon, { backgroundColor: colors.surface }]}>
                    <Ionicons name={step.icon} size={13} color={colors.tint} />
                  </View>
                  <Text style={[styles.retailBridgeStepText, { color: colors.textSecondary }]}>{step.label}</Text>
                  {index < 2 && <Ionicons name="arrow-forward" size={11} color={colors.textTertiary} />}
                </View>
              ))}
            </View>
            <Text style={[styles.retailBridgeNote, { color: colors.textTertiary }]}>ClosetAI helps a person decide what to explore next; it does not claim that a product will fit, be in stock, or be the right purchase.</Text>
          </View>
          {retailMessage && <Text style={[styles.retailMessage, { color: colors.textSecondary }]}>{retailMessage}</Text>}
          {retailRecommendations.map((item) => (
            <Pressable
              key={item.id}
              onPress={() => Linking.openURL(item.searchUrl).catch(() => setRetailMessage('Could not open this retailer search.'))}
              style={[styles.retailCard, { borderColor: colors.border }]}
              accessibilityRole="button"
              accessibilityLabel={`${item.title}. ${item.reason}. Source: bounded retailer search. Search basis: ${item.category}. No product availability or purchase claim.`}
              accessibilityHint="Opens an external retailer search link derived from wardrobe context."
            >
              <View style={styles.retailCardCopy}>
                <Text style={[styles.retailCardTitle, { color: colors.text }]}>{item.title}</Text>
                <Text style={[styles.retailCardReason, { color: colors.textSecondary }]}>{item.reason}</Text>
                <View style={styles.retailProvenanceRow}>
                  <Ionicons name="link-outline" size={11} color={colors.tint} />
                  <Text style={[styles.retailProvenanceText, { color: colors.tint }]}>Bounded retailer search · {item.category}</Text>
                </View>
              </View>
              <Ionicons name="open-outline" size={17} color={colors.tint} />
            </Pressable>
          ))}
        </View>

      {displayOutfits.length === 0 ? (
        <Animated.View entering={FadeIn.duration(400)} style={styles.emptyState}>
          <LinearGradient
            colors={isDark ? ['rgba(110,74,224,0.1)', 'rgba(110,74,224,0.02)'] : ['rgba(110,74,224,0.08)', 'rgba(110,74,224,0.01)']}
            style={styles.emptyIconWrap}
          >
            <Ionicons
              name={tab === 'suggested' ? 'sparkles-outline' : 'bookmark-outline'}
              size={40}
              color="#6E4AE0"
            />
          </LinearGradient>
          <Text style={[styles.emptyTitle, { color: colors.text }]}>
            {tab === 'suggested' ? 'No outfit suggestions' : 'No saved outfits'}
          </Text>
          <Text style={[styles.emptySubtitle, { color: colors.textSecondary }]}>
            {tab === 'suggested'
              ? hasEnoughItems
                  ? 'Generate recommendations from the items currently in your wardrobe'
                  : `Add ${itemsNeeded} more wardrobe item${itemsNeeded === 1 ? '' : 's'} to unlock your first outfit suggestions.`
              : 'Heart outfits you love to save them here'}
          </Text>
          {tab === 'suggested' && hasEnoughItems && (
            <Pressable
              onPress={handleRefresh}
              disabled={isRefreshing}
              accessibilityRole="button"
              accessibilityLabel="Generate outfit suggestions from wardrobe"
              accessibilityState={{ disabled: isRefreshing, busy: isRefreshing }}
              style={({ pressed }) => [styles.generateBtn, { transform: [{ scale: pressed ? 0.96 : 1 }] }]}
            >
              <LinearGradient
                colors={['#6E4AE0', '#9B6DFF']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={styles.generateBtnGradient}
              >
                {isRefreshing ? (
                  <ActivityIndicator size="small" color="#FFF" />
                ) : (
                  <>
                    <Ionicons name="sparkles" size={16} color="#FFF" />
                    <Text style={styles.generateBtnText}>Generate from wardrobe</Text>
                  </>
                )}
              </LinearGradient>
            </Pressable>
          )}
          {tab === 'suggested' && !hasEnoughItems && (
            <Pressable
              onPress={() => router.push('/add-item')}
              accessibilityRole="button"
              accessibilityLabel={`Add ${itemsNeeded} wardrobe item${itemsNeeded === 1 ? '' : 's'} to unlock outfit suggestions`}
              style={({ pressed }) => [styles.generateBtn, { transform: [{ scale: pressed ? 0.96 : 1 }] }]}
            >
              <LinearGradient colors={['#C17F59', '#D4A574']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.generateBtnGradient}>
                <Ionicons name="add-circle-outline" size={17} color="#FFF" />
                <Text style={styles.generateBtnText}>Add a wardrobe item</Text>
              </LinearGradient>
            </Pressable>
          )}
          {tab === 'saved' && (
            <Pressable
              onPress={() => setTab('suggested')}
              accessibilityRole="button"
              accessibilityLabel="View suggested outfits"
              style={({ pressed }) => [styles.generateBtn, { transform: [{ scale: pressed ? 0.96 : 1 }] }]}
            >
              <LinearGradient colors={['#6E4AE0', '#9B6DFF']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.generateBtnGradient}>
                <Ionicons name="sparkles-outline" size={17} color="#FFF" />
                <Text style={styles.generateBtnText}>View suggestions</Text>
              </LinearGradient>
            </Pressable>
          )}
        </Animated.View>
      ) : tab === 'suggested' ? (
        <View style={{ flex: 1 }}>
          <FlatList
            data={displayOutfits}
            horizontal
            pagingEnabled
            showsHorizontalScrollIndicator={false}
            keyExtractor={item => item.id}
            contentContainerStyle={{ paddingHorizontal: 20, paddingTop: 12, paddingBottom: 20, alignItems: 'center' }}
            snapToInterval={SCREEN_WIDTH - 40}
            decelerationRate="fast"
            renderItem={({ item, index }) => (
              <View style={{ width: SCREEN_WIDTH - 40, marginRight: 20 }}>
                <OutfitCard
                  outfit={item}
                  colors={colors}
                  isDark={isDark}
                  index={index}
                  onRate={(id, r) => rateOutfit(id, r)}
                  onSave={(id) => item.saved ? unsaveOutfit(id) : saveOutfit(id)}
                  onPress={(id) => router.push({ pathname: '/outfit-detail', params: { id } })}
                  source={recommendationSource}
                />
              </View>
            )}
          />
          <Text style={{ textAlign: 'center', fontFamily: 'Outfit_400Regular', fontSize: 12, color: colors.textTertiary, marginBottom: 16 }}>
            Swipe left or right to browse recommended looks
          </Text>
        </View>
      ) : (
        <FlatList
          data={displayOutfits}
          keyExtractor={item => item.id}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          renderItem={({ item, index }) => (
            <OutfitCard
              outfit={item}
              colors={colors}
              isDark={isDark}
              index={index}
              onRate={(id, r) => rateOutfit(id, r)}
              onSave={(id) => item.saved ? unsaveOutfit(id) : saveOutfit(id)}
              onPress={(id) => router.push({ pathname: '/outfit-detail', params: { id } })}
              source="saved"
            />
          )}
          ListFooterComponent={<View style={{ height: 120 }} />}
        />
      )}

      {isRefreshing && displayOutfits.length > 0 && (
        <Animated.View entering={FadeInDown.duration(300)} style={styles.loadingOverlay}>
          <LinearGradient
            colors={[colors.background + '00', colors.background]}
            style={styles.loadingGradient}
          >
            <View style={[styles.loadingPill, { backgroundColor: colors.surface }, shadows.medium]}>
              <ActivityIndicator size="small" color="#6E4AE0" />
              <Text style={[styles.loadingText, { color: colors.text }]}>Building recommendations from your wardrobe...</Text>
            </View>
          </LinearGradient>
        </Animated.View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  headerGradient: {
    paddingBottom: 14,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    paddingHorizontal: 20,
    paddingBottom: 14,
  },
  title: { fontFamily: 'Outfit_700Bold', fontSize: 26 },
  subtitle: { fontFamily: 'Outfit_400Regular', fontSize: 13, marginTop: 2 },
  refreshBtnGradient: {
    width: 44,
    height: 44,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#6E4AE0',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 6,
  },
  tabRow: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    gap: 10,
  },
  tabButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 9,
    borderRadius: 20,
    gap: 6,
  },
  tabButtonText: { fontFamily: 'Outfit_600SemiBold', fontSize: 13 },
  recommendationBanner: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 8,
    borderWidth: 1,
    borderRadius: 14,
    padding: 11,
    marginHorizontal: 20,
    marginTop: 12,
  },
  recommendationBannerText: { flex: 1, fontFamily: 'Outfit_400Regular', fontSize: 11, lineHeight: 16 },
  weatherRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: 20,
    marginTop: 12,
    marginBottom: 10,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 16,
    borderWidth: 1,
    gap: 10,
  },
  weatherIcon: {
    width: 30,
    height: 30,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  weatherInput: {
    flex: 1,
    fontFamily: 'Outfit_400Regular',
    fontSize: 14,
    paddingVertical: 2,
  },
  weatherMessage: { fontFamily: 'Outfit_400Regular', fontSize: 10, lineHeight: 14, paddingHorizontal: 20, marginTop: 5 },
  retailSection: { marginHorizontal: 20, marginTop: 4, marginBottom: 14, borderWidth: 1, borderRadius: 16, padding: 13 },
  retailIntentBanner: { flexDirection: 'row', alignItems: 'flex-start', gap: 8, borderRadius: 12, padding: 10, marginTop: 10 },
  retailIntentCopy: { flex: 1 },
  retailIntentTitle: { fontFamily: 'Outfit_700Bold', fontSize: 10 },
  retailIntentText: { fontFamily: 'Outfit_400Regular', fontSize: 9, lineHeight: 13, marginTop: 3 },
  retailHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 },
  retailTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 7, flex: 1 },
  retailTitle: { fontFamily: 'Outfit_700Bold', fontSize: 14 },
  retailButton: { minWidth: 72, minHeight: 32, borderRadius: 10, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 10 },
  retailButtonText: { color: '#FFF', fontFamily: 'Outfit_700Bold', fontSize: 11 },
  retailSubtitle: { fontFamily: 'Outfit_400Regular', fontSize: 10, lineHeight: 14, marginTop: 7 },
  retailBridge: { borderRadius: 12, padding: 10, marginTop: 10 },
  retailBridgeHeader: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  retailBridgeTitle: { fontFamily: 'Outfit_600SemiBold', fontSize: 10 },
  retailBridgeSteps: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 4, marginTop: 9 },
  retailBridgeStep: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 4 },
  retailBridgeIcon: { width: 24, height: 24, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
  retailBridgeStepText: { flex: 1, fontFamily: 'Outfit_500Medium', fontSize: 9, lineHeight: 12 },
  retailBridgeNote: { fontFamily: 'Outfit_400Regular', fontSize: 9, lineHeight: 13, marginTop: 9 },
  retailMessage: { fontFamily: 'Outfit_400Regular', fontSize: 10, marginTop: 8 },
  retailCard: { flexDirection: 'row', alignItems: 'center', gap: 10, borderTopWidth: 1, marginTop: 10, paddingTop: 10 },
  retailCardCopy: { flex: 1 },
  retailCardTitle: { fontFamily: 'Outfit_600SemiBold', fontSize: 12 },
  retailCardReason: { fontFamily: 'Outfit_400Regular', fontSize: 10, lineHeight: 14, marginTop: 2 },
  retailProvenanceRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 5 },
  retailProvenanceText: { fontFamily: 'Outfit_500Medium', fontSize: 9, lineHeight: 12 },
  paletteSection: { marginTop: 2, marginBottom: 4 },
  paletteHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, marginBottom: 8 },
  paletteLabel: { fontFamily: 'Outfit_500Medium', fontSize: 12 },
  paletteClear: { fontFamily: 'Outfit_500Medium', fontSize: 12 },
  paletteList: { gap: 8, paddingHorizontal: 20, paddingBottom: 10 },
  paletteChip: { flexDirection: 'row', alignItems: 'center', gap: 6, borderWidth: 1, borderRadius: 14, paddingHorizontal: 10, paddingVertical: 7 },
  paletteDot: { width: 12, height: 12, borderRadius: 6, borderWidth: 1 },
  paletteChipText: { fontFamily: 'Outfit_500Medium', fontSize: 11 },
  occasionRow: {
    paddingHorizontal: 20,
    gap: 8,
    paddingBottom: 14,
  },
  occasionChip: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 14,
    gap: 5,
    borderWidth: 1,
  },
  occasionChipText: { fontFamily: 'Outfit_500Medium', fontSize: 12 },
  listContent: { paddingHorizontal: 20, gap: 14 },
  outfitCard: {
    borderRadius: 20,
    overflow: 'hidden',
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 14,
    paddingTop: 14,
  },
  cardImages: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  cardImageWrap: {
    width: 56,
    height: 56,
    borderRadius: 16,
    borderWidth: 2.5,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
  },
  cardImage: {
    width: '100%',
    height: '100%',
  },
  moreItemsText: { fontFamily: 'Outfit_600SemiBold', fontSize: 13 },
  cardBody: { padding: 14, paddingTop: 10 },
  cardTitle: { fontFamily: 'Outfit_700Bold', fontSize: 17, marginBottom: 4 },
  cardReason: { fontFamily: 'Outfit_400Regular', fontSize: 14, marginBottom: 10, lineHeight: 20 },
  cardMeta: { flexDirection: 'row', gap: 6, flexWrap: 'wrap' },
  occasionBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
    gap: 4,
  },
  occasionText: { fontFamily: 'Outfit_500Medium', fontSize: 11 },
  tag: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 10 },
  tagText: { fontFamily: 'Outfit_500Medium', fontSize: 11 },
  cardActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 8,
    borderTopWidth: 1,
  },
  actionBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  actionBtnLabel: { fontFamily: 'Outfit_500Medium', fontSize: 12 },
  aiLabel: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
  },
  aiLabelText: { fontFamily: 'Outfit_600SemiBold', fontSize: 10 },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 14,
    paddingHorizontal: 40,
  },
  emptyIconWrap: {
    width: 88,
    height: 88,
    borderRadius: 28,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 4,
  },
  emptyTitle: { fontFamily: 'Outfit_700Bold', fontSize: 22 },
  emptySubtitle: { fontFamily: 'Outfit_400Regular', fontSize: 14, textAlign: 'center', lineHeight: 20 },
  generateBtn: {
    borderRadius: 24,
    overflow: 'hidden',
    marginTop: 8,
    shadowColor: '#6E4AE0',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 6,
  },
  generateBtnGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 28,
    paddingVertical: 16,
  },
  generateBtnText: { fontFamily: 'Outfit_600SemiBold', fontSize: 16, color: '#FFF' },
  loadingOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 120,
  },
  loadingGradient: {
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'center',
    paddingBottom: 30,
  },
  loadingPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 24,
  },
  loadingText: { fontFamily: 'Outfit_500Medium', fontSize: 14 },
});
