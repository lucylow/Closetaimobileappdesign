import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { useTheme } from '@/lib/useTheme';
import { interaction } from '@/constants/colors';
import { MediaStatusCard } from '@/components/ui/MediaStatusCard';
import { fashionTryOnResultPresentation, normalizeFashionProvider, type FashionTryOnResultProvider } from '@shared/fashion-tryon-result';

export default function TryOnResultScreen() {
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const { resultUri, provider, demo } = useLocalSearchParams<{ resultUri: string; provider?: string; demo?: string }>();
  const isDemo = demo === 'true';
  const resolvedProvider = normalizeFashionProvider(provider, isDemo);
  const presentation = fashionTryOnResultPresentation(resolvedProvider);
  const providerLabel = isDemo
    ? 'Fictional Demo Mode'
    : resolvedProvider === 'youcam-ai-clothes-v4'
    ? 'Perfect Corp. YouCam AI Clothes v4'
    : resolvedProvider === 'image-edit'
    ? 'User-photo-only assisted edit'
    : 'Selected-photo preview';

  const webTopInset = Platform.OS === 'web' ? 67 : 0;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: (insets.top || webTopInset) + 12 }]}>
        <Pressable onPress={() => router.back()} hitSlop={12} accessibilityRole="button" accessibilityLabel="Close try-on result" style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}>
          <Ionicons name="close" size={24} color={colors.textSecondary} />
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.text }]}>Try-On Result</Text>
        <View style={{ width: 24 }} />
      </View>

      <View style={styles.content}>
        {resultUri ? (
          <View style={styles.resultStage}>
            <Image
              source={{ uri: resultUri }}
              style={[styles.resultImage, { backgroundColor: colors.surfaceSecondary }]}
              contentFit="contain"
              transition={400}
              accessibilityLabel="Temporary virtual try-on result generated from your selected media"
            />
            <View style={[styles.lineageCard, { backgroundColor: colors.surface, borderColor: colors.border }]} accessible accessibilityRole="summary" accessibilityLabel={`Try-on source lineage. Provider: ${providerLabel}. Inputs: user-photo-only with no stock model substitution.`}>
              <View style={styles.lineageHeader}><Ionicons name="shield-checkmark-outline" size={16} color={colors.tint} /><Text style={[styles.lineageTitle, { color: colors.text }]}>Source Lineage & Provenance</Text></View>
              <Text style={[styles.lineageCopy, { color: colors.textSecondary }]}>Provider: {providerLabel}. {isDemo ? 'Fictional Demo Mode uses offline presentation and never masquerades as a live provider API.' : resolvedProvider === 'youcam-ai-clothes-v4' ? 'Live Perfect Corp. YouCam AI Clothes v4 rendering pipeline applied to your selected photo and garments.' : 'Photo-safe user-photo-only assisted preview. No stock model was substituted.'}</Text>
            </View>
            <MediaStatusCard
              kind={presentation.isUserPhotoPreview ? 'local-only' : 'temporary-result'}
              title={presentation.label}
              detail={presentation.detail}
              tint={resolvedProvider === 'youcam-ai-clothes-v4' ? colors.success : colors.tint}
              surface={colors.surfaceSecondary}
              border={colors.border}
            />
            <View style={styles.actionRow}>
              <Pressable
                onPress={() => router.replace({ pathname: '/outfits', params: { intent: 'retail-gap' } } as any)}
                accessibilityRole="button"
                accessibilityLabel="Review retail gap and plan outfit"
                style={({ pressed }) => [styles.retailButton, { backgroundColor: colors.surfaceSecondary, borderColor: colors.border, borderWidth: 1, opacity: pressed ? 0.8 : 1 }]}
              >
                <Ionicons name="bag-handle-outline" size={16} color={colors.tint} />
                <Text style={[styles.retailButtonText, { color: colors.text }]}>Review Retail Gap</Text>
              </Pressable>
              <Pressable
                onPress={() => router.replace('/tryon')}
                accessibilityRole="button"
                accessibilityLabel="Start another virtual try-on"
                style={({ pressed }) => [styles.newTryOnButton, { backgroundColor: colors.text, opacity: pressed ? 0.82 : 1, transform: [{ scale: pressed ? interaction.primaryPressScale : 1 }] }]}
              >
                <Ionicons name="refresh-outline" size={17} color={colors.background} />
                <Text style={[styles.newTryOnText, { color: colors.background }]}>Try another look</Text>
              </Pressable>
            </View>
          </View>
        ) : (
          <View style={styles.emptyState}>
            <Ionicons name="image-outline" size={56} color={colors.tabIconDefault} />
            <Text style={[styles.emptyText, { color: colors.textSecondary }]}>No result available</Text>
            <Pressable onPress={() => router.replace('/tryon')} accessibilityRole="button" accessibilityLabel="Return to virtual try-on" style={({ pressed }) => [styles.returnButton, { borderColor: colors.border, opacity: pressed ? 0.72 : 1 }]}><Text style={[styles.returnButtonText, { color: colors.text }]}>Return to try-on</Text></Pressable>
          </View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingBottom: 12,
  },
  headerTitle: { fontFamily: 'Outfit_600SemiBold', fontSize: 18 },
  content: { flex: 1, padding: 20 },
  resultStage: { flex: 1, gap: 12 },
  resultImage: { flex: 1, minHeight: 280, borderRadius: 18 },
  lineageCard: { borderWidth: 1, borderRadius: 14, padding: 11, gap: 4 }, lineageHeader: { flexDirection: 'row', alignItems: 'center', gap: 6 }, lineageTitle: { fontFamily: 'Outfit_600SemiBold', fontSize: 12 }, lineageCopy: { fontFamily: 'Outfit_400Regular', fontSize: 10, lineHeight: 14 }, actionRow: { flexDirection: 'row', gap: 10 }, retailButton: { flex: 1, minHeight: 48, borderRadius: 14, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 7 }, retailButtonText: { fontFamily: 'Outfit_600SemiBold', fontSize: 12 }, newTryOnButton: { flex: 1, minHeight: 48, borderRadius: 14, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 8 }, newTryOnText: { fontFamily: 'Outfit_700Bold', fontSize: 12 },
  emptyState: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 12 },
  emptyText: { fontFamily: 'Outfit_500Medium', fontSize: 16 },
  returnButton: { minHeight: 42, borderWidth: 1, borderRadius: 13, justifyContent: 'center', paddingHorizontal: 15 },
  returnButtonText: { fontFamily: 'Outfit_700Bold', fontSize: 12 },
});
