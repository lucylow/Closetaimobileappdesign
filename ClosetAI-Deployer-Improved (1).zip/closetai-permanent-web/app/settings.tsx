import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  ScrollView,
  Switch,
  Alert,
  Platform,
  ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import * as Haptics from 'expo-haptics';
import Animated, { FadeInUp } from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { useApp } from '@/contexts/AppContext';
import { useTheme } from '@/lib/useTheme';
import { shadows } from '@/constants/colors';

const PROFILE_COLORS = ['Black', 'White', 'Navy', 'Beige', 'Brown', 'Red', 'Blue', 'Green'];
const PROFILE_STYLES = ['Minimal', 'Classic', 'Casual', 'Smart Casual', 'Streetwear', 'Romantic'];
const PROFILE_FITS = ['Relaxed', 'Tailored', 'Oversized', 'Fitted'];

function SettingsRow({
  icon,
  label,
  trailing,
  onPress,
  colors,
  destructive,
  isDark,
}: {
  icon: string;
  label: string;
  trailing?: React.ReactNode;
  onPress?: () => void;
  colors: any;
  destructive?: boolean;
  isDark?: boolean;
}) {
  return (
    <Pressable
      onPress={onPress}
      disabled={!onPress}
      style={({ pressed }) => [
        styles.settingsRow,
        { backgroundColor: colors.surface, transform: [{ scale: pressed && onPress ? 0.98 : 1 }] },
        shadows.soft,
      ]}
    >
      <View style={[styles.settingsIcon, { backgroundColor: destructive ? '#E74C3C12' : colors.tint + '12' }]}>
        <Ionicons
          name={icon as any}
          size={20}
          color={destructive ? '#E74C3C' : colors.tint}
        />
      </View>
      <Text style={[styles.settingsLabel, { color: destructive ? '#E74C3C' : colors.text }]}>
        {label}
      </Text>
      {trailing}
    </Pressable>
  );
}

export default function SettingsScreen() {
  const { colors, isDark } = useTheme();
  const insets = useSafeAreaInsets();
  const { demoMode, setDemoMode, clearBlankLiveState, language, setLanguage, isLanguageSwitching, t, toggleTheme, signOut, wardrobeItems, credits, isAuthenticated, subscriptionTier, creditsUsed, monthlyCredits, styleProfile, updateStyleProfile } = useApp();

  const webTopInset = Platform.OS === 'web' ? 67 : 0;
  const webBottomInset = Platform.OS === 'web' ? 34 : 0;

  const toggleProfileValue = (field: 'colors' | 'styles' | 'fitPrefs', value: string) => {
    Haptics.selectionAsync();
    const values = styleProfile[field];
    const nextValues = values.includes(value) ? values.filter((item) => item !== value) : [...values, value].slice(-6);
    updateStyleProfile({ ...styleProfile, [field]: nextValues });
  };

  const handleSignOut = () => {
    Alert.alert(
      'Sign Out',
      'This will reset all your data. Are you sure?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Sign Out',
          style: 'destructive',
          onPress: () => {
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
            signOut();
            router.replace('/onboarding');
          },
        },
      ]
    );
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: (insets.top || webTopInset) + 12, flexWrap: 'wrap', gap: 8 }]}>
        <Pressable onPress={() => router.back()} hitSlop={12}>
          <Ionicons name="close" size={24} color={colors.textSecondary} />
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.text, flexShrink: 1 }]}>Settings</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView
        contentContainerStyle={[styles.scrollContent, { paddingBottom: (insets.bottom || webBottomInset) + 24 }]}
        showsVerticalScrollIndicator={false}
      >
        <Animated.View entering={FadeInUp.duration(400)}>
          <LinearGradient
            colors={isDark ? ['rgba(212,165,116,0.12)', 'rgba(212,165,116,0.04)'] : ['rgba(193,127,89,0.1)', 'rgba(193,127,89,0.02)']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={styles.profileCard}
          >
            <LinearGradient
              colors={['#C17F59', '#D4A574']}
              style={styles.avatar}
            >
              <Ionicons name="person" size={26} color="#FFF" />
            </LinearGradient>
            <View style={{ flex: 1 }}>
              <Text style={[styles.profileName, { color: colors.text }]}>Guest User</Text>
              <Text style={[styles.profileSub, { color: colors.textSecondary }]}>
                {wardrobeItems.length} items in wardrobe
              </Text>
            </View>
            {credits !== undefined && (
              <View style={[styles.profileCredits, { backgroundColor: isDark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.04)' }]}>
                <Ionicons name="flash" size={12} color={colors.tint} />
                <Text style={[styles.profileCreditsText, { color: colors.tint }]}>{credits}</Text>
              </View>
            )}
          </LinearGradient>
        </Animated.View>

        <Animated.View entering={FadeInUp.delay(100).duration(400)}>
          <Text style={[styles.sectionTitle, { color: colors.textSecondary }]}>Appearance</Text>
          <SettingsRow
            icon="moon-outline"
            label="Dark Mode"
            colors={colors}
            isDark={isDark}
            trailing={
              <Switch
                value={isDark}
                onValueChange={() => {
                  Haptics.selectionAsync();
                  toggleTheme();
                }}
                trackColor={{ true: colors.tint, false: colors.border }}
              />
            }
          />
        </Animated.View>

        <Animated.View entering={FadeInUp.delay(150).duration(400)}>
          <Text style={[styles.sectionTitle, { color: colors.textSecondary }]}>Personal Style Profile</Text>
          <View style={[styles.styleProfileCard, { backgroundColor: colors.surface }]}> 
            <Text style={[styles.styleProfileDescription, { color: colors.textSecondary }]}>Your selected preferences and wardrobe signals guide live outfit recommendations. Leave a group empty to keep it neutral.</Text>
            {([['colors', 'Colors', PROFILE_COLORS], ['styles', 'Style directions', PROFILE_STYLES], ['fitPrefs', 'Fit preferences', PROFILE_FITS]] as const).map(([field, label, options]) => (
              <View key={field} style={styles.styleGroup}>
                <Text style={[styles.styleGroupLabel, { color: colors.text }]}>{label}</Text>
                <View style={styles.styleChipWrap}>
                  {options.map((option) => {
                    const selected = styleProfile[field].includes(option);
                    return <Pressable key={option} onPress={() => toggleProfileValue(field, option)} style={[styles.styleChip, { backgroundColor: selected ? colors.tint + '16' : colors.surfaceSecondary, borderColor: selected ? colors.tint : colors.border }]}><Text style={[styles.styleChipText, { color: selected ? colors.tint : colors.textSecondary }]}>{option}</Text></Pressable>;
                  })}
                </View>
              </View>
            ))}
          </View>
        </Animated.View>

        <Animated.View entering={FadeInUp.delay(175).duration(400)}>
          <Text style={[styles.sectionTitle, { color: colors.textSecondary }]}>Subscription</Text>
          <SettingsRow
            icon="diamond-outline"
            label={`${subscriptionTier.charAt(0).toUpperCase() + subscriptionTier.slice(1)} Plan`}
            colors={colors}
            isDark={isDark}
            onPress={() => router.push('/subscription')}
            trailing={
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                <View style={[styles.creditsBadge, { backgroundColor: colors.violet + '18' }]}>
                  <Text style={[styles.creditsText, { color: colors.violet }]}>{subscriptionTier === 'free' ? 'FREE' : subscriptionTier.toUpperCase()}</Text>
                </View>
                <Ionicons name="chevron-forward" size={16} color={colors.textTertiary} />
              </View>
            }
          />
          <SettingsRow
            icon="flash-outline"
            label="AI Credits"
            colors={colors}
            isDark={isDark}
            onPress={() => router.push('/subscription')}
            trailing={
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                <View style={[styles.creditsBadge, { backgroundColor: colors.tint + '12' }]}>
                  <Text style={[styles.creditsText, { color: colors.tint }]}>{monthlyCredits - creditsUsed}/{monthlyCredits}</Text>
                </View>
                <Ionicons name="chevron-forward" size={16} color={colors.textTertiary} />
              </View>
            }
          />
        </Animated.View>

        <Animated.View entering={FadeInUp.delay(200).duration(400)}>
          <Text style={[styles.sectionTitle, { color: colors.textSecondary }]}>App</Text>
          <View style={[{ backgroundColor: colors.card, borderColor: colors.border, borderWidth: 1, borderRadius: 16, marginBottom: 16, padding: 16 }]}>
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <Ionicons name="language-outline" size={20} color={colors.tint} style={{ marginRight: 12 }} />
                <Text style={{ fontFamily: 'Outfit_600SemiBold', fontSize: 15, color: colors.text }}>Language Selection / 语言选择</Text>
              </View>
              {isLanguageSwitching && <ActivityIndicator size="small" color={colors.tint} />}
            </View>
            <Text style={{ fontFamily: 'Outfit_400Regular', fontSize: 12, color: colors.textSecondary, marginBottom: 12 }}>
              Select your preferred language. Your choice is automatically saved and persisted across app restarts.
            </Text>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
              {[
                { code: 'en', label: 'English', flag: '🇺🇸' },
                { code: 'zh', label: '中文', flag: '🇨🇳' },
                { code: 'es', label: 'Español', flag: '🇪🇸' },
                { code: 'fr', label: 'Français', flag: '🇫🇷' },
              ].map((item) => {
                const isSelected = language === item.code;
                return (
                  <Pressable
                    key={item.code}
                    onPress={() => {
                      Haptics.selectionAsync();
                      setLanguage(item.code as any);
                    }}
                    style={{
                      flexBasis: '48%',
                      flexGrow: 1,
                      paddingVertical: 10,
                      paddingHorizontal: 8,
                      borderRadius: 10,
                      flexDirection: 'row',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: 6,
                      backgroundColor: isSelected ? colors.tint : colors.surface,
                      borderWidth: 1,
                      borderColor: isSelected ? colors.tint : colors.border,
                    }}
                  >
                    <Text style={{ fontSize: 14 }}>{item.flag}</Text>
                    <Text style={{ fontFamily: 'Outfit_600SemiBold', fontSize: 13, color: isSelected ? '#FFFFFF' : colors.text }}>
                      {item.label}
                    </Text>
                  </Pressable>
                );
              })}
            </View>
          </View>
          <SettingsRow
            icon="flask-outline"
            label="Demo Mode"
            colors={colors}
            isDark={isDark}
            trailing={
              <Switch
                value={demoMode}
                onValueChange={(v) => {
                  Haptics.selectionAsync();
                  setDemoMode(v);
                }}
                trackColor={{ true: colors.tint, false: colors.border }}
              />
            }
          />
          <SettingsRow
            icon="trash-outline"
            label="Clear to Blank Live State"
            colors={colors}
            isDark={isDark}
            onPress={() => {
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
              Alert.alert(
                'Switch to Blank Live State',
                'This will clear all items and saved outfits to test a blank live state. Demo Mode remains available to re-seed or explore examples.',
                [
                  { text: 'Cancel', style: 'cancel' },
                  {
                    text: 'Clear & Test Blank',
                    style: 'destructive',
                    onPress: async () => {
                      await clearBlankLiveState();
                      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
                      Alert.alert('Blank Live State Active', 'Your wardrobe and outfits are now empty for live testing.');
                    }
                  }
                ]
              );
            }}
            trailing={<Ionicons name="chevron-forward" size={16} color={colors.textTertiary} />}
          />
          <SettingsRow
            icon="bar-chart-outline"
            label="Business Dashboard"
            colors={colors}
            isDark={isDark}
            onPress={() => router.push('/business-dashboard')}
            trailing={<Ionicons name="chevron-forward" size={16} color={colors.textTertiary} />}
          />
          {isAuthenticated && (
            <SettingsRow
              icon="cloud-done-outline"
              label="Connected to Cloud"
              colors={colors}
              isDark={isDark}
              trailing={
                <View style={[styles.connectionDot, { backgroundColor: '#27AE60' }]} />
              }
            />
          )}
        </Animated.View>

        <Animated.View entering={FadeInUp.delay(250).duration(400)}>
          <Text style={[styles.sectionTitle, { color: colors.textSecondary }]}>About</Text>
          <SettingsRow
            icon="information-circle-outline"
            label="Version 1.0.0"
            colors={colors}
            isDark={isDark}
          />
        </Animated.View>

        <Animated.View entering={FadeInUp.delay(250).duration(400)} style={{ marginTop: 12 }}>
          <SettingsRow
            icon="log-out-outline"
            label="Sign Out & Reset"
            colors={colors}
            isDark={isDark}
            destructive
            onPress={handleSignOut}
          />
        </Animated.View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingBottom: 12,
  },
  headerTitle: { fontFamily: 'Outfit_600SemiBold', fontSize: 18 },
  scrollContent: { paddingHorizontal: 20, gap: 8 },
  profileCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    borderRadius: 20,
    padding: 18,
    marginBottom: 12,
  },
  avatar: {
    width: 52,
    height: 52,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileName: { fontFamily: 'Outfit_600SemiBold', fontSize: 18 },
  profileSub: { fontFamily: 'Outfit_400Regular', fontSize: 13, marginTop: 2 },
  profileCredits: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 12,
  },
  profileCreditsText: { fontFamily: 'Outfit_600SemiBold', fontSize: 13 },
  styleProfileCard: { borderRadius: 16, padding: 14, marginBottom: 6 },
  styleProfileDescription: { fontFamily: 'Outfit_400Regular', fontSize: 11, lineHeight: 16 },
  styleGroup: { marginTop: 12 },
  styleGroupLabel: { fontFamily: 'Outfit_600SemiBold', fontSize: 12, marginBottom: 7 },
  styleChipWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 7 },
  styleChip: { borderWidth: 1, borderRadius: 14, paddingHorizontal: 10, paddingVertical: 7 },
  styleChipText: { fontFamily: 'Outfit_500Medium', fontSize: 11 },
  sectionTitle: {
    fontFamily: 'Outfit_600SemiBold',
    fontSize: 12,
    textTransform: 'uppercase',
    letterSpacing: 0.8,
    marginTop: 16,
    marginBottom: 8,
    marginLeft: 4,
  },
  settingsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    borderRadius: 16,
    padding: 14,
    marginBottom: 6,
  },
  settingsIcon: {
    width: 38,
    height: 38,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  settingsLabel: { fontFamily: 'Outfit_500Medium', fontSize: 15, flex: 1 },
  creditsBadge: {
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
  },
  creditsText: { fontFamily: 'Outfit_600SemiBold', fontSize: 14 },
  connectionDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
});
