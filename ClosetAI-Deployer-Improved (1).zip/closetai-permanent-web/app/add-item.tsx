import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  ScrollView,
  TextInput,
  Platform,
  ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import * as ImagePicker from 'expo-image-picker';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import * as Haptics from 'expo-haptics';
import Animated, { FadeInUp } from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { useApp } from '@/contexts/AppContext';
import { useTheme } from '@/lib/useTheme';
import { CATEGORIES, COLORS } from '@/lib/demo-data';
import { shadows } from '@/constants/colors';
import { MediaStatusCard } from '@/components/ui/MediaStatusCard';

export default function AddItemScreen() {
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const { addWardrobeItem } = useApp();

  const webTopInset = Platform.OS === 'web' ? 67 : 0;
  const webBottomInset = Platform.OS === 'web' ? 34 : 0;

  const [imageUri, setImageUri] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [category, setCategory] = useState<string>('top');
  const [color, setColor] = useState<string>('Black');
  const [brand, setBrand] = useState('');
  const [notes, setNotes] = useState('');
  const [formMessage, setFormMessage] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  const pickImage = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setFormMessage(null);
    try {
      const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!permission.granted) {
        setFormMessage('Photo access is needed to add this item. Enable it in device settings, then try again.');
        return;
      }
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ['images'],
        allowsEditing: true,
        aspect: [3, 4],
        quality: 0.8,
      });
      if (!result.canceled && result.assets[0]) {
        setImageUri(result.assets[0].uri);
      }
    } catch (error) {
      setFormMessage(error instanceof Error ? error.message : 'We could not open your photos. Please try again.');
    }
  };

  const handleSave = async () => {
    if (!imageUri || !name.trim()) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      setFormMessage(!imageUri ? 'Add a photo before saving this wardrobe item.' : 'Add a name so you can recognize this item later.');
      return;
    }

    setFormMessage(null);
    setIsSaving(true);
    try {
      await addWardrobeItem({
        name: name.trim(),
        category: category as any,
        color,
        brand: brand.trim(),
        imageUrl: imageUri,
        tags: [],
        notes: notes.trim(),
      });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      router.back();
    } catch (error) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      setFormMessage(error instanceof Error ? error.message : 'We could not save this item. Your details are still here—please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  const canSave = Boolean(imageUri && name.trim() && !isSaving);

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: (insets.top || webTopInset) + 12 }]}>
        <Pressable onPress={() => router.back()} hitSlop={12} accessibilityRole="button" accessibilityLabel="Close add item">
          <Ionicons name="close" size={24} color={colors.textSecondary} />
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.text }]}>Add to wardrobe</Text>
        <Pressable
          onPress={handleSave}
          disabled={!canSave}
          hitSlop={12}
          accessibilityRole="button"
          accessibilityLabel="Save wardrobe item"
          accessibilityState={{ disabled: !canSave, busy: isSaving }}
          accessibilityHint={canSave ? 'Saves this item to your wardrobe.' : 'Add a photo and name to enable saving.'}
          style={({ pressed }) => [{ transform: [{ scale: pressed && canSave ? 0.9 : 1 }], opacity: canSave ? 1 : 0.5 }]}
        >
          <View style={[styles.saveIcon, { backgroundColor: '#C17F59' }]}>
            {isSaving ? <ActivityIndicator size="small" color="#FFF" /> : <Ionicons name="checkmark" size={20} color="#FFF" />}
          </View>
        </Pressable>
      </View>

      <ScrollView
        contentContainerStyle={[styles.scrollContent, { paddingBottom: (insets.bottom || webBottomInset) + 30 }]}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        <Animated.View entering={FadeInUp.duration(320)} style={[styles.progressCard, { backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]}>
          <View style={[styles.progressNumber, { backgroundColor: colors.tint }]}><Text style={styles.progressNumberText}>1</Text></View>
          <View style={styles.flex}><Text style={[styles.progressTitle, { color: colors.text }]}>Start with a photo and a name</Text><Text style={[styles.progressCopy, { color: colors.textSecondary }]}>Those are the only details required. Category and color make future outfit suggestions more useful.</Text></View>
        </Animated.View>

        <Animated.View entering={FadeInUp.delay(70).duration(320)}>
          <Pressable
            onPress={pickImage}
            style={({ pressed }) => [
              styles.imageBox,
              {
                backgroundColor: colors.surface,
                borderColor: imageUri ? '#C17F59' : colors.border,
                transform: [{ scale: pressed ? 0.98 : 1 }],
              },
              shadows.soft,
            ]}
            accessibilityRole="button"
            accessibilityLabel={imageUri ? 'Change wardrobe item photo' : 'Add wardrobe item photo'}
            accessibilityHint="Opens your photo library. A photo is required before saving."
          >
            {imageUri ? (
              <View>
                <Image source={{ uri: imageUri }} style={styles.imagePreview} contentFit="cover" accessibilityLabel="Selected wardrobe item photo. Select this area to replace it." />
                <LinearGradient colors={['transparent', 'rgba(0,0,0,0.45)']} style={styles.imageOverlay}>
                  <View style={styles.changePhotoBtn}>
                    <Ionicons name="camera-outline" size={14} color="#FFF" />
                    <Text style={styles.changePhotoText}>Change photo</Text>
                  </View>
                </LinearGradient>
              </View>
            ) : (
              <View style={styles.imageEmpty}>
                <LinearGradient colors={['#C17F5920', '#C17F5908']} style={styles.cameraIconWrap}>
                  <Ionicons name="camera-outline" size={36} color="#C17F59" />
                </LinearGradient>
                <Text style={[styles.imageEmptyTitle, { color: colors.text }]}>Add your item photo</Text>
                <Text style={[styles.imageEmptyText, { color: colors.textSecondary }]}>Use a clear photo of the piece you want to wear.</Text>
              </View>
            )}
          </Pressable>
        </Animated.View>

        {imageUri && (
          <MediaStatusCard
            kind="user-photo"
            title="Your garment photo is selected"
            detail="This is the exact photo that will appear in your wardrobe. Select the preview above if you want to replace it."
            tint={colors.tint}
            surface={colors.surfaceSecondary}
            border={colors.border}
          />
        )}

        {formMessage && (
          <View style={[styles.formMessage, { backgroundColor: `${colors.tint}12`, borderColor: `${colors.tint}24` }]} accessibilityLiveRegion="assertive" accessibilityRole="alert">
            <Ionicons name="information-circle-outline" size={17} color={colors.tint} />
            <Text style={[styles.formMessageText, { color: colors.textSecondary }]}>{formMessage}</Text>
          </View>
        )}

        <Animated.View entering={FadeInUp.delay(120).duration(320)}>
          <View style={styles.labelRow}><Text style={[styles.label, { color: colors.textSecondary }]}>Item name</Text><Text style={[styles.requiredLabel, { color: colors.tint }]}>REQUIRED</Text></View>
          <TextInput
            value={name}
            onChangeText={(value) => { setName(value); if (formMessage) setFormMessage(null); }}
            placeholder="e.g., Classic White Tee"
            placeholderTextColor={colors.tabIconDefault}
            returnKeyType="done"
            style={[styles.input, { backgroundColor: colors.surface, borderColor: !name.trim() && formMessage ? colors.tint : colors.border, color: colors.text }]}
            accessibilityLabel="Item name"
          />
        </Animated.View>

        <Animated.View entering={FadeInUp.delay(170).duration(320)}>
          <Text style={[styles.label, { color: colors.textSecondary }]}>Category</Text>
          <View style={styles.chipRow}>
            {CATEGORIES.map(cat => {
              const selected = category === cat;
              return (
                <Pressable
                  key={cat}
                  onPress={() => { Haptics.selectionAsync(); setCategory(cat); }}
                  accessibilityRole="radio"
                  accessibilityState={{ selected }}
                  accessibilityLabel={`${cat} category`}
                  style={[styles.chip, { backgroundColor: selected ? colors.tint : colors.surfaceSecondary, borderColor: selected ? colors.tint : 'transparent' }]}
                >
                  <Text style={[styles.chipText, { color: selected ? '#FFF' : colors.textSecondary }]}>{cat.charAt(0).toUpperCase() + cat.slice(1)}</Text>
                </Pressable>
              );
            })}
          </View>
        </Animated.View>

        <Animated.View entering={FadeInUp.delay(220).duration(320)}>
          <Text style={[styles.label, { color: colors.textSecondary }]}>Color</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <View style={styles.colorRow}>
              {COLORS.map(c => {
                const selected = color === c.name;
                return (
                  <Pressable
                    key={c.name}
                    onPress={() => { Haptics.selectionAsync(); setColor(c.name); }}
                    accessibilityRole="radio"
                    accessibilityState={{ selected }}
                    accessibilityLabel={`${c.name} color`}
                    style={styles.colorItem}
                  >
                    <View style={[styles.colorSwatch, { backgroundColor: c.hex, borderWidth: selected ? 3 : 1, borderColor: selected ? colors.tint : colors.border }]} />
                    <Text style={[styles.colorName, { color: selected ? colors.tint : colors.textSecondary }]}>{c.name}</Text>
                  </Pressable>
                );
              })}
            </View>
          </ScrollView>
        </Animated.View>

        <Animated.View entering={FadeInUp.delay(270).duration(320)}>
          <Text style={[styles.label, { color: colors.textSecondary }]}>Brand <Text style={[styles.optionalLabel, { color: colors.textTertiary }]}>OPTIONAL</Text></Text>
          <TextInput value={brand} onChangeText={setBrand} placeholder="e.g., Everlane" placeholderTextColor={colors.tabIconDefault} returnKeyType="next" style={[styles.input, { backgroundColor: colors.surface, borderColor: colors.border, color: colors.text }]} accessibilityLabel="Brand, optional" />
        </Animated.View>

        <Animated.View entering={FadeInUp.delay(320).duration(320)}>
          <Text style={[styles.label, { color: colors.textSecondary }]}>Notes <Text style={[styles.optionalLabel, { color: colors.textTertiary }]}>OPTIONAL</Text></Text>
          <TextInput value={notes} onChangeText={setNotes} placeholder="Anything you want to remember..." placeholderTextColor={colors.tabIconDefault} multiline numberOfLines={3} style={[styles.input, styles.textArea, { backgroundColor: colors.surface, borderColor: colors.border, color: colors.text }]} accessibilityLabel="Notes, optional" />
        </Animated.View>

        <Pressable
          onPress={handleSave}
          disabled={!canSave}
          accessibilityRole="button"
          accessibilityLabel="Save wardrobe item"
          accessibilityState={{ disabled: !canSave, busy: isSaving }}
          accessibilityHint={canSave ? 'Saves this item to your wardrobe.' : 'Add a photo and name to enable saving.'}
          style={({ pressed }) => [styles.bottomSave, { opacity: canSave ? (pressed ? 0.88 : 1) : 0.45, transform: [{ scale: pressed && canSave ? 0.98 : 1 }] }]}
        >
          <LinearGradient colors={['#C17F59', '#D4A574']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.bottomSaveGradient}>
            {isSaving ? <ActivityIndicator size="small" color="#FFF" /> : <Ionicons name="checkmark-circle-outline" size={19} color="#FFF" />}
            <Text style={styles.bottomSaveText}>{isSaving ? 'Saving item…' : 'Save to wardrobe'}</Text>
          </LinearGradient>
        </Pressable>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  flex: { flex: 1 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, paddingBottom: 12 },
  headerTitle: { fontFamily: 'Outfit_600SemiBold', fontSize: 18 },
  saveIcon: { width: 34, height: 34, borderRadius: 17, alignItems: 'center', justifyContent: 'center' },
  scrollContent: { paddingHorizontal: 20, gap: 20 },
  progressCard: { flexDirection: 'row', alignItems: 'flex-start', gap: 10, borderWidth: 1, borderRadius: 16, padding: 12 },
  progressNumber: { width: 25, height: 25, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
  progressNumberText: { fontFamily: 'Outfit_700Bold', fontSize: 12, color: '#FFF' },
  progressTitle: { fontFamily: 'Outfit_700Bold', fontSize: 13 },
  progressCopy: { fontFamily: 'Outfit_400Regular', fontSize: 10, lineHeight: 15, marginTop: 2 },
  imageBox: { height: 220, borderRadius: 18, borderWidth: 2, borderStyle: 'dashed', overflow: 'hidden' },
  imagePreview: { width: '100%', height: '100%' },
  imageOverlay: { position: 'absolute', bottom: 0, left: 0, right: 0, height: 56, justifyContent: 'flex-end', alignItems: 'flex-end', paddingRight: 12, paddingBottom: 10 },
  changePhotoBtn: { flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: 'rgba(0,0,0,0.4)', paddingHorizontal: 10, paddingVertical: 6, borderRadius: 12 },
  changePhotoText: { fontFamily: 'Outfit_600SemiBold', fontSize: 11, color: '#FFF' },
  imageEmpty: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 7, paddingHorizontal: 24 },
  cameraIconWrap: { width: 72, height: 72, borderRadius: 22, alignItems: 'center', justifyContent: 'center', marginBottom: 3 },
  imageEmptyTitle: { fontFamily: 'Outfit_700Bold', fontSize: 16 },
  imageEmptyText: { fontFamily: 'Outfit_400Regular', fontSize: 12, textAlign: 'center' },
  formMessage: { flexDirection: 'row', alignItems: 'flex-start', gap: 8, borderWidth: 1, borderRadius: 14, padding: 11, marginTop: -8 },
  formMessageText: { flex: 1, fontFamily: 'Outfit_400Regular', fontSize: 11, lineHeight: 16 },
  labelRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 },
  label: { fontFamily: 'Outfit_600SemiBold', fontSize: 12, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 8 },
  requiredLabel: { fontFamily: 'Outfit_700Bold', fontSize: 9, letterSpacing: 0.7, marginBottom: 8 },
  optionalLabel: { fontFamily: 'Outfit_600SemiBold', fontSize: 9, letterSpacing: 0.4 },
  input: { borderRadius: 14, borderWidth: 1, paddingHorizontal: 16, paddingVertical: 14, fontFamily: 'Outfit_400Regular', fontSize: 15 },
  textArea: { minHeight: 80, textAlignVertical: 'top' },
  chipRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, borderWidth: 1 },
  chipText: { fontFamily: 'Outfit_500Medium', fontSize: 13 },
  colorRow: { flexDirection: 'row', gap: 14, paddingRight: 20 },
  colorItem: { alignItems: 'center', gap: 4 },
  colorSwatch: { width: 36, height: 36, borderRadius: 18 },
  colorName: { fontFamily: 'Outfit_400Regular', fontSize: 10 },
  bottomSave: { borderRadius: 17, overflow: 'hidden', marginTop: 2, shadowColor: '#C17F59', shadowOffset: { width: 0, height: 5 }, shadowOpacity: 0.25, shadowRadius: 10, elevation: 5 },
  bottomSaveGradient: { minHeight: 54, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingHorizontal: 18 },
  bottomSaveText: { fontFamily: 'Outfit_700Bold', fontSize: 14, color: '#FFF' },
});
