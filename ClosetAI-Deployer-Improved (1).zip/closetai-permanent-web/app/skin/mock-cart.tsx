import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import React from "react";
import { Alert, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

import { useMockCommerce } from "@/contexts/MockCommerceContext";
import type { MockCartLine } from "@/lib/mock-commerce-cart";
import { useTheme } from "@/lib/useTheme";

function lineAccent(line: MockCartLine, colors: any) {
  if (line.availability === "out_of_stock") return colors.textTertiary;
  if (line.availability === "low_stock") return colors.warning;
  return colors.success;
}

function lineStockLabel(line: MockCartLine) {
  if (line.availability === "out_of_stock") return "Mock stock unavailable";
  if (line.availability === "low_stock") return `Low mock stock · ${line.availableQuantity} left`;
  return `Mock stock · ${line.availableQuantity} available`;
}

export default function MockCartScreen() {
  const { colors } = useTheme();
  const { cart, itemCount, subtotal, isReady, setItemQuantity, removeItem, clearCart } = useMockCommerce();
  const [notice, setNotice] = React.useState<string | null>(null);
  const [updatingProductId, setUpdatingProductId] = React.useState<string | null>(null);

  const updateQuantity = async (line: MockCartLine, nextQuantity: number) => {
    setUpdatingProductId(line.productId);
    try {
      const result = nextQuantity <= 0
        ? await removeItem(line.productId)
        : await setItemQuantity(line.productId, nextQuantity);
      setNotice(result.message);
    } catch {
      setNotice("The prototype cart could not be updated. Please try again.");
    } finally {
      setUpdatingProductId(null);
    }
  };

  const removeLine = (line: MockCartLine) => {
    Alert.alert("Remove mock item?", `${line.title} will be removed from this local prototype cart.`, [
      { text: "Keep item", style: "cancel" },
      { text: "Remove", style: "destructive", onPress: () => { removeItem(line.productId).then((result) => setNotice(result.message)).catch(() => setNotice("The prototype cart could not be updated.")); } },
    ]);
  };

  const confirmClear = () => {
    Alert.alert("Clear mock cart?", "This removes all local prototype lines. It does not cancel or change a real order.", [
      { text: "Keep cart", style: "cancel" },
      { text: "Clear cart", style: "destructive", onPress: () => { clearCart().then(() => setNotice("Mock cart cleared.")).catch(() => setNotice("The prototype cart could not be cleared.")); } },
    ]);
  };

  const beginMockCheckout = () => {
    const hasUnavailableLine = cart.lines.some((line) => line.availability === "out_of_stock");
    if (hasUnavailableLine) {
      Alert.alert("Mock checkout paused", "Remove unavailable fictional lines before continuing. No payment, order, reservation, or external contact occurred.");
      return;
    }
    router.push("/skin/mock-checkout");
  };

  return (
    <View style={[styles.page, { backgroundColor: colors.background }]}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <Pressable onPress={() => router.back()} hitSlop={10} accessibilityRole="button" accessibilityLabel="Go back">
            <Ionicons name="chevron-back" size={25} color={colors.text} />
          </Pressable>
          <View style={styles.headerText}><Text style={[styles.eyebrow, { color: colors.tint }]}>CLOSET A.I. · PROTOTYPE</Text><Text style={[styles.title, { color: colors.text }]}>Mock Cart</Text></View>
          <View style={[styles.cartIcon, { backgroundColor: colors.tint + "16" }]}><Ionicons name="bag-handle-outline" size={19} color={colors.tint} /></View>
        </View>

        <View style={[styles.banner, { backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]}>
          <Ionicons name="flask-outline" size={18} color={colors.tint} />
          <View style={styles.flex}><Text style={[styles.bannerTitle, { color: colors.text }]}>Prototype cart · no payment</Text><Text style={[styles.bannerText, { color: colors.textSecondary }]}>Prices, inventory, cart, and checkout are fictional test data. No real order or payment can be created here.</Text></View>
        </View>

        {!isReady ? <View style={[styles.empty, { backgroundColor: colors.surface, borderColor: colors.border }]}><Text style={[styles.emptyText, { color: colors.textSecondary }]}>Loading your local prototype cart…</Text></View> : cart.lines.length === 0 ? (
          <View style={[styles.empty, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Ionicons name="bag-outline" size={29} color={colors.tint} />
            <Text style={[styles.emptyTitle, { color: colors.text }]}>Your mock cart is empty</Text>
            <Text style={[styles.emptyText, { color: colors.textSecondary }]}>Add a recommended product to test the local cart and inventory flow. No transaction will occur.</Text>
            <Pressable onPress={() => router.push("/skin/products")} style={[styles.primaryButton, { backgroundColor: colors.text }]} accessibilityRole="button"><Text style={[styles.primaryButtonText, { color: colors.background }]}>Browse Product Recommendations</Text></Pressable>
          </View>
        ) : (
          <>
            <View style={styles.summaryRow}><Text style={[styles.summaryText, { color: colors.textSecondary }]}>{itemCount} mock item{itemCount === 1 ? "" : "s"}</Text><Pressable onPress={confirmClear} accessibilityRole="button"><Text style={[styles.clearText, { color: colors.error }]}>Clear mock cart</Text></Pressable></View>
            {cart.lines.map((line) => {
              const accent = lineAccent(line, colors);
              const unavailable = line.availability === "out_of_stock";
              const atLimit = line.quantity >= line.availableQuantity;
              const updating = updatingProductId === line.productId;
              return <View key={line.productId} style={[styles.lineCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
                <View style={styles.lineHead}><View style={styles.flex}><Text style={[styles.lineTitle, { color: colors.text }]}>{line.title}</Text><Text style={[styles.mockPrice, { color: colors.textSecondary }]}>MOCK PRICE · ${line.unitPrice.toFixed(2)} USD each</Text></View><Text style={[styles.lineTotal, { color: colors.text }]}>${(line.unitPrice * line.quantity).toFixed(2)}</Text></View>
                <View style={[styles.stockBadge, { backgroundColor: accent + "18" }]}><Text style={[styles.stockText, { color: accent }]}>{lineStockLabel(line)}</Text></View>
                {unavailable && <Text style={[styles.unavailableText, { color: colors.warning }]}>This saved prototype line is unavailable. You can remove it; it cannot proceed to checkout.</Text>}
                <View style={styles.lineActions}>
                  <View style={[styles.quantityControl, { borderColor: colors.border }]}>
                    <Pressable onPress={() => updateQuantity(line, line.quantity - 1)} disabled={updating} style={styles.quantityButton} accessibilityRole="button" accessibilityLabel={line.quantity === 1 ? `Remove ${line.title}` : `Decrease ${line.title} quantity`}><Ionicons name={line.quantity === 1 ? "trash-outline" : "remove"} size={16} color={colors.text} /></Pressable>
                    <Text style={[styles.quantityValue, { color: colors.text }]}>{line.quantity}</Text>
                    <Pressable onPress={() => updateQuantity(line, line.quantity + 1)} disabled={updating || unavailable || atLimit} style={[styles.quantityButton, { opacity: unavailable || atLimit ? 0.35 : 1 }]} accessibilityRole="button" accessibilityState={{ disabled: unavailable || atLimit }} accessibilityLabel={atLimit ? "Mock inventory limit reached" : `Increase ${line.title} quantity`}><Ionicons name="add" size={16} color={colors.text} /></Pressable>
                  </View>
                  <Pressable onPress={() => removeLine(line)} disabled={updating} style={[styles.removeButton, { borderColor: colors.border }]} accessibilityRole="button"><Text style={[styles.removeText, { color: colors.text }]}>Remove</Text></Pressable>
                </View>
              </View>;
            })}
            {notice && <View style={[styles.notice, { backgroundColor: colors.surfaceSecondary }]}><Text style={[styles.noticeText, { color: colors.textSecondary }]}>{notice}</Text></View>}
            <View style={[styles.orderCard, { backgroundColor: colors.surface, borderColor: colors.border }]}> 
              <View style={styles.totalRow}><Text style={[styles.totalLabel, { color: colors.text }]}>Mock subtotal</Text><Text style={[styles.totalValue, { color: colors.text }]}>${subtotal.toFixed(2)} USD</Text></View>
              <Text style={[styles.orderNote, { color: colors.textSecondary }]}>Taxes, shipping, discounts, fulfillment, payment, address collection, and real brand inventory are not calculated or contacted in this prototype.</Text>
              <Pressable onPress={beginMockCheckout} style={[styles.checkoutButton, { backgroundColor: colors.text }]} accessibilityRole="button" accessibilityLabel="Begin multi-step mock checkout" accessibilityHint="Opens a fictional prototype flow. It does not collect payment or address data, create an order, or contact a store."><Text style={[styles.checkoutText, { color: colors.background }]}>Simulate Mock Checkout</Text>
</Pressable>
              <Pressable onPress={() => router.push("/skin/products")} style={[styles.continueButton, { borderColor: colors.border }]} accessibilityRole="button"><Text style={[styles.continueText, { color: colors.text }]}>Continue Browsing</Text></Pressable>
            </View>
          </>
        )}
        <Text style={[styles.disclosure, { color: colors.textTertiary }]}>{cart.disclosure}</Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1 }, content: { padding: 20, paddingBottom: 48 }, flex: { flex: 1 }, header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 17 }, headerText: { alignItems: "center" }, eyebrow: { fontFamily: "Outfit_700Bold", fontSize: 8, letterSpacing: 1 }, title: { fontFamily: "Outfit_700Bold", fontSize: 19 }, cartIcon: { width: 34, height: 34, borderRadius: 11, alignItems: "center", justifyContent: "center" }, banner: { flexDirection: "row", alignItems: "flex-start", gap: 9, borderWidth: 1, borderRadius: 15, padding: 12, marginBottom: 16 }, bannerTitle: { fontFamily: "Outfit_700Bold", fontSize: 12 }, bannerText: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 14, marginTop: 2 }, empty: { alignItems: "center", borderWidth: 1, borderRadius: 18, padding: 23 }, emptyTitle: { fontFamily: "Outfit_700Bold", fontSize: 16, marginTop: 10 }, emptyText: { fontFamily: "Outfit_400Regular", fontSize: 11, lineHeight: 16, textAlign: "center", marginTop: 6 }, primaryButton: { borderRadius: 12, paddingHorizontal: 12, paddingVertical: 10, marginTop: 14 }, primaryButtonText: { fontFamily: "Outfit_700Bold", fontSize: 11 }, summaryRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 9 }, summaryText: { fontFamily: "Outfit_500Medium", fontSize: 11 }, clearText: { fontFamily: "Outfit_600SemiBold", fontSize: 11 }, lineCard: { borderWidth: 1, borderRadius: 16, padding: 13, marginBottom: 9 }, lineHead: { flexDirection: "row", alignItems: "flex-start", gap: 9 }, lineTitle: { fontFamily: "Outfit_600SemiBold", fontSize: 13 }, mockPrice: { fontFamily: "Outfit_400Regular", fontSize: 9, marginTop: 3 }, lineTotal: { fontFamily: "Outfit_700Bold", fontSize: 13 }, stockBadge: { alignSelf: "flex-start", borderRadius: 9, paddingHorizontal: 7, paddingVertical: 4, marginTop: 9 }, stockText: { fontFamily: "Outfit_600SemiBold", fontSize: 9 }, unavailableText: { fontFamily: "Outfit_500Medium", fontSize: 9, lineHeight: 13, marginTop: 8 }, lineActions: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: 11 }, quantityControl: { flexDirection: "row", alignItems: "center", borderWidth: 1, borderRadius: 10, overflow: "hidden" }, quantityButton: { width: 34, minHeight: 31, alignItems: "center", justifyContent: "center" }, quantityValue: { minWidth: 28, textAlign: "center", fontFamily: "Outfit_700Bold", fontSize: 12 }, removeButton: { borderWidth: 1, borderRadius: 9, paddingHorizontal: 10, paddingVertical: 8 }, removeText: { fontFamily: "Outfit_600SemiBold", fontSize: 10 }, notice: { borderRadius: 11, padding: 10, marginBottom: 9 }, noticeText: { fontFamily: "Outfit_500Medium", fontSize: 10, lineHeight: 14 }, orderCard: { borderWidth: 1, borderRadius: 17, padding: 14, marginTop: 4 }, totalRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" }, totalLabel: { fontFamily: "Outfit_600SemiBold", fontSize: 13 }, totalValue: { fontFamily: "Outfit_700Bold", fontSize: 17 }, orderNote: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 14, marginTop: 7 }, checkoutButton: { borderRadius: 12, alignItems: "center", paddingVertical: 11, marginTop: 13 }, checkoutText: { fontFamily: "Outfit_700Bold", fontSize: 11 }, continueButton: { borderWidth: 1, borderRadius: 12, alignItems: "center", paddingVertical: 10, marginTop: 8 }, continueText: { fontFamily: "Outfit_600SemiBold", fontSize: 11 }, disclosure: { fontFamily: "Outfit_400Regular", fontSize: 9, lineHeight: 13, marginTop: 14, textAlign: "center" },
});
