import { Ionicons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import * as ImagePicker from 'expo-image-picker';
import { LinearGradient } from 'expo-linear-gradient';
import { router, useFocusEffect } from 'expo-router';
import React from 'react';
import { Alert, Linking, Pressable, ScrollView, StyleSheet, Switch, Text, View } from 'react-native';

import { MediaStatusCard } from '@/components/ui/MediaStatusCard';
import { AR_ENVIRONMENT_CUES, AR_OVERLAY_INTENSITIES, AR_VISUAL_MODES, AR_VISUAL_PREVIEW_DISCLOSURE, type ArEnvironmentCue, type ArOverlayIntensity, type ArVisualMode } from '@/lib/ar-skin-preview';
import { FICTIONAL_AR_PREVIEW_SCENARIOS } from '@/lib/fictional-demo-scenarios';
import { realSkinProductCatalog } from '@/lib/skin-product-catalog';
import { ULTRA_LUXURY_SKIN_DISCOVERY_RECORDS, type UltraLuxurySkinDiscoveryRecord } from '@/lib/ultra-luxury-skin-discovery';
import { useTheme } from '@/lib/useTheme';

const LOCAL_TEXTURE_PREVIEW_BOUNDARY = 'It does not analyse skin, predict results, diagnose, claim efficacy, reproduce a brand formula, or show a stock model.';

const COMFORT_CUES = [
  { id: 'comfortable', title: 'Comfortable', detail: 'Keep the routine simple.' },
  { id: 'dry-feeling', title: 'Dry feeling', detail: 'Review a moisturizer category and the product label.' },
  { id: 'shiny-feeling', title: 'Shiny feeling', detail: 'Review a gentle cleanser or serum category and the product label.' },
  { id: 'not-sure', title: 'Not sure', detail: 'No inference is made; explore a basic routine category.' },
] as const;

export default function TexturePreviewScreen() {
  const { colors } = useTheme();
  const [photoUri, setPhotoUri] = React.useState<string | null>(null);
  const [consent, setConsent] = React.useState(false);
  const [selectedFinish, setSelectedFinish] = React.useState<ArVisualMode>(AR_VISUAL_MODES[1]);
  const [overlayVisible, setOverlayVisible] = React.useState(true);
  const [overlayIntensity, setOverlayIntensity] = React.useState<ArOverlayIntensity>(AR_OVERLAY_INTENSITIES[1]);
  const [selectedReference, setSelectedReference] = React.useState<UltraLuxurySkinDiscoveryRecord>(ULTRA_LUXURY_SKIN_DISCOVERY_RECORDS[0]);
  const [environmentCue, setEnvironmentCue] = React.useState<ArEnvironmentCue>(AR_ENVIRONMENT_CUES[0]);
  const [comfortCue, setComfortCue] = React.useState<(typeof COMFORT_CUES)[number]>(COMFORT_CUES[0]);
  const [photoPermissions, setPhotoPermissions] = React.useState<{ camera: boolean | null; library: boolean | null }>({ camera: null, library: null });
  const [lastPermissionSource, setLastPermissionSource] = React.useState<'camera' | 'library' | null>(null);
  const categoryReferences = React.useMemo(() => realSkinProductCatalog.filter((product) => environmentCue.preferredCategories.includes(product.category)).slice(0, 3), [environmentCue]);
  const fictionalPreviewPresets = React.useMemo(() => FICTIONAL_AR_PREVIEW_SCENARIOS.slice(-5), []);
  const previewStatus = React.useMemo(() => {
    if (!photoUri) return { title: 'No user photo selected', detail: 'Choose your own camera photo or library image. No stock model is substituted.' };
    if (!consent) return { title: 'Waiting for visual-preview consent', detail: 'Your selected photo is shown unchanged. The local overlay stays hidden until you provide consent.' };
    if (!overlayVisible) return { title: 'Original photo view active', detail: 'You are viewing your selected photo without the local cosmetic-style overlay.' };
    return { title: 'Local visual overlay ready', detail: 'The selected user photo is shown with a local interface overlay only. No product formula or treatment result is simulated.' };
  }, [photoUri, consent, overlayVisible]);

  useFocusEffect(React.useCallback(() => {
    let active = true;
    void Promise.all([ImagePicker.getCameraPermissionsAsync(), ImagePicker.getMediaLibraryPermissionsAsync()]).then(([camera, library]) => {
      if (active) setPhotoPermissions({ camera: camera.granted, library: library.granted });
    }).catch(() => {
      if (active) setPhotoPermissions({ camera: null, library: null });
    });
    return () => { active = false; };
  }, []));

  const openPhotoSettings = () => {
    void Linking.openSettings().catch(() => Alert.alert('Open settings manually', 'Photo access can be changed in your device settings. You can continue without a photo or return to product discovery.'));
  };

  const applyFictionalPreview = (scenario: (typeof FICTIONAL_AR_PREVIEW_SCENARIOS)[number]) => {
    const finish = AR_VISUAL_MODES.find((mode) => mode.id === scenario.visualModeId);
    const intensity = AR_OVERLAY_INTENSITIES.find((item) => item.id === scenario.intensityId);
    if (finish) setSelectedFinish(finish);
    if (intensity) setOverlayIntensity(intensity);
    setOverlayVisible(true);
  };

  const selectPhoto = async (source: 'camera' | 'library') => {
    setLastPermissionSource(source);
    try {
      const permission = source === 'camera' ? await ImagePicker.requestCameraPermissionsAsync() : await ImagePicker.requestMediaLibraryPermissionsAsync();
      setPhotoPermissions((current) => ({ ...current, [source]: permission.granted }));
      if (!permission.granted) {
        Alert.alert('Photo permission optional', 'You can return to the product plan without selecting a photo. ClosetAI does not substitute a stock model.', [
          { text: 'Not now', style: 'cancel' },
          { text: 'Open Settings', onPress: openPhotoSettings },
        ]);
        return;
      }
      const result = source === 'camera'
        ? await ImagePicker.launchCameraAsync({ mediaTypes: ['images'], cameraType: ImagePicker.CameraType.front, allowsEditing: true, aspect: [4, 5], quality: 0.8, exif: false })
        : await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], allowsEditing: true, aspect: [4, 5], quality: 0.8, exif: false });
      if (!result.canceled && result.assets[0]?.uri) setPhotoUri(result.assets[0].uri);
    } catch {
      Alert.alert('Photo unavailable', 'We could not open that photo source. You can try again or return to product discovery.');
    }
  };

  const canPreview = Boolean(photoUri && consent && overlayVisible);
  const openOfficialListing = (url: string) => Linking.openURL(url).catch(() => Alert.alert('Official listing unavailable', 'We could not open the manufacturer page. Please try again later.'));

  return <View style={[styles.page, { backgroundColor: colors.background }]}>
    <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} hitSlop={10} accessibilityRole="button" accessibilityLabel="Go back from cosmetic texture preview"><Ionicons name="chevron-back" size={25} color={colors.text} /></Pressable>
        <View style={styles.headerCopy}><Text style={[styles.eyebrow, { color: colors.tint }]}>CLOSET A.I. · VISUAL PREVIEW</Text><Text style={[styles.title, { color: colors.text }]}>Cosmetic texture preview</Text></View>
        <Ionicons name="color-wand-outline" size={20} color={colors.tint} />
      </View>

        <View style={[styles.notice, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Ionicons name="eye-outline" size={20} color={colors.tint} />
        <View style={styles.flex}><Text style={[styles.noticeTitle, { color: colors.text }]}>A visual finish overlay, not a product simulation</Text><Text style={[styles.body, { color: colors.textSecondary }]}>{AR_VISUAL_PREVIEW_DISCLOSURE} {LOCAL_TEXTURE_PREVIEW_BOUNDARY}</Text>
</View>
      </View>

      <MediaStatusCard kind="local-only" title={previewStatus.title} detail={previewStatus.detail} tint={colors.tint} surface={colors.surfaceSecondary} border={colors.border} />

      {!photoUri ? <View style={[styles.pickCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <Ionicons name="person-outline" size={29} color={colors.tint} />
        <Text style={[styles.pickTitle, { color: colors.text }]}>Choose your own photo</Text>
        <Text style={[styles.body, { color: colors.textSecondary }]}>A photo is optional. We never insert a model image. The selected image stays in this local preview until you clear it or leave the screen; ClosetAI does not upload it or save a history entry.</Text>
        {lastPermissionSource && photoPermissions[lastPermissionSource] === false && <View style={[styles.permissionRecovery, { backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]} accessibilityLiveRegion="polite"><Ionicons name="lock-closed-outline" size={16} color={colors.tint} /><View style={styles.flex}><Text style={[styles.permissionRecoveryTitle, { color: colors.text }]}>Photo access is currently unavailable</Text><Text style={[styles.body, { color: colors.textSecondary }]}>Return to device Settings to restore {lastPermissionSource === 'camera' ? 'camera' : 'photo library'} access, or continue without a photo. No stock model is substituted.</Text><Pressable onPress={openPhotoSettings} accessibilityRole="button" accessibilityLabel="Open photo access settings" accessibilityHint="Opens device settings to restore optional photo access." style={styles.permissionRecoveryButton}><Text style={[styles.permissionRecoveryButtonText, { color: colors.tint }]}>Open Settings</Text></Pressable></View></View>}
        <Pressable onPress={() => selectPhoto('camera')} style={[styles.primaryButton, { backgroundColor: colors.text }]} accessibilityRole="button" accessibilityLabel="Take my photo for local cosmetic texture preview"><Ionicons name="camera-outline" size={17} color={colors.background} /><Text style={[styles.primaryButtonText, { color: colors.background }]}>Use my camera</Text></Pressable>
        <Pressable onPress={() => selectPhoto('library')} style={[styles.secondaryButton, { borderColor: colors.border }]} accessibilityRole="button" accessibilityLabel="Choose my photo for local cosmetic texture preview"><Ionicons name="images-outline" size={17} color={colors.tint} /><Text style={[styles.secondaryButtonText, { color: colors.text }]}>Choose my photo</Text></Pressable>
      </View> : <>
        <View style={styles.previewFrame} accessibilityLabel={canPreview ? `Your selected photo with ${selectedFinish.title} visual finish overlay` : 'Your selected photo. Consent is required before the visual finish overlay appears.'}>
          <Image source={{ uri: photoUri }} style={styles.photo} contentFit="cover" />
          {canPreview && <><LinearGradient colors={selectedFinish.overlay} locations={[0, 0.54, 1]} style={[StyleSheet.absoluteFill, { opacity: overlayIntensity.opacity }]} pointerEvents="none" /><View style={[styles.highlight, { opacity: overlayIntensity.opacity }]} pointerEvents="none" /><Text style={styles.previewPill}>{selectedFinish.title} · {overlayIntensity.title.toLowerCase()} visual overlay</Text></>}
        </View>
        <MediaStatusCard kind="user-photo" title="Your selected photo" detail="Used only for this local visual preview. It is not sent to a brand, included in cart or checkout, or saved in Skin Care history." tint={colors.tint} surface={colors.surfaceSecondary} border={colors.border} />
        <Pressable onPress={() => { setPhotoUri(null); setConsent(false); setOverlayVisible(true); }} style={[styles.secondaryButton, { borderColor: colors.border }]} accessibilityRole="button" accessibilityLabel="Clear my selected photo"><Ionicons name="trash-outline" size={16} color={colors.text} /><Text style={[styles.secondaryButtonText, { color: colors.text }]}>Clear photo</Text></Pressable>
      </>}

      <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <View style={styles.switchRow}><View style={styles.flex}><Text style={[styles.cardTitle, { color: colors.text }]}>Visual-preview consent</Text><Text style={[styles.body, { color: colors.textSecondary }]}>I understand that this is a cosmetic-style visualization only, not a depiction of product use, efficacy, treatment, diagnosis, or a brand formula.</Text></View><Switch value={consent} onValueChange={setConsent} accessibilityRole="switch" accessibilityLabel="Consent to cosmetic texture visual preview" accessibilityHint="Required before the finish overlay is shown over your selected photo." /></View>
      </View>

      <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <View style={styles.switchRow}><View style={styles.flex}><Text style={[styles.cardTitle, { color: colors.text }]}>Compare original and overlay</Text><Text style={[styles.body, { color: colors.textSecondary }]}>{photoUri && consent ? (overlayVisible ? 'Overlay view is active. Turn this off to inspect your original selected photo.' : 'Original-photo view is active. Turn this on to inspect the local cosmetic-style overlay.') : 'Choose a photo and provide visual-preview consent before comparison becomes available.'}</Text></View><Switch value={overlayVisible} disabled={!photoUri || !consent} onValueChange={setOverlayVisible} accessibilityRole="switch" accessibilityState={{ disabled: !photoUri || !consent, checked: overlayVisible }} accessibilityLabel="Show local cosmetic overlay for comparison" accessibilityHint="Switch between your original selected photo and a local interface overlay. This does not compare treatment results." /></View>
        <View style={styles.intensityRow} accessibilityRole="radiogroup" accessibilityLabel="Local overlay intensity">{AR_OVERLAY_INTENSITIES.map((intensity) => { const selected = intensity.id === overlayIntensity.id; return <Pressable key={intensity.id} onPress={() => setOverlayIntensity(intensity)} accessibilityRole="radio" accessibilityState={{ selected }} accessibilityLabel={`${intensity.title}: ${intensity.description}${selected ? ', selected' : ''}`} style={[styles.intensityChip, { borderColor: selected ? colors.tint : colors.border, backgroundColor: selected ? `${colors.tint}12` : colors.surfaceSecondary }]}><Text style={[styles.intensityText, { color: selected ? colors.tint : colors.text }]}>{intensity.title}</Text></Pressable>; })}</View>
      </View>

      <Text style={[styles.sectionLabel, { color: colors.text }]}>Choose a neutral finish overlay</Text>
      <View style={styles.chipRow} accessibilityRole="radiogroup" accessibilityLabel="Cosmetic visual finish options">{AR_VISUAL_MODES.filter((mode) => mode.id !== 'guide').map((preset) => { const selected = preset.id === selectedFinish.id; return <Pressable key={preset.id} onPress={() => setSelectedFinish(preset)} accessibilityRole="radio" accessibilityState={{ selected }} accessibilityLabel={`${preset.title}, ${preset.description}${selected ? ', selected' : ''}`} style={[styles.chip, { borderColor: selected ? colors.tint : colors.border, backgroundColor: selected ? `${colors.tint}12` : colors.surface }]}><Text style={[styles.chipTitle, { color: selected ? colors.tint : colors.text }]}>{preset.title}</Text><Text style={[styles.chipDescription, { color: colors.textSecondary }]}>{preset.description}</Text></Pressable>; })}</View>

      <Text style={[styles.sectionLabel, { color: colors.text }]}>Local environment and comfort context</Text>
      <Text style={[styles.body, { color: colors.textSecondary }]}>These are optional session-only cues, not live weather measurement or a health assessment. They change only the product categories shown below.</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.referenceRow} accessibilityRole="radiogroup" accessibilityLabel="Local environment context">{AR_ENVIRONMENT_CUES.map((cue) => { const selected = cue.id === environmentCue.id; return <Pressable key={cue.id} onPress={() => setEnvironmentCue(cue)} accessibilityRole="radio" accessibilityState={{ selected }} accessibilityLabel={`${cue.title}: ${cue.description}${selected ? ', selected' : ''}`} style={[styles.contextChip, { borderColor: selected ? colors.tint : colors.border, backgroundColor: selected ? `${colors.tint}12` : colors.surface }]}><Text style={[styles.chipTitle, { color: selected ? colors.tint : colors.text }]}>{cue.title}</Text><Text style={[styles.chipDescription, { color: colors.textSecondary }]}>{cue.description}</Text></Pressable>; })}</ScrollView>
      <View style={styles.comfortRow} accessibilityRole="radiogroup" accessibilityLabel="Daily skin comfort check-in">{COMFORT_CUES.map((cue) => { const selected = cue.id === comfortCue.id; return <Pressable key={cue.id} onPress={() => setComfortCue(cue)} accessibilityRole="radio" accessibilityState={{ selected }} accessibilityLabel={`${cue.title}: ${cue.detail}${selected ? ', selected' : ''}`} style={[styles.comfortChip, { borderColor: selected ? colors.tint : colors.border, backgroundColor: selected ? `${colors.tint}12` : colors.surface }]}><Text style={[styles.comfortText, { color: selected ? colors.tint : colors.textSecondary }]}>{cue.title}</Text></Pressable>; })}</View>

      <View style={[styles.contextSummary, { backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]}><Ionicons name="leaf-outline" size={16} color={colors.tint} /><View style={styles.flex}><Text style={[styles.cardTitle, { color: colors.text }]}>Session cue</Text><Text style={[styles.body, { color: colors.textSecondary }]}>{environmentCue.title} · {comfortCue.title}. {environmentCue.description} {comfortCue.detail}</Text></View></View>

      <Text style={[styles.sectionLabel, { color: colors.text }]}>Fictional Demo Mode preview presets</Text>
      <Text style={[styles.body, { color: colors.textSecondary }]}>These presets only adjust local visual controls. Choose your own photo and provide consent before any overlay appears; no stock model or provider-generated face is used.</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.referenceRow} accessibilityRole="radiogroup" accessibilityLabel="Fictional local AR preview presets">
        {fictionalPreviewPresets.map((scenario) => (
          <Pressable key={scenario.id} onPress={() => applyFictionalPreview(scenario)} accessibilityRole="button" accessibilityLabel={`Apply fictional preview preset ${scenario.persona} ${scenario.title}`} accessibilityHint="Changes only the local visual finish and intensity controls; it does not analyze your photo or predict an outcome." style={[styles.contextChip, { borderColor: colors.border, backgroundColor: colors.surface }]}>
            <Text style={[styles.chipTitle, { color: colors.text }]}>{scenario.persona} · {scenario.title}</Text>
            <Text style={[styles.chipDescription, { color: colors.textSecondary }]}>{scenario.context}</Text>
          </Pressable>
        ))}
      </ScrollView>

      <Text style={[styles.sectionLabel, { color: colors.text }]}>Official product-category references</Text>
      <Text style={[styles.body, { color: colors.textSecondary }]}>These category links align with the local cue only. They are not personalized product recommendations, treatment guidance, suitability decisions, or live availability data.</Text>
      <View style={styles.productReferenceList}>{categoryReferences.map((product) => <Pressable key={product.id} onPress={() => openOfficialListing(product.officialUrl)} accessibilityRole="link" accessibilityLabel={`Open official manufacturer page for ${product.name}`} accessibilityHint="Opens an external manufacturer page. Review the current product label, ingredients, and availability before use or purchase." style={[styles.productReference, { backgroundColor: colors.surface, borderColor: colors.border }]}><View style={[styles.productReferenceIcon, { backgroundColor: `${colors.tint}12` }]}><Ionicons name={product.category === 'SPF' ? 'sunny-outline' : product.category === 'Cleanser' ? 'water-outline' : product.category === 'Serum' ? 'beaker-outline' : 'heart-outline'} size={16} color={colors.tint} /></View><View style={styles.flex}><Text style={[styles.productReferenceTitle, { color: colors.text }]}>{product.name}</Text><Text style={[styles.productReferenceMeta, { color: colors.textSecondary }]}>{product.brand} · {product.category} · Manufacturer product page</Text></View><Ionicons name="open-outline" size={15} color={colors.tint} /></Pressable>)}</View>

      <Text style={[styles.sectionLabel, { color: colors.text }]}>Optional product-exploration label</Text>
      <Text style={[styles.body, { color: colors.textSecondary }]}>Selecting an external reference only labels this local preview for browsing context. It does not change the overlay, recreate a product texture or formula, determine suitability, or show a treatment result.</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.referenceRow} accessibilityRole="radiogroup" accessibilityLabel="Ultra-luxury external discovery references">{ULTRA_LUXURY_SKIN_DISCOVERY_RECORDS.map((reference) => { const selected = reference.id === selectedReference.id; return <Pressable key={reference.id} onPress={() => setSelectedReference(reference)} accessibilityRole="radio" accessibilityState={{ selected }} accessibilityLabel={`${reference.brand} ${reference.productName}${selected ? ', selected' : ''}`} style={[styles.referenceChip, { borderColor: selected ? colors.tint : colors.border, backgroundColor: selected ? `${colors.tint}12` : colors.surface }]}><Text style={[styles.referenceBrand, { color: colors.tint }]}>{reference.brand}</Text><Text numberOfLines={2} style={[styles.referenceName, { color: colors.text }]}>{reference.productName}</Text></Pressable>; })}</ScrollView>
      <Text style={[styles.referenceDisclosure, { color: colors.textTertiary }]}>Selected external reference: {selectedReference.officialSourceLabel}. Cart and checkout values remain fictional prototype data; this preview is not a product simulation and never opens the external product page or communicates with a brand.</Text>
    </ScrollView>
  </View>;
}

const styles = StyleSheet.create({
  page: { flex: 1 }, content: { padding: 20, paddingBottom: 48 }, header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 17 }, headerCopy: { alignItems: 'center' }, eyebrow: { fontFamily: 'Outfit_700Bold', fontSize: 8, letterSpacing: 1 }, title: { fontFamily: 'Outfit_700Bold', fontSize: 18 }, flex: { flex: 1 }, notice: { flexDirection: 'row', gap: 10, borderWidth: 1, borderRadius: 17, padding: 13, marginBottom: 12 }, noticeTitle: { fontFamily: 'Outfit_700Bold', fontSize: 13 }, body: { fontFamily: 'Outfit_400Regular', fontSize: 10, lineHeight: 15, marginTop: 4 }, pickCard: { borderWidth: 1, borderRadius: 18, alignItems: 'center', padding: 20, marginBottom: 12 }, pickTitle: { fontFamily: 'Outfit_700Bold', fontSize: 17, marginTop: 8 }, permissionRecovery: { alignSelf: 'stretch', flexDirection: 'row', gap: 8, borderWidth: 1, borderRadius: 13, padding: 10, marginTop: 12 }, permissionRecoveryTitle: { fontFamily: 'Outfit_700Bold', fontSize: 11 }, permissionRecoveryButton: { alignSelf: 'flex-start', paddingVertical: 5, paddingRight: 5 }, permissionRecoveryButtonText: { fontFamily: 'Outfit_700Bold', fontSize: 10 }, primaryButton: { alignSelf: 'stretch', minHeight: 45, borderRadius: 13, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 7, marginTop: 13 }, primaryButtonText: { fontFamily: 'Outfit_700Bold', fontSize: 12 }, secondaryButton: { alignSelf: 'stretch', minHeight: 43, borderWidth: 1, borderRadius: 13, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 7, marginTop: 8 }, secondaryButtonText: { fontFamily: 'Outfit_700Bold', fontSize: 12 }, previewFrame: { height: 380, overflow: 'hidden', borderRadius: 20, marginBottom: 11, backgroundColor: '#111' }, photo: { width: '100%', height: '100%' }, highlight: { position: 'absolute', width: '120%', height: '28%', top: '10%', left: '-10%', borderRadius: 999, backgroundColor: 'rgba(255,255,255,0.14)', transform: [{ rotate: '-16deg' }] }, previewPill: { position: 'absolute', bottom: 12, alignSelf: 'center', backgroundColor: 'rgba(0,0,0,0.58)', color: '#fff', borderRadius: 99, overflow: 'hidden', paddingHorizontal: 9, paddingVertical: 5, fontFamily: 'Outfit_700Bold', fontSize: 10 }, card: { borderWidth: 1, borderRadius: 16, padding: 13, marginTop: 12 }, switchRow: { flexDirection: 'row', alignItems: 'center', gap: 10 }, intensityRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 7, marginTop: 11 }, intensityChip: { borderWidth: 1, borderRadius: 10, paddingHorizontal: 10, paddingVertical: 7 }, intensityText: { fontFamily: 'Outfit_700Bold', fontSize: 10 }, cardTitle: { fontFamily: 'Outfit_700Bold', fontSize: 13 }, sectionLabel: { fontFamily: 'Outfit_700Bold', fontSize: 12, marginTop: 16, marginBottom: 7 }, chipRow: { gap: 8 }, chip: { borderWidth: 1, borderRadius: 13, padding: 11 }, chipTitle: { fontFamily: 'Outfit_700Bold', fontSize: 12 }, chipDescription: { fontFamily: 'Outfit_400Regular', fontSize: 10, lineHeight: 14, marginTop: 3 }, referenceRow: { gap: 8, marginTop: 9 }, contextChip: { width: 162, minHeight: 76, borderWidth: 1, borderRadius: 13, padding: 10 }, comfortRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 7, marginTop: 9 }, comfortChip: { borderWidth: 1, borderRadius: 12, paddingHorizontal: 10, paddingVertical: 8 }, comfortText: { fontFamily: 'Outfit_600SemiBold', fontSize: 10 }, contextSummary: { flexDirection: 'row', gap: 8, borderWidth: 1, borderRadius: 13, padding: 11, marginTop: 9 }, productReferenceList: { gap: 8, marginTop: 9 }, productReference: { flexDirection: 'row', alignItems: 'center', gap: 9, borderWidth: 1, borderRadius: 13, padding: 11 }, productReferenceIcon: { width: 31, height: 31, borderRadius: 10, alignItems: 'center', justifyContent: 'center' }, productReferenceTitle: { fontFamily: 'Outfit_700Bold', fontSize: 11 }, productReferenceMeta: { fontFamily: 'Outfit_400Regular', fontSize: 9, lineHeight: 12, marginTop: 2 }, referenceChip: { width: 145, minHeight: 72, borderWidth: 1, borderRadius: 13, padding: 10 }, referenceBrand: { fontFamily: 'Outfit_700Bold', fontSize: 9 }, referenceName: { fontFamily: 'Outfit_600SemiBold', fontSize: 11, lineHeight: 14, marginTop: 3 }, referenceDisclosure: { fontFamily: 'Outfit_400Regular', fontSize: 9, lineHeight: 13, marginTop: 10 },
});
