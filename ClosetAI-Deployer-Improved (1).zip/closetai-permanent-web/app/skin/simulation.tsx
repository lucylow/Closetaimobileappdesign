import { Image } from "expo-image";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import React from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

import { useSelfieScan } from "@/contexts/SelfieScanContext";
import { createSkinSimulation } from "@/lib/skin-simulation";
import { selectedImageUriToBase64 } from "@/lib/selected-image-base64";
import { useTheme } from "@/lib/useTheme";
import { SKIN_SIMULATION_CONCERNS, SKIN_SIMULATION_DISCLOSURE, type SkinSimulationAdjustments, type SkinSimulationConcern } from "@shared/skin-simulation";

const labels: Record<SkinSimulationConcern, string> = {
  wrinkle: "Fine lines", radiance: "Radiance", oiliness: "Oil balance", acne: "Blemishes", eye_bags: "Eye bags", dark_circle: "Dark circles", spots: "Spots", pores: "Pores", texture: "Texture", redness: "Redness",
};

function nextIntensity(value: number | undefined): number {
  if (!value) return 0.25;
  if (value < 0.5) return 0.5;
  if (value < 0.75) return 0.75;
  return 0;
}

function intensityLabel(value: number | undefined): string {
  if (!value) return "Off";
  if (value <= 0.25) return "Subtle";
  if (value <= 0.5) return "Balanced";
  return "Strong";
}

export default function SkinSimulationScreen() {
  const { colors } = useTheme();
  const { asset } = useSelfieScan();
  const [adjustments, setAdjustments] = React.useState<SkinSimulationAdjustments>({});
  const [busy, setBusy] = React.useState(false);
  const [resultUrl, setResultUrl] = React.useState<string | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  const selectedCount = Object.values(adjustments).filter((value) => (value || 0) > 0).length;

  const updateAdjustment = (concern: SkinSimulationConcern) => {
    setResultUrl(null);
    setError(null);
    setAdjustments((current) => ({ ...current, [concern]: nextIntensity(current[concern]) }));
  };

  const generate = async () => {
    if (!asset || selectedCount === 0) return;
    setBusy(true);
    setError(null);
    setResultUrl(null);
    try {
      const imageBase64 = await selectedImageUriToBase64(asset.uri);
      const result = await createSkinSimulation(imageBase64, adjustments);
      setResultUrl(result.resultUrl);
    } catch (simulationError) {
      setError(simulationError instanceof Error ? simulationError.message : "We could not create a cosmetic preview. No generated image was shown.");
    } finally {
      setBusy(false);
    }
  };

  return <View style={[styles.page, { backgroundColor: colors.background }]}><ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
    <View style={styles.header}><Pressable onPress={() => router.back()} hitSlop={10} accessibilityRole="button" accessibilityLabel="Go back"><Ionicons name="chevron-back" size={25} color={colors.text} /></Pressable><View style={styles.headerCopy}><Text style={[styles.eyebrow, { color: colors.tint }]}>CLOSET A.I. · COSMETIC PREVIEW</Text><Text style={[styles.title, { color: colors.text }]}>Explore a gentle visual preview</Text></View><Ionicons name="sparkles-outline" size={21} color={colors.tint} /></View>

    <View style={[styles.notice, { backgroundColor: colors.surfaceSecondary }]}><Ionicons name="information-circle-outline" size={17} color={colors.tint} /><Text style={[styles.noticeText, { color: colors.textSecondary }]}>{SKIN_SIMULATION_DISCLOSURE}</Text></View>

    {!asset ? <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}><Ionicons name="camera-outline" size={27} color={colors.tint} /><Text style={[styles.cardTitle, { color: colors.text }]}>Choose a selfie first</Text><Text style={[styles.body, { color: colors.textSecondary }]}>A selected, front-facing selfie is required for an optional live cosmetic preview. No stock image or demo simulation will be substituted.</Text><Pressable onPress={() => router.push("/skin/selfie-scan")} style={[styles.primaryButton, { backgroundColor: colors.text }]} accessibilityRole="button" accessibilityLabel="Choose a selfie for cosmetic preview"><Text style={[styles.primaryButtonText, { color: colors.background }]}>Choose a selfie</Text></Pressable></View> : <>
      <View style={styles.compareRow}><View style={styles.imageColumn}><Image source={{ uri: asset.uri }} style={styles.image} contentFit="cover" /><Text style={[styles.imageCaption, { color: colors.textSecondary }]}>Selected selfie</Text></View><View style={styles.imageColumn}>{resultUrl ? <Image source={{ uri: resultUrl }} style={styles.image} contentFit="cover" /> : <View style={[styles.emptyPreview, { backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]}><Ionicons name="sparkles-outline" size={24} color={colors.tint} /><Text style={[styles.emptyPreviewText, { color: colors.textSecondary }]}>Your generated preview appears here only after a successful live request.</Text></View>}<Text style={[styles.imageCaption, { color: colors.textSecondary }]}>Cosmetic visualization</Text></View></View>

      <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}><Text style={[styles.cardTitle, { color: colors.text }]}>Choose what to visualize</Text><Text style={[styles.body, { color: colors.textSecondary }]}>Tap a concern to cycle through Subtle, Balanced, Strong, and Off. Start low; this is an adjustable visual preference, not a treatment plan.</Text><View style={styles.adjustmentGrid}>{SKIN_SIMULATION_CONCERNS.map((concern) => { const value = adjustments[concern]; const active = Boolean(value); return <Pressable key={concern} onPress={() => updateAdjustment(concern)} style={[styles.adjustment, { borderColor: active ? colors.tint : colors.border, backgroundColor: active ? `${colors.tint}12` : colors.background }]} accessibilityRole="button" accessibilityLabel={`${labels[concern]}: ${intensityLabel(value)}. Tap to change intensity`}><Text style={[styles.adjustmentLabel, { color: colors.text }]}>{labels[concern]}</Text><Text style={[styles.adjustmentValue, { color: active ? colors.tint : colors.textTertiary }]}>{intensityLabel(value)}</Text></Pressable>; })}</View></View>

      <Pressable onPress={generate} disabled={busy || selectedCount === 0} style={[styles.primaryButton, { backgroundColor: colors.text, opacity: busy || selectedCount === 0 ? 0.45 : 1 }]} accessibilityRole="button" accessibilityState={{ disabled: busy || selectedCount === 0 }} accessibilityLabel="Generate live cosmetic visualization preview"><Ionicons name="sparkles-outline" size={18} color={colors.background} /><Text style={[styles.primaryButtonText, { color: colors.background }]}>{busy ? "Creating preview…" : selectedCount ? `Generate preview · ${selectedCount} focus${selectedCount === 1 ? "" : "es"}` : "Select at least one focus"}</Text></Pressable>
      <Text style={[styles.helper, { color: colors.textTertiary }]}>The result is a short-lived provider preview and is not saved to your Skin History or mock catalog.</Text>
      {error && <View style={[styles.errorCard, { backgroundColor: `${colors.error}12` }]}><Ionicons name="alert-circle-outline" size={18} color={colors.error} /><Text style={[styles.errorText, { color: colors.error }]}>{error}</Text></View>}
    </>}
  </ScrollView></View>;
}

const styles = StyleSheet.create({
  page: { flex: 1 }, content: { padding: 20, paddingBottom: 50, gap: 13 }, header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 10 }, headerCopy: { flex: 1, alignItems: "center" }, eyebrow: { fontFamily: "Outfit_700Bold", fontSize: 8, letterSpacing: 1 }, title: { fontFamily: "Outfit_700Bold", fontSize: 18, marginTop: 3, textAlign: "center" }, notice: { flexDirection: "row", alignItems: "flex-start", gap: 8, borderRadius: 15, padding: 12 }, noticeText: { flex: 1, fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 15 }, card: { borderWidth: 1, borderRadius: 18, padding: 15 }, cardTitle: { fontFamily: "Outfit_700Bold", fontSize: 15, marginTop: 9 }, body: { fontFamily: "Outfit_400Regular", fontSize: 11, lineHeight: 16, marginTop: 4 }, primaryButton: { minHeight: 49, borderRadius: 14, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, paddingHorizontal: 14, marginTop: 14 }, primaryButtonText: { fontFamily: "Outfit_700Bold", fontSize: 13 }, compareRow: { flexDirection: "row", gap: 10 }, imageColumn: { flex: 1 }, image: { width: "100%", aspectRatio: 0.76, borderRadius: 16 }, emptyPreview: { width: "100%", aspectRatio: 0.76, borderRadius: 16, borderWidth: 1, padding: 13, alignItems: "center", justifyContent: "center" }, emptyPreviewText: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 14, textAlign: "center", marginTop: 8 }, imageCaption: { fontFamily: "Outfit_500Medium", fontSize: 10, textAlign: "center", marginTop: 6 }, adjustmentGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginTop: 13 }, adjustment: { width: "48%", borderWidth: 1, borderRadius: 13, padding: 10 }, adjustmentLabel: { fontFamily: "Outfit_600SemiBold", fontSize: 11 }, adjustmentValue: { fontFamily: "Outfit_500Medium", fontSize: 10, marginTop: 3 }, helper: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 14, textAlign: "center", marginTop: -5 }, errorCard: { flexDirection: "row", alignItems: "flex-start", gap: 8, borderRadius: 14, padding: 12 }, errorText: { flex: 1, fontFamily: "Outfit_500Medium", fontSize: 11, lineHeight: 16 },
});
