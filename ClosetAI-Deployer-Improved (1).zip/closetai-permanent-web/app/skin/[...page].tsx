import { useLocalSearchParams } from "expo-router";

import { SkinJourneyPage } from "@/components/skin/SkinJourneyPage";

export default function SkinJourneyRoute() {
  const { page } = useLocalSearchParams<{ page?: string | string[] }>();
  const segments = Array.isArray(page) ? page : page ? [page] : [];
  return <SkinJourneyPage segments={segments} />;
}
