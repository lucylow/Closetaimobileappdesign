import { SelfieFlowScreen } from "@/components/skin/SelfieFlowScreen";

export default function SelfieScanRoute() {
  return <SelfieFlowScreen />;
}
