import { Image } from "expo-image";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import React from "react";
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

import { useSelfieScan } from "@/contexts/SelfieScanContext";
import { createAiSmile } from "@/lib/ai-smile";
import { selectedImageUriToBase64 } from "@/lib/selected-image-base64";
import { useTheme } from "@/lib/useTheme";
import { AI_SMILE_DISCLOSURE, AI_SMILE_EXPRESSION_TYPES, type AiSmileExpressionType, type AiSmileResult } from "@shared/ai-smile";

const STYLE_COPY: Record<AiSmileExpressionType, { title: string; description: string; icon: "happy-outline" | "ellipse-outline" }> = {
  smile_with_teeth_visible: { title: "Smile with teeth visible", description: "A creative, more expressive smile preview.", icon: "happy-outline" },
  closed_mouth_smile: { title: "Closed-mouth smile", description: "A creative, subtle smile preview.", icon: "ellipse-outline" },
};

export default function AiSmileScreen() {
  const { colors } = useTheme();
  const { asset } = useSelfieScan();
  const [consent, setConsent] = React.useState(false);
  const [expressionType, setExpressionType] = React.useState<AiSmileExpressionType>("closed_mouth_smile");
  const [result, setResult] = React.useState<AiSmileResult | null>(null);
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const requestIdRef = React.useRef(0);

  React.useEffect(() => () => {
    requestIdRef.current += 1;
  }, []);

  const createPreview = async () => {
    if (!asset || !consent || busy) return;
    const runId = ++requestIdRef.current;
    const selectedAssetUri = asset.uri;
    const selectedExpressionType = expressionType;
    const isCurrentRequest = () => requestIdRef.current === runId;
    setBusy(true); setError(null); setResult(null);
    try {
      const imageBase64 = await selectedImageUriToBase64(selectedAssetUri);
      if (!isCurrentRequest() || asset.uri !== selectedAssetUri || expressionType !== selectedExpressionType) return;
      const response = await createAiSmile({ imageBase64, expressionType: selectedExpressionType, consent });
      if (!isCurrentRequest() || asset.uri !== selectedAssetUri || expressionType !== selectedExpressionType) return;
      setResult(response.simulation);
    } catch (requestError) {
      if (!isCurrentRequest()) return;
      setError(requestError instanceof Error ? requestError.message : "Smile visualization is unavailable. No image was shown.");
    } finally {
      if (isCurrentRequest()) setBusy(false);
    }
  };

  const cancelPreview = () => {
    if (!busy) return;
    requestIdRef.current += 1;
    setBusy(false);
    setError("Smile visualization cancelled. No generated image was shown or saved.");
  };

  return <View style={[styles.page, { backgroundColor: colors.background }]}><ScrollView contentContainerStyle={styles.content}>
    <View style={styles.header}><Pressable onPress={() => router.back()} hitSlop={10} accessibilityRole="button" accessibilityLabel="Go back"><Ionicons name="chevron-back" size={25} color={colors.text} /></Pressable><View style={styles.headerCopy}><Text style={[styles.eyebrow, { color: colors.tint }]}>OPTIONAL CREATIVE PREVIEW</Text><Text style={[styles.title, { color: colors.text }]}>AI smile preview</Text></View><Ionicons name="happy-outline" size={21} color={colors.tint} /></View>
    <View style={[styles.notice, { backgroundColor: colors.surfaceSecondary }]}><Ionicons name="information-circle-outline" size={17} color={colors.tint} /><Text style={[styles.noticeText, { color: colors.textSecondary }]}>{AI_SMILE_DISCLOSURE}</Text></View>
    {!asset ? <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}><Ionicons name="camera-outline" size={28} color={colors.tint} /><Text style={[styles.cardTitle, { color: colors.text }]}>Choose your own photo first</Text><Text style={[styles.body, { color: colors.textSecondary }]}>Use a clear, front-facing photo containing only you. This feature creates a creative expression edit from your selected photo; ClosetAI will not infer your mood or substitute a stock image.</Text><Pressable onPress={() => router.push("/skin/selfie-scan")} style={[styles.primaryButton, { backgroundColor: colors.text }]} accessibilityRole="button" accessibilityLabel="Choose a photo for smile preview"><Text style={[styles.primaryText, { color: colors.background }]}>Choose a photo</Text></Pressable></View> : <>
      <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}><Text style={[styles.cardTitle, { color: colors.text }]}>Choose a creative smile style</Text><Text style={[styles.body, { color: colors.textSecondary }]}>The provider supports the two styles below. These are visual options, not a judgement about your expression or a recommendation for how you should look.</Text><View style={styles.options}>{AI_SMILE_EXPRESSION_TYPES.map((style) => <Pressable key={style} onPress={() => { setExpressionType(style); setResult(null); }} style={[styles.option, { borderColor: expressionType === style ? colors.tint : colors.border, backgroundColor: expressionType === style ? `${colors.tint}12` : colors.background }]} accessibilityRole="radio" accessibilityState={{ checked: expressionType === style }} accessibilityLabel={`Select ${STYLE_COPY[style].title}`}><Ionicons name={STYLE_COPY[style].icon} size={20} color={expressionType === style ? colors.tint : colors.textSecondary} /><View style={styles.optionCopy}><Text style={[styles.optionTitle, { color: colors.text }]}>{STYLE_COPY[style].title}</Text><Text style={[styles.optionText, { color: colors.textSecondary }]}>{STYLE_COPY[style].description}</Text></View></Pressable>)}</View></View>
      <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}><Text style={[styles.cardTitle, { color: colors.text }]}>Confirm before generating</Text><Pressable onPress={() => setConsent((value) => !value)} style={styles.checkRow} accessibilityRole="checkbox" accessibilityState={{ checked: consent }} accessibilityLabel="I understand this is a creative smile photo visualization"><Ionicons name={consent ? "checkbox-outline" : "square-outline"} size={22} color={consent ? colors.tint : colors.textTertiary} /><Text style={[styles.checkText, { color: colors.textSecondary }]}>I understand this is a creative smile photo visualization, not an assessment of my emotions, mood, identity, health, or attractiveness.</Text></Pressable></View>
      <Pressable onPress={() => { void createPreview(); }} disabled={busy || !consent} style={[styles.primaryButton, { backgroundColor: colors.text, opacity: busy || !consent ? 0.5 : 1 }]} accessibilityRole="button" accessibilityState={{ disabled: busy || !consent, busy }} accessibilityLabel="Create AI smile preview"><Ionicons name="happy-outline" size={18} color={colors.background} /><Text style={[styles.primaryText, { color: colors.background }]}>{busy ? "Creating temporary preview…" : "Create smile preview"}</Text></Pressable>
      {busy && <View style={[styles.loadingCard, { backgroundColor: colors.surfaceSecondary }]} accessibilityLiveRegion="polite" accessibilityRole="progressbar" accessibilityState={{ busy: true }} accessibilityLabel="Creating temporary AI smile preview"><ActivityIndicator size="small" color={colors.tint} /><View style={styles.loadingCopy}><Text style={[styles.body, { color: colors.textSecondary, marginTop: 0 }]}>Creating a temporary creative smile visualization from your selected photo.</Text><Pressable onPress={cancelPreview} accessibilityRole="button" accessibilityLabel="Cancel AI smile preview" accessibilityHint="Stops accepting the provider response and shows no generated image." style={styles.cancelPreviewButton}><Text style={[styles.cancelPreviewText, { color: colors.tint }]}>Cancel preview</Text></Pressable></View></View>}
      <Text style={[styles.helper, { color: colors.textTertiary }]}>The provider-issued preview URL is temporary and is not written to your skin-scan history.</Text>
      {result && <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}><Text style={[styles.cardTitle, { color: colors.text }]}>Temporary creative smile preview</Text><Image source={{ uri: result.resultUrl }} contentFit="contain" style={[styles.preview, { backgroundColor: colors.surfaceSecondary }]} accessibilityLabel="Temporary provider-rendered creative smile preview" /><Text style={[styles.stageNote, { color: colors.textSecondary }]}>{STYLE_COPY[result.expressionType].title} · temporary provider result. It is not an emotion assessment or a promise of a real-world outcome.</Text></View>}
      {error && <View style={[styles.errorCard, { backgroundColor: `${colors.error}12` }]}><Ionicons name="alert-circle-outline" size={18} color={colors.error} /><View style={styles.errorCopy}><Text style={[styles.errorText, { color: colors.error }]}>{error}</Text>{consent && !busy && <Pressable onPress={() => { void createPreview(); }} accessibilityRole="button" accessibilityLabel="Retry AI smile preview" accessibilityHint="Retries the temporary provider visualization with the same selected photo, expression style, and consent." style={({ pressed }) => [styles.retryButton, { borderColor: colors.error, opacity: pressed ? 0.7 : 1 }]}><Text style={[styles.retryText, { color: colors.error }]}>Retry preview</Text></Pressable>}</View></View>}
    </>}
  </ScrollView></View>;
}

const styles = StyleSheet.create({ page: { flex: 1 }, content: { padding: 20, paddingBottom: 50, gap: 13 }, header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 10 }, headerCopy: { flex: 1, alignItems: "center" }, eyebrow: { fontFamily: "Outfit_700Bold", fontSize: 8, letterSpacing: 1 }, title: { fontFamily: "Outfit_700Bold", fontSize: 18, marginTop: 3, textAlign: "center" }, notice: { flexDirection: "row", alignItems: "flex-start", gap: 8, borderRadius: 15, padding: 12 }, noticeText: { flex: 1, fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 15 }, card: { borderWidth: 1, borderRadius: 18, padding: 15 }, cardTitle: { fontFamily: "Outfit_700Bold", fontSize: 15, marginTop: 7 }, body: { fontFamily: "Outfit_400Regular", fontSize: 11, lineHeight: 16, marginTop: 4 }, primaryButton: { minHeight: 49, borderRadius: 14, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, paddingHorizontal: 14, marginTop: 2 }, primaryText: { fontFamily: "Outfit_700Bold", fontSize: 13 }, options: { gap: 9, marginTop: 13 }, option: { borderWidth: 1, borderRadius: 14, flexDirection: "row", alignItems: "center", gap: 10, padding: 12 }, optionCopy: { flex: 1 }, optionTitle: { fontFamily: "Outfit_600SemiBold", fontSize: 12 }, optionText: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 14, marginTop: 2 }, checkRow: { flexDirection: "row", alignItems: "flex-start", gap: 9, marginTop: 13 }, checkText: { flex: 1, fontFamily: "Outfit_500Medium", fontSize: 11, lineHeight: 16 }, helper: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 14, textAlign: "center", marginTop: -4 }, loadingCard: { flexDirection: "row", alignItems: "flex-start", gap: 9, borderRadius: 14, padding: 12 }, loadingCopy: { flex: 1 }, cancelPreviewButton: { alignSelf: "flex-start", paddingVertical: 6, paddingRight: 6 }, cancelPreviewText: { fontFamily: "Outfit_700Bold", fontSize: 10 }, preview: { width: "100%", height: 330, borderRadius: 14, marginTop: 12 }, stageNote: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 15, marginTop: 10 }, errorCard: { flexDirection: "row", alignItems: "flex-start", gap: 8, borderRadius: 14, padding: 12 }, errorCopy: { flex: 1 }, errorText: { fontFamily: "Outfit_500Medium", fontSize: 11, lineHeight: 16 }, retryButton: { alignSelf: "flex-start", borderWidth: 1, borderRadius: 11, paddingHorizontal: 10, paddingVertical: 7, marginTop: 8 }, retryText: { fontFamily: "Outfit_700Bold", fontSize: 10 }, });
