import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import React from "react";
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

import { getFitzpatrickCapability } from "@/lib/fitzpatrick";
import { useTheme } from "@/lib/useTheme";
import { FITZPATRICK_DISCLOSURE, type FitzpatrickCapability } from "@shared/fitzpatrick-profile";

const TYPE_CONTEXT = [
  ["I–II", "Very light to light cosmetic skin-tone profile"],
  ["III–IV", "Light brown to medium brown cosmetic skin-tone profile"],
  ["V–VI", "Brown to very dark brown cosmetic skin-tone profile"],
] as const;

export default function FitzpatrickScreen() {
  const { colors } = useTheme();
  const [capability, setCapability] = React.useState<FitzpatrickCapability | null>(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    let mounted = true;
    getFitzpatrickCapability()
      .then((result) => { if (mounted) setCapability(result); })
      .catch(() => { if (mounted) setCapability({ available: false, state: "not_configured", sourceLabel: "Capability unavailable", message: "We could not check live provider availability. ClosetAI will not estimate a classification from your photo.", disclosure: FITZPATRICK_DISCLOSURE }); })
      .finally(() => { if (mounted) setLoading(false); });
    return () => { mounted = false; };
  }, []);

  return <View style={[styles.page, { backgroundColor: colors.background }]}><ScrollView contentContainerStyle={styles.content}>
    <View style={styles.header}><Pressable onPress={() => router.back()} hitSlop={10} accessibilityRole="button" accessibilityLabel="Go back"><Ionicons name="chevron-back" size={25} color={colors.text} /></Pressable><View style={styles.headerCopy}><Text style={[styles.eyebrow, { color: colors.tint }]}>OPTIONAL COSMETIC PROFILE</Text><Text style={[styles.title, { color: colors.text }]}>Fitzpatrick skin-tone profile</Text></View><Ionicons name="color-palette-outline" size={21} color={colors.tint} /></View>

    <View style={[styles.notice, { backgroundColor: colors.surfaceSecondary }]}><Ionicons name="information-circle-outline" size={17} color={colors.tint} /><Text style={[styles.noticeText, { color: colors.textSecondary }]}>{FITZPATRICK_DISCLOSURE}</Text></View>

    <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}><Text style={[styles.cardTitle, { color: colors.text }]}>What this feature can show</Text><Text style={[styles.body, { color: colors.textSecondary }]}>When a verified provider contract is connected, ClosetAI can display an optional provider-returned cosmetic skin-tone profile. It does not infer ethnicity, prescribe sunscreen, assess UV risk, or replace professional advice.</Text><View style={styles.typeList}>{TYPE_CONTEXT.map(([range, label]) => <View key={range} style={[styles.typeRow, { borderColor: colors.border }]}><Text style={[styles.typeRange, { color: colors.tint }]}>{range}</Text><Text style={[styles.typeLabel, { color: colors.textSecondary }]}>{label}</Text></View>)}</View></View>

    <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}><View style={styles.statusHead}><View><Text style={[styles.cardTitle, { color: colors.text }]}>Live provider status</Text><Text style={[styles.body, { color: colors.textSecondary }]}>Classifications are displayed only when directly returned by a verified server provider.</Text></View>{loading ? <ActivityIndicator color={colors.tint} /> : <Ionicons name={capability?.available ? "checkmark-circle-outline" : "shield-checkmark-outline"} size={23} color={capability?.available ? colors.success : colors.tint} />}</View>{!loading && capability && <View style={[styles.statusBox, { backgroundColor: colors.surfaceSecondary }]}><Text style={[styles.statusLabel, { color: colors.tint }]}>{capability.sourceLabel}</Text><Text style={[styles.body, { color: colors.textSecondary }]}>{capability.message}</Text></View>}</View>

    <View style={[styles.footer, { backgroundColor: colors.surfaceSecondary }]}><Ionicons name="lock-closed-outline" size={16} color={colors.textTertiary} /><Text style={[styles.footerText, { color: colors.textTertiary }]}>No selfie is sent from this screen, no local classification is guessed, and no Fitzpatrick value is saved unless a future verified provider integration returns one with explicit user consent.</Text></View>
  </ScrollView></View>;
}

const styles = StyleSheet.create({
  page: { flex: 1 }, content: { padding: 20, paddingBottom: 50, gap: 13 }, header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 10 }, headerCopy: { flex: 1, alignItems: "center" }, eyebrow: { fontFamily: "Outfit_700Bold", fontSize: 8, letterSpacing: 1 }, title: { fontFamily: "Outfit_700Bold", fontSize: 18, marginTop: 3, textAlign: "center" }, notice: { flexDirection: "row", alignItems: "flex-start", gap: 8, borderRadius: 15, padding: 12 }, noticeText: { flex: 1, fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 15 }, card: { borderWidth: 1, borderRadius: 18, padding: 15 }, cardTitle: { fontFamily: "Outfit_700Bold", fontSize: 15 }, body: { fontFamily: "Outfit_400Regular", fontSize: 11, lineHeight: 16, marginTop: 5 }, typeList: { gap: 8, marginTop: 14 }, typeRow: { flexDirection: "row", alignItems: "center", gap: 12, paddingTop: 8, borderTopWidth: 1 }, typeRange: { fontFamily: "Outfit_700Bold", fontSize: 13, minWidth: 43 }, typeLabel: { flex: 1, fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 14 }, statusHead: { flexDirection: "row", justifyContent: "space-between", gap: 12 }, statusBox: { borderRadius: 13, padding: 11, marginTop: 13 }, statusLabel: { fontFamily: "Outfit_700Bold", fontSize: 10, letterSpacing: 0.3 }, footer: { flexDirection: "row", alignItems: "flex-start", gap: 8, borderRadius: 14, padding: 12 }, footerText: { flex: 1, fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 15 },
});
