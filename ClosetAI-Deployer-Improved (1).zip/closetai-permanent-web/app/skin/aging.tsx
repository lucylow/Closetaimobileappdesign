import { Image } from "expo-image";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import React from "react";
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

import { useSelfieScan } from "@/contexts/SelfieScanContext";
import { createAgingSimulation } from "@/lib/aging-simulation";
import { selectedImageUriToBase64 } from "@/lib/selected-image-base64";
import { useTheme } from "@/lib/useTheme";
import { AGING_SIMULATION_DISCLOSURE, type AgingSimulationResult } from "@shared/aging-simulation";

export default function AgingScreen() {
  const { colors } = useTheme();
  const { asset } = useSelfieScan();
  const [consent, setConsent] = React.useState(false);
  const [result, setResult] = React.useState<AgingSimulationResult | null>(null);
  const [selectedAge, setSelectedAge] = React.useState<number | null>(null);
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const requestIdRef = React.useRef(0);

  React.useEffect(() => () => {
    requestIdRef.current += 1;
  }, []);

  const createPreview = async () => {
    if (!asset || !consent || busy) return;
    const runId = ++requestIdRef.current;
    const selectedAssetUri = asset.uri;
    const isCurrentRequest = () => requestIdRef.current === runId;
    setBusy(true); setError(null); setResult(null); setSelectedAge(null);
    try {
      const response = await createAgingSimulation(await selectedImageUriToBase64(selectedAssetUri), consent);
      if (!isCurrentRequest()) return;
      if (asset.uri !== selectedAssetUri) return;
      setResult(response.simulation);
      setSelectedAge(response.simulation.previews[0]?.displayAge ?? null);
    } catch (simulationError) {
      if (!isCurrentRequest()) return;
      setError(simulationError instanceof Error ? simulationError.message : "Age-progression visualization is unavailable. No image was shown.");
    } finally {
      if (isCurrentRequest()) setBusy(false);
    }
  };

  const cancelPreview = () => {
    if (!busy) return;
    requestIdRef.current += 1;
    setBusy(false);
    setError("Creative preview cancelled. No generated image was shown or saved.");
  };

  const selected = result?.previews.find((preview) => preview.displayAge === selectedAge) || result?.previews[0];

  return <View style={[styles.page, { backgroundColor: colors.background }]}><ScrollView contentContainerStyle={styles.content}>
    <View style={styles.header}><Pressable onPress={() => router.back()} hitSlop={10} accessibilityRole="button" accessibilityLabel="Go back"><Ionicons name="chevron-back" size={25} color={colors.text} /></Pressable><View style={styles.headerCopy}><Text style={[styles.eyebrow, { color: colors.tint }]}>OPTIONAL CREATIVE PREVIEW</Text><Text style={[styles.title, { color: colors.text }]}>AI aging visualization</Text></View><Ionicons name="hourglass-outline" size={21} color={colors.tint} /></View>
    <View style={[styles.notice, { backgroundColor: colors.surfaceSecondary }]}><Ionicons name="information-circle-outline" size={17} color={colors.tint} /><Text style={[styles.noticeText, { color: colors.textSecondary }]}>{AGING_SIMULATION_DISCLOSURE}</Text></View>
    {!asset ? <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}><Ionicons name="camera-outline" size={28} color={colors.tint} /><Text style={[styles.cardTitle, { color: colors.text }]}>Choose a selfie first</Text><Text style={[styles.body, { color: colors.textSecondary }]}>Use one clear, forward-facing selfie in even lighting. ClosetAI will never substitute a stock face or fictional aging image.</Text><Pressable onPress={() => router.push("/skin/selfie-scan")} style={[styles.primaryButton, { backgroundColor: colors.text }]} accessibilityRole="button" accessibilityLabel="Choose a selfie for aging visualization"><Text style={[styles.primaryText, { color: colors.background }]}>Choose a selfie</Text></Pressable></View> : <>
      <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}><Text style={[styles.cardTitle, { color: colors.text }]}>Before you generate</Text><Text style={[styles.body, { color: colors.textSecondary }]}>This feature creates a creative series from your selected photo. It does not know your current age or predict what you will look like in the future.</Text><Pressable onPress={() => setConsent((current) => !current)} style={styles.consentRow} accessibilityRole="checkbox" accessibilityState={{ checked: consent }} accessibilityLabel="I understand this is a non-predictive creative visualization" accessibilityHint="When checked, this enables creation of temporary creative previews from your selected selfie."><Ionicons name={consent ? "checkbox-outline" : "square-outline"} size={22} color={consent ? colors.tint : colors.textTertiary} /><Text style={[styles.consentText, { color: colors.textSecondary }]}>I understand this is a non-predictive creative visualization using my selected photo.</Text></Pressable></View>
      <Pressable onPress={() => { void createPreview(); }} disabled={busy || !consent} style={[styles.primaryButton, { backgroundColor: colors.text, opacity: busy || !consent ? 0.5 : 1 }]} accessibilityRole="button" accessibilityState={{ disabled: busy || !consent, busy }} accessibilityLabel="Create AI aging visualization"><Ionicons name="hourglass-outline" size={18} color={colors.background} /><Text style={[styles.primaryText, { color: colors.background }]}>{busy ? "Generating previews…" : "Create aging visualization"}</Text></Pressable>
      {busy && <View style={[styles.loadingCard, { backgroundColor: colors.surfaceSecondary }]} accessibilityLiveRegion="polite" accessibilityRole="progressbar" accessibilityState={{ busy: true }} accessibilityLabel="Generating temporary AI aging previews"><ActivityIndicator size="small" color={colors.tint} /><View style={styles.loadingCopy}><Text style={[styles.body, { color: colors.textSecondary, marginTop: 0 }]}>Creating temporary creative previews from your selected photo. This can take a moment.</Text><Pressable onPress={cancelPreview} accessibilityRole="button" accessibilityLabel="Cancel AI aging visualization" accessibilityHint="Stops accepting the provider response and shows no generated image." style={({ pressed }) => [styles.cancelPreviewButton, { opacity: pressed ? 0.7 : 1 }]}><Text style={[styles.cancelPreviewText, { color: colors.tint }]}>Cancel generation</Text></Pressable></View></View>}
      <Text style={[styles.helper, { color: colors.textTertiary }]}>Preview URLs are provider-issued and temporary. Generated results are not saved to history or added to your skin-scan history.</Text>
      {selected && <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}><Text style={[styles.cardTitle, { color: colors.text }]}>Selected creative stage</Text><Image source={{ uri: selected.resultUrl }} contentFit="contain" style={[styles.preview, { backgroundColor: colors.surfaceSecondary }]} accessibilityLabel={`Temporary provider-generated creative age-progression visualization, stage ${selected.displayAge}. This is not a prediction of your future appearance.`} /><Text style={[styles.stageTitle, { color: colors.text }]}>Creative stage {selected.displayAge}</Text><Text style={[styles.stageNote, { color: colors.textSecondary }]}>“Stage” is the provider-generated label for this visualization—not your predicted future age.</Text><View style={styles.stages} accessibilityRole="radiogroup" accessibilityLabel="Choose a creative visualization stage">{result?.previews.map((preview) => <Pressable key={preview.displayAge} onPress={() => setSelectedAge(preview.displayAge)} style={[styles.stageChip, { borderColor: selectedAge === preview.displayAge ? colors.tint : colors.border, backgroundColor: selectedAge === preview.displayAge ? `${colors.tint}12` : colors.background }]} accessibilityRole="radio" accessibilityState={{ selected: selectedAge === preview.displayAge, checked: selectedAge === preview.displayAge }} accessibilityLabel={`View creative stage ${preview.displayAge}`}><Text style={[styles.stageChipText, { color: selectedAge === preview.displayAge ? colors.tint : colors.textSecondary }]}>{preview.displayAge}</Text></Pressable>)}</View></View>}
      {error && <View style={[styles.errorCard, { backgroundColor: `${colors.error}12` }]} accessibilityLiveRegion="assertive" accessibilityRole="alert"><Ionicons name="alert-circle-outline" size={18} color={colors.error} /><View style={styles.errorCopy}><Text style={[styles.errorText, { color: colors.error }]}>{error}</Text>{consent && !busy && <Pressable onPress={() => { void createPreview(); }} accessibilityRole="button" accessibilityLabel="Retry AI aging visualization" accessibilityHint="Retries the temporary provider visualization with the same selected selfie and consent." style={({ pressed }) => [styles.retryButton, { borderColor: colors.error, opacity: pressed ? 0.7 : 1 }]}><Text style={[styles.retryText, { color: colors.error }]}>Retry visualization</Text></Pressable>}</View></View>}
    </>}
  </ScrollView></View>;
}

const styles = StyleSheet.create({ page: { flex: 1 }, content: { padding: 20, paddingBottom: 50, gap: 13 }, header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 10 }, headerCopy: { flex: 1, alignItems: "center" }, eyebrow: { fontFamily: "Outfit_700Bold", fontSize: 8, letterSpacing: 1 }, title: { fontFamily: "Outfit_700Bold", fontSize: 18, marginTop: 3, textAlign: "center" }, notice: { flexDirection: "row", alignItems: "flex-start", gap: 8, borderRadius: 15, padding: 12 }, noticeText: { flex: 1, fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 15 }, card: { borderWidth: 1, borderRadius: 18, padding: 15 }, cardTitle: { fontFamily: "Outfit_700Bold", fontSize: 15, marginTop: 7 }, body: { fontFamily: "Outfit_400Regular", fontSize: 11, lineHeight: 16, marginTop: 4 }, primaryButton: { minHeight: 49, borderRadius: 14, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, paddingHorizontal: 14, marginTop: 2 }, primaryText: { fontFamily: "Outfit_700Bold", fontSize: 13 }, consentRow: { flexDirection: "row", alignItems: "flex-start", gap: 9, marginTop: 14 }, consentText: { flex: 1, fontFamily: "Outfit_500Medium", fontSize: 11, lineHeight: 16 }, helper: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 14, textAlign: "center", marginTop: -4 }, preview: { width: "100%", height: 330, borderRadius: 14, marginTop: 12 }, stageTitle: { fontFamily: "Outfit_700Bold", fontSize: 14, marginTop: 11 }, stageNote: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 15, marginTop: 3 }, stages: { flexDirection: "row", flexWrap: "wrap", gap: 7, marginTop: 12 }, stageChip: { minWidth: 38, borderWidth: 1, borderRadius: 12, paddingVertical: 8, paddingHorizontal: 10, alignItems: "center" }, stageChipText: { fontFamily: "Outfit_600SemiBold", fontSize: 11 }, loadingCard: { flexDirection: "row", alignItems: "flex-start", gap: 9, borderRadius: 14, padding: 12 }, loadingCopy: { flex: 1 }, cancelPreviewButton: { alignSelf: "flex-start", paddingVertical: 6, paddingRight: 6 }, cancelPreviewText: { fontFamily: "Outfit_700Bold", fontSize: 10 }, errorCard: { flexDirection: "row", alignItems: "flex-start", gap: 8, borderRadius: 14, padding: 12 }, errorCopy: { flex: 1 }, errorText: { fontFamily: "Outfit_500Medium", fontSize: 11, lineHeight: 16 }, retryButton: { alignSelf: "flex-start", borderWidth: 1, borderRadius: 11, paddingHorizontal: 10, paddingVertical: 7, marginTop: 8 }, retryText: { fontFamily: "Outfit_700Bold", fontSize: 10 }, });
