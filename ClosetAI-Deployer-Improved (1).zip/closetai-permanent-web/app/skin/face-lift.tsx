import { Image } from "expo-image";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import React from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

import { useSelfieScan } from "@/contexts/SelfieScanContext";
import { createFaceLiftSimulation } from "@/lib/face-lift-simulation";
import { selectedImageUriToBase64 } from "@/lib/selected-image-base64";
import { useTheme } from "@/lib/useTheme";
import { EMPTY_FACE_LIFT_FEATURES, FACE_LIFT_FEATURE_KEYS, FACE_LIFT_SIMULATION_DISCLOSURE, type FaceLiftFeatureKey, type FaceLiftFeatures, type FaceLiftSimulationResult } from "@shared/face-lift-simulation";

const FEATURE_COPY: Record<FaceLiftFeatureKey, { title: string; note: string }> = {
  eye_bag: { title: "Eye-area preview", note: "Cosmetic visual adjustment" },
  cheek: { title: "Cheek preview", note: "Cosmetic visual adjustment" },
  forehead: { title: "Forehead preview", note: "Cosmetic visual adjustment" },
  shape: { title: "Face-contour preview", note: "Cosmetic visual adjustment" },
  mouth: { title: "Mouth-area preview", note: "Cosmetic visual adjustment" },
};

export default function FaceLiftScreen() {
  const { colors } = useTheme();
  const { asset } = useSelfieScan();
  const [consent, setConsent] = React.useState(false);
  const [features, setFeatures] = React.useState<FaceLiftFeatures>(EMPTY_FACE_LIFT_FEATURES);
  const [result, setResult] = React.useState<FaceLiftSimulationResult | null>(null);
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const hasAdjustment = Object.values(features).some((value) => value > 0);

  const changeFeature = (key: FaceLiftFeatureKey, delta: number) => {
    setFeatures((current) => ({ ...current, [key]: Math.max(0, Math.min(100, current[key] + delta)) }));
    setResult(null);
  };

  const createPreview = async () => {
    if (!asset || !consent || !hasAdjustment) return;
    setBusy(true); setError(null); setResult(null);
    try {
      const response = await createFaceLiftSimulation({ imageBase64: await selectedImageUriToBase64(asset.uri), features, consent });
      setResult(response.simulation);
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Cosmetic face visualization is unavailable. No image was shown.");
    } finally { setBusy(false); }
  };

  return <View style={[styles.page, { backgroundColor: colors.background }]}><ScrollView contentContainerStyle={styles.content}>
    <View style={styles.header}><Pressable onPress={() => router.back()} hitSlop={10} accessibilityRole="button" accessibilityLabel="Go back"><Ionicons name="chevron-back" size={25} color={colors.text} /></Pressable><View style={styles.headerCopy}><Text style={[styles.eyebrow, { color: colors.tint }]}>OPTIONAL COSMETIC PREVIEW</Text><Text style={[styles.title, { color: colors.text }]}>Face refinement preview</Text></View><Ionicons name="sparkles-outline" size={21} color={colors.tint} /></View>
    <View style={[styles.notice, { backgroundColor: colors.surfaceSecondary }]}><Ionicons name="information-circle-outline" size={17} color={colors.tint} /><Text style={[styles.noticeText, { color: colors.textSecondary }]}>{FACE_LIFT_SIMULATION_DISCLOSURE}</Text></View>
    {!asset ? <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}><Ionicons name="camera-outline" size={28} color={colors.tint} /><Text style={[styles.cardTitle, { color: colors.text }]}>Choose your own photo first</Text><Text style={[styles.body, { color: colors.textSecondary }]}>Use one clear, front-facing photo containing only you. ClosetAI checks for exactly one face and will not choose a target from a group photo or substitute a stock image.</Text><Pressable onPress={() => router.push("/skin/selfie-scan")} style={[styles.primaryButton, { backgroundColor: colors.text }]} accessibilityRole="button" accessibilityLabel="Choose a photo for cosmetic face preview"><Text style={[styles.primaryText, { color: colors.background }]}>Choose a photo</Text></Pressable></View> : <>
      <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}><Text style={[styles.cardTitle, { color: colors.text }]}>Set optional preview controls</Text><Text style={[styles.body, { color: colors.textSecondary }]}>Choose one or more feature-level visual controls. Values are bounded from 0 to 100; 0 means no visual adjustment for that feature.</Text><View style={styles.featureList}>{FACE_LIFT_FEATURE_KEYS.map((key) => <View key={key} style={[styles.featureRow, { borderColor: colors.border }]}><View style={styles.featureCopy}><Text style={[styles.featureTitle, { color: colors.text }]}>{FEATURE_COPY[key].title}</Text><Text style={[styles.featureNote, { color: colors.textSecondary }]}>{FEATURE_COPY[key].note}</Text></View><View style={styles.featureControl}><Pressable onPress={() => changeFeature(key, -25)} disabled={features[key] === 0} style={[styles.stepButton, { borderColor: colors.border, opacity: features[key] === 0 ? 0.4 : 1 }]} accessibilityRole="button" accessibilityLabel={`Reduce ${FEATURE_COPY[key].title}`}><Ionicons name="remove" size={17} color={colors.text} /></Pressable><Text style={[styles.featureValue, { color: colors.tint }]}>{features[key]}</Text><Pressable onPress={() => changeFeature(key, 25)} disabled={features[key] === 100} style={[styles.stepButton, { borderColor: colors.border, opacity: features[key] === 100 ? 0.4 : 1 }]} accessibilityRole="button" accessibilityLabel={`Increase ${FEATURE_COPY[key].title}`}><Ionicons name="add" size={17} color={colors.text} /></Pressable></View></View>)}</View></View>
      <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}><Text style={[styles.cardTitle, { color: colors.text }]}>Confirm before generating</Text><Pressable onPress={() => setConsent((value) => !value)} style={styles.checkRow} accessibilityRole="checkbox" accessibilityState={{ checked: consent }} accessibilityLabel="I understand this is a non-medical cosmetic photo visualization"><Ionicons name={consent ? "checkbox-outline" : "square-outline"} size={22} color={consent ? colors.tint : colors.textTertiary} /><Text style={[styles.checkText, { color: colors.textSecondary }]}>I understand this is a cosmetic photo visualization, not medical advice, a diagnosis, a surgical plan, or a prediction.</Text></Pressable></View>
      <Pressable onPress={createPreview} disabled={busy || !consent || !hasAdjustment} style={[styles.primaryButton, { backgroundColor: colors.text, opacity: busy || !consent || !hasAdjustment ? 0.5 : 1 }]} accessibilityRole="button" accessibilityState={{ disabled: busy || !consent || !hasAdjustment }} accessibilityLabel="Create cosmetic face preview"><Ionicons name="sparkles-outline" size={18} color={colors.background} /><Text style={[styles.primaryText, { color: colors.background }]}>{busy ? "Creating temporary preview…" : "Create face refinement preview"}</Text></Pressable>
      {!hasAdjustment && <Text style={[styles.helper, { color: colors.textTertiary }]}>Select at least one non-zero control before generating.</Text>}<Text style={[styles.helper, { color: colors.textTertiary }]}>The provider-issued preview URL is temporary and is not written to your skin-scan history.</Text>
      {result && <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}><Text style={[styles.cardTitle, { color: colors.text }]}>Temporary cosmetic face preview</Text><Image source={{ uri: result.resultUrl }} contentFit="contain" style={[styles.preview, { backgroundColor: colors.surfaceSecondary }]} accessibilityLabel="Temporary provider-rendered cosmetic face refinement preview" /><Text style={[styles.stageNote, { color: colors.textSecondary }]}>Temporary provider result only. It is not a medical or surgical outcome, a beauty score, or a promise of a real-world result.</Text></View>}
      {error && <View style={[styles.errorCard, { backgroundColor: `${colors.error}12` }]}><Ionicons name="alert-circle-outline" size={18} color={colors.error} /><Text style={[styles.errorText, { color: colors.error }]}>{error}</Text></View>}
    </>}
  </ScrollView></View>;
}

const styles = StyleSheet.create({ page: { flex: 1 }, content: { padding: 20, paddingBottom: 50, gap: 13 }, header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 10 }, headerCopy: { flex: 1, alignItems: "center" }, eyebrow: { fontFamily: "Outfit_700Bold", fontSize: 8, letterSpacing: 1 }, title: { fontFamily: "Outfit_700Bold", fontSize: 18, marginTop: 3, textAlign: "center" }, notice: { flexDirection: "row", alignItems: "flex-start", gap: 8, borderRadius: 15, padding: 12 }, noticeText: { flex: 1, fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 15 }, card: { borderWidth: 1, borderRadius: 18, padding: 15 }, cardTitle: { fontFamily: "Outfit_700Bold", fontSize: 15, marginTop: 7 }, body: { fontFamily: "Outfit_400Regular", fontSize: 11, lineHeight: 16, marginTop: 4 }, primaryButton: { minHeight: 49, borderRadius: 14, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, paddingHorizontal: 14, marginTop: 2 }, primaryText: { fontFamily: "Outfit_700Bold", fontSize: 13 }, featureList: { gap: 9, marginTop: 13 }, featureRow: { borderTopWidth: 1, paddingTop: 10, flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 10 }, featureCopy: { flex: 1 }, featureTitle: { fontFamily: "Outfit_600SemiBold", fontSize: 12 }, featureNote: { fontFamily: "Outfit_400Regular", fontSize: 9, marginTop: 2 }, featureControl: { flexDirection: "row", alignItems: "center", gap: 7 }, stepButton: { width: 29, height: 29, borderWidth: 1, borderRadius: 9, alignItems: "center", justifyContent: "center" }, featureValue: { fontFamily: "Outfit_700Bold", fontSize: 12, minWidth: 24, textAlign: "center" }, checkRow: { flexDirection: "row", alignItems: "flex-start", gap: 9, marginTop: 13 }, checkText: { flex: 1, fontFamily: "Outfit_500Medium", fontSize: 11, lineHeight: 16 }, helper: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 14, textAlign: "center", marginTop: -4 }, preview: { width: "100%", height: 330, borderRadius: 14, marginTop: 12 }, stageNote: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 15, marginTop: 10 }, errorCard: { flexDirection: "row", alignItems: "flex-start", gap: 8, borderRadius: 14, padding: 12 }, errorText: { flex: 1, fontFamily: "Outfit_500Medium", fontSize: 11, lineHeight: 16 }, });
