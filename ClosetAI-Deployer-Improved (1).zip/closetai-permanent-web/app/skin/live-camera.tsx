import { LiveSkinCamera } from "@/components/skin/LiveSkinCamera";

export default function LiveSkinCameraScreen() {
  return <LiveSkinCamera />;
}
