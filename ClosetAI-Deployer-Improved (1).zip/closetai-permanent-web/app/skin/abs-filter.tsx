import { Image } from "expo-image";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import React from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

import { useSelfieScan } from "@/contexts/SelfieScanContext";
import { createAbsFilterSimulation } from "@/lib/abs-filter-simulation";
import { selectedImageUriToBase64 } from "@/lib/selected-image-base64";
import { useTheme } from "@/lib/useTheme";
import { ABS_FILTER_INTENSITIES, ABS_FILTER_MODES, ABS_FILTER_SIMULATION_DISCLOSURE, type AbsFilterIntensity, type AbsFilterMode, type AbsFilterSimulationResult } from "@shared/abs-filter-simulation";

const MODE_COPY: Record<AbsFilterMode, { title: string; description: string }> = {
  "Six-pack": { title: "Six-pack", description: "Creative abdominal-definition preview." },
  "Vest-line": { title: "Vest-line", description: "Creative central-definition preview." },
};

export default function AbsFilterScreen() {
  const { colors } = useTheme();
  const { asset } = useSelfieScan();
  const [adultConfirmed, setAdultConfirmed] = React.useState(false);
  const [singlePersonConfirmed, setSinglePersonConfirmed] = React.useState(false);
  const [consent, setConsent] = React.useState(false);
  const [mode, setMode] = React.useState<AbsFilterMode>("Six-pack");
  const [intensity, setIntensity] = React.useState<AbsFilterIntensity>(1);
  const [result, setResult] = React.useState<AbsFilterSimulationResult | null>(null);
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  const canSubmit = Boolean(asset && adultConfirmed && singlePersonConfirmed && consent && !busy);
  const createPreview = async () => {
    if (!asset || !adultConfirmed || !singlePersonConfirmed || !consent) return;
    setBusy(true); setError(null); setResult(null);
    try {
      const response = await createAbsFilterSimulation({
        imageBase64: await selectedImageUriToBase64(asset.uri), mode, intensity,
        consent, adultConfirmed, singlePersonConfirmed,
      });
      setResult(response.simulation);
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Cosmetic abdominal visualization is unavailable. No image was shown.");
    } finally { setBusy(false); }
  };

  const Check = ({ checked, onPress, children, label }: { checked: boolean; onPress: () => void; children: React.ReactNode; label: string }) => <Pressable onPress={onPress} style={styles.checkRow} accessibilityRole="checkbox" accessibilityState={{ checked }} accessibilityLabel={label}><Ionicons name={checked ? "checkbox-outline" : "square-outline"} size={22} color={checked ? colors.tint : colors.textTertiary} /><Text style={[styles.checkText, { color: colors.textSecondary }]}>{children}</Text></Pressable>;

  return <View style={[styles.page, { backgroundColor: colors.background }]}><ScrollView contentContainerStyle={styles.content}>
    <View style={styles.header}><Pressable onPress={() => router.back()} hitSlop={10} accessibilityRole="button" accessibilityLabel="Go back"><Ionicons name="chevron-back" size={25} color={colors.text} /></Pressable><View style={styles.headerCopy}><Text style={[styles.eyebrow, { color: colors.tint }]}>OPTIONAL ADULT-ONLY COSMETIC PREVIEW</Text><Text style={[styles.title, { color: colors.text }]}>AI abs filter</Text></View><Ionicons name="body-outline" size={21} color={colors.tint} /></View>
    <View style={[styles.notice, { backgroundColor: colors.surfaceSecondary }]}><Ionicons name="information-circle-outline" size={17} color={colors.tint} /><Text style={[styles.noticeText, { color: colors.textSecondary }]}>{ABS_FILTER_SIMULATION_DISCLOSURE}</Text></View>
    {!asset ? <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}><Ionicons name="camera-outline" size={28} color={colors.tint} /><Text style={[styles.cardTitle, { color: colors.text }]}>Choose your own clothed photo first</Text><Text style={[styles.body, { color: colors.textSecondary }]}>Use a clear adult upper-body or full-body photo containing only you, with both shoulders and your abdomen visible. ClosetAI will not submit a group photo or substitute a stock image.</Text><Pressable onPress={() => router.push("/skin/selfie-scan")} style={[styles.primaryButton, { backgroundColor: colors.text }]} accessibilityRole="button" accessibilityLabel="Choose a photo for cosmetic abdominal preview"><Text style={[styles.primaryText, { color: colors.background }]}>Choose a photo</Text></Pressable></View> : <>
      <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}><Text style={[styles.cardTitle, { color: colors.text }]}>Choose a creative mode</Text><Text style={[styles.body, { color: colors.textSecondary }]}>These documented controls affect a creative photo visualization only. They are not a fitness assessment or a recommended body goal.</Text><View style={styles.options}>{ABS_FILTER_MODES.map((item) => <Pressable key={item} onPress={() => { setMode(item); setResult(null); }} style={[styles.option, { borderColor: mode === item ? colors.tint : colors.border, backgroundColor: mode === item ? `${colors.tint}12` : colors.background }]} accessibilityRole="radio" accessibilityState={{ checked: mode === item }} accessibilityLabel={`Select ${MODE_COPY[item].title}`}><Ionicons name="body-outline" size={20} color={mode === item ? colors.tint : colors.textSecondary} /><View style={styles.optionCopy}><Text style={[styles.optionTitle, { color: colors.text }]}>{MODE_COPY[item].title}</Text><Text style={[styles.optionText, { color: colors.textSecondary }]}>{MODE_COPY[item].description}</Text></View></Pressable>)}</View><Text style={[styles.controlLabel, { color: colors.text }]}>Documented intensity</Text><View style={styles.chips}>{ABS_FILTER_INTENSITIES.map((item) => <Pressable key={item} onPress={() => { setIntensity(item); setResult(null); }} style={[styles.chip, { borderColor: intensity === item ? colors.tint : colors.border, backgroundColor: intensity === item ? `${colors.tint}12` : colors.background }]} accessibilityRole="radio" accessibilityState={{ checked: intensity === item }} accessibilityLabel={`Select intensity ${item}`}><Text style={[styles.chipText, { color: intensity === item ? colors.tint : colors.textSecondary }]}>Level {item}{item === 2 ? " · stronger" : ""}</Text></Pressable>)}</View></View>
      <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}><Text style={[styles.cardTitle, { color: colors.text }]}>Confirm before generating</Text><Check checked={adultConfirmed} onPress={() => setAdultConfirmed((value) => !value)} label="I confirm I am 18 or older">I confirm that I am 18 or older.</Check><Check checked={singlePersonConfirmed} onPress={() => setSinglePersonConfirmed((value) => !value)} label="I confirm this clothed photo contains only me">I confirm that this clothed photo contains only me. ClosetAI will not submit group photos where a provider might select someone automatically.</Check><Check checked={consent} onPress={() => setConsent((value) => !value)} label="I understand this is an adult-only cosmetic photo visualization">I understand this is an adult-only cosmetic photo visualization, not medical, health, fitness, anatomy, or attractiveness assessment.</Check></View>
      <Pressable onPress={createPreview} disabled={!canSubmit} style={[styles.primaryButton, { backgroundColor: colors.text, opacity: canSubmit ? 1 : 0.5 }]} accessibilityRole="button" accessibilityState={{ disabled: !canSubmit }} accessibilityLabel="Create AI Abs Filter preview"><Ionicons name="sparkles-outline" size={18} color={colors.background} /><Text style={[styles.primaryText, { color: colors.background }]}>{busy ? "Creating temporary preview…" : "Create cosmetic preview"}</Text></Pressable>
      <Text style={[styles.helper, { color: colors.textTertiary }]}>Provider preview URLs are temporary. The result is not saved to history, and no stock or fallback image is shown after an error.</Text>
      {result && <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}><Text style={[styles.cardTitle, { color: colors.text }]}>Temporary cosmetic preview</Text><Image source={{ uri: result.resultUrl }} contentFit="contain" style={[styles.preview, { backgroundColor: colors.surfaceSecondary }]} accessibilityLabel="Temporary provider-rendered cosmetic abdominal preview" /><Text style={[styles.stageNote, { color: colors.textSecondary }]}>{result.mode} · intensity {result.intensity} · creative visualization only, not a real-world outcome.</Text></View>}
      {error && <View style={[styles.errorCard, { backgroundColor: `${colors.error}12` }]}><Ionicons name="alert-circle-outline" size={18} color={colors.error} /><Text style={[styles.errorText, { color: colors.error }]}>{error}</Text></View>}
    </>}
  </ScrollView></View>;
}

const styles = StyleSheet.create({ page: { flex: 1 }, content: { padding: 20, paddingBottom: 50, gap: 13 }, header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 10 }, headerCopy: { flex: 1, alignItems: "center" }, eyebrow: { fontFamily: "Outfit_700Bold", fontSize: 8, letterSpacing: 0.8, textAlign: "center" }, title: { fontFamily: "Outfit_700Bold", fontSize: 18, marginTop: 3, textAlign: "center" }, notice: { flexDirection: "row", alignItems: "flex-start", gap: 8, borderRadius: 15, padding: 12 }, noticeText: { flex: 1, fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 15 }, card: { borderWidth: 1, borderRadius: 18, padding: 15 }, cardTitle: { fontFamily: "Outfit_700Bold", fontSize: 15, marginTop: 7 }, body: { fontFamily: "Outfit_400Regular", fontSize: 11, lineHeight: 16, marginTop: 4 }, primaryButton: { minHeight: 49, borderRadius: 14, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, paddingHorizontal: 14, marginTop: 2 }, primaryText: { fontFamily: "Outfit_700Bold", fontSize: 13 }, options: { gap: 9, marginTop: 13 }, option: { borderWidth: 1, borderRadius: 14, flexDirection: "row", alignItems: "center", gap: 10, padding: 12 }, optionCopy: { flex: 1 }, optionTitle: { fontFamily: "Outfit_600SemiBold", fontSize: 12 }, optionText: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 14, marginTop: 2 }, controlLabel: { fontFamily: "Outfit_600SemiBold", fontSize: 12, marginTop: 15 }, chips: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginTop: 8 }, chip: { borderWidth: 1, borderRadius: 12, paddingVertical: 8, paddingHorizontal: 11 }, chipText: { fontFamily: "Outfit_600SemiBold", fontSize: 10 }, checkRow: { flexDirection: "row", alignItems: "flex-start", gap: 9, marginTop: 12 }, checkText: { flex: 1, fontFamily: "Outfit_500Medium", fontSize: 11, lineHeight: 16 }, helper: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 14, textAlign: "center", marginTop: -4 }, preview: { width: "100%", height: 330, borderRadius: 14, marginTop: 12 }, stageNote: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 15, marginTop: 10 }, errorCard: { flexDirection: "row", alignItems: "flex-start", gap: 8, borderRadius: 14, padding: 12 }, errorText: { flex: 1, fontFamily: "Outfit_500Medium", fontSize: 11, lineHeight: 16 }, });
