import { Image } from "expo-image";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import React from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

import { useSelfieScan } from "@/contexts/SelfieScanContext";
import { createBreastShapeSimulation } from "@/lib/breast-shape-simulation";
import { selectedImageUriToBase64 } from "@/lib/selected-image-base64";
import { useTheme } from "@/lib/useTheme";
import { BREAST_SHAPE_INTENSITIES, BREAST_SHAPE_SIMULATION_DISCLOSURE, type BreastShapeIntensity, type BreastShapeSimulationResult } from "@shared/breast-shape-simulation";

export default function BreastShapeScreen() {
  const { colors } = useTheme();
  const { asset } = useSelfieScan();
  const [adultConfirmed, setAdultConfirmed] = React.useState(false);
  const [consent, setConsent] = React.useState(false);
  const [intensity, setIntensity] = React.useState<BreastShapeIntensity>(1);
  const [result, setResult] = React.useState<BreastShapeSimulationResult | null>(null);
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  const createPreview = async () => {
    if (!asset || !adultConfirmed || !consent) return;
    setBusy(true); setError(null); setResult(null);
    try {
      const response = await createBreastShapeSimulation({
        imageBase64: await selectedImageUriToBase64(asset.uri),
        intensity,
        adultConfirmed,
        consent,
      });
      setResult(response.simulation);
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "Cosmetic visualization is unavailable. No image was shown.");
    } finally { setBusy(false); }
  };

  return <View style={[styles.page, { backgroundColor: colors.background }]}><ScrollView contentContainerStyle={styles.content}>
    <View style={styles.header}><Pressable onPress={() => router.back()} hitSlop={10} accessibilityRole="button" accessibilityLabel="Go back"><Ionicons name="chevron-back" size={25} color={colors.text} /></Pressable><View style={styles.headerCopy}><Text style={[styles.eyebrow, { color: colors.tint }]}>OPTIONAL · 18+ ONLY</Text><Text style={[styles.title, { color: colors.text }]}>Cosmetic body preview</Text></View><Ionicons name="body-outline" size={21} color={colors.tint} /></View>
    <View style={[styles.notice, { backgroundColor: colors.surfaceSecondary }]}><Ionicons name="information-circle-outline" size={17} color={colors.tint} /><Text style={[styles.noticeText, { color: colors.textSecondary }]}>{BREAST_SHAPE_SIMULATION_DISCLOSURE}</Text></View>
    {!asset ? <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}><Ionicons name="camera-outline" size={28} color={colors.tint} /><Text style={[styles.cardTitle, { color: colors.text }]}>Choose your own photo first</Text><Text style={[styles.body, { color: colors.textSecondary }]}>For this adult-only visualization, use a clear, clothed, front-facing upper-body photo of yourself. Both shoulders should be visible. ClosetAI will not substitute a stock, demo, or fictional image.</Text><Pressable onPress={() => router.push("/skin/selfie-scan")} style={[styles.primaryButton, { backgroundColor: colors.text }]} accessibilityRole="button" accessibilityLabel="Choose an adult upper-body photo"><Text style={[styles.primaryText, { color: colors.background }]}>Choose a photo</Text></Pressable></View> : <>
      <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}><Text style={[styles.cardTitle, { color: colors.text }]}>Photo guidance</Text><Text style={[styles.body, { color: colors.textSecondary }]}>Use a clothed adult upper-body image with both shoulders visible, a front-facing pose, and no bag straps, scarves, or objects across the upper body. This app does not require or request nude images.</Text></View>
      <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}><Text style={[styles.cardTitle, { color: colors.text }]}>Choose a visualization level</Text><View style={styles.levels}>{BREAST_SHAPE_INTENSITIES.map((level) => <Pressable key={level} onPress={() => setIntensity(level)} style={[styles.level, { borderColor: intensity === level ? colors.tint : colors.border, backgroundColor: intensity === level ? `${colors.tint}12` : colors.background }]} accessibilityRole="radio" accessibilityState={{ checked: intensity === level }} accessibilityLabel={`Select cosmetic visualization level ${level}`}><Text style={[styles.levelNumber, { color: intensity === level ? colors.tint : colors.text }]}>{level}</Text><Text style={[styles.levelCopy, { color: colors.textSecondary }]}>{level === 1 ? "Subtle" : level === 2 ? "Moderate" : "Most visible"}</Text></Pressable>)}</View><Text style={[styles.helper, { color: colors.textTertiary }]}>Start at level 1. The level controls a temporary photo edit; it is not a body measurement or recommendation.</Text></View>
      <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}><Text style={[styles.cardTitle, { color: colors.text }]}>Confirm before generating</Text><Pressable onPress={() => setAdultConfirmed((value) => !value)} style={styles.checkRow} accessibilityRole="checkbox" accessibilityState={{ checked: adultConfirmed }} accessibilityLabel="I confirm that I am 18 or older"><Ionicons name={adultConfirmed ? "checkbox-outline" : "square-outline"} size={22} color={adultConfirmed ? colors.tint : colors.textTertiary} /><Text style={[styles.checkText, { color: colors.textSecondary }]}>I confirm that I am **18 or older** and that this is my photo.</Text></Pressable><Pressable onPress={() => setConsent((value) => !value)} style={styles.checkRow} accessibilityRole="checkbox" accessibilityState={{ checked: consent }} accessibilityLabel="I understand this is not medical or surgical planning"><Ionicons name={consent ? "checkbox-outline" : "square-outline"} size={22} color={consent ? colors.tint : colors.textTertiary} /><Text style={[styles.checkText, { color: colors.textSecondary }]}>I understand this is a cosmetic visualization, not medical advice, diagnosis, or surgical planning.</Text></Pressable></View>
      <Pressable onPress={createPreview} disabled={busy || !adultConfirmed || !consent} style={[styles.primaryButton, { backgroundColor: colors.text, opacity: busy || !adultConfirmed || !consent ? 0.5 : 1 }]} accessibilityRole="button" accessibilityState={{ disabled: busy || !adultConfirmed || !consent }} accessibilityLabel="Create adult cosmetic visualization"><Ionicons name="sparkles-outline" size={18} color={colors.background} /><Text style={[styles.primaryText, { color: colors.background }]}>{busy ? "Creating temporary preview…" : "Create cosmetic visualization"}</Text></Pressable>
      <Text style={[styles.helper, { color: colors.textTertiary }]}>A provider-issued result URL is temporary and is not written to your scan history.</Text>
      {result && <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}><Text style={[styles.cardTitle, { color: colors.text }]}>Temporary cosmetic preview</Text><Image source={{ uri: result.resultUrl }} contentFit="contain" style={[styles.preview, { backgroundColor: colors.surfaceSecondary }]} accessibilityLabel={`Temporary cosmetic visualization, level ${result.intensity}`} /><Text style={[styles.stageNote, { color: colors.textSecondary }]}>Level {result.intensity} · temporary provider result. This image is a creative cosmetic visualization only and not a medical or surgical outcome.</Text></View>}
      {error && <View style={[styles.errorCard, { backgroundColor: `${colors.error}12` }]}><Ionicons name="alert-circle-outline" size={18} color={colors.error} /><Text style={[styles.errorText, { color: colors.error }]}>{error}</Text></View>}
    </>}
  </ScrollView></View>;
}

const styles = StyleSheet.create({ page: { flex: 1 }, content: { padding: 20, paddingBottom: 50, gap: 13 }, header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 10 }, headerCopy: { flex: 1, alignItems: "center" }, eyebrow: { fontFamily: "Outfit_700Bold", fontSize: 8, letterSpacing: 1 }, title: { fontFamily: "Outfit_700Bold", fontSize: 18, marginTop: 3, textAlign: "center" }, notice: { flexDirection: "row", alignItems: "flex-start", gap: 8, borderRadius: 15, padding: 12 }, noticeText: { flex: 1, fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 15 }, card: { borderWidth: 1, borderRadius: 18, padding: 15 }, cardTitle: { fontFamily: "Outfit_700Bold", fontSize: 15, marginTop: 7 }, body: { fontFamily: "Outfit_400Regular", fontSize: 11, lineHeight: 16, marginTop: 4 }, primaryButton: { minHeight: 49, borderRadius: 14, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, paddingHorizontal: 14, marginTop: 2 }, primaryText: { fontFamily: "Outfit_700Bold", fontSize: 13 }, levels: { flexDirection: "row", gap: 7, marginTop: 13 }, level: { flex: 1, minHeight: 62, alignItems: "center", justifyContent: "center", borderWidth: 1, borderRadius: 13, padding: 7 }, levelNumber: { fontFamily: "Outfit_700Bold", fontSize: 17 }, levelCopy: { fontFamily: "Outfit_500Medium", fontSize: 9, marginTop: 2 }, helper: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 14, marginTop: 9, textAlign: "center" }, checkRow: { flexDirection: "row", alignItems: "flex-start", gap: 9, marginTop: 13 }, checkText: { flex: 1, fontFamily: "Outfit_500Medium", fontSize: 11, lineHeight: 16 }, preview: { width: "100%", height: 330, borderRadius: 14, marginTop: 12 }, stageNote: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 15, marginTop: 10 }, errorCard: { flexDirection: "row", alignItems: "flex-start", gap: 8, borderRadius: 14, padding: 12 }, errorText: { flex: 1, fontFamily: "Outfit_500Medium", fontSize: 11, lineHeight: 16 }, });
