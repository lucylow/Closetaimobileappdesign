import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import React from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

import { useSelfieScan } from "@/contexts/SelfieScanContext";
import { analyzeFacialColorTones } from "@/lib/facial-color-tones";
import { selectedImageUriToBase64 } from "@/lib/selected-image-base64";
import { useTheme } from "@/lib/useTheme";
import { FACIAL_COLOR_TONES_DISCLOSURE, FACE_ANGLE_STRICTNESS_LEVELS, type FaceAngleStrictness, type FacialColorTones } from "@shared/facial-color-tones";

const labels: { key: keyof Pick<FacialColorTones, "skinColor" | "eyeColor" | "lipColor" | "eyebrowColor" | "hairColor">; label: string }[] = [
  { key: "skinColor", label: "Skin" }, { key: "eyeColor", label: "Eyes" }, { key: "lipColor", label: "Lips" }, { key: "eyebrowColor", label: "Brows" }, { key: "hairColor", label: "Hair" },
];

export default function ColorTonesScreen() {
  const { colors } = useTheme();
  const { asset } = useSelfieScan();
  const [strictness, setStrictness] = React.useState<FaceAngleStrictness>("high");
  const [result, setResult] = React.useState<FacialColorTones | null>(null);
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  const analyze = async () => {
    if (!asset) return;
    setBusy(true); setError(null); setResult(null);
    try {
      const response = await analyzeFacialColorTones(await selectedImageUriToBase64(asset.uri), strictness);
      setResult(response.colors);
    } catch (analysisError) {
      setError(analysisError instanceof Error ? analysisError.message : "Live color-tone analysis is unavailable. No color values were shown.");
    } finally { setBusy(false); }
  };

  return <View style={[styles.page, { backgroundColor: colors.background }]}><ScrollView contentContainerStyle={styles.content}>
    <View style={styles.header}><Pressable onPress={() => router.back()} hitSlop={10} accessibilityRole="button" accessibilityLabel="Go back"><Ionicons name="chevron-back" size={25} color={colors.text} /></Pressable><View style={styles.headerCopy}><Text style={[styles.eyebrow, { color: colors.tint }]}>LIVE PROVIDER FEATURE</Text><Text style={[styles.title, { color: colors.text }]}>Facial color tones</Text></View><Ionicons name="color-palette-outline" size={21} color={colors.tint} /></View>

    <View style={[styles.notice, { backgroundColor: colors.surfaceSecondary }]}><Ionicons name="information-circle-outline" size={17} color={colors.tint} /><Text style={[styles.noticeText, { color: colors.textSecondary }]}>{FACIAL_COLOR_TONES_DISCLOSURE}</Text></View>

    {!asset ? <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}><Ionicons name="camera-outline" size={27} color={colors.tint} /><Text style={[styles.cardTitle, { color: colors.text }]}>Choose a selfie first</Text><Text style={[styles.body, { color: colors.textSecondary }]}>Use one clear, front-facing selfie in even lighting. No stock photo, demo values, or guessed color palette will be substituted.</Text><Pressable onPress={() => router.push("/skin/selfie-scan")} style={[styles.primaryButton, { backgroundColor: colors.text }]} accessibilityRole="button" accessibilityLabel="Choose a selfie for color-tone analysis"><Text style={[styles.primaryText, { color: colors.background }]}>Choose a selfie</Text></Pressable></View> : <>
      <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}><Text style={[styles.cardTitle, { color: colors.text }]}>Capture quality preference</Text><Text style={[styles.body, { color: colors.textSecondary }]}>Higher strictness requests a more frontal face position. Start with High for a balanced mobile experience.</Text><View style={styles.chips}>{FACE_ANGLE_STRICTNESS_LEVELS.map((level) => <Pressable key={level} onPress={() => setStrictness(level)} style={[styles.chip, { borderColor: strictness === level ? colors.tint : colors.border, backgroundColor: strictness === level ? `${colors.tint}12` : colors.background }]} accessibilityRole="button" accessibilityState={{ selected: strictness === level }} accessibilityLabel={`${level} face-angle strictness`}><Text style={[styles.chipText, { color: strictness === level ? colors.tint : colors.textSecondary }]}>{level}</Text></Pressable>)}</View></View>
      <Pressable onPress={analyze} disabled={busy} style={[styles.primaryButton, { backgroundColor: colors.text, opacity: busy ? 0.5 : 1 }]} accessibilityRole="button" accessibilityState={{ disabled: busy }} accessibilityLabel="Analyze facial cosmetic color tones"><Ionicons name="color-palette-outline" size={18} color={colors.background} /><Text style={[styles.primaryText, { color: colors.background }]}>{busy ? "Analyzing tones…" : "Analyze color tones"}</Text></Pressable>
      <Text style={[styles.helper, { color: colors.textTertiary }]}>Results remain on this screen only and are not added to skin history or used as an identity profile.</Text>
      {result && <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}><Text style={[styles.cardTitle, { color: colors.text }]}>Provider-returned cosmetic values</Text><View style={styles.swatches}>{labels.map(({ key, label }) => <View key={key} style={[styles.swatchRow, { borderColor: colors.border }]}><View style={[styles.swatch, { backgroundColor: result[key] }]} /><View style={styles.swatchCopy}><Text style={[styles.swatchLabel, { color: colors.text }]}>{label}</Text><Text style={[styles.swatchValue, { color: colors.textSecondary }]}>{result[key]}</Text></View></View>)}</View>{result.eyeColorName && <Text style={[styles.namedText, { color: colors.textSecondary }]}>Eye color label: {result.eyeColorName}</Text>}{result.hairColorName && <Text style={[styles.namedText, { color: colors.textSecondary }]}>Hair color label: {result.hairColorName}</Text>}</View>}
      {error && <View style={[styles.errorCard, { backgroundColor: `${colors.error}12` }]}><Ionicons name="alert-circle-outline" size={18} color={colors.error} /><Text style={[styles.errorText, { color: colors.error }]}>{error}</Text></View>}
    </>}
  </ScrollView></View>;
}

const styles = StyleSheet.create({ page: { flex: 1 }, content: { padding: 20, paddingBottom: 50, gap: 13 }, header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 10 }, headerCopy: { flex: 1, alignItems: "center" }, eyebrow: { fontFamily: "Outfit_700Bold", fontSize: 8, letterSpacing: 1 }, title: { fontFamily: "Outfit_700Bold", fontSize: 18, marginTop: 3, textAlign: "center" }, notice: { flexDirection: "row", alignItems: "flex-start", gap: 8, borderRadius: 15, padding: 12 }, noticeText: { flex: 1, fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 15 }, card: { borderWidth: 1, borderRadius: 18, padding: 15 }, cardTitle: { fontFamily: "Outfit_700Bold", fontSize: 15, marginTop: 7 }, body: { fontFamily: "Outfit_400Regular", fontSize: 11, lineHeight: 16, marginTop: 4 }, primaryButton: { minHeight: 49, borderRadius: 14, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, paddingHorizontal: 14, marginTop: 2 }, primaryText: { fontFamily: "Outfit_700Bold", fontSize: 13 }, chips: { flexDirection: "row", flexWrap: "wrap", gap: 7, marginTop: 13 }, chip: { borderWidth: 1, borderRadius: 12, paddingVertical: 8, paddingHorizontal: 10 }, chipText: { fontFamily: "Outfit_600SemiBold", fontSize: 10, textTransform: "capitalize" }, helper: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 14, textAlign: "center", marginTop: -4 }, swatches: { marginTop: 10 }, swatchRow: { flexDirection: "row", alignItems: "center", gap: 10, paddingVertical: 9, borderTopWidth: 1 }, swatch: { width: 32, height: 32, borderRadius: 10, borderWidth: 1, borderColor: "rgba(0,0,0,0.12)" }, swatchCopy: { flex: 1 }, swatchLabel: { fontFamily: "Outfit_600SemiBold", fontSize: 12 }, swatchValue: { fontFamily: "Outfit_400Regular", fontSize: 10, marginTop: 2 }, namedText: { fontFamily: "Outfit_400Regular", fontSize: 10, marginTop: 5 }, errorCard: { flexDirection: "row", alignItems: "flex-start", gap: 8, borderRadius: 14, padding: 12 }, errorText: { flex: 1, fontFamily: "Outfit_500Medium", fontSize: 11, lineHeight: 16 }, });
