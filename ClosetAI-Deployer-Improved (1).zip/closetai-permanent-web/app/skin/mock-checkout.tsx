import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import React from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';

import { useMockCommerce } from '@/contexts/MockCommerceContext';
import { MOCK_COMMERCE_DISCLOSURE } from '@/lib/skin-commerce-provider';
import { useTheme } from '@/lib/useTheme';

type CheckoutStep = 1 | 2 | 3 | 4;

const DELIVERY_PROFILES = [
  { id: 'studio-pickup', title: 'Prototype studio handoff', detail: 'Fictional delivery label only. No address is requested, saved, or sent.' },
  { id: 'digital-summary', title: 'Digital order summary', detail: 'Fictional delivery label only. No email or contact details are collected.' },
] as const;

const PAYMENT_PROFILES = [
  { id: 'mock-card', title: 'Mock card ending 4242', detail: 'Pre-filled fictional test method. No card number, expiry, CVV, or payment token exists.' },
  { id: 'mock-wallet', title: 'Mock wallet', detail: 'Pre-filled fictional test method. No wallet or payment provider is opened.' },
] as const;

const SCREENSHOT_PREVIEW_LINES = [
  { productId: 'la-prairie-skin-caviar-luxe-cream', title: 'La Prairie · Skin Caviar Luxe Cream', quantity: 1, unitPrice: 240, availability: 'low_stock' as const },
  { productId: 'augustinus-bader-rich-cream', title: 'Augustinus Bader · The Rich Cream', quantity: 1, unitPrice: 185, availability: 'in_stock' as const },
];

export default function MockCheckoutScreen() {
  const { colors } = useTheme();
  const { cart, subtotal, itemCount } = useMockCommerce();
  const { preview } = useLocalSearchParams<{ preview?: string }>();
  const isStaticPreview = preview === '1' && cart.lines.length === 0;
  const displayLines = isStaticPreview ? SCREENSHOT_PREVIEW_LINES : cart.lines;
  const displayItemCount = isStaticPreview ? SCREENSHOT_PREVIEW_LINES.reduce((count, line) => count + line.quantity, 0) : itemCount;
  const displaySubtotal = isStaticPreview ? SCREENSHOT_PREVIEW_LINES.reduce((total, line) => total + (line.quantity * line.unitPrice), 0) : subtotal;
  const [step, setStep] = React.useState<CheckoutStep>(1);
  const [deliveryId, setDeliveryId] = React.useState<(typeof DELIVERY_PROFILES)[number]['id']>(DELIVERY_PROFILES[0].id);
  const [paymentId, setPaymentId] = React.useState<(typeof PAYMENT_PROFILES)[number]['id']>(PAYMENT_PROFILES[0].id);
  const [reference, setReference] = React.useState<string | null>(null);

  const delivery = DELIVERY_PROFILES.find((item) => item.id === deliveryId) ?? DELIVERY_PROFILES[0];
  const payment = PAYMENT_PROFILES.find((item) => item.id === paymentId) ?? PAYMENT_PROFILES[0];
  const hasUnavailableLine = displayLines.some((line) => line.availability === 'out_of_stock');

  React.useEffect(() => {
    if (!cart.lines.length && !isStaticPreview) router.replace('/skin/mock-cart');
  }, [cart.lines.length, isStaticPreview]);

  const moveForward = () => {
    if (hasUnavailableLine) {
      Alert.alert('Mock checkout paused', 'Remove unavailable fictional items in the mock cart before continuing. No payment or external order has been attempted.');
      router.replace('/skin/mock-cart');
      return;
    }
    setStep((current) => Math.min(3, current + 1) as CheckoutStep);
  };

  const simulatePayment = () => {
    if (hasUnavailableLine) return;
    setReference(`SIM-${Date.now().toString(36).toUpperCase()}`);
    setStep(4);
  };

  if (!displayLines.length) return <View style={[styles.page, { backgroundColor: colors.background }]} />;

  const steps = ['Cart', 'Prototype delivery', 'Mock payment', 'Confirmation'];

  return <View style={[styles.page, { backgroundColor: colors.background }]}>
    <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <View style={styles.header}><Pressable onPress={() => step === 1 ? router.back() : setStep((current) => Math.max(1, current - 1) as CheckoutStep)} accessibilityRole="button" accessibilityLabel={step === 1 ? 'Return to mock cart' : 'Go to previous mock checkout step'}><Ionicons name="chevron-back" size={25} color={colors.text} /></Pressable><View style={styles.headerCopy}><Text style={[styles.eyebrow, { color: colors.tint }]}>CLOSET A.I. · PROTOTYPE</Text><Text style={[styles.title, { color: colors.text }]}>Mock Checkout</Text></View><Ionicons name="card-outline" size={20} color={colors.tint} /></View>

      <View style={[styles.disclosureBanner, { backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]}><Ionicons name="flask-outline" size={18} color={colors.tint} /><View style={styles.flex}><Text style={[styles.disclosureTitle, { color: colors.text }]}>Fictional checkout simulation</Text><Text style={[styles.disclosureText, { color: colors.textSecondary }]}>No payment, address, email, personal data, order, reservation, live price, live inventory, or brand/store contact is created by this flow.</Text></View></View>
      {isStaticPreview && <View style={[styles.staticPreviewBanner, { borderColor: colors.border }]} accessibilityLiveRegion="polite"><Ionicons name="eye-outline" size={15} color={colors.tint} /><Text style={[styles.staticPreviewText, { color: colors.textSecondary }]}>Static screenshot preview: fictional sample cart lines are shown only for route review. They are not saved, ordered, or connected to a store.</Text></View>}

      <View style={styles.stepRow} accessibilityRole="progressbar" accessibilityValue={{ min: 1, max: 4, now: step }} accessibilityLabel={`Mock checkout step ${step} of 4`}>{steps.map((label, index) => { const number = index + 1; const active = number <= step; return <View key={label} style={styles.stepItem}><View style={[styles.stepDot, { backgroundColor: active ? colors.tint : colors.border }]}><Text style={[styles.stepDotText, { color: active ? colors.background : colors.textTertiary }]}>{number}</Text></View><Text style={[styles.stepLabel, { color: active ? colors.text : colors.textTertiary }]}>{label}</Text></View>; })}</View>

      {step === 1 && <><Text style={[styles.sectionTitle, { color: colors.text }]}>1. Review fictional cart</Text><Text style={[styles.body, { color: colors.textSecondary }]}>{displayItemCount} fictional item{displayItemCount === 1 ? '' : 's'} · Mock subtotal ${displaySubtotal.toFixed(2)} USD</Text>{displayLines.map((line) => <View key={line.productId} style={[styles.line, { backgroundColor: colors.surface, borderColor: colors.border }]}><View style={styles.flex}><Text style={[styles.lineTitle, { color: colors.text }]}>{line.title}</Text><Text style={[styles.lineText, { color: colors.textSecondary }]}>Mock quantity {line.quantity} · fictional value ${line.unitPrice.toFixed(2)} USD each</Text></View><Text style={[styles.lineTotal, { color: colors.text }]}>${(line.quantity * line.unitPrice).toFixed(2)}</Text></View>)}<Action label="Continue to prototype delivery" onPress={moveForward} colors={colors} /></>}

      {step === 2 && <><Text style={[styles.sectionTitle, { color: colors.text }]}>2. Choose a fictional delivery label</Text><Text style={[styles.body, { color: colors.textSecondary }]}>Choose a prototype label to exercise the checkout steps. No shipping address, contact detail, or fulfillment request is collected.</Text><View style={styles.optionList} accessibilityRole="radiogroup" accessibilityLabel="Fictional delivery profile">{DELIVERY_PROFILES.map((profile) => <Option key={profile.id} selected={profile.id === deliveryId} title={profile.title} detail={profile.detail} onPress={() => setDeliveryId(profile.id)} colors={colors} />)}</View><Action label="Continue to mock payment" onPress={moveForward} colors={colors} /></>}

      {step === 3 && <><Text style={[styles.sectionTitle, { color: colors.text }]}>3. Choose a fictional payment method</Text><Text style={[styles.body, { color: colors.textSecondary }]}>These labels are pre-filled test choices only. Do not enter a real card, wallet, billing, or payment detail anywhere in ClosetAI.</Text><View style={styles.optionList} accessibilityRole="radiogroup" accessibilityLabel="Fictional payment method">{PAYMENT_PROFILES.map((profile) => <Option key={profile.id} selected={profile.id === paymentId} title={profile.title} detail={profile.detail} onPress={() => setPaymentId(profile.id)} colors={colors} />)}</View><Action label="Review fictional checkout" onPress={moveForward} colors={colors} /></>}

      {step === 4 && !reference && <><Text style={[styles.sectionTitle, { color: colors.text }]}>4. Confirm simulation</Text><View style={[styles.reviewCard, { backgroundColor: colors.surface, borderColor: colors.border }]}><Summary label="Cart" value={`${displayItemCount} fictional item${displayItemCount === 1 ? '' : 's'}`} colors={colors} /><Summary label="Mock subtotal" value={`$${displaySubtotal.toFixed(2)} USD`} colors={colors} /><Summary label="Prototype delivery" value={delivery.title} colors={colors} /><Summary label="Fictional payment" value={payment.title} colors={colors} /><Text style={[styles.reviewDisclosure, { color: colors.textTertiary }]}>{MOCK_COMMERCE_DISCLOSURE}</Text></View><Action label="Simulate mock payment" onPress={simulatePayment} colors={colors} /></>}

      {reference && <View style={[styles.confirmation, { backgroundColor: `${colors.success}12`, borderColor: colors.success }]} accessibilityLiveRegion="polite"><Ionicons name="checkmark-circle-outline" size={25} color={colors.success} /><Text style={[styles.confirmationTitle, { color: colors.text }]}>Mock payment simulated</Text><Text style={[styles.confirmationText, { color: colors.textSecondary }]}>Reference {reference}. This is a local prototype confirmation only; no payment was processed, no order was created, no inventory was reserved, and no personal or payment detail was collected.</Text><Action label="Return to mock cart" onPress={() => router.replace('/skin/mock-cart')} colors={colors} /></View>}
      <Text style={[styles.footerDisclosure, { color: colors.textTertiary }]}>{MOCK_COMMERCE_DISCLOSURE}</Text>
    </ScrollView>
  </View>;
}

function Option({ selected, title, detail, onPress, colors }: { selected: boolean; title: string; detail: string; onPress: () => void; colors: any }) {
  return <Pressable onPress={onPress} accessibilityRole="radio" accessibilityState={{ selected }} accessibilityLabel={`${title}. ${detail}${selected ? ', selected' : ''}`} style={[styles.option, { backgroundColor: selected ? `${colors.tint}12` : colors.surface, borderColor: selected ? colors.tint : colors.border }]}><Ionicons name={selected ? 'radio-button-on' : 'radio-button-off'} size={18} color={selected ? colors.tint : colors.textTertiary} /><View style={styles.flex}><Text style={[styles.optionTitle, { color: colors.text }]}>{title}</Text><Text style={[styles.optionText, { color: colors.textSecondary }]}>{detail}</Text></View></Pressable>;
}

function Summary({ label, value, colors }: { label: string; value: string; colors: any }) {
  return <View style={styles.summaryRow}><Text style={[styles.summaryLabel, { color: colors.textSecondary }]}>{label}</Text><Text style={[styles.summaryValue, { color: colors.text }]}>{value}</Text></View>;
}

function Action({ label, onPress, colors }: { label: string; onPress: () => void; colors: any }) {
  return <Pressable onPress={onPress} accessibilityRole="button" accessibilityLabel={label} style={[styles.action, { backgroundColor: colors.text }]}><Text style={[styles.actionText, { color: colors.background }]}>{label}</Text><Ionicons name="arrow-forward" size={16} color={colors.background} /></Pressable>;
}

const styles = StyleSheet.create({
  page: { flex: 1 }, content: { padding: 20, paddingBottom: 48 }, flex: { flex: 1 }, header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }, headerCopy: { alignItems: 'center' }, eyebrow: { fontFamily: 'Outfit_700Bold', fontSize: 8, letterSpacing: 1 }, title: { fontFamily: 'Outfit_700Bold', fontSize: 19 }, disclosureBanner: { flexDirection: 'row', gap: 9, borderWidth: 1, borderRadius: 15, padding: 12 }, disclosureTitle: { fontFamily: 'Outfit_700Bold', fontSize: 12 }, disclosureText: { fontFamily: 'Outfit_400Regular', fontSize: 10, lineHeight: 14, marginTop: 2 }, staticPreviewBanner: { flexDirection: 'row', gap: 7, borderWidth: 1, borderRadius: 12, padding: 10, marginTop: 8 }, staticPreviewText: { flex: 1, fontFamily: 'Outfit_400Regular', fontSize: 9, lineHeight: 13 }, stepRow: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 18, marginBottom: 17 }, stepItem: { width: 76, alignItems: 'center', gap: 4 }, stepDot: { width: 25, height: 25, borderRadius: 13, alignItems: 'center', justifyContent: 'center' }, stepDotText: { fontFamily: 'Outfit_700Bold', fontSize: 10 }, stepLabel: { fontFamily: 'Outfit_600SemiBold', fontSize: 8, textAlign: 'center' }, sectionTitle: { fontFamily: 'Outfit_700Bold', fontSize: 16 }, body: { fontFamily: 'Outfit_400Regular', fontSize: 11, lineHeight: 16, marginTop: 5 }, line: { flexDirection: 'row', alignItems: 'flex-start', gap: 8, borderWidth: 1, borderRadius: 13, padding: 11, marginTop: 9 }, lineTitle: { fontFamily: 'Outfit_600SemiBold', fontSize: 12 }, lineText: { fontFamily: 'Outfit_400Regular', fontSize: 9, lineHeight: 13, marginTop: 3 }, lineTotal: { fontFamily: 'Outfit_700Bold', fontSize: 12 }, optionList: { gap: 8, marginTop: 12 }, option: { flexDirection: 'row', alignItems: 'flex-start', gap: 9, borderWidth: 1, borderRadius: 14, padding: 12 }, optionTitle: { fontFamily: 'Outfit_700Bold', fontSize: 12 }, optionText: { fontFamily: 'Outfit_400Regular', fontSize: 10, lineHeight: 14, marginTop: 3 }, action: { marginTop: 15, minHeight: 47, borderRadius: 13, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 7 }, actionText: { fontFamily: 'Outfit_700Bold', fontSize: 12 }, reviewCard: { borderWidth: 1, borderRadius: 15, padding: 13, marginTop: 12, gap: 10 }, summaryRow: { flexDirection: 'row', justifyContent: 'space-between', gap: 12 }, summaryLabel: { fontFamily: 'Outfit_500Medium', fontSize: 10, flex: 0.43 }, summaryValue: { fontFamily: 'Outfit_600SemiBold', fontSize: 10, flex: 0.57, textAlign: 'right' }, reviewDisclosure: { fontFamily: 'Outfit_400Regular', fontSize: 9, lineHeight: 13, marginTop: 4 }, confirmation: { borderWidth: 1, borderRadius: 17, padding: 17, alignItems: 'center' }, confirmationTitle: { fontFamily: 'Outfit_700Bold', fontSize: 16, marginTop: 8 }, confirmationText: { fontFamily: 'Outfit_400Regular', fontSize: 11, lineHeight: 16, textAlign: 'center', marginTop: 5 }, footerDisclosure: { fontFamily: 'Outfit_400Regular', fontSize: 9, lineHeight: 13, textAlign: 'center', marginTop: 18 },
});
