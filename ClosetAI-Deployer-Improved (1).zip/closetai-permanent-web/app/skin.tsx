import SkinScreen from "@/components/skin/SkinScreen";

export default function RootSkinModalRoute() {
  return <SkinScreen />;
}
