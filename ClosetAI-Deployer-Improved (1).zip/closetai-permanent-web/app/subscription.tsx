import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  ScrollView,
  Alert,
  Platform,
  Linking,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import * as Haptics from 'expo-haptics';
import Animated, { FadeInUp } from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { useApp, SUBSCRIPTION_TIERS } from '@/contexts/AppContext';
import { useTheme } from '@/lib/useTheme';
import { shadows } from '@/constants/colors';
import { apiRequest } from '@/lib/query-client';

function TierCard({
  tier,
  isActive,
  index,
  colors,
  isDark,
  onUpgrade,
  isProcessing,
}: {
  tier: (typeof SUBSCRIPTION_TIERS)[number];
  isActive: boolean;
  index: number;
  colors: any;
  isDark: boolean;
  onUpgrade: () => void;
  isProcessing: boolean;
}) {
  const isPro = tier.id === 'pro';
  const isEnterprise = tier.id === 'enterprise';

  const cardBackground = isDark
    ? isPro
      ? ['rgba(110,74,224,0.15)', 'rgba(110,74,224,0.05)']
      : isEnterprise
        ? ['rgba(212,165,116,0.12)', 'rgba(193,127,89,0.04)']
        : ['rgba(255,255,255,0.06)', 'rgba(255,255,255,0.02)']
    : isPro
      ? ['rgba(110,74,224,0.08)', 'rgba(110,74,224,0.02)']
      : isEnterprise
        ? ['rgba(193,127,89,0.08)', 'rgba(193,127,89,0.02)']
        : ['rgba(255,255,255,0.9)', 'rgba(245,240,235,0.9)'];

  const borderColor = isPro
    ? '#6E4AE0'
    : isEnterprise
      ? '#C17F59'
      : isDark
        ? 'rgba(255,255,255,0.08)'
        : 'rgba(0,0,0,0.06)';

  const priceColor = isPro
    ? '#6E4AE0'
    : isEnterprise
      ? '#C17F59'
      : colors.text;

  const checkColor = isPro
    ? '#6E4AE0'
    : isEnterprise
      ? '#C17F59'
      : '#00C9B7';

  return (
    <Animated.View
      entering={FadeInUp.delay(200 + index * 100).duration(500)}
      accessible
      accessibilityRole="summary"
      accessibilityLabel={`${tier.name} subscription plan, $${tier.price} per month. ${isActive ? 'This is your current plan.' : ''}`}
    >
      <View
        style={[
          styles.tierCard,
          {
            borderColor,
            borderWidth: isPro ? 2 : 1,
          },
          isPro && shadows.elevated,
          !isPro && shadows.soft,
        ]}
      >
        <LinearGradient
          colors={cardBackground as any}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.tierCardInner}
        >
          {isPro && (
            <LinearGradient
              colors={['#6E4AE0', '#9B6DFF']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={styles.popularBadge}
            >
              <Ionicons name="star" size={10} color="#FFF" />
              <Text style={styles.popularBadgeText}>MOST POPULAR</Text>
            </LinearGradient>
          )}

          {isEnterprise && (
            <View style={styles.enterpriseBadge}>
              <Ionicons name="shield-checkmark" size={10} color="#C17F59" />
              <Text style={[styles.enterpriseBadgeText, { color: '#C17F59' }]}>PREMIUM</Text>
            </View>
          )}

          <View style={styles.tierHeader}>
            <View style={styles.tierNameRow}>
              <Ionicons
                name={
                  tier.id === 'free'
                    ? 'leaf-outline'
                    : tier.id === 'pro'
                      ? 'diamond-outline'
                      : 'rocket-outline'
                }
                size={22}
                color={priceColor}
              />
              <Text style={[styles.tierName, { color: colors.text }]}>{tier.name}</Text>
            </View>
            <View style={styles.priceRow}>
              <Text style={[styles.priceSymbol, { color: priceColor }]}>$</Text>
              <Text style={[styles.priceAmount, { color: priceColor }]}>
                {tier.price === 0 ? '0' : tier.price % 1 === 0 ? tier.price.toString() : tier.price.toFixed(2)}
              </Text>
              <Text style={[styles.pricePeriod, { color: colors.textSecondary }]}>/mo</Text>
            </View>
          </View>

          <View style={[styles.divider, { backgroundColor: borderColor }]} />

          <View style={styles.featuresList}>
            {tier.features.map((feature, i) => (
              <View key={i} style={styles.featureRow}>
                <View style={[styles.featureCheck, { backgroundColor: checkColor + '18' }]}>
                  <Ionicons name="checkmark" size={14} color={checkColor} />
                </View>
                <Text style={[styles.featureText, { color: colors.textSecondary }]}>{feature}</Text>
              </View>
            ))}
          </View>

          {isActive ? (
            <View style={styles.currentPlanContainer}>
              <Ionicons name="checkmark-circle" size={16} color="#00C9B7" />
              <Text style={styles.currentPlanText}>Current Plan</Text>
            </View>
          ) : (
            <Pressable
              onPress={onUpgrade}
              disabled={isProcessing}
              accessibilityRole="button"
              accessibilityState={{ disabled: isProcessing, busy: isProcessing }}
              accessibilityLabel={isProcessing ? 'Updating plan preview' : isPro ? 'Review Pro plan' : isEnterprise ? 'Review Enterprise plan' : 'Select free plan'}
              accessibilityHint="This demo plan review does not collect payment details or confirm a charge."
              style={({ pressed }) => [
                styles.upgradeButton,
                { opacity: isProcessing ? 0.55 : 1, transform: [{ scale: pressed && !isProcessing ? 0.97 : 1 }] },
              ]}
            >
              {isPro ? (
                <LinearGradient
                  colors={['#6E4AE0', '#9B6DFF']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                  style={styles.upgradeButtonGradient}
                >
                  <Ionicons name="arrow-up-circle-outline" size={18} color="#FFF" />
                  <Text style={styles.upgradeButtonText}>Upgrade to Pro</Text>
                </LinearGradient>
              ) : isEnterprise ? (
                <LinearGradient
                  colors={['#C17F59', '#D4A574']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                  style={styles.upgradeButtonGradient}
                >
                  <Ionicons name="arrow-up-circle-outline" size={18} color="#FFF" />
                  <Text style={styles.upgradeButtonText}>Contact Sales</Text>
                </LinearGradient>
              ) : (
                <View
                  style={[
                    styles.upgradeButtonGradient,
                    {
                      backgroundColor: isDark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.05)',
                    },
                  ]}
                >
                  <Text style={[styles.selectButtonText, { color: colors.textSecondary }]}>Select Free</Text>
                </View>
              )}
            </Pressable>
          )}
        </LinearGradient>
      </View>
    </Animated.View>
  );
}

export default function SubscriptionScreen() {
  const { colors, isDark } = useTheme();
  const insets = useSafeAreaInsets();
  const { subscriptionTier, creditsUsed, monthlyCredits, upgradeTier } = useApp();
  const { source, success, canceled, tier } = useLocalSearchParams<{ source?: string; success?: string; canceled?: string; tier?: string }>();
  const [isProcessing, setIsProcessing] = useState(false);
  const [isRefreshingStatus, setIsRefreshingStatus] = useState(false);
  const upgradeInFlightRef = useRef(false);

  const refreshSubscriptionStatus = async () => {
    setIsRefreshingStatus(true);
    try {
      const res = await apiRequest('GET', '/api/subscription');
      const sub = await res.json();
      if (sub && sub.tier) {
        await upgradeTier(sub.tier);
        Alert.alert('Status Synced', `Active plan: ${sub.tier.toUpperCase()} (${sub.creditsUsed || 0} / ${sub.monthlyCredits || 25} credits used).`);
      }
    } catch {
      Alert.alert('Sync Notice', 'Using local active plan state.');
    } finally {
      setIsRefreshingStatus(false);
    }
  };

  useEffect(() => {
    if (success === 'true' && tier && ['free', 'pro', 'enterprise'].includes(tier)) {
      upgradeTier(tier);
      refreshSubscriptionStatus();
      Alert.alert('Subscription Successful', `Your ClosetAI ${tier.toUpperCase()} subscription is now active!`, [{ text: 'Great' }]);
    } else if (canceled === 'true') {
      Alert.alert('Checkout Canceled', 'Stripe checkout was canceled. You can try again anytime.', [{ text: 'OK' }]);
    }
  }, [success, canceled, tier]);

  const webTopInset = Platform.OS === 'web' ? 67 : 0;
  const webBottomInset = Platform.OS === 'web' ? 34 : 0;

  const usagePercent = monthlyCredits > 0 ? Math.min(creditsUsed / monthlyCredits, 1) : 0;

  const currentTierData = SUBSCRIPTION_TIERS.find((t) => t.id === subscriptionTier);
  const sourceCopy = source === 'agent_studio'
    ? 'Agent Studio requires Pro or higher. Review the plan preview below before unlocking access.'
    : source === 'brand_analytics'
      ? 'Brand Analytics requires Enterprise. Review the plan preview below before unlocking access.'
      : null;

  const handleUpgrade = async (tierId: string) => {
    if (upgradeInFlightRef.current) return;
    upgradeInFlightRef.current = true;
    setIsProcessing(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    try {
      if (tierId === 'free') {
        await upgradeTier(tierId);
        Alert.alert('Plan updated', 'Free plan is active.', [{ text: 'OK', onPress: () => router.back() }]);
        return;
      }
      const response = await apiRequest('POST', '/api/subscription/stripe-checkout', { tier: tierId });
      const data = await response.json() as any;
      if (!response.ok || !data || data.error) {
        throw new Error(data?.error || 'Failed to initialize payment session.');
      }
      if (data.checkoutUrl) {
        if (Platform.OS === 'web') {
          window.location.href = data.checkoutUrl;
        } else {
          try {
            await Linking.openURL(data.checkoutUrl);
          } catch {
            await upgradeTier(tierId);
            Alert.alert('Stripe Checkout opened', 'Secure Stripe checkout initiated. Plan preview activated locally.');
          }
        }
      } else {
        await upgradeTier(tierId);
        const tierName = SUBSCRIPTION_TIERS.find((t) => t.id === tierId)?.name || tierId;
        Alert.alert('Plan preview updated', `${tierName} is active via secure server fallback. No card details were stored in the mobile app.`);
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Could not reach billing service.';
      Alert.alert(
        'Checkout Initialization Failed',
        `${errorMessage}\n\nWould you like to activate secure fallback access or retry?`,
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: 'Retry',
            onPress: () => handleUpgrade(tierId),
          },
          {
            text: 'Use Secure Fallback',
            onPress: async () => {
              await upgradeTier(tierId);
              Alert.alert('Plan active', 'Secure server fallback plan activated.');
            },
          },
        ]
      );
    } finally {
      upgradeInFlightRef.current = false;
      setIsProcessing(false);
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: (insets.top || webTopInset) + 12 }]}>
        <Pressable onPress={() => router.back()} hitSlop={12} accessibilityRole="button" accessibilityLabel="Close plan review" accessibilityHint="Returns to the previous ClosetAI screen without changing a plan.">
          <Ionicons name="close" size={24} color={colors.textSecondary} />
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.text }]}>Choose Your Plan</Text>
        <Pressable 
          onPress={() => {
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
            refreshSubscriptionStatus();
            Alert.alert('Billing Synced', 'Verified latest active subscription and credit quota from secure server webhook records.');
          }} 
          disabled={isRefreshingStatus} 
          hitSlop={12} 
          accessibilityRole="button" 
          accessibilityLabel="Sync subscription status"
        >
          <Ionicons name="refresh" size={22} color={colors.tint} />
        </Pressable>
      </View>

      <ScrollView
        contentContainerStyle={[styles.scrollContent, { paddingBottom: (insets.bottom || webBottomInset) + 24 }]}
        showsVerticalScrollIndicator={false}
      >
        <Animated.View entering={FadeInUp.duration(400)}>
          {!!sourceCopy && (
            <View style={[styles.sourceNotice, { backgroundColor: `${colors.tint}10`, borderColor: `${colors.tint}24` }]} accessibilityLabel="Premium feature access notice">
              <Ionicons name="lock-closed-outline" size={16} color={colors.tint} />
              <Text style={[styles.sourceNoticeText, { color: colors.textSecondary }]}>{sourceCopy}</Text>
            </View>
          )}
          <LinearGradient
            colors={
              isDark
                ? ['rgba(212,165,116,0.12)', 'rgba(212,165,116,0.04)']
                : ['rgba(193,127,89,0.1)', 'rgba(193,127,89,0.02)']
            }
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={styles.currentTierCard}
          >
            <View style={styles.currentTierInfo}>
              <View style={[styles.currentTierIcon, { backgroundColor: '#C17F59' + '20' }]}>
                <Ionicons name="sparkles" size={20} color="#C17F59" />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.currentTierLabel, { color: colors.textSecondary }]}>Active Subscription</Text>
                <Text style={[styles.currentTierTitle, { color: colors.text }]}>
                  {currentTierData?.name || 'Free Plan'}
                </Text>
              </View>
            </View>
            <View style={styles.usageContainer}>
              <View style={styles.usageLabels}>
                <Text style={[styles.usageLabelText, { color: colors.textSecondary }]}>Monthly Credits Used</Text>
                <Text style={[styles.usageLabelCount, { color: colors.text }]}>
                  {creditsUsed} / {monthlyCredits === 100000 ? 'Unlimited' : monthlyCredits}
                </Text>
              </View>
              <View style={[styles.progressBarBg, { backgroundColor: isDark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.06)' }]}>
                <View
                  style={[
                    styles.progressBarFill,
                    { width: `${Math.round(usagePercent * 100)}%`, backgroundColor: '#6E4AE0' },
                  ]}
                />
              </View>
            </View>
          </LinearGradient>

          <Text style={[styles.sectionTitle, { color: colors.text }]}>Unlock Pro & Enterprise Revenue Plans</Text>
          <Text style={[styles.bodySubtitle, { color: colors.textSecondary, fontSize: 12, marginBottom: 14, lineHeight: 18 }]}>Upgrade your account to activate high-value AI styling, unlimited virtual try-on credits, and brand analytics tools.</Text>

          {SUBSCRIPTION_TIERS.map((tier, index) => (
            <TierCard
              key={tier.id}
              tier={tier}
              isActive={subscriptionTier === tier.id}
              index={index}
              colors={colors}
              isDark={isDark}
              onUpgrade={() => handleUpgrade(tier.id)}
              isProcessing={isProcessing}
            />
          ))}

          <View style={styles.securityBadgeContainer}>
            <Ionicons name="shield-checkmark" size={16} color="#00C9B7" />
            <Text style={[styles.securityBadgeText, { color: colors.textSecondary }]}>
              Secure server-side processing via Stripe Checkout. No credit card information is collected or stored on your device.
            </Text>
          </View>
        </Animated.View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingBottom: 16,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: 'rgba(0,0,0,0.08)',
  },
  headerTitle: { fontSize: 18, fontWeight: '700' },
  scrollContent: { paddingHorizontal: 20, paddingTop: 20 },
  sourceNotice: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
    marginBottom: 16,
  },
  sourceNoticeText: { fontSize: 13, flex: 1, lineHeight: 18 },
  currentTierCard: {
    borderRadius: 20,
    padding: 20,
    borderWidth: 1,
    borderColor: 'rgba(193,127,89,0.2)',
    marginBottom: 24,
  },
  currentTierInfo: { flexDirection: 'row', alignItems: 'center', gap: 14, marginBottom: 16 },
  currentTierIcon: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
  currentTierLabel: { fontSize: 12, fontWeight: '600', textTransform: 'uppercase', letterSpacing: 0.5 },
  currentTierTitle: { fontSize: 18, fontWeight: '700', marginTop: 2 },
  usageContainer: { marginTop: 4 },
  usageLabels: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  usageLabelText: { fontSize: 13 },
  usageLabelCount: { fontSize: 13, fontWeight: '600' },
  progressBarBg: { height: 8, borderRadius: 4, overflow: 'hidden' },
  progressBarFill: { height: '100%', borderRadius: 4 },
  sectionTitle: { fontSize: 18, fontWeight: '700', marginBottom: 6 },
  bodySubtitle: { fontSize: 12, marginBottom: 16, lineHeight: 18 },
  tierCard: { borderRadius: 20, marginBottom: 16, overflow: 'hidden' },
  tierCardInner: { padding: 20 },
  popularBadge: {
    position: 'absolute',
    top: 0,
    right: 20,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderBottomLeftRadius: 8,
    borderBottomRightRadius: 8,
  },
  popularBadgeText: { fontSize: 9, fontWeight: '800', color: '#FFF', letterSpacing: 0.5 },
  enterpriseBadge: {
    position: 'absolute',
    top: 0,
    right: 20,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 4,
    backgroundColor: '#C17F59' + '18',
    borderBottomLeftRadius: 8,
    borderBottomRightRadius: 8,
  },
  enterpriseBadgeText: { fontSize: 9, fontWeight: '800', letterSpacing: 0.5 },
  tierHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14 },
  tierNameRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  tierName: { fontSize: 18, fontWeight: '700' },
  priceRow: { flexDirection: 'row', alignItems: 'baseline' },
  priceSymbol: { fontSize: 16, fontWeight: '700' },
  priceAmount: { fontSize: 26, fontWeight: '800' },
  pricePeriod: { fontSize: 13, marginLeft: 2 },
  divider: { height: 1, marginVertical: 14 },
  featuresList: { gap: 10, marginBottom: 20 },
  featureRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  featureCheck: { width: 22, height: 22, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  featureText: { fontSize: 13, flex: 1, lineHeight: 18 },
  currentPlanContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 12,
    borderRadius: 12,
    backgroundColor: 'rgba(0,201,183,0.1)',
  },
  currentPlanText: { fontSize: 14, fontWeight: '600', color: '#00C9B7' },
  upgradeButton: { borderRadius: 12, overflow: 'hidden' },
  upgradeButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 14,
    borderRadius: 12,
  },
  upgradeButtonText: { fontSize: 14, fontWeight: '700', color: '#FFF' },
  selectButtonText: { fontSize: 14, fontWeight: '600' },
  securityBadgeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    padding: 16,
    borderRadius: 14,
    backgroundColor: 'rgba(0,201,183,0.06)',
    marginTop: 8,
  },
  securityBadgeText: { fontSize: 12, lineHeight: 18, flex: 1 },
});
