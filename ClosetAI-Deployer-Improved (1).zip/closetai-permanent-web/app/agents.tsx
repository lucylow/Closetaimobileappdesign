import React, { useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  View,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import * as Haptics from "expo-haptics";
import { router, useLocalSearchParams } from "expo-router";

import { useApp } from "@/contexts/AppContext";
import { requestClosetAgentPlan, type ClosetAgentPlan } from "@/lib/closetai-agents";
import {
  FICTIONAL_DEMO_SCENARIOS_DISCLOSURE,
  FICTIONAL_PERSONA_LOOKBOOKS,
  FICTIONAL_ROUTINE_SCENARIOS,
  FICTIONAL_WARDROBE_CAPSULES,
  getFictionalAgentPlan,
} from "@/lib/fictional-demo-scenarios";
import { useTheme } from "@/lib/useTheme";
import { interaction, shadows } from "@/constants/colors";
import { hasRequiredTier, MonetizationPaywall } from "@/components/MonetizationPaywall";

type AgentMode = "fashion" | "skincare";

const FASHION_OCCASIONS = ["Everyday", "Work", "Dinner", "Travel"] as const;
const FASHION_PALETTES = ["Open palette", "Neutrals", "Warm tones", "Cool tones"] as const;
const SKIN_TIMES = [
  { id: "AM", label: "AM" },
  { id: "PM", label: "PM" },
  { id: "AM_PM", label: "AM + PM" },
] as const;
const SKIN_GOALS = [
  { id: "simple_routine", label: "Simple routine" },
  { id: "comfort", label: "Comfort" },
  { id: "hydration", label: "Hydration" },
  { id: "radiance", label: "Radiance" },
  { id: "texture_appearance", label: "Texture appearance" },
] as const;

function sourceLabel(source: string): string {
  const labels: Record<string, string> = {
    selected_preferences: "Selected preferences",
    local_wardrobe: "Local wardrobe",
    saved_normalized_skin_summary: "Saved normalized summary",
    fictional_demo: "Fictional Demo Mode",
    external_category_reference: "External category references",
  };
  return labels[source] || "Scoped agent context";
}

export default function ClosetAgentStudioScreen() {
  const { colors, isDark } = useTheme();
  const { demoMode, subscriptionTier } = useApp();
  const params = useLocalSearchParams<{ mode?: string }>();
  const initialMode: AgentMode = params.mode === "skincare" ? "skincare" : "fashion";
  const [mode, setMode] = useState<AgentMode>(initialMode);
  const [occasion, setOccasion] = useState<(typeof FASHION_OCCASIONS)[number]>("Everyday");
  const [palette, setPalette] = useState<(typeof FASHION_PALETTES)[number]>("Open palette");
  const [routineTime, setRoutineTime] = useState<"AM" | "PM" | "AM_PM">("AM_PM");
  const [skincareGoal, setSkincareGoal] = useState<"comfort" | "hydration" | "radiance" | "texture_appearance" | "simple_routine">("simple_routine");
  const [includeSummary, setIncludeSummary] = useState(false);
  const [prompt, setPrompt] = useState("");
  const [plan, setPlan] = useState<ClosetAgentPlan | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const nextMode: AgentMode = params.mode === "skincare" ? "skincare" : "fashion";
    setMode(nextMode);
    setPlan(null);
    setError(null);
  }, [params.mode]);

  const modeCopy = useMemo(() => mode === "fashion"
    ? {
      eyebrow: "CLOSET A.I. · AGENT STUDIO",
      title: "Plan a look with what you own.",
      body: "Fashion Look Planner combines the occasion, color direction, and local wardrobe context you select. It never purchases, reserves, or verifies a product.",
      icon: "shirt-outline" as const,
      primary: "Create fashion plan",
    }
    : {
      eyebrow: "CLOSET A.I. · AGENT STUDIO",
      title: "Organize a gentle cosmetic routine.",
      body: "Skin Routine Companion creates a general cosmetic-routine outline from your chosen goal. It is not medical advice, a diagnosis, or a product-suitability decision.",
      icon: "sparkles-outline" as const,
      primary: "Create routine outline",
    }, [mode]);
  const hasProAccess = hasRequiredTier(subscriptionTier, "pro");
  const demoScenarioTitles = useMemo(() => (mode === "fashion" ? FICTIONAL_WARDROBE_CAPSULES : FICTIONAL_ROUTINE_SCENARIOS).slice(-5), [mode]);

  const chooseMode = (nextMode: AgentMode) => {
    setMode(nextMode);
    setPlan(null);
    setError(null);
  };

  const createPlan = async () => {
    setIsLoading(true);
    setError(null);
    setPlan(null);
    try {
      const response = mode === "fashion"
        ? await requestClosetAgentPlan({ agent: "fashion", prompt, occasion, palette, demoMode })
        : await requestClosetAgentPlan({
          agent: "skincare",
          prompt,
          routineTime,
          skincareGoal,
          includeLatestNormalizedSummary: includeSummary,
          demoMode,
        });
      setPlan(response);
    } catch (requestError) {
      if (demoMode) {
        const fictionalPlan = getFictionalAgentPlan(mode);
        if (fictionalPlan) {
          setPlan(fictionalPlan);
          setError("Live agent coordinator unavailable. Showing a clearly labeled Fictional Demo Mode plan instead.");
        } else {
          setError("The fictional Demo Mode plan is unavailable. Try again or continue with the existing local tools.");
        }
      } else {
        setError(requestError instanceof Error ? requestError.message : "The agent planner could not be reached. Try again or continue with the existing local tools.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  if (!hasProAccess) {
    return (
      <MonetizationPaywall
        requiredTier="pro"
        source="agent_studio"
        title="Unlock Pro AI Studio & Unlimited Renders"
        description="Agent Studio and advanced AR try-on pipelines are Pro creator features. Upgrade to unlock unlimited monthly credits, priority processing, and affiliate revenue tools."
        benefits={[
          "1,500 Monthly Credits for Unlimited AR Try-Ons",
          "Advanced Fashion & Skin Agent Planning Tools",
          "Priority YouCam & OpenAI Pipeline Execution",
          "Affiliate Revenue & Monetization Eligibility",
        ]}
        continueLabel="Use free outfit tools"
        onContinue={() => router.replace('/(tabs)/outfits')}
      />
    );
  }

  return (
    <View style={[styles.page, { backgroundColor: colors.background }]}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
        <View style={styles.topRow}>
          <Pressable
            onPress={() => router.back()}
            accessibilityRole="button"
            accessibilityLabel="Go back"
            accessibilityHint="Returns to the previous ClosetAI screen."
            style={({ pressed }) => [styles.backButton, { backgroundColor: colors.surface, borderColor: colors.border, opacity: pressed ? 0.72 : 1 }]}
          >
            <Ionicons name="arrow-back" size={18} color={colors.text} />
          </Pressable>
          <Text style={[styles.topLabel, { color: colors.textSecondary }]}>USER-INITIATED AGENT PLANS</Text>
        </View>

        <LinearGradient
          colors={mode === "fashion" ? (isDark ? ["#25203A", "#11100F"] : ["#ECE7FF", "#FBF9FF"]) : (isDark ? ["#30211C", "#11100F"] : ["#F7E5D9", "#FFF9F5"])}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={[styles.hero, { borderColor: `${colors.tint}1F` }]}
        >
          <View style={[styles.heroIcon, { backgroundColor: mode === "fashion" ? "#6E4AE018" : "#A85F4818" }]}>
            <Ionicons name={modeCopy.icon} size={23} color={mode === "fashion" ? "#6E4AE0" : "#A85F48"} />
          </View>
          <Text style={[styles.eyebrow, { color: colors.tint }]}>{modeCopy.eyebrow}</Text>
          <Text style={[styles.heroTitle, { color: colors.text }]}>{modeCopy.title}</Text>
          <Text style={[styles.heroBody, { color: colors.textSecondary }]}>{modeCopy.body}</Text>
        </LinearGradient>

        <View style={[styles.modeControl, { backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]} accessibilityRole="tablist" accessibilityLabel="Choose a ClosetAI planning agent">
          {(["fashion", "skincare"] as const).map((agentMode) => {
            const selected = mode === agentMode;
            const isFashion = agentMode === "fashion";
            return (
              <Pressable
                key={agentMode}
                onPress={() => chooseMode(agentMode)}
                accessibilityRole="tab"
                accessibilityState={{ selected }}
                accessibilityLabel={isFashion ? "Choose Fashion Look Planner" : "Choose Skin Routine Companion"}
                accessibilityHint={isFashion ? "Creates a styling outline from your selected context." : "Creates a general cosmetic routine outline from your selected context."}
                style={({ pressed }) => [styles.modeButton, { backgroundColor: selected ? colors.surface : "transparent", opacity: pressed ? 0.76 : 1 }]}
              >
                <Ionicons name={isFashion ? "shirt-outline" : "sparkles-outline"} size={15} color={selected ? colors.tint : colors.textSecondary} />
                <Text style={[styles.modeButtonText, { color: selected ? colors.text : colors.textSecondary }]}>{isFashion ? "Fashion" : "Skin Care"}</Text>
              </Pressable>
            );
          })}
        </View>

        {demoMode && (
          <>
            <View style={[styles.demoBanner, { backgroundColor: `${colors.tint}12`, borderColor: `${colors.tint}28` }]} accessibilityRole="text" accessibilityLabel="Fictional Demo Mode is active">
              <Ionicons name="flask-outline" size={16} color={colors.tint} />
              <Text style={[styles.demoText, { color: colors.textSecondary }]}>Fictional Demo Mode is active. Agent responses will use labeled fictional context, not a real scan or live wardrobe.</Text>
            </View>
            <View style={[styles.demoLibrary, { backgroundColor: colors.surface, borderColor: colors.border }]} accessibilityRole="text" accessibilityLabel={`${mode === "fashion" ? "Wardrobe capsule" : "Skincare routine"} fictional scenario library`}>
              <Text style={[styles.demoLibraryTitle, { color: colors.text }]}>More fictional scenarios</Text>
              <Text style={[styles.demoLibraryMeta, { color: colors.textSecondary }]}>{FICTIONAL_WARDROBE_CAPSULES.length} wardrobe capsules · {FICTIONAL_PERSONA_LOOKBOOKS.length} persona lookbooks · {FICTIONAL_ROUTINE_SCENARIOS.length} routine outlines · fictional only · no live inventory</Text>
              <View style={styles.demoScenarioWrap}>{demoScenarioTitles.map((scenario) => <View key={scenario.id} style={[styles.demoScenarioChip, { backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]}><Text style={[styles.demoScenarioChipTitle, { color: colors.text }]}>{scenario.title}</Text><Text style={[styles.demoScenarioChipMeta, { color: colors.textSecondary }]}>{"occasion" in scenario ? scenario.occasion : `${scenario.routineTime} · ${scenario.focus}`}</Text></View>)}</View>
              <Text style={[styles.demoLibraryTitle, { color: colors.text }]}>Persona lookbooks</Text>
              <View style={styles.demoScenarioWrap}>{FICTIONAL_PERSONA_LOOKBOOKS.slice(-5).map((lookbook) => <View key={lookbook.id} style={[styles.demoScenarioChip, { backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]}><Text style={[styles.demoScenarioChipTitle, { color: colors.text }]}>{lookbook.persona} · {lookbook.title}</Text><Text style={[styles.demoScenarioChipMeta, { color: colors.textSecondary }]}>{lookbook.mood} · {lookbook.anchorPieces.slice(0, 2).join(" · ")}</Text></View>)}</View>
              <Text style={[styles.demoLibraryDisclosure, { color: colors.textTertiary }]}>{FICTIONAL_DEMO_SCENARIOS_DISCLOSURE}</Text>
            </View>
          </>
        )}

        <View style={[styles.formCard, { backgroundColor: colors.surface, borderColor: colors.border }, shadows.soft]}>
          {mode === "fashion" ? (
            <>
              <Text style={[styles.formTitle, { color: colors.text }]}>Fashion Look Planner</Text>
              <Text style={[styles.formDescription, { color: colors.textSecondary }]}>Choose a little context. The agent can only refer to local wardrobe items supplied by ClosetAI.</Text>
              <Text style={[styles.fieldLabel, { color: colors.text }]}>Occasion</Text>
              <View style={styles.choiceWrap}>
                {FASHION_OCCASIONS.map((item) => (
                  <Pressable
                    key={item}
                    onPress={() => {
                      Haptics.selectionAsync();
                      setOccasion(item);
                    }}
                    accessibilityRole="radio"
                    accessibilityState={{ selected: occasion === item }}
                    accessibilityLabel={`Occasion: ${item}`}
                    accessibilityHint={occasion === item ? 'Currently planning outfits for this occasion.' : `Plan outfits for ${item.toLowerCase()}`}
                    style={({ pressed }) => [styles.choice, { borderColor: occasion === item ? colors.tint : colors.border, backgroundColor: occasion === item ? `${colors.tint}12` : colors.surfaceSecondary, opacity: pressed ? 0.72 : 1 }]}
                  >
                    <Text style={[styles.choiceText, { color: occasion === item ? colors.tint : colors.textSecondary }]}>{item}</Text>
                  </Pressable>
                ))}
              </View>
              <Text style={[styles.fieldLabel, { color: colors.text }]}>Color direction</Text>
              <View style={styles.choiceWrap}>
                {FASHION_PALETTES.map((item) => (
                  <Pressable key={item} onPress={() => setPalette(item)} accessibilityRole="radio" accessibilityState={{ selected: palette === item }} accessibilityLabel={`Color direction: ${item}`} style={({ pressed }) => [styles.choice, { borderColor: palette === item ? colors.tint : colors.border, backgroundColor: palette === item ? `${colors.tint}12` : colors.surfaceSecondary, opacity: pressed ? 0.72 : 1 }]}>
                    <Text style={[styles.choiceText, { color: palette === item ? colors.tint : colors.textSecondary }]}>{item}</Text>
                  </Pressable>
                ))}
              </View>
            </>
          ) : (
            <>
              <Text style={[styles.formTitle, { color: colors.text }]}>Skin Routine Companion</Text>
              <Text style={[styles.formDescription, { color: colors.textSecondary }]}>Set a cosmetic-planning goal. A selfie is never required for this general routine outline.</Text>
              <Text style={[styles.fieldLabel, { color: colors.text }]}>Routine timing</Text>
              <View style={styles.choiceWrap}>
                {SKIN_TIMES.map((item) => (
                  <Pressable key={item.id} onPress={() => setRoutineTime(item.id)} accessibilityRole="radio" accessibilityState={{ selected: routineTime === item.id }} accessibilityLabel={`Routine timing: ${item.label}`} style={({ pressed }) => [styles.choice, { borderColor: routineTime === item.id ? colors.tint : colors.border, backgroundColor: routineTime === item.id ? `${colors.tint}12` : colors.surfaceSecondary, opacity: pressed ? 0.72 : 1 }]}>
                    <Text style={[styles.choiceText, { color: routineTime === item.id ? colors.tint : colors.textSecondary }]}>{item.label}</Text>
                  </Pressable>
                ))}
              </View>
              <Text style={[styles.fieldLabel, { color: colors.text }]}>Cosmetic-planning focus</Text>
              <View style={styles.choiceWrap}>
                {SKIN_GOALS.map((item) => (
                  <Pressable key={item.id} onPress={() => setSkincareGoal(item.id)} accessibilityRole="radio" accessibilityState={{ selected: skincareGoal === item.id }} accessibilityLabel={`Cosmetic planning focus: ${item.label}`} style={({ pressed }) => [styles.choice, { borderColor: skincareGoal === item.id ? colors.tint : colors.border, backgroundColor: skincareGoal === item.id ? `${colors.tint}12` : colors.surfaceSecondary, opacity: pressed ? 0.72 : 1 }]}>
                    <Text style={[styles.choiceText, { color: skincareGoal === item.id ? colors.tint : colors.textSecondary }]}>{item.label}</Text>
                  </Pressable>
                ))}
              </View>
              <View style={[styles.switchRow, { borderColor: colors.border, backgroundColor: colors.surfaceSecondary }]}>
                <View style={styles.switchCopy}>
                  <Text style={[styles.switchTitle, { color: colors.text }]}>Use latest saved normalized summary</Text>
                  <Text style={[styles.switchDetail, { color: colors.textSecondary }]}>Optional context only. Original photos are not sent to this agent.</Text>
                </View>
                <Switch
                  value={includeSummary}
                  onValueChange={setIncludeSummary}
                  accessibilityRole="switch"
                  accessibilityLabel="Use latest saved normalized skin summary"
                  accessibilityHint="Includes a saved source-labeled summary as optional context. Original photos are not sent."
                  accessibilityState={{ checked: includeSummary }}
                  trackColor={{ false: colors.border, true: colors.tint }}
                />
              </View>
            </>
          )}

          <Text style={[styles.fieldLabel, { color: colors.text }]}>Optional note</Text>
          <TextInput
            value={prompt}
            onChangeText={setPrompt}
            placeholder={mode === "fashion" ? "e.g., I want a relaxed, polished look" : "e.g., I want a simple evening sequence"}
            placeholderTextColor={colors.textTertiary}
            multiline
            maxLength={360}
            accessibilityLabel="Optional agent-planning note"
            accessibilityHint="Adds a short preference to the request. Do not include medical, payment, or secret information."
            style={[styles.promptInput, { color: colors.text, borderColor: colors.border, backgroundColor: colors.surfaceSecondary }]}
          />
          <Text style={[styles.characterCount, { color: colors.textTertiary }]}>{prompt.length}/360</Text>

          <Pressable
            onPress={createPlan}
            disabled={isLoading}
            accessibilityRole="button"
            accessibilityState={{ disabled: isLoading, busy: isLoading }}
            accessibilityLabel={modeCopy.primary}
            accessibilityHint="Creates one bounded, reviewable agent plan from the choices on this screen."
            style={({ pressed }) => [styles.createButton, { backgroundColor: colors.text, opacity: isLoading ? 0.6 : pressed ? 0.86 : 1, transform: [{ scale: pressed ? interaction.primaryPressScale : 1 }] }]}
          >
            {isLoading ? <ActivityIndicator size="small" color={colors.background} /> : <Ionicons name="sparkles-outline" size={18} color={colors.background} />}
            <Text style={[styles.createButtonText, { color: colors.background }]}>{isLoading ? `${mode === "fashion" ? "Planning your look" : "Organizing your routine"}…` : modeCopy.primary}</Text>
          </Pressable>
        </View>

        {isLoading && (
          <View style={[styles.statusCard, { backgroundColor: `${colors.tint}12`, borderColor: `${colors.tint}24` }]} accessibilityLiveRegion="polite" accessibilityRole="progressbar" accessibilityState={{ busy: true }} accessibilityLabel={`${mode === "fashion" ? "Fashion Look Planner" : "Skin Routine Companion"} is preparing a bounded plan`}>
            <ActivityIndicator size="small" color={colors.tint} />
            <Text style={[styles.statusText, { color: colors.textSecondary }]}>Preparing a request-scoped plan. ClosetAI checks the response before it appears here.</Text>
          </View>
        )}

        {error && (
          <View style={[styles.errorCard, { backgroundColor: "#D94C4C12", borderColor: "#D94C4C35" }]} accessibilityLiveRegion="polite" accessibilityRole="alert">
            <Ionicons name="alert-circle-outline" size={18} color="#D94C4C" />
            <View style={styles.flex}><Text style={[styles.errorTitle, { color: colors.text }]}>Agent plan unavailable</Text><Text style={[styles.errorText, { color: colors.textSecondary }]}>{error}</Text></View>
          </View>
        )}

        {plan && (
          <View style={[styles.planCard, { backgroundColor: colors.surface, borderColor: colors.border }, shadows.medium]} accessibilityLiveRegion="polite" accessibilityLabel={`${plan.agent === "fashion" ? "Fashion" : "Skin Care"} agent plan ready`}>
            <View style={styles.planHeader}>
              <View style={[styles.planIcon, { backgroundColor: plan.agent === "fashion" ? "#6E4AE015" : "#A85F4815" }]}><Ionicons name={plan.agent === "fashion" ? "shirt-outline" : "sparkles-outline"} size={18} color={plan.agent === "fashion" ? "#6E4AE0" : "#A85F48"} /></View>
              <View style={styles.flex}><Text style={[styles.planKicker, { color: colors.tint }]}>{plan.mode === "live_model" ? "AI-ASSISTED · VERIFIED" : plan.mode === "fictional_demo" ? "FICTIONAL DEMO PLAN" : "LOCAL PLANNING FALLBACK"}</Text><Text style={[styles.planTitle, { color: colors.text }]}>{plan.title}</Text></View>
            </View>
            <Text style={[styles.planSummary, { color: colors.textSecondary }]}>{plan.summary}</Text>
            <View style={styles.contextWrap}>{plan.contextSources.map((source) => <View key={source} style={[styles.contextChip, { backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]}><Text style={[styles.contextChipText, { color: colors.textSecondary }]}>{sourceLabel(source)}</Text></View>)}</View>
            <View style={styles.stepsWrap}>{plan.steps.map((step, index) => <View key={step.id} style={styles.stepRow}><View style={[styles.stepNumber, { backgroundColor: `${colors.tint}15` }]}><Text style={[styles.stepNumberText, { color: colors.tint }]}>{index + 1}</Text></View><View style={styles.flex}><Text style={[styles.stepTitle, { color: colors.text }]}>{step.title}</Text><Text style={[styles.stepDetail, { color: colors.textSecondary }]}>{step.detail}</Text></View></View>)}</View>
            {plan.categoryReferences.length > 0 && <View style={[styles.referencePanel, { backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]}><Text style={[styles.referenceTitle, { color: colors.text }]}>Optional category references</Text><Text style={[styles.referenceText, { color: colors.textSecondary }]}>{plan.categoryReferences.map((reference) => reference.label).join(" · ")}. These are source-labeled discovery categories, not product matches or availability claims.</Text></View>}
            <View style={[styles.disclosurePanel, { backgroundColor: `${colors.tint}0D` }]}><Ionicons name="shield-checkmark-outline" size={16} color={colors.tint} /><Text style={[styles.disclosureText, { color: colors.textSecondary }]}>{plan.disclosure}</Text></View>
            <Pressable onPress={() => router.push(plan.agent === "fashion" ? "/(tabs)/wardrobe" : "/skin")} accessibilityRole="button" accessibilityLabel={plan.agent === "fashion" ? "Review wardrobe" : "Return to Skin Care"} accessibilityHint="Continues with existing ClosetAI tools; no action is taken automatically." style={({ pressed }) => [styles.reviewButton, { borderColor: colors.border, backgroundColor: colors.surfaceSecondary, opacity: pressed ? 0.72 : 1 }]}><Text style={[styles.reviewButtonText, { color: colors.text }]}>{plan.agent === "fashion" ? "Review wardrobe" : "Explore Skin Care"}</Text><Ionicons name="arrow-forward" size={15} color={colors.tint} /></Pressable>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1 }, content: { padding: 18, paddingBottom: 120, gap: 14 }, flex: { flex: 1 },
  topRow: { flexDirection: "row", alignItems: "center", gap: 10, marginTop: 4 }, backButton: { width: 38, height: 38, borderWidth: 1, borderRadius: 13, alignItems: "center", justifyContent: "center" }, topLabel: { fontFamily: "Outfit_700Bold", fontSize: 9, letterSpacing: 1.1 },
  hero: { borderWidth: 1, borderRadius: 26, padding: 18, gap: 7 }, heroIcon: { width: 46, height: 46, borderRadius: 16, alignItems: "center", justifyContent: "center", marginBottom: 3 }, eyebrow: { fontFamily: "Outfit_700Bold", fontSize: 9, letterSpacing: 1.2 }, heroTitle: { fontFamily: "Outfit_700Bold", fontSize: 25, lineHeight: 31, letterSpacing: -0.4 }, heroBody: { fontFamily: "Outfit_400Regular", fontSize: 12, lineHeight: 18 },
  modeControl: { flexDirection: "row", padding: 4, borderWidth: 1, borderRadius: 16, gap: 4 }, modeButton: { flex: 1, minHeight: 42, borderRadius: 12, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7 }, modeButtonText: { fontFamily: "Outfit_700Bold", fontSize: 12 },
  demoBanner: { flexDirection: "row", alignItems: "flex-start", gap: 9, borderWidth: 1, borderRadius: 15, padding: 12 }, demoText: { flex: 1, fontFamily: "Outfit_500Medium", fontSize: 11, lineHeight: 16 },
  demoLibrary: { borderWidth: 1, borderRadius: 15, padding: 12, gap: 7 }, demoLibraryTitle: { fontFamily: "Outfit_700Bold", fontSize: 12 }, demoLibraryMeta: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 14 }, demoScenarioWrap: { flexDirection: "row", flexWrap: "wrap", gap: 7 }, demoScenarioChip: { borderWidth: 1, borderRadius: 12, paddingHorizontal: 9, paddingVertical: 7, minWidth: "30%" }, demoScenarioChipTitle: { fontFamily: "Outfit_700Bold", fontSize: 10 }, demoScenarioChipMeta: { fontFamily: "Outfit_400Regular", fontSize: 9, lineHeight: 12, marginTop: 2 }, demoLibraryDisclosure: { fontFamily: "Outfit_400Regular", fontSize: 9, lineHeight: 13 },
  formCard: { borderWidth: 1, borderRadius: 22, padding: 15, gap: 10 }, formTitle: { fontFamily: "Outfit_700Bold", fontSize: 18 }, formDescription: { fontFamily: "Outfit_400Regular", fontSize: 11, lineHeight: 16, marginBottom: 3 }, fieldLabel: { fontFamily: "Outfit_700Bold", fontSize: 11, marginTop: 3 }, choiceWrap: { flexDirection: "row", flexWrap: "wrap", gap: 7 }, choice: { minHeight: 34, borderWidth: 1, borderRadius: 11, paddingHorizontal: 10, alignItems: "center", justifyContent: "center" }, choiceText: { fontFamily: "Outfit_600SemiBold", fontSize: 10 },
  switchRow: { flexDirection: "row", alignItems: "center", gap: 10, borderWidth: 1, borderRadius: 14, padding: 11, marginTop: 2 }, switchCopy: { flex: 1 }, switchTitle: { fontFamily: "Outfit_700Bold", fontSize: 11 }, switchDetail: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 14, marginTop: 2 },
  promptInput: { minHeight: 78, borderWidth: 1, borderRadius: 14, padding: 11, fontFamily: "Outfit_400Regular", fontSize: 12, textAlignVertical: "top" }, characterCount: { alignSelf: "flex-end", fontFamily: "Outfit_400Regular", fontSize: 10, marginTop: -5 }, createButton: { minHeight: 52, borderRadius: 15, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 8, marginTop: 2 }, createButtonText: { fontFamily: "Outfit_700Bold", fontSize: 13 },
  statusCard: { minHeight: 52, borderWidth: 1, borderRadius: 15, padding: 12, flexDirection: "row", alignItems: "center", gap: 10 }, statusText: { flex: 1, fontFamily: "Outfit_500Medium", fontSize: 11, lineHeight: 16 }, errorCard: { flexDirection: "row", borderWidth: 1, borderRadius: 16, padding: 13, gap: 10 }, errorTitle: { fontFamily: "Outfit_700Bold", fontSize: 12 }, errorText: { fontFamily: "Outfit_400Regular", fontSize: 11, lineHeight: 16, marginTop: 2 },
  planCard: { borderWidth: 1, borderRadius: 22, padding: 15, gap: 12 }, planHeader: { flexDirection: "row", gap: 10, alignItems: "flex-start" }, planIcon: { width: 38, height: 38, borderRadius: 13, alignItems: "center", justifyContent: "center" }, planKicker: { fontFamily: "Outfit_700Bold", fontSize: 9, letterSpacing: 1.05 }, planTitle: { fontFamily: "Outfit_700Bold", fontSize: 18, lineHeight: 23, marginTop: 2 }, planSummary: { fontFamily: "Outfit_400Regular", fontSize: 12, lineHeight: 18 }, contextWrap: { flexDirection: "row", flexWrap: "wrap", gap: 6 }, contextChip: { borderWidth: 1, borderRadius: 999, paddingHorizontal: 8, paddingVertical: 5 }, contextChipText: { fontFamily: "Outfit_600SemiBold", fontSize: 9 },
  stepsWrap: { gap: 11 }, stepRow: { flexDirection: "row", gap: 10, alignItems: "flex-start" }, stepNumber: { width: 24, height: 24, borderRadius: 12, alignItems: "center", justifyContent: "center", marginTop: 1 }, stepNumberText: { fontFamily: "Outfit_700Bold", fontSize: 10 }, stepTitle: { fontFamily: "Outfit_700Bold", fontSize: 12 }, stepDetail: { fontFamily: "Outfit_400Regular", fontSize: 11, lineHeight: 16, marginTop: 1 },
  referencePanel: { borderWidth: 1, borderRadius: 14, padding: 11 }, referenceTitle: { fontFamily: "Outfit_700Bold", fontSize: 11 }, referenceText: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 15, marginTop: 3 }, disclosurePanel: { flexDirection: "row", alignItems: "flex-start", gap: 8, borderRadius: 14, padding: 11 }, disclosureText: { flex: 1, fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 15 }, reviewButton: { minHeight: 45, borderWidth: 1, borderRadius: 14, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7 }, reviewButtonText: { fontFamily: "Outfit_700Bold", fontSize: 12 },
});
