import { QueryClientProvider } from "@tanstack/react-query";
import { Stack } from "expo-router";
import * as SplashScreen from "expo-splash-screen";
import React, { useEffect } from "react";
import { StyleSheet } from "react-native";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { queryClient } from "@/lib/query-client";
import { AppProvider } from "@/contexts/AppContext";
import { SkinCareProvider } from "@/contexts/SkinCareContext";
import { SelfieScanProvider } from "@/contexts/SelfieScanContext";
import { MockCommerceProvider } from "@/contexts/MockCommerceContext";
import {
  useFonts,
  Outfit_300Light,
  Outfit_400Regular,
  Outfit_500Medium,
  Outfit_600SemiBold,
  Outfit_700Bold,
} from "@expo-google-fonts/outfit";

SplashScreen.preventAutoHideAsync();

function RootLayoutNav() {
  return (
    <Stack screenOptions={{ headerBackTitle: "Back" }}>
      <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
      <Stack.Screen name="onboarding" options={{ headerShown: false, gestureEnabled: false }} />
      <Stack.Screen name="add-item" options={{ headerShown: false, presentation: "modal" }} />
      <Stack.Screen name="outfit-detail" options={{ headerShown: false, presentation: "modal" }} />
      <Stack.Screen name="settings" options={{ headerShown: false, presentation: "modal" }} />
      <Stack.Screen name="tryon-result" options={{ headerShown: false, presentation: "modal" }} />
      <Stack.Screen name="item-detail" options={{ headerShown: false, presentation: "modal" }} />
      <Stack.Screen name="skin" options={{ headerShown: false, presentation: "modal" }} />
      <Stack.Screen name="subscription" options={{ headerShown: false, presentation: "modal" }} />
      <Stack.Screen name="business-dashboard" options={{ headerShown: false, presentation: "modal" }} />
      <Stack.Screen name="commerce-agent" options={{ headerShown: false, presentation: "modal" }} />
    </Stack>
  );
}

export default function RootLayout() {
  const [fontsLoaded, fontError] = useFonts({
    Outfit_300Light,
    Outfit_400Regular,
    Outfit_500Medium,
    Outfit_600SemiBold,
    Outfit_700Bold,
  });

  useEffect(() => {
    if (fontsLoaded || fontError) {
      SplashScreen.hideAsync();
    }
  }, [fontsLoaded, fontError]);

  if (!fontsLoaded && !fontError) return null;

  return <SafeAreaProvider>
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <GestureHandlerRootView style={styles.root}>
          <AppProvider>
            <SkinCareProvider>
              <MockCommerceProvider>
                <SelfieScanProvider>
                  <RootLayoutNav />
                </SelfieScanProvider>
              </MockCommerceProvider>
            </SkinCareProvider>
          </AppProvider>
        </GestureHandlerRootView>
      </QueryClientProvider>
    </ErrorBoundary>
  </SafeAreaProvider>;
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
  },
});
