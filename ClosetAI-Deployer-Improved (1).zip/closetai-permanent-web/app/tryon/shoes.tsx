import { Ionicons } from "@expo/vector-icons";
import { Image } from "expo-image";
import { router, useFocusEffect } from "expo-router";
import * as ImagePicker from "expo-image-picker";
import React from "react";
import { Alert, Linking, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

import { createAiShoesTryOn } from "@/lib/ai-shoes-tryon";
import { selectedImageUriToBase64 } from "@/lib/selected-image-base64";
import { useTheme } from "@/lib/useTheme";
import { interaction } from "@/constants/colors";
import { MediaStatusCard } from "@/components/ui/MediaStatusCard";
import { clearAiShoesRetryQueue, createAiShoesRetryQueueEntry, loadAiShoesRetryQueue, saveAiShoesRetryQueue, type AiShoesRetryQueueEntry } from "@/lib/ai-shoes-retry-queue";
import { AI_SHOES_RENDER_STYLES, AI_SHOES_RENDERING_SETTINGS, AI_SHOES_TRYON_DISCLOSURE, type AiShoesRenderStyle, type AiShoesRenderingSetting, type AiShoesTryOnResult } from "@shared/ai-shoes-tryon";

const STYLE_COPY: Record<AiShoesRenderStyle, string> = {
  random: "Provider-selected render treatment",
  style_minimalist: "Minimalist render treatment",
  style_bohemian: "Bohemian render treatment",
  style_cottagecore: "Cottagecore render treatment",
  style_french_elegance: "French elegance render treatment",
  style_retro_fashion: "Retro fashion render treatment",
};

function asDataImageUri(base64: string, uri: string) {
  if (base64.startsWith("data:image/")) return base64;
  const mime = /\.png(?:$|\?)/i.test(uri) ? "image/png" : "image/jpeg";
  return `data:${mime};base64,${base64}`;
}

export default function AiShoesTryOnScreen() {
  const { colors } = useTheme();
  const [targetUri, setTargetUri] = React.useState<string | null>(null);
  const [referenceUri, setReferenceUri] = React.useState<string | null>(null);
  const [style, setStyle] = React.useState<AiShoesRenderStyle>("random");
  const [renderingSetting, setRenderingSetting] = React.useState<AiShoesRenderingSetting>("female");
  const [targetPhotoConfirmed, setTargetPhotoConfirmed] = React.useState(false);
  const [referenceConfirmed, setReferenceConfirmed] = React.useState(false);
  const [consent, setConsent] = React.useState(false);
  const [result, setResult] = React.useState<AiShoesTryOnResult | null>(null);
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [status, setStatus] = React.useState<string | null>(null);
  const [photoPermissionState, setPhotoPermissionState] = React.useState<"unknown" | "granted" | "blocked">("unknown");
  const [queuedRetry, setQueuedRetry] = React.useState<AiShoesRetryQueueEntry | null>(null);
  const isMountedRef = React.useRef(true);
  const tryOnRunRef = React.useRef(0);
  const queueActionRef = React.useRef(false);

  React.useEffect(() => () => {
    isMountedRef.current = false;
    tryOnRunRef.current += 1;
  }, []);

  useFocusEffect(React.useCallback(() => {
    let active = true;
    void ImagePicker.getMediaLibraryPermissionsAsync().then((permission) => {
      if (active) setPhotoPermissionState(permission.granted ? "granted" : "blocked");
    }).catch(() => {
      if (active) setPhotoPermissionState("unknown");
    });
    void loadAiShoesRetryQueue().then((entry) => {
      if (active) setQueuedRetry(entry);
    });
    return () => { active = false; };
  }, []));

  const openPhotoSettings = async () => {
    try {
      await Linking.openSettings();
    } catch {
      Alert.alert("Open settings manually", "Photo access can be changed in your device settings. The selected-photo workflow remains optional.");
    }
  };

  const chooseImage = async (kind: "target" | "reference") => {
    setError(null);
    setStatus(null);
    try {
      const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!permission.granted) { setPhotoPermissionState("blocked"); setError("Photo-library access is needed to choose your target photo or shoe reference. You can enable it in device settings and try again."); return; }
      setPhotoPermissionState("granted");
      const picked = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ["images"], allowsEditing: true, aspect: kind === "target" ? [3, 4] : [1, 1], quality: 0.85, exif: false });
      if (!picked.canceled && picked.assets[0]) {
        if (kind === "target") { setTargetUri(picked.assets[0].uri); setTargetPhotoConfirmed(false); }
        else { setReferenceUri(picked.assets[0].uri); setReferenceConfirmed(false); }
                setResult(null);
        setQueuedRetry(null);
        void clearAiShoesRetryQueue();
      }
    } catch (pickError) {
 setError(pickError instanceof Error ? pickError.message : "We could not open your photos. Please try again."); }
  };

  const canSubmit = Boolean(targetUri && referenceUri && targetPhotoConfirmed && referenceConfirmed && consent && !busy);
  const createPreview = async (queuedInput?: AiShoesRetryQueueEntry) => {
    const activeTargetUri = queuedInput?.targetUri ?? targetUri;
    const activeReferenceUri = queuedInput?.referenceUri ?? referenceUri;
    const activeStyle = queuedInput?.style ?? style;
    const activeRenderingSetting = queuedInput?.renderingSetting ?? renderingSetting;
    const activeTargetPhotoConfirmed = queuedInput?.targetPhotoConfirmed ?? targetPhotoConfirmed;
    const activeReferenceConfirmed = queuedInput?.referenceConfirmed ?? referenceConfirmed;
    const activeConsent = queuedInput?.consent ?? consent;
    if (!activeTargetUri || !activeReferenceUri || !activeTargetPhotoConfirmed || !activeReferenceConfirmed || !activeConsent || busy) return;
    const runId = tryOnRunRef.current + 1;
    tryOnRunRef.current = runId;
    const isCurrentRun = () => tryOnRunRef.current === runId;
    setBusy(true); setError(null); setStatus(null); setResult(null);
    try {
      const [targetBase64, referenceBase64] = await Promise.all([selectedImageUriToBase64(activeTargetUri), selectedImageUriToBase64(activeReferenceUri)]);
      if (!isCurrentRun() || !isMountedRef.current) return;
      const response = await createAiShoesTryOn({
        targetImageBase64: asDataImageUri(targetBase64, activeTargetUri),
        shoeReferenceBase64: asDataImageUri(referenceBase64, activeReferenceUri),
        style: activeStyle, renderingSetting: activeRenderingSetting, targetPhotoConfirmed: activeTargetPhotoConfirmed, referenceConfirmed: activeReferenceConfirmed, consent: activeConsent,
      });
      if (!isCurrentRun() || !isMountedRef.current) return;
      setResult(response.tryOn);
      setQueuedRetry(null);
      void clearAiShoesRetryQueue();
    } catch (requestError) {
      if (isCurrentRun() && isMountedRef.current) {
        setError(requestError instanceof Error ? requestError.message : "Shoe virtual try-on is unavailable. No image was shown.");
        const entry = createAiShoesRetryQueueEntry({ targetUri: activeTargetUri, referenceUri: activeReferenceUri, style: activeStyle, renderingSetting: activeRenderingSetting, targetPhotoConfirmed: true, referenceConfirmed: true, consent: true });
        void saveAiShoesRetryQueue(entry).then(() => {
          if (isMountedRef.current && isCurrentRun()) setQueuedRetry(entry);
        }).catch(() => {
          // The visible error remains actionable when local persistence is unavailable.
        });
      }
    } finally {
      if (isCurrentRun()) {
        tryOnRunRef.current = 0;
        if (isMountedRef.current) setBusy(false);
      }
    }
  };

  const retryQueuedPreview = () => {
    if (!queuedRetry || busy || queueActionRef.current) return;
    queueActionRef.current = true;
    const entry = queuedRetry;
    setTargetUri(entry.targetUri);
    setReferenceUri(entry.referenceUri);
    setStyle(entry.style);
    setRenderingSetting(entry.renderingSetting);
    setTargetPhotoConfirmed(true);
    setReferenceConfirmed(true);
    setConsent(true);
    setQueuedRetry(null);
    void clearAiShoesRetryQueue();
    void createPreview(entry).finally(() => {
      queueActionRef.current = false;
    });
  };

  const dismissQueuedPreview = () => {
    setQueuedRetry(null);
    void clearAiShoesRetryQueue();
  };

  const cancelPreview = () => {
    tryOnRunRef.current += 1;
    setBusy(false);
    setError(null);
    setQueuedRetry(null);
    void clearAiShoesRetryQueue();
    setStatus("Shoe preview cancelled. Your selected photos and settings remain available for review.");
  };

  const Check = ({ checked, onPress, label, children }: { checked: boolean; onPress: () => void; label: string; children: React.ReactNode }) => <Pressable onPress={onPress} style={styles.checkRow} accessibilityRole="checkbox" accessibilityState={{ checked }} accessibilityLabel={label}><Ionicons name={checked ? "checkbox-outline" : "square-outline"} size={22} color={checked ? colors.tint : colors.textTertiary} /><Text style={[styles.checkText, { color: colors.textSecondary }]}>{children}</Text></Pressable>;

  return <View style={[styles.page, { backgroundColor: colors.background }]}><ScrollView contentContainerStyle={styles.content}>
    <View style={styles.header}><Pressable onPress={() => router.back()} hitSlop={10} accessibilityRole="button" accessibilityLabel="Go back"><Ionicons name="chevron-back" size={25} color={colors.text} /></Pressable><View style={styles.headerCopy}><Text style={[styles.eyebrow, { color: colors.tint }]}>USER-PHOTO-ONLY VIRTUAL TRY-ON</Text><Text style={[styles.title, { color: colors.text }]}>AI shoes preview</Text></View><Ionicons name="footsteps-outline" size={21} color={colors.tint} /></View>
    <View style={[styles.notice, { backgroundColor: colors.surfaceSecondary }]}><Ionicons name="information-circle-outline" size={17} color={colors.tint} /><Text style={[styles.noticeText, { color: colors.textSecondary }]}>{AI_SHOES_TRYON_DISCLOSURE}</Text></View>
    {photoPermissionState === "blocked" && <View style={[styles.notice, { backgroundColor: colors.surfaceSecondary, borderWidth: 1, borderColor: colors.border }]} accessibilityLiveRegion="polite"><Ionicons name="lock-closed-outline" size={17} color={colors.tint} /><Text style={[styles.noticeText, { color: colors.textSecondary }]}>Photo access is currently off. Enable it in Settings to choose your target or shoe reference images.</Text><Pressable onPress={() => { void openPhotoSettings(); }} accessibilityRole="button" accessibilityLabel="Open photo settings" style={{ borderWidth: 1, borderColor: colors.border, borderRadius: 10, paddingHorizontal: 9, paddingVertical: 7 }}><Text style={{ color: colors.text, fontFamily: "Outfit_600SemiBold", fontSize: 10 }}>Settings</Text></Pressable></View>}

    <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}><Text style={[styles.cardTitle, { color: colors.text }]}>1. Choose your target photo</Text><Text style={[styles.body, { color: colors.textSecondary }]}>Use a clear photo containing only you, with your face visible and head-to-chest or half-body framing. No stock model is ever substituted.</Text><Pressable onPress={() => chooseImage("target")} style={({ pressed }) => [styles.imagePicker, { borderColor: targetUri ? colors.tint : colors.border, backgroundColor: colors.background, opacity: pressed ? 0.78 : 1, transform: [{ scale: pressed ? interaction.cardPressScale : 1 }] }]} accessibilityRole="button" accessibilityLabel={targetUri ? "Replace your selected target photo" : "Choose your target photo"} accessibilityHint="The preview uses only the photo you select.">{targetUri ? <Image source={{ uri: targetUri }} contentFit="cover" style={styles.selectedImage} accessibilityLabel="Selected user target photo. Select to replace it." /> : <><Ionicons name="person-add-outline" size={25} color={colors.tint} /><Text style={[styles.pickerText, { color: colors.text }]}>Choose your photo</Text></>}</Pressable>{targetUri && <MediaStatusCard kind="user-photo" title="Your target photo is selected" detail="This selected photo is the only person image sent to create this temporary preview." tint={colors.tint} surface={colors.surfaceSecondary} border={colors.border} />}</View>

    <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}><Text style={[styles.cardTitle, { color: colors.text }]}>2. Choose one shoe product reference</Text><Text style={[styles.body, { color: colors.textSecondary }]}>Select one clear, unobstructed shoe product image. Do not use a collage, multiple shoes, or an image you do not have permission to use.</Text><Pressable onPress={() => chooseImage("reference")} style={({ pressed }) => [styles.imagePicker, { borderColor: referenceUri ? colors.tint : colors.border, backgroundColor: colors.background, opacity: pressed ? 0.78 : 1, transform: [{ scale: pressed ? interaction.cardPressScale : 1 }] }]} accessibilityRole="button" accessibilityLabel={referenceUri ? "Replace your shoe product reference image" : "Choose shoe product reference image"} accessibilityHint="Select one shoe reference image you have permission to use.">{referenceUri ? <Image source={{ uri: referenceUri }} contentFit="cover" style={styles.selectedImage} accessibilityLabel="Selected shoe reference image. Select to replace it." /> : <><Ionicons name="footsteps-outline" size={25} color={colors.tint} /><Text style={[styles.pickerText, { color: colors.text }]}>Choose shoe reference</Text></>}</Pressable>{referenceUri && <MediaStatusCard kind="reference" title="Your shoe reference is selected" detail="This product reference is used only for the temporary virtual try-on render." tint={colors.tint} surface={colors.surfaceSecondary} border={colors.border} />}</View>

    <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}><Text style={[styles.cardTitle, { color: colors.text }]}>3. Choose documented render controls</Text><Text style={[styles.body, { color: colors.textSecondary }]}>The provider requires a rendering setting. Select the one you want used for this image render; ClosetAI does not infer it from your photo or treat it as identity data.</Text><Text style={[styles.sectionLabel, { color: colors.text }]}>Provider rendering setting</Text><View style={styles.chips}>{AI_SHOES_RENDERING_SETTINGS.map((item) => <Pressable key={item} onPress={() => { setRenderingSetting(item); setResult(null); setQueuedRetry(null); void clearAiShoesRetryQueue(); }} style={[styles.chip, { borderColor: renderingSetting === item ? colors.tint : colors.border, backgroundColor: renderingSetting === item ? `${colors.tint}12` : colors.background }]} accessibilityRole="radio" accessibilityState={{ checked: renderingSetting === item }} accessibilityLabel={`Select ${item} provider rendering setting`}><Text style={[styles.chipText, { color: renderingSetting === item ? colors.tint : colors.textSecondary }]}>{item === "female" ? "Female rendering setting" : "Male rendering setting"}</Text></Pressable>)}</View><Text style={[styles.sectionLabel, { color: colors.text }]}>Visual render style</Text><View style={styles.styleList}>{AI_SHOES_RENDER_STYLES.map((item) => <Pressable key={item} onPress={() => { setStyle(item); setResult(null); setQueuedRetry(null); void clearAiShoesRetryQueue(); }} style={[styles.styleOption, { borderColor: style === item ? colors.tint : colors.border, backgroundColor: style === item ? `${colors.tint}12` : colors.background }]} accessibilityRole="radio" accessibilityState={{ checked: style === item }} accessibilityLabel={`Select ${STYLE_COPY[item]}`}><Ionicons name={style === item ? "radio-button-on-outline" : "radio-button-off-outline"} size={18} color={style === item ? colors.tint : colors.textTertiary} /><Text style={[styles.styleText, { color: colors.textSecondary }]}>{STYLE_COPY[item]}</Text></Pressable>)}</View></View>

    <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}><Text style={[styles.cardTitle, { color: colors.text }]}>4. Confirm before creating</Text><Check checked={targetPhotoConfirmed} onPress={() => setTargetPhotoConfirmed((value) => !value)} label="I confirm that the target photo is my own and contains only me">I confirm that the target photo is my own and contains only me.</Check><Check checked={referenceConfirmed} onPress={() => setReferenceConfirmed((value) => !value)} label="I confirm the reference contains one shoe product and I may use it">I confirm that the reference contains one shoe product and that I may use the image for this preview.</Check><Check checked={consent} onPress={() => setConsent((value) => !value)} label="I understand this is a creative virtual try-on visualization">I understand this is a creative visualization, not a fit, size, comfort, purchase, body-measurement, identity, or gender assessment.</Check></View>

    <Pressable onPress={() => { void createPreview(); }} disabled={!canSubmit} style={({ pressed }) => [styles.primaryButton, { backgroundColor: colors.text, opacity: canSubmit ? (pressed ? 0.82 : 1) : interaction.disabledOpacity, transform: [{ scale: pressed && canSubmit ? interaction.primaryPressScale : 1 }] }]} accessibilityRole="button" accessibilityState={{ disabled: !canSubmit, busy }} accessibilityLabel="Create AI Shoes virtual try-on preview" accessibilityHint={canSubmit ? "Creates a temporary provider result using your selected images only." : "Choose both images and complete all confirmations to enable this action."}><Ionicons name="footsteps-outline" size={18} color={colors.background} /><Text style={[styles.primaryText, { color: colors.background }]}>{busy ? "Creating temporary preview…" : "Create shoe preview"}</Text></Pressable>
    {busy && <View style={[styles.busyCard, { backgroundColor: `${colors.tint}12` }]} accessibilityLiveRegion="polite" accessibilityRole="progressbar" accessibilityState={{ busy: true }} accessibilityLabel="Creating temporary AI Shoes preview"><Ionicons name="hourglass-outline" size={17} color={colors.tint} /><Text style={[styles.busyText, { color: colors.textSecondary }]}>Preparing a temporary provider render from your two selected images…</Text><Pressable onPress={cancelPreview} style={[styles.cancelButton, { borderColor: colors.border }]} accessibilityRole="button" accessibilityLabel="Cancel AI Shoes preview" accessibilityHint="Stops the current request and keeps your selected photos and settings available for review."><Ionicons name="close-circle-outline" size={17} color={colors.textSecondary} /><Text style={[styles.cancelButtonText, { color: colors.text }]}>Cancel preview</Text></Pressable></View>}
    {queuedRetry && !busy && <View style={[styles.queueCard, { backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]} accessibilityLiveRegion="polite" accessibilityLabel="AI Shoes retry saved locally. The provider request did not complete. Your selected target photo, shoe reference, consent, and settings remain available. No stock or fabricated preview was added."><Ionicons name="cloud-offline-outline" size={18} color={colors.warning} /><View style={styles.queueContent}><Text style={[styles.queueTitle, { color: colors.text }]}>AI Shoes retry saved locally</Text><Text style={[styles.errorText, { color: colors.textSecondary }]}>The provider request did not complete. Your selected target photo, shoe reference, consent, and render settings remain available; no stock or fabricated preview was added.</Text><View style={styles.queueActions}><Pressable onPress={retryQueuedPreview} accessibilityRole="button" accessibilityLabel="Retry saved AI Shoes preview" accessibilityHint="Retries the same two selected images and settings." style={({ pressed }) => [styles.retryButton, { borderColor: colors.border, backgroundColor: colors.surface, opacity: pressed ? 0.72 : 1 }]}><Ionicons name="refresh-outline" size={14} color={colors.tint} /><Text style={[styles.retryButtonText, { color: colors.tint }]}>Retry now</Text></Pressable><Pressable onPress={dismissQueuedPreview} accessibilityRole="button" accessibilityLabel="Dismiss saved AI Shoes retry" style={({ pressed }) => [{ paddingVertical: 7, opacity: pressed ? 0.72 : 1 }]}><Text style={[styles.dismissText, { color: colors.textSecondary }]}>Dismiss</Text></Pressable></View></View></View>}
    {status && <View style={[styles.statusCard, { backgroundColor: `${colors.success}12`, borderColor: colors.border }]} accessibilityLiveRegion="polite"><Ionicons name="checkmark-circle-outline" size={17} color={colors.success} /><Text style={[styles.statusText, { color: colors.textSecondary }]}>{status}</Text></View>}
    <Text style={[styles.helper, { color: colors.textTertiary }]}>Target, reference, and result data are not added to history. If live processing fails, no stock, demo, stale, or fabricated preview is shown.</Text>
    {result && <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}><Text style={[styles.cardTitle, { color: colors.text }]}>Temporary shoe virtual try-on preview</Text><Image source={{ uri: result.resultUrl }} contentFit="contain" style={[styles.preview, { backgroundColor: colors.surfaceSecondary }]} accessibilityLabel="Temporary provider-rendered shoe virtual try-on preview" /><MediaStatusCard kind="temporary-result" title="Temporary provider-rendered preview" detail="This visual is not saved to your history and is not a fit, size, or purchase guarantee." tint={colors.tint} surface={colors.surfaceSecondary} border={colors.border} /><Text style={[styles.stageNote, { color: colors.textSecondary }]}>{STYLE_COPY[result.style]} · user-selected provider rendering setting. This is not a fit or purchase guarantee.</Text></View>}
    {error && <View style={[styles.errorCard, { backgroundColor: `${colors.error}12` }]} accessibilityLiveRegion="assertive" accessibilityRole="alert"><Ionicons name="alert-circle-outline" size={18} color={colors.error} /><Text style={[styles.errorText, { color: colors.error }]}>{error}</Text>{canSubmit && <Pressable onPress={() => { void createPreview(); }} accessibilityRole="button" accessibilityLabel="Retry AI Shoes preview" accessibilityHint="Retries the preview with the same selected photos and settings." style={[styles.retryButton, { borderColor: colors.border }]}><Text style={[styles.retryButtonText, { color: colors.text }]}>Retry</Text></Pressable>}</View>}
  </ScrollView></View>;
}

const styles = StyleSheet.create({ page: { flex: 1 }, content: { padding: 20, paddingBottom: 50, gap: 13 }, header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 10 }, headerCopy: { flex: 1, alignItems: "center" }, eyebrow: { fontFamily: "Outfit_700Bold", fontSize: 8, letterSpacing: 0.8, textAlign: "center" }, title: { fontFamily: "Outfit_700Bold", fontSize: 18, marginTop: 3, textAlign: "center" }, notice: { flexDirection: "row", alignItems: "flex-start", gap: 8, borderRadius: 15, padding: 12 }, noticeText: { flex: 1, fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 15 }, card: { borderWidth: 1, borderRadius: 18, padding: 15 }, cardTitle: { fontFamily: "Outfit_700Bold", fontSize: 15, marginTop: 1 }, body: { fontFamily: "Outfit_400Regular", fontSize: 11, lineHeight: 16, marginTop: 5 }, cancelButton: { marginTop: 10, borderWidth: 1, borderRadius: 12, paddingHorizontal: 13, paddingVertical: 8, flexDirection: "row", alignItems: "center", gap: 6 }, cancelButtonText: { fontFamily: "Outfit_600SemiBold", fontSize: 11 }, retryButton: { borderWidth: 1, borderRadius: 10, paddingHorizontal: 9, paddingVertical: 7, marginLeft: 4 }, retryButtonText: { fontFamily: "Outfit_600SemiBold", fontSize: 10 }, statusCard: { flexDirection: "row", alignItems: "flex-start", gap: 8, borderWidth: 1, borderRadius: 14, padding: 12 }, statusText: { flex: 1, fontFamily: "Outfit_400Regular", fontSize: 11, lineHeight: 16 }, imagePicker: { height: 172, marginTop: 12, borderWidth: 1, borderStyle: "dashed", borderRadius: 14, alignItems: "center", justifyContent: "center", gap: 7, overflow: "hidden" }, selectedImage: { width: "100%", height: "100%" }, pickerText: { fontFamily: "Outfit_600SemiBold", fontSize: 12 }, sectionLabel: { fontFamily: "Outfit_600SemiBold", fontSize: 12, marginTop: 15 }, chips: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginTop: 8 }, chip: { borderWidth: 1, borderRadius: 12, paddingVertical: 8, paddingHorizontal: 10 }, chipText: { fontFamily: "Outfit_600SemiBold", fontSize: 10 }, styleList: { gap: 7, marginTop: 8 }, styleOption: { borderWidth: 1, borderRadius: 12, flexDirection: "row", alignItems: "center", gap: 8, padding: 10 }, styleText: { fontFamily: "Outfit_500Medium", fontSize: 10, flex: 1 }, checkRow: { flexDirection: "row", alignItems: "flex-start", gap: 9, marginTop: 12 }, checkText: { flex: 1, fontFamily: "Outfit_500Medium", fontSize: 11, lineHeight: 16 }, primaryButton: { minHeight: 49, borderRadius: 14, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, paddingHorizontal: 14, marginTop: 2 }, primaryText: { fontFamily: "Outfit_700Bold", fontSize: 13 }, helper: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 14, textAlign: "center", marginTop: -4 }, preview: { width: "100%", height: 330, borderRadius: 14, marginTop: 12 }, stageNote: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 15, marginTop: 10 }, busyCard: { flexDirection: "row", alignItems: "center", gap: 8, borderRadius: 14, padding: 12, marginTop: -3 }, busyText: { flex: 1, fontFamily: "Outfit_500Medium", fontSize: 10, lineHeight: 15 }, errorCard: { flexDirection: "row", alignItems: "flex-start", gap: 8, borderRadius: 14, padding: 12 }, errorText: { flex: 1, fontFamily: "Outfit_500Medium", fontSize: 11, lineHeight: 16 }, queueCard: { flexDirection: "row", alignItems: "flex-start", gap: 8, borderRadius: 14, borderWidth: 1, padding: 12 }, queueContent: { flex: 1, gap: 8 }, queueTitle: { fontFamily: "Outfit_700Bold", fontSize: 11 }, queueActions: { flexDirection: "row", alignItems: "center", gap: 12 }, dismissText: { fontFamily: "Outfit_500Medium", fontSize: 10 }, });
