import React, { useState } from "react";
import {
  ActivityIndicator,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  Platform,
  Alert,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import * as Haptics from "expo-haptics";
import { router, useLocalSearchParams } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useApp } from "@/contexts/AppContext";
import { useTheme } from "@/lib/useTheme";
import { interaction, shadows } from "@/constants/colors";
import {
  createCommercePlan,
  searchCommerceCandidates,
} from "@/lib/commerce-agent";
import {
  COMMERCE_PLAN_TIERS,
  COMMERCE_MONETIZATION_DISCLOSURE,
} from "@/shared/commerce-monetization";
import { trackAffiliateClick } from "@/lib/commerce-attribution";
import { COMMERCE_CREDIT_PACKS } from "@/shared/commerce-entitlements";
import {
  getUserEntitlements,
  updateUserTier,
  logFunnelEvent,
} from "@/lib/commerce-entitlements-resolver";
import {
  createBillingIntent,
  approveAndFulfillBillingIntent,
} from "@/lib/billing-intent";
import {
  prepareCheckoutSession,
  approveAndCompleteCheckout,
} from "@/lib/checkout-session";
import {
  addPriceWatchRule,
  getPriceWatchRules,
  loadPriceWatchRules,
} from "@/lib/price-watch";
import type {
  CommerceCandidate,
  CommerceAgentPlan,
  CheckoutSession,
} from "@/shared/agentic-commerce-contracts";

const QUICK_PROMPTS = [
  "Find a lightweight moisturizer under $35",
  "Find a structured wool blazer under $200",
  "Compare reviews for barrier repair creams",
  "Watch price on silk blend trousers",
];

export default function CommerceAgentScreen() {
  const { colors, isDark } = useTheme();
  const insets = useSafeAreaInsets();
  const { demoMode } = useApp();
  const params = useLocalSearchParams<{ initialQuery?: string }>();

  const [query, setQuery] = useState(params.initialQuery || "Find a lightweight moisturizer under $35");
  const [category, setCategory] = useState<"skincare" | "fashion">("skincare");
  const [plan, setPlan] = useState<CommerceAgentPlan | null>(null);
  const [candidates, setCandidates] = useState<CommerceCandidate[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [selectedCandidate, setSelectedCandidate] = useState<CommerceCandidate | null>(null);
  const [activeCheckoutSession, setActiveCheckoutSession] = useState<CheckoutSession | null>(null);
  const [selectedPlanTier, setSelectedPlanTier] = useState<"free" | "pro_shopper" | "concierge_enterprise">("free");
  const [userCredits, setUserCredits] = useState<number>(25);
  const currentTier = COMMERCE_PLAN_TIERS.find(t => t.id === selectedPlanTier) || COMMERCE_PLAN_TIERS[0];
  const [orderCompleted, setOrderCompleted] = useState(false);
  const [watchRules, setWatchRules] = useState(() => getPriceWatchRules());

  React.useEffect(() => {
    let isMounted = true;
    loadPriceWatchRules()
      .then(rules => {
        if (isMounted) setWatchRules([...rules]);
      })
      .catch(err => {
        console.warn('[Agentic Commerce] Failed to load price watch rules:', err);
      });

    getUserEntitlements()
      .then(ent => {
        if (isMounted) {
          setSelectedPlanTier(ent.tierId);
          setUserCredits(ent.creditsRemaining);
          logFunnelEvent('agentic_commerce_screen_viewed', { tierId: ent.tierId });
        }
      })
      .catch(err => {
        console.warn('[Agentic Commerce] Failed to load user entitlements:', err);
      });

    return () => {
      isMounted = false;
    };
  }, []);

  const webTopInset = Platform.OS === 'web' ? 67 : 0;

  const handleRunAgent = () => {
    if (!query.trim()) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setIsSearching(true);
    setSelectedCandidate(null);
    setActiveCheckoutSession(null);
    setOrderCompleted(false);
    logFunnelEvent("commerce_search_started", { query, category });

    setTimeout(() => {
      try {
        const cat = query.toLowerCase().includes("blazer") || query.toLowerCase().includes("trouser") ? "fashion" : "skincare";
        setCategory(cat);
        const newPlan = createCommercePlan(query, cat);
        const results = searchCommerceCandidates(query, cat, demoMode);
        setPlan(newPlan);
        setCandidates(results);
        setIsSearching(false);
        logFunnelEvent("commerce_search_completed", { candidatesCount: results.length });
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      } catch (err) {
        console.warn('[Agentic Commerce] Search execution error, using mock fallback:', err);
        const fallbackCat = 'fashion';
        setCategory(fallbackCat);
        setPlan(createCommercePlan(query, fallbackCat));
        const fallbackResults = searchCommerceCandidates('outfit', fallbackCat, true);
        setCandidates(fallbackResults);
        setIsSearching(false);
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
      }
    }, 600);
  };

  const handlePrepareCheckout = async (candidate: CommerceCandidate) => {
    try {
      Haptics.selectionAsync();
      await trackAffiliateClick(candidate.productId, candidate.merchantId, 0.05);
      setSelectedCandidate(candidate);
      const session = prepareCheckoutSession(candidate, 1);
      setActiveCheckoutSession(session);
      setOrderCompleted(false);
    } catch (err) {
      console.warn('[Agentic Commerce] Prepare checkout error:', err);
      Alert.alert('Checkout Notice', 'Unable to prepare secure checkout session. Please try again.');
    }
  };

  const handleConfirmPurchase = () => {
    try {
      if (!activeCheckoutSession) return;
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      const completed = approveAndCompleteCheckout(activeCheckoutSession);
      setActiveCheckoutSession(completed);
      setOrderCompleted(true);
    } catch (err) {
      console.warn('[Agentic Commerce] Confirm purchase error:', err);
      Alert.alert('Approval Notice', 'Unable to complete simulated purchase. Please verify payment details.');
    }
  };

  const handleAddPriceWatch = async (candidate: CommerceCandidate) => {
    try {
      Haptics.selectionAsync();
      if (watchRules.length >= currentTier.priceWatchLimit) {
        Alert.alert(
          "Contextual Upgrade: Price Watch",
          `Your current ${currentTier.name} plan allows up to ${currentTier.priceWatchLimit} active price watches. Upgrade to Pro Shopper to unlock unlimited price tracking and review intelligence.`,
          [
            { text: "Cancel", style: "cancel" },
            { 
              text: "Upgrade to Pro ($19.99)", 
              onPress: () => {
                setSelectedPlanTier("pro_shopper");
                Alert.alert("Success", "You are now on Pro Shopper! Unlimited price watches unlocked.");
              }
            }
          ]
        );
        return;
      }
      const updated = await addPriceWatchRule(candidate.productId, candidate.title, candidate.price);
      setWatchRules([...updated]);
      Alert.alert("Price Watch Active", `ClosetAI will notify you when ${candidate.title} drops below $${candidate.price.amount}. (${watchRules.length + 1}/${currentTier.priceWatchLimit} used)`);
    } catch (err) {
      console.warn('[Agentic Commerce] Add price watch error:', err);
      Alert.alert("Price Watch Notice", "Unable to establish price watch rule. Please try again.");
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: (insets.top || webTopInset) + 12, backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <Pressable onPress={() => router.back()} hitSlop={12} style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}>
          <Ionicons name="close" size={24} color={colors.textSecondary} />
        </Pressable>
        <View style={styles.headerTitleWrap}>
          <Text style={[styles.headerTitle, { color: colors.text }]}>Agentic Shopping Copilot</Text>
          <Text style={[styles.headerSubtitle, { color: colors.textSecondary }]}>Web Discovery, Reviews & Secure Checkout</Text>
        </View>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView contentContainerStyle={[styles.scrollContent, { paddingBottom: insets.bottom + 40 }]}>
        {/* Disclosure Banner */}
        <View style={[styles.disclosureBanner, { backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]}>
          <Ionicons name="information-circle-outline" size={16} color={colors.tint} />
          <Text style={[styles.disclosureText, { color: colors.textSecondary }]}>
            Agentic Commerce Simulation: Offers, review intelligence, and checkout sessions are verified prototype flows. Explicit user approval is required for all actions.
          </Text>
        </View>

        {/* Affiliate & Monetization Disclosure Banner */}
        <View style={[styles.disclosureBanner, { backgroundColor: isDark ? "rgba(168, 85, 247, 0.1)" : "rgba(168, 85, 247, 0.08)", borderColor: "#a855f7", marginTop: 8 }]}>
          <Ionicons name="pricetag-outline" size={16} color="#a855f7" />
          <Text style={[styles.disclosureText, { color: colors.textSecondary }]}>
            {COMMERCE_MONETIZATION_DISCLOSURE}
          </Text>
        </View>

        {/* Plan Tier Selector */}
        <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border, marginTop: 12 }]}>
          <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
            <Text style={[styles.cardTitle, { color: colors.text }]}>Shopping Copilot Plan ({userCredits} Credits)</Text>
            <Pressable
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                logFunnelEvent("plan_review_opened", { selectedPlanTier });
                Alert.alert(
                  "Subscription & Entitlements",
                  `Current Tier: ${currentTier.name}\nCredits Remaining: ${userCredits}\nPrice Watch Limit: ${currentTier.priceWatchLimit}\n\nChoose an upgrade option or credit pack below:`,
                  [
                    { text: "Close", style: "cancel" },
                    {
                      text: "Buy Credit Pack (500 pts - $14.99)",
                      onPress: async () => {
                        const intent = await createBillingIntent("credit_pack", "pack_creator", "Pro Creator Pack", 14.99);
                        const result = await approveAndFulfillBillingIntent(intent, userCredits);
                        setUserCredits(result.newCredits);
                        Alert.alert("Credit Pack Purchased", `Added credits successfully! New balance: ${result.newCredits}`);
                      }
                    },
                    { 
                      text: "Upgrade to Pro ($19.99/mo)", 
                      onPress: async () => {
                        const intent = await createBillingIntent("subscription", "pro_shopper", "Pro Shopper Subscription", 19.99);
                        const result = await approveAndFulfillBillingIntent(intent, userCredits);
                        setSelectedPlanTier(result.tierId);
                        setUserCredits(result.newCredits);
                        Alert.alert("Subscription Active", "You are now on Pro Shopper! Unlimited price watches unlocked.");
                      }
                    }
                  ]
                );
              }}
              style={{ backgroundColor: colors.primary, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12 }}
            >
              <Text style={{ color: "#fff", fontSize: 12, fontWeight: "600" }}>Manage Plan</Text>
            </Pressable>
          </View>
          <View style={{ flexDirection: "row", gap: 8 }}>
            {COMMERCE_PLAN_TIERS.map(tier => (
              <Pressable
                key={tier.id}
                onPress={() => {
                  Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                  setSelectedPlanTier(tier.id);
                }}
                style={{
                  flex: 1,
                  padding: 8,
                  borderRadius: 8,
                  borderWidth: 1,
                  borderColor: selectedPlanTier === tier.id ? colors.primary : colors.border,
                  backgroundColor: selectedPlanTier === tier.id ? (isDark ? "rgba(59, 130, 246, 0.15)" : "rgba(59, 130, 246, 0.1)") : "transparent",
                  alignItems: "center",
                }}
              >
                <Text style={{ fontSize: 12, fontWeight: "600", color: colors.text }}>{tier.name}</Text>
                <Text style={{ fontSize: 10, color: colors.textTertiary, marginTop: 2 }}>${tier.monthlyPrice}/mo</Text>
              </Pressable>
            ))}
          </View>
          <Text style={{ fontSize: 11, color: colors.textTertiary, marginTop: 8 }}>
            Active tier limits: {currentTier.priceWatchLimit} price watches, {currentTier.aiSearchesPerDay} daily AI searches.
          </Text>
        </View>

        {/* Input & Quick Prompts */}
        <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <View style={styles.cardHeader}>
            <Ionicons name="sparkles" size={18} color="#EC4899" />
            <Text style={[styles.cardTitle, { color: colors.text }]}>What should your AI shopping agent find?</Text>
          </View>
          <TextInput
            style={[styles.input, { backgroundColor: colors.surfaceSecondary, color: colors.text, borderColor: colors.border }]}
            value={query}
            onChangeText={setQuery}
            placeholder="e.g. Find lightweight moisturizer under $35"
            placeholderTextColor={colors.textTertiary}
            multiline
          />
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.quickPrompts}>
            {QUICK_PROMPTS.map((p, idx) => (
              <Pressable
                key={idx}
                onPress={() => {
                  setQuery(p);
                  Haptics.selectionAsync();
                }}
                style={({ pressed }) => [styles.promptChip, { backgroundColor: colors.surfaceSecondary, borderColor: colors.border, opacity: pressed ? 0.7 : 1 }]}
              >
                <Text style={[styles.promptChipText, { color: colors.text }]}>{p}</Text>
              </Pressable>
            ))}
          </ScrollView>

          <Pressable
            onPress={handleRunAgent}
            disabled={isSearching}
            style={({ pressed }) => [styles.runButton, { opacity: pressed || isSearching ? 0.8 : 1, transform: [{ scale: pressed ? interaction.primaryPressScale : 1 }] }]}
          >
            <LinearGradient colors={["#EC4899", "#8B5CF6"]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.runButtonGradient}>
              {isSearching ? (
                <ActivityIndicator size="small" color="#FFF" />
              ) : (
                <>
                  <Ionicons name="search" size={18} color="#FFF" />
                  <Text style={styles.runButtonText}>Run Shopping Agent</Text>
                </>
              )}
            </LinearGradient>
          </Pressable>
        </View>

        {/* Plan Display */}
        {plan && (
          <View style={[styles.planCard, { backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]}>
            <View style={styles.planHeader}>
              <Ionicons name="shield-checkmark-outline" size={16} color="#27AE60" />
              <Text style={[styles.planTitle, { color: colors.text }]}>Agent Execution Plan</Text>
            </View>
            <Text style={[styles.planCopy, { color: colors.textSecondary }]}>
              Goal: {plan.goal} • Category: {plan.category} • Mode: {demoMode ? "Fictional Demo" : "Live Verified Feed"}
            </Text>
            {plan.actions.map((act, i) => (
              <View key={i} style={styles.planActionRow}>
                <Ionicons name="checkmark-circle" size={14} color="#EC4899" />
                <Text style={[styles.planActionText, { color: colors.text }]}>{act}</Text>
              </View>
            ))}
          </View>
        )}

        {/* Candidates Result List */}
        {candidates.length > 0 && (
          <View style={styles.candidatesSection}>
            <Text style={[styles.sectionTitle, { color: colors.text }]}>Verified Offers & Review Intelligence</Text>
            {candidates.map(candidate => (
              <View key={candidate.productId} style={[styles.candidateCard, { backgroundColor: colors.surface, borderColor: colors.border }, shadows.soft]}>
                <View style={styles.candidateHeader}>
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.brandName, { color: colors.textSecondary }]}>{candidate.brand || "Verified Brand"}</Text>
                    <Text style={[styles.productTitle, { color: colors.text }]}>{candidate.title}</Text>
                  </View>
                  <View style={styles.priceBadge}>
                    <Text style={styles.priceText}>${candidate.price.amount.toFixed(2)}</Text>
                    <Text style={styles.currencyText}>{candidate.price.currency}</Text>
                  </View>
                </View>

                <View style={styles.metaRow}>
                  <View style={styles.metaBadge}>
                    <Ionicons name="storefront-outline" size={13} color={colors.tint} />
                    <Text style={[styles.metaText, { color: colors.textSecondary }]}>{candidate.merchantId}</Text>
                  </View>
                  <View style={styles.metaBadge}>
                    <Ionicons name="shield-checkmark-outline" size={13} color="#27AE60" />
                    <Text style={[styles.metaText, { color: colors.textSecondary }]}>{candidate.source.providerName} ({Math.round(candidate.source.confidence * 100)}% conf)</Text>
                  </View>
                </View>
                <View style={styles.provenanceRow}>
                  <Ionicons name="time-outline" size={12} color={colors.textTertiary} />
                  <Text style={[styles.provenanceText, { color: colors.textTertiary }]}>
                    Verified {new Date(candidate.lastCheckedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} • {candidate.source.isDemo ? "Demo Data Mode" : "Live Verified Feed"}
                  </Text>
                </View>

                {candidate.reviewSummary && (
                  <View style={[styles.reviewSummaryBox, { backgroundColor: colors.surfaceSecondary }]}>
                    <View style={styles.reviewHeader}>
                      <Ionicons name="star" size={14} color="#F1C40F" />
                      <Text style={[styles.reviewRating, { color: colors.text }]}>{candidate.reviewSummary.averageRating} / 5.0 ({candidate.reviewSummary.totalReviews} reviews)</Text>
                    </View>
                    <Text style={[styles.reviewTheme, { color: colors.textSecondary }]}>Pros: {candidate.reviewSummary.positiveThemes.join(" • ")}</Text>
                  </View>
                )}

                <View style={styles.cardActionRow}>
                  <Pressable
                    onPress={() => handleAddPriceWatch(candidate)}
                    style={({ pressed }) => [styles.actionSubButton, { borderColor: colors.border, opacity: pressed ? 0.7 : 1 }]}
                  >
                    <Ionicons name="notifications-outline" size={14} color={colors.text} />
                    <Text style={[styles.actionSubText, { color: colors.text }]}>Watch Price</Text>
                  </Pressable>

                  <Pressable
                    onPress={() => handlePrepareCheckout(candidate)}
                    style={({ pressed }) => [styles.actionPrimaryButton, { opacity: pressed ? 0.8 : 1 }]}
                  >
                    <LinearGradient colors={["#EC4899", "#8B5CF6"]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.gradientButtonInner}>
                      <Ionicons name="bag-check-outline" size={14} color="#FFF" />
                      <Text style={styles.actionPrimaryText}>Prepare Checkout</Text>
                    </LinearGradient>
                  </Pressable>
                </View>
              </View>
            ))}
          </View>
        )}

        {/* Active Checkout Session Modal / Bottom Card */}
        {activeCheckoutSession && (
          <View style={[styles.checkoutCard, { backgroundColor: colors.surface, borderColor: '#EC4899', borderWidth: 2 }, shadows.soft]}>
            <View style={styles.checkoutHeader}>
              <Ionicons name="lock-closed" size={18} color="#27AE60" />
              <Text style={[styles.checkoutTitle, { color: colors.text }]}>Secure Agent Checkout Preparation</Text>
            </View>
            <Text style={[styles.checkoutSub, { color: colors.textSecondary }]}>
              Review order details below. ClosetAI requires your explicit confirmation before completing any transaction.
            </Text>

            <View style={[styles.receiptBox, { backgroundColor: colors.surfaceSecondary }]}>
              <View style={styles.receiptRow}>
                <Text style={[styles.receiptLabel, { color: colors.textSecondary }]}>Item</Text>
                <Text style={[styles.receiptValue, { color: colors.text }]}>{activeCheckoutSession.title}</Text>
              </View>
              <View style={styles.receiptRow}>
                <Text style={[styles.receiptLabel, { color: colors.textSecondary }]}>Merchant</Text>
                <Text style={[styles.receiptValue, { color: colors.text }]}>{activeCheckoutSession.merchantName}</Text>
              </View>
              <View style={styles.receiptRow}>
                <Text style={[styles.receiptLabel, { color: colors.textSecondary }]}>Subtotal</Text>
                <Text style={[styles.receiptValue, { color: colors.text }]}>${activeCheckoutSession.subtotal.amount.toFixed(2)}</Text>
              </View>
              <View style={styles.receiptRow}>
                <Text style={[styles.receiptLabel, { color: colors.textSecondary }]}>Shipping</Text>
                <Text style={[styles.receiptValue, { color: colors.text }]}>${activeCheckoutSession.shipping.amount.toFixed(2)}</Text>
              </View>
              <View style={styles.receiptRow}>
                <Text style={[styles.receiptLabel, { color: colors.textSecondary }]}>Tax (Est.)</Text>
                <Text style={[styles.receiptValue, { color: colors.text }]}>${activeCheckoutSession.tax.amount.toFixed(2)}</Text>
              </View>
              <View style={[styles.receiptRow, styles.receiptTotalRow]}>
                <Text style={[styles.receiptTotalLabel, { color: colors.text }]}>Total</Text>
                <Text style={[styles.receiptTotalValue, { color: '#EC4899' }]}>${activeCheckoutSession.total.amount.toFixed(2)} {activeCheckoutSession.total.currency}</Text>
              </View>
            </View>

            {orderCompleted ? (
              <View style={styles.successBox}>
                <Ionicons name="checkmark-circle" size={24} color="#27AE60" />
                <Text style={styles.successText}>Order Confirmed & Completed via Agentic Checkout Protocol!</Text>
              </View>
            ) : (
              <Pressable
                onPress={handleConfirmPurchase}
                style={({ pressed }) => [styles.confirmButton, { opacity: pressed ? 0.8 : 1 }]}
              >
                <LinearGradient colors={["#27AE60", "#2ECC71"]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.gradientButtonInner}>
                  <Ionicons name="checkmark-done-circle" size={18} color="#FFF" />
                  <Text style={styles.actionPrimaryText}>Confirm & Complete Checkout (User Authorized)</Text>
                </LinearGradient>
              </Pressable>
            )}
          </View>
        )}

        {/* Price Watches Summary */}
        {watchRules.length > 0 && (
          <View style={[styles.watchCard, { backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]}>
            <View style={styles.watchHeader}>
              <Ionicons name="notifications" size={16} color="#EC4899" />
              <Text style={[styles.watchTitle, { color: colors.text }]}>Active Price Watches ({watchRules.length})</Text>
            </View>
            {watchRules.map(r => (
              <View key={r.id} style={styles.watchRow}>
                <Text style={[styles.watchItemText, { color: colors.text }]}>{r.title}</Text>
                <Text style={[styles.watchPriceText, { color: colors.textSecondary }]}>Target: ${r.targetPrice.amount.toFixed(2)}</Text>
              </View>
            ))}
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingBottom: 12,
    borderBottomWidth: 1,
  },
  headerTitleWrap: { alignItems: "center" },
  headerTitle: { fontFamily: "Outfit_700Bold", fontSize: 16 },
  headerSubtitle: { fontFamily: "Outfit_400Regular", fontSize: 11, marginTop: 2 },
  scrollContent: { padding: 16, gap: 16 },
  card: { borderWidth: 1, borderRadius: 16, padding: 16, gap: 12 },
  cardHeader: { flexDirection: "row", alignItems: "center", gap: 8 },
  cardTitle: { fontFamily: "Outfit_600SemiBold", fontSize: 14 },
  input: {
    borderWidth: 1,
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontFamily: "Outfit_400Regular",
    fontSize: 14,
    minHeight: 70,
    textAlignVertical: "top",
  },
  quickPrompts: { gap: 8, paddingVertical: 4 },
  promptChip: { borderWidth: 1, borderRadius: 12, paddingHorizontal: 10, paddingVertical: 6 },
  promptChipText: { fontFamily: "Outfit_500Medium", fontSize: 11 },
  runButton: { borderRadius: 14, overflow: "hidden", marginTop: 4 },
  runButtonGradient: { height: 48, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8 },
  runButtonText: { fontFamily: "Outfit_600SemiBold", fontSize: 14, color: "#FFF" },
  planCard: { borderWidth: 1, borderRadius: 16, padding: 14, gap: 8 },
  planHeader: { flexDirection: "row", alignItems: "center", gap: 6 },
  planTitle: { fontFamily: "Outfit_700Bold", fontSize: 13 },
  planCopy: { fontFamily: "Outfit_400Regular", fontSize: 12 },
  planActionRow: { flexDirection: "row", alignItems: "center", gap: 6, marginTop: 2 },
  planActionText: { fontFamily: "Outfit_400Regular", fontSize: 11 },
  candidatesSection: { gap: 12 },
  sectionTitle: { fontFamily: "Outfit_700Bold", fontSize: 15, marginBottom: 4 },
  candidateCard: { borderWidth: 1, borderRadius: 16, padding: 14, gap: 10 },
  candidateHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" },
  brandName: { fontFamily: "Outfit_500Medium", fontSize: 11, textTransform: "uppercase", letterSpacing: 0.5 },
  productTitle: { fontFamily: "Outfit_700Bold", fontSize: 14, marginTop: 2 },
  priceBadge: { alignItems: "flex-end" },
  priceText: { fontFamily: "Outfit_700Bold", fontSize: 16, color: "#EC4899" },
  currencyText: { fontFamily: "Outfit_400Regular", fontSize: 10, color: "#8E8E93" },
  metaRow: { flexDirection: "row", gap: 12 },
  metaBadge: { flexDirection: "row", alignItems: "center", gap: 4 },
  metaText: { fontFamily: "Outfit_400Regular", fontSize: 11 },
  provenanceRow: { flexDirection: "row", alignItems: "center", gap: 4, marginTop: -2 },
  provenanceText: { fontFamily: "Outfit_400Regular", fontSize: 10 },
  reviewSummaryBox: { borderRadius: 10, padding: 8, gap: 4 },
  reviewHeader: { flexDirection: "row", alignItems: "center", gap: 4 },
  reviewRating: { fontFamily: "Outfit_600SemiBold", fontSize: 12 },
  reviewTheme: { fontFamily: "Outfit_400Regular", fontSize: 11 },
  cardActionRow: { flexDirection: "row", gap: 8, marginTop: 4 },
  actionSubButton: { flex: 1, height: 40, borderWidth: 1, borderRadius: 12, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6 },
  actionSubText: { fontFamily: "Outfit_500Medium", fontSize: 12 },
  actionPrimaryButton: { flex: 1, height: 40, borderRadius: 12, overflow: "hidden" },
  gradientButtonInner: { flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6 },
  actionPrimaryText: { fontFamily: "Outfit_600SemiBold", fontSize: 12, color: "#FFF" },
  checkoutCard: { borderWidth: 2, borderRadius: 18, padding: 16, gap: 12 },
  checkoutHeader: { flexDirection: "row", alignItems: "center", gap: 8 },
  checkoutTitle: { fontFamily: "Outfit_700Bold", fontSize: 15 },
  checkoutSub: { fontFamily: "Outfit_400Regular", fontSize: 12 },
  receiptBox: { borderRadius: 12, padding: 12, gap: 6 },
  receiptRow: { flexDirection: "row", justifyContent: "space-between" },
  receiptLabel: { fontFamily: "Outfit_400Regular", fontSize: 12 },
  receiptValue: { fontFamily: "Outfit_500Medium", fontSize: 12 },
  receiptTotalRow: { borderTopWidth: 1, borderTopColor: "rgba(0,0,0,0.06)", paddingTop: 6, marginTop: 4 },
  receiptTotalLabel: { fontFamily: "Outfit_700Bold", fontSize: 13 },
  receiptTotalValue: { fontFamily: "Outfit_700Bold", fontSize: 14 },
  confirmButton: { height: 48, borderRadius: 14, overflow: "hidden", marginTop: 4 },
  successBox: { flexDirection: "row", alignItems: "center", gap: 8, padding: 12, backgroundColor: "rgba(39, 174, 96, 0.1)", borderRadius: 12 },
  successText: { fontFamily: "Outfit_600SemiBold", fontSize: 12, color: "#27AE60", flex: 1 },
  watchCard: { borderWidth: 1, borderRadius: 14, padding: 12, gap: 6 },
  watchHeader: { flexDirection: "row", alignItems: "center", gap: 6 },
  watchTitle: { fontFamily: "Outfit_600SemiBold", fontSize: 12 },
  watchRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  watchItemText: { fontFamily: "Outfit_400Regular", fontSize: 12 },
  watchPriceText: { fontFamily: "Outfit_500Medium", fontSize: 11 },
  disclosureBanner: { flexDirection: "row", alignItems: "center", gap: 10, borderWidth: 1, borderRadius: 14, padding: 12 },
  disclosureText: { fontFamily: "Outfit_400Regular", fontSize: 11, flex: 1, lineHeight: 15 },
});
