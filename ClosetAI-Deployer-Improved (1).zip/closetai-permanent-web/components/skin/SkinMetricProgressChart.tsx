import React from "react";
import { ActivityIndicator, Alert, Pressable, StyleSheet, Text, View } from "react-native";

import { clearSkinMetricHistory, loadSkinMetricHistory, type SkinMetricHistoryPoint } from "@/lib/skin-metric-history";
import { buildSkinProgressOverview, getSkinProgressMetricPoints, progressDirectionLabel, PROGRESS_METRICS, SKIN_PROGRESS_DISCLOSURE } from "@/lib/skin-progress-trends";

function formatSnapshotDate(value?: string): string {
  if (!value) return "—";
  const date = new Date(value);
  return Number.isFinite(date.getTime()) ? date.toLocaleDateString(undefined, { month: "short", day: "numeric" }) : "Saved snapshot";
}

function sourceLabel(sources: string[]): string {
  if (sources.length === 0) return "No source yet";
  if (sources.length > 1) return "Mixed local sources";
  if (sources[0] === "demo") return "Fictional Demo Mode";
  if (sources[0] === "youcam") return "Normalized live snapshots";
  return "Local cached snapshots";
}

export function SkinMetricProgressChart({ colors }: { colors: any }) {
  const [selected, setSelected] = React.useState("hydration");
  const [points, setPoints] = React.useState<SkinMetricHistoryPoint[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [notice, setNotice] = React.useState<string | null>(null);

  const refresh = React.useCallback(async () => {
    setLoading(true);
    try {
      const rows = await loadSkinMetricHistory();
      setPoints(rows);
      setNotice(null);
    } catch {
      setNotice("Local normalized history is unavailable on this device right now. No fictional trend values are shown.");
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => { void refresh(); }, [refresh]);

  const overview = React.useMemo(() => buildSkinProgressOverview(points), [points]);
  const availableMetrics = React.useMemo(() => PROGRESS_METRICS.filter((metric) => points.some((point) => point.metricKey === metric.key)), [points]);
  React.useEffect(() => {
    if (availableMetrics.length && !availableMetrics.some((metric) => metric.key === selected)) setSelected(availableMetrics[0]!.key);
  }, [availableMetrics, selected]);
  const selectedPoints = React.useMemo(() => getSkinProgressMetricPoints(points, selected), [points, selected]);
  const selectedSummary = React.useMemo(() => overview.metricSummaries.find((summary) => summary.metricKey === selected), [overview.metricSummaries, selected]);
  const selectedMetric = PROGRESS_METRICS.find((metric) => metric.key === selected);

  const clearLocalHistory = () => {
    Alert.alert(
      "Clear local progress history?",
      "This removes only normalized snapshot values stored on this device. Original selfies, raw provider output, and remote provider data are not stored here and are not affected. This cannot be undone.",
      [
        { text: "Cancel", style: "cancel" },
        { text: "Clear local history", style: "destructive", onPress: () => { void (async () => {
          try {
            await clearSkinMetricHistory();
            setPoints([]);
            setNotice("Local normalized metric history was cleared on this device.");
          } catch {
            setNotice("We could not clear local normalized history on this device. Please try again.");
          }
        })(); } },
      ],
    );
  };

  const reflectionPrompt = overview.snapshotCount >= 2
    ? "Reflection prompt: What routine step felt sustainable between these saved snapshots?"
    : "After you save another optional snapshot, you can use this space to reflect on a routine that feels sustainable.";

  return <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
    <View style={styles.header}>
      <View style={styles.headerCopy}>
        <Text style={[styles.title, { color: colors.text }]}>Your Progress</Text>
        <Text style={[styles.subtitle, { color: colors.textSecondary }]}>Saved normalized scores only. Photos and raw API data are not stored here. Local snapshot trends are for reflection.</Text>
      </View>
      <Pressable onPress={() => { void refresh(); }} style={[styles.refresh, { backgroundColor: colors.surfaceSecondary }]} accessibilityRole="button" accessibilityLabel="Refresh local snapshot trends"><Text style={[styles.refreshText, { color: colors.tint }]}>Refresh</Text></Pressable>
    </View>

    {loading ? <View style={styles.empty}><ActivityIndicator color={colors.tint} /></View> : notice ? <View style={styles.notice}><Text style={[styles.emptyText, { color: colors.textSecondary }]}>{notice}</Text><Pressable onPress={() => { void refresh(); }} style={[styles.outlineButton, { borderColor: colors.border }]} accessibilityRole="button"><Text style={[styles.outlineButtonText, { color: colors.text }]}>Try refresh</Text></Pressable></View> : <>
      <View style={[styles.overview, { backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]}>
        <View style={styles.overviewRow}><View><Text style={[styles.overviewValue, { color: colors.text }]}>{overview.snapshotCount}</Text><Text style={[styles.overviewLabel, { color: colors.textSecondary }]}>local snapshots</Text></View><View><Text style={[styles.overviewValue, { color: colors.text }]}>{overview.captureDayCount}</Text><Text style={[styles.overviewLabel, { color: colors.textSecondary }]}>capture days</Text></View><View style={styles.overviewSource}><Text style={[styles.sourceBadge, { color: colors.tint }]}>{sourceLabel(overview.sources)}</Text><Text style={[styles.overviewLabel, { color: colors.textSecondary }]}>{formatSnapshotDate(overview.firstCapturedAt)} → {formatSnapshotDate(overview.latestCapturedAt)}</Text></View></View>
        <Text style={[styles.overviewNote, { color: colors.textSecondary }]}>{overview.note}</Text>
      </View>

      <Text style={[styles.disclosure, { color: colors.textTertiary }]}>{SKIN_PROGRESS_DISCLOSURE}</Text>
      {points.length > 0 && <Pressable onPress={clearLocalHistory} style={[styles.clearButton, { borderColor: colors.border }]} accessibilityRole="button" accessibilityLabel="Clear local normalized progress history"><Text style={[styles.clearText, { color: colors.textSecondary }]}>Clear local history</Text></Pressable>}

      {availableMetrics.length === 0 ? <Text style={[styles.emptyText, { color: colors.textSecondary }]}>Save an optional demo or live snapshot to begin a local trend history. Demo snapshots stay clearly fictional.</Text> : <>
        <View style={styles.chips}>{availableMetrics.map((metric) => <Pressable key={metric.key} onPress={() => setSelected(metric.key)} style={[styles.chip, { borderColor: selected === metric.key ? colors.tint : colors.border, backgroundColor: selected === metric.key ? `${colors.tint}14` : "transparent" }]} accessibilityRole="radio" accessibilityState={{ checked: selected === metric.key }} accessibilityLabel={`Show ${metric.label} snapshot trend`}><Text style={[styles.chipText, { color: selected === metric.key ? colors.tint : colors.textSecondary }]}>{metric.label}</Text></Pressable>)}</View>
        <View style={styles.summaryRow}><View style={styles.flex}><Text style={[styles.summaryTitle, { color: colors.text }]}>{selectedMetric?.label ?? "Metric"} Snapshot direction
</Text><Text style={[styles.summaryNote, { color: colors.textSecondary }]}>{selectedSummary?.note}</Text></View><Text style={[styles.directionBadge, { color: selectedSummary?.direction === "up" ? colors.success : selectedSummary?.direction === "down" ? colors.tint : colors.textSecondary }]}>{progressDirectionLabel(selectedSummary?.direction ?? "insufficient")}</Text></View>
        {selectedPoints.length < 2 ? <Text style={[styles.emptyText, { color: colors.textSecondary }]}>Save at least two snapshots from one source context to draw a local {selectedMetric?.label.toLowerCase()} direction. No outcome is inferred from a single snapshot.</Text> : <View style={styles.chart}>{selectedPoints.map((point, index) => { const label = formatSnapshotDate(point.capturedAt); const sourceColor = point.source === "demo" ? colors.warning : point.source === "youcam" ? colors.tint : colors.textSecondary; return <View key={`${point.scanId}-${point.metricKey}`} style={styles.barColumn} accessible accessibilityLabel={`${selectedMetric?.label ?? point.metricKey} normalized score ${Math.round(point.score)} saved ${label}, ${point.source} source`}><Text style={[styles.barValue, { color: colors.text }]}>{Math.round(point.score)}</Text><View style={[styles.barTrack, { backgroundColor: colors.surfaceSecondary }]}><View style={[styles.bar, { height: `${Math.max(4, Math.min(100, point.score))}%`, backgroundColor: sourceColor }]} /></View><Text style={[styles.barLabel, { color: colors.textTertiary }]}>{index === selectedPoints.length - 1 ? "Latest" : label}</Text><Text style={[styles.barSource, { color: colors.textTertiary }]}>{point.source === "demo" ? "Demo" : point.source === "youcam" ? "Live" : "Cached"}</Text></View>; })}</View>}
      </>}
      <Text style={[styles.reflection, { color: colors.textSecondary }]}>{reflectionPrompt}</Text>
    </>}
  </View>;
}

const styles = StyleSheet.create({
  card: { borderWidth: 1, borderRadius: 18, padding: 14, marginBottom: 13 },
  header: { flexDirection: "row", gap: 10, justifyContent: "space-between" }, headerCopy: { flex: 1 }, title: { fontFamily: "Outfit_700Bold", fontSize: 14 }, subtitle: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 14, marginTop: 2 },
  refresh: { borderRadius: 10, paddingHorizontal: 9, paddingVertical: 6, alignSelf: "flex-start" }, refreshText: { fontFamily: "Outfit_600SemiBold", fontSize: 10 },
  overview: { borderWidth: 1, borderRadius: 13, padding: 11, marginTop: 12 }, overviewRow: { flexDirection: "row", alignItems: "flex-start", gap: 14 }, overviewValue: { fontFamily: "Outfit_700Bold", fontSize: 16 }, overviewLabel: { fontFamily: "Outfit_400Regular", fontSize: 8, lineHeight: 12, marginTop: 1 }, overviewSource: { flex: 1 }, sourceBadge: { fontFamily: "Outfit_700Bold", fontSize: 9, lineHeight: 13 }, overviewNote: { fontFamily: "Outfit_400Regular", fontSize: 9, lineHeight: 13, marginTop: 8 },
  disclosure: { fontFamily: "Outfit_400Regular", fontSize: 9, lineHeight: 13, marginTop: 10 }, clearButton: { alignSelf: "flex-start", borderWidth: 1, borderRadius: 10, paddingHorizontal: 9, paddingVertical: 6, marginTop: 9 }, clearText: { fontFamily: "Outfit_600SemiBold", fontSize: 9 },
  chips: { flexDirection: "row", gap: 6, flexWrap: "wrap", marginTop: 12 }, chip: { borderWidth: 1, borderRadius: 13, paddingHorizontal: 9, paddingVertical: 6 }, chipText: { fontFamily: "Outfit_600SemiBold", fontSize: 10 },
  summaryRow: { flexDirection: "row", alignItems: "flex-start", gap: 10, marginTop: 13 }, flex: { flex: 1 }, summaryTitle: { fontFamily: "Outfit_700Bold", fontSize: 11 }, summaryNote: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 14, marginTop: 3 }, directionBadge: { fontFamily: "Outfit_700Bold", fontSize: 10, textAlign: "right" },
  empty: { minHeight: 100, alignItems: "center", justifyContent: "center" }, notice: { minHeight: 100, alignItems: "center", justifyContent: "center" }, emptyText: { fontFamily: "Outfit_400Regular", fontSize: 11, lineHeight: 16, textAlign: "center", paddingVertical: 18 }, outlineButton: { borderWidth: 1, borderRadius: 10, paddingHorizontal: 10, paddingVertical: 7, marginTop: -8 }, outlineButtonText: { fontFamily: "Outfit_600SemiBold", fontSize: 10 },
  chart: { height: 192, flexDirection: "row", alignItems: "flex-end", justifyContent: "space-between", gap: 8, paddingTop: 16 }, barColumn: { flex: 1, height: "100%", alignItems: "center", justifyContent: "flex-end" }, barValue: { fontFamily: "Outfit_700Bold", fontSize: 11, marginBottom: 5 }, barTrack: { height: 112, width: "72%", maxWidth: 26, borderRadius: 8, overflow: "hidden", justifyContent: "flex-end" }, bar: { width: "100%", borderRadius: 8 }, barLabel: { fontFamily: "Outfit_500Medium", fontSize: 8, marginTop: 6, textAlign: "center" }, barSource: { fontFamily: "Outfit_400Regular", fontSize: 7, marginTop: 2, textAlign: "center" },
  reflection: { fontFamily: "Outfit_500Medium", fontSize: 10, lineHeight: 15, marginTop: 12, paddingTop: 10, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: "#00000020" },
});
