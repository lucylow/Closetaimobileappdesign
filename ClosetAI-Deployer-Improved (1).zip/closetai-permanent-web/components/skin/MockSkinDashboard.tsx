import { Ionicons } from "@expo/vector-icons";
import React from "react";
import { router } from "expo-router";
import { Alert, Linking, Pressable, StyleSheet, Text, View } from "react-native";

import { type DemoRoutineStep, type DemoSkinMetric, type DemoSkinProfile } from "@/lib/skin-demo-profiles";
import { boundedPercent } from "@/lib/selfie-quality";
import { getDemoPaletteIdeas, getDemoPriorities, getDemoProducts, getDemoProgressHistory, getDemoWardrobeRecommendations, type DemoPaletteIdea, type DemoPriority, type DemoProduct, type DemoProgressPoint, type DemoWardrobeRecommendation } from "@/lib/skin-demo-content";
import { MockCommercePanel } from "@/components/skin/MockCommercePanel";

interface MockSkinDashboardProps {
  profile: DemoSkinProfile;
  colors: any;
  isScanning: boolean;
  hasRunDemo: boolean;
  onRunDemoScan: () => void;
  onAddSelfie: () => void;
  onOpenWardrobe: () => void;
  onBuildLook: () => void;
}

const metricIcons: Record<string, keyof typeof Ionicons.glyphMap> = {
  hydration: "water-outline",
  oiliness: "contrast-outline",
  texture: "sparkles-outline",
  pores: "ellipse-outline",
  redness: "flame-outline",
  blemishes: "medical-outline",
  radiance: "sunny-outline",
  "dark-spots": "color-palette-outline",
  "fine-lines": "analytics-outline",
};

function metricAccent(status: DemoSkinMetric["status"], colors: any) {
  if (status === "Excellent") return colors.success;
  if (status === "Low" || status === "Low Concern") return colors.tint;
  if (status === "Moderate") return colors.warning;
  return colors.tint;
}

function MetricCard({ metric, colors }: { metric: DemoSkinMetric; colors: any }) {
  const accent = metricAccent(metric.status, colors);
  return (
    <View style={[styles.metricCard, { backgroundColor: colors.surface, borderColor: colors.border }]}> 
      <View style={styles.metricTop}>
        <View style={[styles.metricIcon, { backgroundColor: `${accent}16` }]}>
          <Ionicons name={metricIcons[metric.id] ?? "sparkles-outline"} size={16} color={accent} />
        </View>
        <Text style={[styles.metricScore, { color: accent }]}>{metric.score}</Text>
      </View>
      <Text style={[styles.metricLabel, { color: colors.text }]}>{metric.label}</Text>
      <Text style={[styles.metricStatus, { color: accent }]}>{metric.status}</Text>
      <View style={[styles.track, { backgroundColor: colors.borderLight ?? colors.border }]}>
        <View style={[styles.fill, { backgroundColor: accent, width: `${boundedPercent(metric.score)}%` }]} />
      </View>
      <Text style={[styles.metricDescription, { color: colors.textSecondary }]} numberOfLines={3}>{metric.description}</Text>
    </View>
  );
}

function RoutineSection({
  title,
  icon,
  steps,
  colors,
}: {
  title: string;
  icon: keyof typeof Ionicons.glyphMap;
  steps: DemoRoutineStep[];
  colors: any;
}) {
  const [expanded, setExpanded] = React.useState(true);
  return (
    <View style={[styles.routineCard, { backgroundColor: colors.surface, borderColor: colors.border }]}> 
      <Pressable onPress={() => setExpanded((value) => !value)} style={styles.routineHeader} accessibilityRole="button" accessibilityLabel={`${expanded ? "Collapse" : "Expand"} ${title}`}>
        <View style={[styles.routineIcon, { backgroundColor: `${colors.tint}16` }]}>
          <Ionicons name={icon} size={18} color={colors.tint} />
        </View>
        <Text style={[styles.routineTitle, { color: colors.text }]}>{title}</Text>
        <Ionicons name={expanded ? "chevron-up" : "chevron-down"} size={18} color={colors.textTertiary} />
      </Pressable>
      {expanded && steps.map((step) => (
        <View key={step.id} style={styles.routineRow}>
          <View style={[styles.stepNumber, { backgroundColor: `${colors.tint}16` }]}>
            <Text style={[styles.stepNumberText, { color: colors.tint }]}>{String(step.step).padStart(2, "0")}</Text>
          </View>
          <View style={styles.flex}>
            <View style={styles.stepTitleLine}>
              <Text style={[styles.stepName, { color: colors.text }]}>{step.name}</Text>
              <Text style={[styles.stepDuration, { color: colors.textTertiary }]}>{step.duration}</Text>
            </View>
            <Text style={[styles.stepCategory, { color: colors.tint }]}>{step.category}</Text>
            <Text style={[styles.stepDescription, { color: colors.textSecondary }]}>{step.description}</Text>
          </View>
        </View>
      ))}
    </View>
  );
}

function PriorityCard({ item, colors }: { item: DemoPriority; colors: any }) {
  return (
    <View style={[styles.priorityCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
      <View style={[styles.priorityIcon, { backgroundColor: `${colors.tint}16` }]}>
        <Ionicons name={item.icon} size={18} color={colors.tint} />
      </View>
      <View style={styles.flex}>
        <Text style={[styles.priorityTitle, { color: colors.text }]}>{item.title}</Text>
        <Text style={[styles.priorityExplanation, { color: colors.textSecondary }]}>{item.explanation}</Text>
        <Text style={[styles.priorityAction, { color: colors.tint }]}>{item.action}</Text>
      </View>
    </View>
  );
}

function ProductCard({ product, colors }: { product: DemoProduct; colors: any }) {
  const productIcon: Record<DemoProduct["category"], keyof typeof Ionicons.glyphMap> = {
    Cleanser: "water-outline",
    Serum: "beaker-outline",
    Moisturizer: "heart-outline",
    SPF: "sunny-outline",
    Treatment: "sparkles-outline",
  };
  const openOfficialListing = () => Linking.openURL(product.officialUrl).catch(() => Alert.alert("Official listing unavailable", "We could not open the manufacturer page. Please try again later."));
  return (
    <View style={[styles.productCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
      <View style={styles.productHead}>
        <View style={[styles.productIcon, { backgroundColor: `${colors.tint}16` }]}>
          <Ionicons name={productIcon[product.category]} size={18} color={colors.tint} />
        </View>
        <View style={styles.flex}>
          <Text style={[styles.productCategory, { color: colors.tint }]}>{product.category.toUpperCase()}</Text>
          <Text style={[styles.productName, { color: colors.text }]}>{product.name}</Text>
        </View>
        <Text style={[styles.productSource, { color: colors.tint }]}>REAL CATALOG</Text>
      </View>
      <Text style={[styles.productMeta, { color: colors.textTertiary }]}>{product.brand} · {product.routine} · {product.sourceLabel}</Text>
      <Text style={[styles.productWhy, { color: colors.textSecondary }]}>Ingredients highlighted by the manufacturer: {product.primaryIngredients.join(", ")}</Text>
      <Text style={[styles.productWhy, { color: colors.textSecondary }]}>{product.usageNote}</Text>
      <View style={styles.tagRow}>
        {product.supports.map((signal) => <View key={signal} style={[styles.tag, { backgroundColor: `${colors.tint}14` }]}><Text style={[styles.tagText, { color: colors.tint }]}>{signal}</Text></View>)}
      </View>
      <Text style={[styles.productAvailability, { color: colors.textTertiary }]}>{product.availabilityNotice}</Text>
      <MockCommercePanel productId={product.id} colors={colors} />
      <Pressable onPress={openOfficialListing} style={[styles.productButton, { borderColor: colors.border }]} accessibilityRole="link" accessibilityLabel={`${product.officialCartAvailable ? "Add to cart on official site" : "View official product listing"} for ${product.name}`}>
        <Text style={[styles.productButtonText, { color: colors.text }]} >{product.officialCartAvailable ? "Add to Cart on Official Site" : "View Official Listing"}</Text>
        <Ionicons name="open-outline" size={14} color={colors.tint} />
      </Pressable>
    </View>
  );
}

function PaletteCard({ idea, colors }: { idea: DemoPaletteIdea; colors: any }) {
  return (
    <View style={[styles.paletteCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
      <Text style={[styles.paletteTitle, { color: colors.text }]}>{idea.title}</Text>
      <View style={styles.tagRow}>
        {idea.colors.map((colour) => <View key={colour} style={[styles.tag, { backgroundColor: `${colors.tint}14` }]}><Text style={[styles.tagText, { color: colors.tint }]}>{colour}</Text></View>)}
      </View>
      <Text style={[styles.paletteReason, { color: colors.textSecondary }]}>{idea.reason}</Text>
    </View>
  );
}

function ProgressHistory({ colors, history }: { colors: any; history: DemoProgressPoint[] }) {
  return (
    <View style={[styles.progressCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
      <Text style={[styles.progressCaption, { color: colors.textSecondary }]}>Demo history preview · fictional reference values</Text>
      {history.map((point) => (
        <View key={point.label} style={styles.progressRow}>
          <View style={styles.progressLabelRow}>
            <Text style={[styles.progressLabel, { color: colors.text }]}>{point.label}</Text>
            <View style={styles.progressScoreRow}>
              {typeof point.change === "number" && <Text style={[styles.progressChange, { color: colors.success }]}>+{point.change}</Text>}
              <Text style={[styles.progressScore, { color: colors.tint }]}>{point.score}</Text>
            </View>
          </View>
          <View style={[styles.track, { backgroundColor: colors.borderLight ?? colors.border }]}>
            <View style={[styles.fill, { backgroundColor: colors.tint, width: `${boundedPercent(point.score)}%` }]} />
          </View>
        </View>
      ))}
    </View>
  );
}

function WardrobeDemoCard({ recommendation, colors }: { recommendation: DemoWardrobeRecommendation; colors: any }) {
  return <View style={[styles.wardrobeDemoCard, { backgroundColor: colors.surface, borderColor: colors.border }]}><View style={styles.wardrobeDemoHead}><View style={[styles.styleIcon, { backgroundColor: `${colors.tint}16` }]}><Ionicons name="shirt-outline" size={17} color={colors.tint} /></View><View style={styles.flex}><Text style={[styles.wardrobeDemoTitle, { color: colors.text }]}>{recommendation.title}</Text><Text style={[styles.wardrobeDemoOccasion, { color: colors.tint }]}>{recommendation.occasion}</Text></View></View><Text style={[styles.wardrobeDemoPieces, { color: colors.textSecondary }]}>{recommendation.pieces.join(" · ")}</Text><Text style={[styles.wardrobeDemoAccessories, { color: colors.textSecondary }]}>Finish with: {recommendation.accessories.join(" · ")}</Text><Text style={[styles.wardrobeDemoReason, { color: colors.textSecondary }]}>{recommendation.reason}</Text></View>;
}

export function MockSkinDashboard({
  profile,
  colors,
  isScanning,
  hasRunDemo,
  onRunDemoScan,
  onAddSelfie,
  onOpenWardrobe,
  onBuildLook,
}: MockSkinDashboardProps) {
  const priorities = getDemoPriorities(profile.id);
  const products = getDemoProducts(profile.id);
  const palettes = getDemoPaletteIdeas(profile.id);
  const progressHistory = getDemoProgressHistory(profile.id);
  const wardrobeRecommendations = getDemoWardrobeRecommendations(profile.id);
  return (
    <>
      <View style={[styles.demoBanner, { backgroundColor: colors.surface, borderColor: `${colors.tint}35` }]}>
        <View style={[styles.demoIcon, { backgroundColor: `${colors.tint}16` }]}>
          <Ionicons name="flask-outline" size={17} color={colors.tint} />
        </View>
        <View style={styles.flex}>
          <Text style={[styles.demoTitle, { color: colors.text }]}>Demo Mode · Mock Skin Analysis</Text>
          <Text style={[styles.demoText, { color: colors.textSecondary }]}>{profile.profileDisclosure ?? "Fictional preview data for the ClosetAI Skin Care experience. It is not a medical diagnosis or live YouCam analysis."}</Text>
        </View>
      </View>

      <View style={[styles.heroCard, { backgroundColor: colors.surface, borderColor: colors.border }]}> 
        <View style={styles.heroTop}>
          <View>
            <Text style={[styles.heroEyebrow, { color: colors.tint }]}>YOUR SKIN SNAPSHOT</Text>
            <Text style={[styles.heroTitle, { color: colors.text }]}>{profile.headline}</Text>
            <Text style={[styles.heroSummary, { color: colors.textSecondary }]}>{profile.summary}</Text>
          </View>
          <View style={[styles.scoreCircle, { borderColor: `${colors.tint}55`, backgroundColor: `${colors.tint}0D` }]}>
            <Text style={[styles.scoreValue, { color: colors.text }]}>{profile.overallScore}</Text>
            <Text style={[styles.scoreLabel, { color: colors.tint }]}>SCORE</Text>
          </View>
        </View>
        <View style={[styles.profileChip, { backgroundColor: `${colors.tint}14` }]}>
          <Ionicons name="person-outline" size={15} color={colors.tint} />
          <Text style={[styles.profileChipText, { color: colors.tint }]}>{profile.displayName ? `${profile.displayName} · ` : ""}{profile.skinType} Skin · Fictional Demo profile</Text>
        </View>
      </View>

      <View style={[styles.focusCard, { backgroundColor: colors.surfaceSecondary }]}> 
        <View style={[styles.focusIcon, { backgroundColor: `${colors.tint}16` }]}>
          <Ionicons name="flag-outline" size={19} color={colors.tint} />
        </View>
        <View style={styles.flex}>
          <Text style={[styles.focusLabel, { color: colors.textSecondary }]}>TODAY’S FOCUS</Text>
          <Text style={[styles.focusValue, { color: colors.text }]}>{profile.focus}</Text>
        </View>
      </View>

      <View style={[styles.journeyCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <Text style={[styles.journeyTitle, { color: colors.text }]}>Your Skin Care hub</Text>
        <Text style={[styles.journeyText, { color: colors.textSecondary }]}>Choose one calm next action, then return whenever it is useful.</Text>
        <View style={styles.journeyGrid}>
          {[['Signals', 'analytics-outline', '/skin/concerns'], ['Routine', 'list-outline', '/skin/routine'], ['Products', 'bag-outline', '/skin/products'], ['Progress', 'trending-up-outline', '/skin/progress'], ['Style', 'shirt-outline', '/skin/style-match'], ['Settings', 'settings-outline', '/skin/settings']].map(([label, icon, path]) => (
            <Pressable key={label} onPress={() => router.push(path as any)} style={[styles.journeyLink, { backgroundColor: colors.surfaceSecondary }]} accessibilityRole="button" accessibilityLabel={`Open ${label}`}>
              <Ionicons name={icon as keyof typeof Ionicons.glyphMap} size={16} color={colors.tint} />
              <Text style={[styles.journeyLinkText, { color: colors.text }]}>{label}</Text>
            </Pressable>
          ))}
        </View>
      </View>

      <View style={styles.sectionHead}>
        <View>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Today’s priorities</Text>
          <Text style={[styles.sectionSubtitle, { color: colors.textSecondary }]}>Three focused demo suggestions for this profile.</Text>
        </View>
      </View>
      {priorities.map((item) => <PriorityCard key={item.id} item={item} colors={colors} />)}

      <View style={styles.sectionHead}>
        <View>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Skin Health</Text>
          <Text style={[styles.sectionSubtitle, { color: colors.textSecondary }]}>Demo signals for a richer product preview.</Text>
        </View>
      </View>
      <View style={styles.metricsGrid}>
        {profile.metrics.map((metric) => <MetricCard key={metric.id} metric={metric} colors={colors} />)}
      </View>

      <View style={styles.sectionHead}>
        <View>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Your gentle routine</Text>
          <Text style={[styles.sectionSubtitle, { color: colors.textSecondary }]}>Keep it simple, consistent, and comfortable.</Text>
        </View>
      </View>
      <RoutineSection title="Morning Routine" icon="sunny-outline" steps={profile.morningRoutine} colors={colors} />
      <RoutineSection title="Evening Routine" icon="moon-outline" steps={profile.eveningRoutine} colors={colors} />

      <View style={styles.sectionHead}>
        <View>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Real Product Recommendations</Text>
          <Text style={[styles.sectionSubtitle, { color: colors.textSecondary }]}>Verified manufacturer products; the demo profile itself remains fictional.</Text>
        </View>
      </View>
      {products.map((product) => <ProductCard key={product.id} product={product} colors={colors} />)}

      <View style={styles.sectionHead}>
        <View>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Skin × Wardrobe</Text>
          <Text style={[styles.sectionSubtitle, { color: colors.textSecondary }]}>Style guidance, never style rules.</Text>
        </View>
      </View>
      <View style={[styles.styleCard, { backgroundColor: colors.surface, borderColor: colors.border }]}> 
        <View style={[styles.styleIcon, { backgroundColor: `${colors.tint}16` }]}>
          <Ionicons name="shirt-outline" size={20} color={colors.tint} />
        </View>
        <View style={styles.flex}>
          <Text style={[styles.styleTitle, { color: colors.text }]}>Today’s style suggestion</Text>
          <Text style={[styles.styleText, { color: colors.textSecondary }]}>{profile.styleSuggestion}</Text>
          <Pressable onPress={onOpenWardrobe} style={styles.wardrobeLink} accessibilityRole="button" accessibilityLabel="View wardrobe recommendations">
            <Text style={[styles.wardrobeLinkText, { color: colors.tint }]}>View Outfit Recommendations</Text>
            <Ionicons name="arrow-forward" size={14} color={colors.tint} />
          </Pressable>
        </View>
      </View>
      <View style={styles.paletteStack}>
        {palettes.map((idea) => <PaletteCard key={idea.id} idea={idea} colors={colors} />)}
      </View>
      {wardrobeRecommendations.map((recommendation) => <WardrobeDemoCard key={recommendation.id} recommendation={recommendation} colors={colors} />)}
      <View style={styles.styleActions}>
        <Pressable onPress={onBuildLook} style={[styles.styleActionPrimary, { backgroundColor: colors.text }]} accessibilityRole="button" accessibilityLabel="Build my look from skin style guidance">
          <Ionicons name="sparkles-outline" size={16} color={colors.background} />
          <Text style={[styles.styleActionPrimaryText, { color: colors.background }]}>Build My Look</Text>
        </Pressable>
        <Pressable onPress={onOpenWardrobe} style={[styles.styleActionSecondary, { borderColor: colors.border }]} accessibilityRole="button" accessibilityLabel="Explore wardrobe">
          <Ionicons name="shirt-outline" size={16} color={colors.tint} />
          <Text style={[styles.styleActionSecondaryText, { color: colors.text }]}>Explore Wardrobe</Text>
        </Pressable>
      </View>

      <View style={styles.sectionHead}>
        <View>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Your Progress</Text>
          <Text style={[styles.sectionSubtitle, { color: colors.textSecondary }]}>Demo history only; not prior personal analysis.</Text>
        </View>
      </View>
      <ProgressHistory colors={colors} history={progressHistory} />

      <View style={[styles.controlsCard, { backgroundColor: colors.surfaceSecondary }]}> 
        <Ionicons name="options-outline" size={18} color={colors.tint} />
        <View style={styles.flex}><Text style={[styles.controlsTitle, { color: colors.text }]}>Demo scan controls</Text><Text style={[styles.controlsText, { color: colors.textSecondary }]}>Run Demo rotates among three complete fictional profiles. Add Selfie opens the optional guided capture flow instead.</Text></View>
      </View>

      <Pressable
        onPress={onRunDemoScan}
        disabled={isScanning}
        style={({ pressed }) => [styles.primaryButton, { backgroundColor: colors.text, opacity: isScanning || pressed ? 0.7 : 1 }]}
        accessibilityRole="button"
        accessibilityLabel={isScanning ? "Analyzing demo skin profile" : hasRunDemo ? "Try another demo skin profile" : "Run demo skin scan"}
      >
        {isScanning ? <Ionicons name="hourglass-outline" size={19} color={colors.background} /> : <Ionicons name="sparkles-outline" size={19} color={colors.background} />}
        <Text style={[styles.primaryButtonText, { color: colors.background }]}>{isScanning ? "Analyzing demo skin profile…" : hasRunDemo ? "Try Another Demo" : "Run Demo Skin Scan"}</Text>
      </Pressable>
      <Pressable
        onPress={onAddSelfie}
        style={({ pressed }) => [styles.secondaryButton, { borderColor: colors.border, opacity: pressed ? 0.7 : 1 }]}
        accessibilityRole="button"
        accessibilityLabel="Add a selfie for Skin Care scan"
      >
        <Ionicons name="camera-outline" size={18} color={colors.tint} />
        <Text style={[styles.secondaryButtonText, { color: colors.text }]}>Add Selfie</Text>
      </Pressable>

      <View style={[styles.disclaimer, { backgroundColor: colors.surfaceSecondary }]}> 
        <Ionicons name="information-circle-outline" size={17} color={colors.textTertiary} />
        <Text style={[styles.disclaimerText, { color: colors.textTertiary }]}>This mock snapshot is general wellness and style guidance only, not medical advice. For persistent or concerning symptoms, consult a qualified professional.</Text>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  demoBanner: { flexDirection: "row", gap: 10, padding: 13, borderRadius: 17, borderWidth: 1, marginBottom: 13 },
  demoIcon: { width: 34, height: 34, borderRadius: 11, alignItems: "center", justifyContent: "center" },
  demoTitle: { fontFamily: "Outfit_700Bold", fontSize: 13 },
  demoText: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 15, marginTop: 2 },
  heroCard: { borderRadius: 25, borderWidth: 1, padding: 18, marginBottom: 12 },
  heroTop: { flexDirection: "row", gap: 12 },
  heroEyebrow: { fontFamily: "Outfit_700Bold", fontSize: 9, letterSpacing: 1 },
  heroTitle: { fontFamily: "Outfit_700Bold", fontSize: 22, lineHeight: 27, marginTop: 5 },
  heroSummary: { fontFamily: "Outfit_400Regular", fontSize: 11, lineHeight: 17, marginTop: 6, paddingRight: 4 },
  scoreCircle: { width: 78, height: 78, borderRadius: 39, borderWidth: 5, alignItems: "center", justifyContent: "center" },
  scoreValue: { fontFamily: "Outfit_700Bold", fontSize: 28, lineHeight: 30 },
  scoreLabel: { fontFamily: "Outfit_700Bold", fontSize: 8, letterSpacing: 0.7 },
  profileChip: { alignSelf: "flex-start", flexDirection: "row", alignItems: "center", gap: 5, borderRadius: 12, paddingHorizontal: 9, paddingVertical: 6, marginTop: 15 },
  profileChipText: { fontFamily: "Outfit_600SemiBold", fontSize: 10 },
  focusCard: { flexDirection: "row", alignItems: "center", gap: 10, borderRadius: 17, padding: 13, marginBottom: 22 },
  focusIcon: { width: 37, height: 37, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  focusLabel: { fontFamily: "Outfit_700Bold", fontSize: 9, letterSpacing: 0.8 },
  focusValue: { fontFamily: "Outfit_700Bold", fontSize: 15, marginTop: 2 },
  sectionHead: { marginTop: 2, marginBottom: 10 },
  sectionTitle: { fontFamily: "Outfit_700Bold", fontSize: 19 },
  sectionSubtitle: { fontFamily: "Outfit_400Regular", fontSize: 10, marginTop: 2 },
  metricsGrid: { flexDirection: "row", flexWrap: "wrap", justifyContent: "space-between", marginBottom: 14 },
  metricCard: { width: "48.5%", minHeight: 150, borderRadius: 17, borderWidth: 1, padding: 12, marginBottom: 9 },
  metricTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  metricIcon: { width: 31, height: 31, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  metricScore: { fontFamily: "Outfit_700Bold", fontSize: 20 },
  metricLabel: { fontFamily: "Outfit_600SemiBold", fontSize: 12, marginTop: 9 },
  metricStatus: { fontFamily: "Outfit_600SemiBold", fontSize: 9, marginTop: 2 },
  track: { height: 5, borderRadius: 3, overflow: "hidden", marginTop: 8 },
  fill: { height: "100%", borderRadius: 3 },
  metricDescription: { fontFamily: "Outfit_400Regular", fontSize: 9, lineHeight: 13, marginTop: 8 },
  routineCard: { borderRadius: 18, borderWidth: 1, padding: 14, marginBottom: 11 },
  routineHeader: { flexDirection: "row", alignItems: "center", gap: 9, marginBottom: 13 },
  routineIcon: { width: 35, height: 35, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  routineTitle: { fontFamily: "Outfit_700Bold", fontSize: 15 },
  routineRow: { flexDirection: "row", gap: 9, marginBottom: 13 },
  stepNumber: { width: 29, height: 29, borderRadius: 10, alignItems: "center", justifyContent: "center", marginTop: 1 },
  stepNumberText: { fontFamily: "Outfit_700Bold", fontSize: 10 },
  stepTitleLine: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 6 },
  stepName: { fontFamily: "Outfit_600SemiBold", fontSize: 12, flex: 1 },
  stepDuration: { fontFamily: "Outfit_500Medium", fontSize: 9 },
  stepCategory: { fontFamily: "Outfit_600SemiBold", fontSize: 9, marginTop: 2 },
  stepDescription: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 14, marginTop: 2 },
  styleCard: { flexDirection: "row", alignItems: "flex-start", gap: 10, borderRadius: 18, borderWidth: 1, padding: 14, marginBottom: 15 },
  styleIcon: { width: 39, height: 39, borderRadius: 13, alignItems: "center", justifyContent: "center" },
  styleTitle: { fontFamily: "Outfit_600SemiBold", fontSize: 13 },
  styleText: { fontFamily: "Outfit_400Regular", fontSize: 11, lineHeight: 16, marginTop: 3 },
  wardrobeLink: { alignSelf: "flex-start", flexDirection: "row", alignItems: "center", gap: 5, marginTop: 9, paddingVertical: 3 },
  wardrobeLinkText: { fontFamily: "Outfit_600SemiBold", fontSize: 10 },
  wardrobeDemoCard: { borderRadius: 17, borderWidth: 1, padding: 13, marginTop: 9 },
  wardrobeDemoHead: { flexDirection: "row", alignItems: "center", gap: 9 },
  wardrobeDemoTitle: { fontFamily: "Outfit_600SemiBold", fontSize: 12 },
  wardrobeDemoOccasion: { fontFamily: "Outfit_600SemiBold", fontSize: 9, marginTop: 2 },
  wardrobeDemoPieces: { fontFamily: "Outfit_400Regular", fontSize: 10, marginTop: 10 },
  wardrobeDemoAccessories: { fontFamily: "Outfit_400Regular", fontSize: 10, marginTop: 4 },
  wardrobeDemoReason: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 14, marginTop: 7 },
  controlsCard: { flexDirection: "row", alignItems: "flex-start", gap: 9, padding: 13, borderRadius: 15, marginTop: 3, marginBottom: 11 },
  controlsTitle: { fontFamily: "Outfit_600SemiBold", fontSize: 12 },
  controlsText: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 14, marginTop: 2 },
  primaryButton: { minHeight: 51, borderRadius: 16, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, marginBottom: 9 },
  primaryButtonText: { fontFamily: "Outfit_700Bold", fontSize: 14 },
  secondaryButton: { minHeight: 49, borderRadius: 16, borderWidth: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, marginBottom: 15 },
  secondaryButtonText: { fontFamily: "Outfit_600SemiBold", fontSize: 13 },
  disclaimer: { flexDirection: "row", alignItems: "flex-start", gap: 8, padding: 12, borderRadius: 13, marginBottom: 4 },
  disclaimerText: { flex: 1, fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 15 },
  journeyCard: { borderWidth: 1, borderRadius: 18, padding: 14, marginBottom: 20 },
  journeyTitle: { fontFamily: "Outfit_700Bold", fontSize: 16 },
  journeyText: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 15, marginTop: 3 },
  journeyGrid: { flexDirection: "row", flexWrap: "wrap", gap: 7, marginTop: 11 },
  journeyLink: { width: "31%", minHeight: 58, borderRadius: 12, alignItems: "center", justifyContent: "center", gap: 4, paddingHorizontal: 4 },
  journeyLinkText: { fontFamily: "Outfit_600SemiBold", fontSize: 9 },
  priorityCard: { flexDirection: "row", alignItems: "flex-start", gap: 10, borderRadius: 17, borderWidth: 1, padding: 13, marginBottom: 9 },
  priorityIcon: { width: 37, height: 37, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  priorityTitle: { fontFamily: "Outfit_600SemiBold", fontSize: 13 },
  priorityExplanation: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 15, marginTop: 2 },
  priorityAction: { fontFamily: "Outfit_600SemiBold", fontSize: 10, lineHeight: 15, marginTop: 5 },
  productCard: { borderRadius: 18, borderWidth: 1, padding: 14, marginBottom: 9 },
  productHead: { flexDirection: "row", alignItems: "center", gap: 9 },
  productIcon: { width: 38, height: 38, borderRadius: 13, alignItems: "center", justifyContent: "center" },
  productCategory: { fontFamily: "Outfit_700Bold", fontSize: 8, letterSpacing: 0.7 },
  productName: { fontFamily: "Outfit_600SemiBold", fontSize: 13, marginTop: 2 },
  productPrice: { fontFamily: "Outfit_700Bold", fontSize: 13 },
  productSource: { fontFamily: "Outfit_700Bold", fontSize: 8, letterSpacing: 0.5 },
  productAvailability: { fontFamily: "Outfit_400Regular", fontSize: 9, lineHeight: 13, marginTop: 8 },
  productMeta: { fontFamily: "Outfit_400Regular", fontSize: 10, marginTop: 9 },
  productWhy: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 15, marginTop: 4 },
  tagRow: { flexDirection: "row", flexWrap: "wrap", gap: 5, marginTop: 8 },
  tag: { borderRadius: 9, paddingHorizontal: 7, paddingVertical: 3 },
  tagText: { fontFamily: "Outfit_500Medium", fontSize: 9 },
  productButton: { alignSelf: "flex-start", flexDirection: "row", alignItems: "center", gap: 5, borderWidth: 1, borderRadius: 10, paddingHorizontal: 9, paddingVertical: 7, marginTop: 10 },
  productButtonText: { fontFamily: "Outfit_600SemiBold", fontSize: 10 },
  paletteStack: { gap: 8, marginBottom: 10 },
  paletteCard: { borderRadius: 16, borderWidth: 1, padding: 12 },
  paletteTitle: { fontFamily: "Outfit_600SemiBold", fontSize: 12 },
  paletteReason: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 15, marginTop: 7 },
  styleActions: { flexDirection: "row", gap: 9, marginBottom: 19 },
  styleActionPrimary: { flex: 1, minHeight: 45, borderRadius: 14, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6 },
  styleActionPrimaryText: { fontFamily: "Outfit_700Bold", fontSize: 11 },
  styleActionSecondary: { flex: 1, minHeight: 45, borderWidth: 1, borderRadius: 14, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6 },
  styleActionSecondaryText: { fontFamily: "Outfit_600SemiBold", fontSize: 11 },
  progressCard: { borderRadius: 18, borderWidth: 1, padding: 14, marginBottom: 17 },
  progressCaption: { fontFamily: "Outfit_400Regular", fontSize: 10, marginBottom: 12 },
  progressRow: { marginBottom: 12 },
  progressLabelRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 5 },
  progressLabel: { fontFamily: "Outfit_600SemiBold", fontSize: 11 },
  progressScoreRow: { flexDirection: "row", alignItems: "center", gap: 7 },
  progressChange: { fontFamily: "Outfit_600SemiBold", fontSize: 10 },
  progressScore: { fontFamily: "Outfit_700Bold", fontSize: 12 },
});
