import { Ionicons } from "@expo/vector-icons";
import * as FileSystem from "expo-file-system/legacy";
import * as ImagePicker from "expo-image-picker";
import { Image } from "expo-image";
import { router, useFocusEffect } from "expo-router";
import React, { useEffect, useRef, useState } from "react";
import { Alert, Linking, Pressable, ScrollView, StyleSheet, Switch, Text, View, Share } from "react-native";

import { useSelfieScan } from "@/contexts/SelfieScanContext";
import { analyzeSkin } from "@/lib/skin-analysis-controller";
import { useTheme } from "@/lib/useTheme";
import { interaction } from "@/constants/colors";
import { MediaStatusCard } from "@/components/ui/MediaStatusCard";
import { clearSkinAnalysisRetryQueue, createSkinAnalysisRetryQueueEntry, loadSkinAnalysisRetryQueue, saveSkinAnalysisRetryQueue, type SkinAnalysisRetryQueueEntry } from "@/lib/skin-analysis-retry-queue";

export function SelfieFlowScreen() {
  const { colors } = useTheme();
  const { asset, quality, acceptsGuidance, saveSummary, stage, result, savedResults, error, choose, setAcceptsGuidance, setSaveSummary, setStage, finish, fail, reset } = useSelfieScan();
  const [busy, setBusy] = useState(false);
  const [isPicking, setIsPicking] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [photoPermissionState, setPhotoPermissionState] = useState<"unknown" | "granted" | "blocked">("unknown");
  const [queuedRetry, setQueuedRetry] = useState<SkinAnalysisRetryQueueEntry | null>(null);
  const isMountedRef = useRef(true);
  const pickerInFlightRef = useRef(false);
  const analysisInFlightRef = useRef(false);
  const analysisRunIdRef = useRef(0);
  const isWorking = busy || isPicking;

  useEffect(() => () => {
    isMountedRef.current = false;
    analysisRunIdRef.current += 1;
  }, []);

  useFocusEffect(React.useCallback(() => {
    let active = true;
    void Promise.all([ImagePicker.getCameraPermissionsAsync(), ImagePicker.getMediaLibraryPermissionsAsync()]).then(([camera, library]) => {
      if (!active) return;
      setPhotoPermissionState(camera.granted || library.granted ? "granted" : "blocked");
    }).catch(() => {
      if (active) setPhotoPermissionState("unknown");
    });
    void loadSkinAnalysisRetryQueue().then((entry) => {
      if (active) setQueuedRetry(entry);
    });
    return () => { active = false; };
  }, []));

  const openPhotoSettings = async () => {
    try {
      await Linking.openSettings();
    } catch {
      if (isMountedRef.current) Alert.alert("Open settings manually", "Photo access can be changed in your device settings. Demo Mode remains available without photo access.");
    }
  };

  const pick = async (source: "camera" | "library") => {
    if (pickerInFlightRef.current || analysisInFlightRef.current) return;
    pickerInFlightRef.current = true;
    setStatusMessage(null);
    setIsPicking(true);
    try {
      const permission = source === "camera" ? await ImagePicker.requestCameraPermissionsAsync() : await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!permission.granted) {
        if (isMountedRef.current) setPhotoPermissionState("blocked");
        if (isMountedRef.current) Alert.alert("Photo access is off", "You can continue using the fictional Demo Mode snapshot without granting photo access. If you want to try a live selfie later, open device settings to change this permission.", [
          { text: "Continue with Demo", style: "cancel" },
          { text: "Open Settings", onPress: () => { void openPhotoSettings(); } },
        ]);
        return;
      }
      if (isMountedRef.current) setPhotoPermissionState("granted");
      const response = source === "camera"
        ? await ImagePicker.launchCameraAsync({ mediaTypes: ["images"], cameraType: ImagePicker.CameraType.front, allowsEditing: true, aspect: [4, 5], quality: 0.8, exif: false })
        : await ImagePicker.launchImageLibraryAsync({ mediaTypes: ["images"], allowsEditing: true, aspect: [4, 5], quality: 0.8, exif: false });
      if (response.canceled || !response.assets[0]) return;
      const image = response.assets[0];
      choose({ uri: image.uri, source, width: image.width, height: image.height, fileSize: image.fileSize, mimeType: image.mimeType });
      setQueuedRetry(null);
      void clearSkinAnalysisRetryQueue();
      if (isMountedRef.current) router.replace("/skin/selfie-review");
    } catch (captureError) {
      if (isMountedRef.current) fail(captureError instanceof Error ? captureError.message : "We could not open that photo. Please try another image.");
    } finally {
      pickerInFlightRef.current = false;
      if (isMountedRef.current) setIsPicking(false);
    }
  };

  const analyze = async (queuedInput?: SkinAnalysisRetryQueueEntry) => {
    const activeAssetUri = queuedInput?.selfieUri ?? asset?.uri;
    const activeSaveSnapshot = queuedInput?.saveSnapshot ?? saveSummary;
    const approvedCurrentPhoto = Boolean(asset && quality && quality.band !== "retake" && acceptsGuidance);
    if (!activeAssetUri || (!queuedInput && !approvedCurrentPhoto) || analysisInFlightRef.current || pickerInFlightRef.current) return;
    const runId = ++analysisRunIdRef.current;
    setStatusMessage(null);
    analysisInFlightRef.current = true;
    setBusy(true); setStage("analysing");
    try {
      const base64 = await FileSystem.readAsStringAsync(activeAssetUri, { encoding: "base64" as any });
      const next = await analyzeSkin({ imageUri: activeAssetUri, imageBase64: base64, demo: false, saveSnapshot: activeSaveSnapshot });
      if (!isMountedRef.current || analysisRunIdRef.current !== runId) return;
      setQueuedRetry(null);
      void clearSkinAnalysisRetryQueue();
      finish(next); router.replace("/skin/scan-results");
    } catch (analysisError) {
      if (isMountedRef.current && analysisRunIdRef.current === runId) {
        const message = analysisError instanceof Error ? analysisError.message : "We could not analyse this photo. Try a clear, well-lit selfie.";
        const retryEntry = createSkinAnalysisRetryQueueEntry(activeAssetUri, activeSaveSnapshot);
        await saveSkinAnalysisRetryQueue(retryEntry).then(() => {
          if (isMountedRef.current && analysisRunIdRef.current === runId) setQueuedRetry(retryEntry);
        }).catch(() => undefined);
        fail(`${message} Your selected selfie remains available for retry. No fictional Demo Mode result was substituted.`);
      }
    } finally {
      if (analysisRunIdRef.current !== runId) return;
      analysisInFlightRef.current = false;
      if (isMountedRef.current) setBusy(false);
    }
  };

  const cancelAnalysis = () => {
    if (!analysisInFlightRef.current) return;
    analysisRunIdRef.current += 1;
    analysisInFlightRef.current = false;
    setBusy(false);
    setStage("review");
    setQueuedRetry(null);
    void clearSkinAnalysisRetryQueue();
    setStatusMessage("Analysis cancelled. Your selected selfie is still available for review and was not replaced.");
  };

  const retryQueuedAnalysis = () => {
    if (!queuedRetry || isWorking) return;
    const entry = queuedRetry;
    setQueuedRetry(null);
    void clearSkinAnalysisRetryQueue();
    void analyze(entry);
  };

  const dismissQueuedAnalysis = () => {
    setQueuedRetry(null);
    void clearSkinAnalysisRetryQueue();
  };

  const resetFlow = () => {
    if (isWorking) return;
    setQueuedRetry(null);
    void clearSkinAnalysisRetryQueue();
    reset();
  };

  const updateGuidanceConsent = (value: boolean) => {
    setAcceptsGuidance(value);
    setQueuedRetry(null);
    void clearSkinAnalysisRetryQueue();
  };

  const updateSaveSummary = (value: boolean) => {
    setSaveSummary(value);
    setQueuedRetry(null);
    void clearSkinAnalysisRetryQueue();
  };

  const canAnalyze = !!asset && !!quality && quality.band !== "retake" && acceptsGuidance;
  const title = stage === "analysing" ? "Preparing your guidance" : asset ? "Review your selfie" : "Your optional selfie scan";
  return <View style={[styles.page, { backgroundColor: colors.background }]}><ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
    <View style={styles.header}><Pressable onPress={() => router.back()} disabled={isWorking} hitSlop={10} accessibilityRole="button" accessibilityState={{ disabled: isWorking }} accessibilityLabel="Go back from selfie scan" accessibilityHint={isWorking ? "Wait until the current photo action finishes." : "Returns to the previous Skin Care screen."} style={({ pressed }) => [{ opacity: isWorking ? 0.45 : pressed ? 0.7 : 1 }]}><Ionicons name="chevron-back" size={25} color={colors.text} /></Pressable><View style={styles.headerCopy}><Text style={[styles.eyebrow, { color: colors.tint }]}>CLOSET A.I. · SELFIE SCAN</Text><Text style={[styles.title, { color: colors.text }]}>{title}</Text></View><Pressable onPress={resetFlow} disabled={isWorking} hitSlop={10} accessibilityRole="button" accessibilityState={{ disabled: isWorking }} accessibilityLabel="Clear selected selfie and restart" accessibilityHint={isWorking ? "Wait until the current photo action finishes." : "Clears this locally selected selfie and returns to capture."} style={({ pressed }) => [{ opacity: isWorking ? 0.45 : pressed ? 0.7 : 1 }]}><Ionicons name="refresh-outline" size={20} color={colors.textSecondary} /></Pressable></View>
    {!asset ? <><View style={[styles.hero, { backgroundColor: colors.surface, borderColor: colors.border }]}><Ionicons name="camera-outline" size={28} color={colors.tint} /><Text style={[styles.heroTitle, { color: colors.text }]}>Start only when you want to.</Text><Text style={[styles.body, { color: colors.textSecondary }]}>A selfie is optional. The Skin Care hub and demo guidance remain available without camera access, a backend, or a live provider.</Text></View>{photoPermissionState === "blocked" && <View style={[styles.permissionNotice, { backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]} accessibilityLiveRegion="polite"><Ionicons name="lock-closed-outline" size={18} color={colors.tint} /><View style={styles.flex}><Text style={[styles.cardTitle, { color: colors.text }]}>Photo access is currently off</Text><Text style={[styles.body, { color: colors.textSecondary }]}>You can keep using fictional Demo Mode, or reopen device settings before trying a live camera or library scan.</Text><Button label="Open Photo Settings" icon="settings-outline" secondary colors={colors} onPress={openPhotoSettings} /></View></View>}<Button label="Live Camera Scan" icon="scan-outline" colors={colors} disabled={isWorking} busy={isPicking} onPress={() => router.push("/skin/live-camera")} /><Button label={isPicking ? "Opening Photo Library…" : "Choose Photo"} icon="images-outline" secondary colors={colors} disabled={isWorking} busy={isPicking} onPress={() => pick("library")} /><Button label="Use Demo Scan" icon="sparkles-outline" secondary colors={colors} disabled={isWorking} onPress={() => router.replace("/skin")} /></> : <>
      <View style={styles.preview}><Image source={{ uri: asset.uri }} style={styles.image} contentFit="cover" accessibilityLabel="Selected selfie preview. This is the photo you chose for optional review." /><View style={styles.guide} accessibilityElementsHidden importantForAccessibility="no-hide-descendants"><View style={styles.oval} /><Text style={styles.guideLabel}>Face centred in guide</Text></View></View>
      <MediaStatusCard kind="user-photo" title="Your selected selfie" detail="Only this photo can be sent for the optional analysis after you consent. Choose another selfie to replace it." tint={colors.tint} surface={colors.surfaceSecondary} border={colors.border} />
      {stage === "complete" && result && <View style={[styles.resultCard, { backgroundColor: colors.surface, borderColor: colors.border }]} accessible accessibilityRole="summary" accessibilityLabel={`Skin analysis complete. Source: ${result.source === "youcam" ? "Perfect Corp. YouCam Skin Analysis" : result.source === "demo" ? "Fictional Demo Mode" : "Cached normalized summary"}. ${result.visualSignalSummary ?? "Normalized visual signals are available."} ${result.disclaimer}`}>
        <View style={styles.resultHeader}><View style={styles.flex}><Text style={[styles.cardTitle, { color: colors.text }]}>Skin analysis complete</Text><Text style={[styles.resultSource, { color: colors.tint }]}>{result.source === "youcam" ? "Perfect Corp. YouCam Skin Analysis" : result.source === "demo" ? "Fictional Demo Mode" : "Cached normalized summary"}</Text></View><Ionicons name={result.source === "youcam" ? "cloud-done-outline" : "flask-outline"} size={18} color={colors.tint} /></View>
        {result.overallScore !== undefined && <Text style={[styles.resultScore, { color: colors.text }]}>{result.overallScore}<Text style={[styles.resultScoreUnit, { color: colors.textSecondary }]}> / visual signal score</Text></Text>}
        <Text style={[styles.body, { color: colors.textSecondary }]}>{result.visualSignalSummary ?? `${result.metrics.filter((metric) => metric.available).length} normalized signals available.`}</Text>
        <View style={styles.resultStats}><Text style={[styles.resultStat, { color: colors.textSecondary }]}>{result.metrics.filter((metric) => metric.available).length}/{result.metrics.length} signals</Text><Text style={[styles.resultStat, { color: colors.textSecondary }]}>{result.routine.length} routine steps</Text><Text style={[styles.resultStat, { color: colors.textSecondary }]}>{result.source === "youcam" ? "Live" : result.source === "demo" ? "Offline" : "Cached"}</Text></View>
        <View style={[styles.resultBoundary, { backgroundColor: colors.surfaceSecondary }]}><Ionicons name="shield-checkmark-outline" size={14} color={colors.tint} /><Text style={[styles.resultBoundaryText, { color: colors.textSecondary }]}>{result.disclaimer} No diagnosis, treatment, or identity classification is provided.</Text></View>
        <Button
          label="Share skin analysis"
          icon="share-social-outline"
          secondary
          colors={colors}
          onPress={async () => {
            try {
              await Share.share({
                message: `ClosetAI Skin Analysis Summary: score ${result.overallScore ?? 'N/A'}/100. ${result.visualSignalSummary ?? ''} (#ClosetAI #SkinCare #AIGuidance)`,
                title: 'ClosetAI Skin Analysis',
              });
            } catch {
              // Share cancelled or unavailable
            }
          }}
        />
        <Button label="Start another selfie scan" icon="camera-reverse-outline" secondary colors={colors} onPress={resetFlow} />
      </View>}
      {quality && <View style={[styles.card, { backgroundColor: colors.surface, borderColor: quality.band === "ready" ? colors.success : quality.band === "review" ? colors.warning : colors.error }]}><Text style={[styles.cardTitle, { color: colors.text }]}>{quality.summary}</Text>{quality.checks.map((check) => <View key={check.id} style={styles.check}><Ionicons name={check.status === "pass" ? "checkmark-circle" : "information-circle-outline"} size={16} color={check.status === "pass" ? colors.success : check.status === "review" ? colors.warning : colors.error} /><Text style={[styles.checkText, { color: colors.textSecondary }]}>{check.label}: {check.detail}</Text></View>)}</View>}
      <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}><View style={styles.switchRow}><View style={styles.flex}><Text style={[styles.cardTitle, { color: colors.text }]}>General-guidance consent</Text><Text style={[styles.body, { color: colors.textSecondary }]}>I understand this provides general wellness and style guidance, not a diagnosis or treatment.</Text></View><Switch value={acceptsGuidance} disabled={isWorking} onValueChange={updateGuidanceConsent} accessibilityRole="switch" accessibilityState={{ checked: acceptsGuidance, disabled: isWorking }} accessibilityLabel="Consent to general skin guidance" accessibilityHint={isWorking ? "Consent choices are unavailable while this photo action is active." : "Required before optional photo analysis can continue."} /></View><View style={styles.switchRow}><View style={styles.flex}><Text style={[styles.cardTitle, { color: colors.text }]}>Save normalised summary</Text><Text style={[styles.body, { color: colors.textSecondary }]}>Keep written guidance for comparison; do not display the original selfie in history.</Text></View><Switch value={saveSummary} disabled={isWorking} onValueChange={updateSaveSummary} accessibilityRole="switch" accessibilityState={{ checked: saveSummary, disabled: isWorking }} accessibilityLabel="Save normalized written summary" accessibilityHint={isWorking ? "Summary preferences are unavailable while this photo action is active." : "Saves guidance only and does not retain the original selfie in history."} /></View></View>
      {stage === "complete" && result ? null : stage === "analysing" ? <View style={[styles.hero, { backgroundColor: colors.surface, borderColor: colors.border }]} accessibilityLiveRegion="polite" accessibilityRole="progressbar" accessibilityState={{ busy: true }} accessibilityLabel="Preparing optional skin guidance from your selected selfie"><Ionicons name="hourglass-outline" size={28} color={colors.tint} /><Text style={[styles.heroTitle, { color: colors.text }]}>Analysing your chosen photo…</Text><Text style={[styles.body, { color: colors.textSecondary }]}>Preparing photo and requesting secure live analysis when available. If the provider cannot complete, this flow stops with retry metadata; Demo Mode remains a separate choice.</Text><Button label="Cancel analysis" icon="close-circle-outline" secondary colors={colors} onPress={cancelAnalysis} /></View> : <><Button label={canAnalyze ? "Analyse My Skin" : "Complete review to continue"} icon="sparkles-outline" colors={colors} disabled={!canAnalyze || isWorking} busy={busy} onPress={analyze} /><Button label="Choose another selfie" icon="camera-reverse-outline" secondary colors={colors} disabled={isWorking} onPress={() => { reset(); router.replace("/skin/selfie-scan"); }} /></>}
    </>}
    {queuedRetry && !isWorking && <View style={[styles.queueCard, { backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]} accessibilityLiveRegion="polite" accessibilityLabel="Live Skin Care analysis retry saved locally. The selected selfie and consent choice remain available. Demo Mode remains a separate choice; no diagnosis or treatment claim was added."><Ionicons name="cloud-offline-outline" size={18} color={colors.warning} /><View style={styles.queueContent}><Text style={[styles.queueTitle, { color: colors.text }]}>Live Skin Care retry saved locally</Text><Text style={[styles.error, { color: colors.textSecondary }]}>YouCam was unavailable, so this live path stopped without substituting fictional Demo Mode guidance. Retry uses the same selected selfie and consent choice; no diagnosis or treatment claim was added.</Text><View style={styles.queueActions}><Pressable onPress={retryQueuedAnalysis} accessibilityRole="button" accessibilityLabel="Retry saved Skin Care analysis" accessibilityHint="Retries the same selected selfie when live YouCam is ready." style={({ pressed }) => [styles.retryButton, { borderColor: colors.border, backgroundColor: colors.surface, opacity: pressed ? 0.72 : 1 }]}><Ionicons name="refresh-outline" size={14} color={colors.tint} /><Text style={[styles.retryButtonText, { color: colors.tint }]}>Retry live analysis</Text></Pressable><Pressable onPress={dismissQueuedAnalysis} accessibilityRole="button" accessibilityLabel="Dismiss saved Skin Care analysis retry" style={({ pressed }) => [{ paddingVertical: 7, opacity: pressed ? 0.72 : 1 }]}><Text style={[styles.dismissText, { color: colors.textSecondary }]}>Dismiss</Text></Pressable></View></View></View>}
    {!!statusMessage && <Text style={[styles.status, { color: colors.textSecondary }]} accessibilityLiveRegion="polite" accessibilityRole="text">{statusMessage}</Text>}
    {!!error && <Text style={[styles.error, { color: colors.error }]} accessibilityLiveRegion="assertive" accessibilityRole="alert">{error}</Text>}
    {savedResults.length > 0 && <Pressable onPress={() => router.push("/skin/selfie-history")} style={({ pressed }) => [styles.history, { opacity: pressed ? 0.72 : 1 }]} accessibilityRole="button" accessibilityLabel={`View ${savedResults.length} saved normalized selfie summaries`}><Text style={[styles.historyText, { color: colors.tint }]}>{savedResults.length} saved selfie summary{savedResults.length === 1 ? "" : "ies"} · View history</Text></Pressable>}
    <Pressable onPress={() => router.push("/skin/selfie-privacy")} style={({ pressed }) => [styles.history, { opacity: pressed ? 0.72 : 1 }]} accessibilityRole="button" accessibilityLabel="Review selfie privacy and consent"><Text style={[styles.historyText, { color: colors.tint }]}>Review selfie privacy and consent</Text></Pressable>
  </ScrollView></View>;
}

function Button({ label, icon, onPress, colors, secondary = false, disabled = false, busy = false }: { label: string; icon: keyof typeof Ionicons.glyphMap; onPress: () => void; colors: any; secondary?: boolean; disabled?: boolean; busy?: boolean }) { return <Pressable onPress={onPress} disabled={disabled} accessibilityRole="button" accessibilityState={{ disabled, busy }} accessibilityLabel={label} accessibilityHint={busy ? "Wait while ClosetAI completes the current photo action." : label === "Use Demo Scan" ? "Explores fictional guidance without using a selfie." : label === "Live Camera Scan" ? "Opens the optional camera flow. The camera stream is not stored." : label === "Open Photo Settings" ? "Opens device settings so you can change photo access later." : label.includes("Photo") ? "Opens your photo library. Your selected photo is reviewed before any optional analysis." : undefined} style={({ pressed }) => [styles.button, secondary ? { borderColor: colors.border, borderWidth: 1 } : { backgroundColor: colors.text }, { opacity: disabled ? interaction.disabledOpacity : pressed ? 0.8 : 1, transform: [{ scale: pressed && !disabled ? interaction.primaryPressScale : 1 }] }]}><Ionicons name={icon} size={18} color={secondary ? colors.tint : colors.background} /><Text style={[styles.buttonText, { color: secondary ? colors.text : colors.background }]}>{label}</Text></Pressable>; }

const styles = StyleSheet.create({ page: { flex: 1 }, content: { padding: 20, paddingBottom: 48 }, header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 18 }, headerCopy: { alignItems: "center" }, eyebrow: { fontFamily: "Outfit_700Bold", fontSize: 8, letterSpacing: 1 }, title: { fontFamily: "Outfit_700Bold", fontSize: 18 }, hero: { borderWidth: 1, borderRadius: 20, padding: 18, marginBottom: 12 }, heroTitle: { fontFamily: "Outfit_700Bold", fontSize: 20, marginTop: 10 }, body: { fontFamily: "Outfit_400Regular", fontSize: 11, lineHeight: 16, marginTop: 5 }, button: { minHeight: 51, borderRadius: 16, flexDirection: "row", justifyContent: "center", alignItems: "center", gap: 8, marginBottom: 9 }, buttonText: { fontFamily: "Outfit_700Bold", fontSize: 13 }, preview: { height: 320, borderRadius: 22, overflow: "hidden", marginBottom: 12 }, image: { width: "100%", height: "100%" }, guide: { ...StyleSheet.absoluteFillObject, alignItems: "center", justifyContent: "center" }, oval: { width: "52%", height: "62%", borderRadius: 999, borderWidth: 2, borderColor: "rgba(255,255,255,0.9)" }, guideLabel: { position: "absolute", bottom: 16, color: "#fff", backgroundColor: "rgba(0,0,0,0.45)", borderRadius: 10, paddingHorizontal: 8, paddingVertical: 4, fontFamily: "Outfit_600SemiBold", fontSize: 10 }, card: { borderWidth: 1, borderRadius: 17, padding: 13, marginBottom: 12 }, permissionNotice: { borderWidth: 1, borderRadius: 17, padding: 13, marginBottom: 12, flexDirection: "row", alignItems: "flex-start", gap: 10 }, cardTitle: { fontFamily: "Outfit_600SemiBold", fontSize: 13 }, check: { flexDirection: "row", alignItems: "flex-start", gap: 6, marginTop: 7 }, checkText: { flex: 1, fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 14 }, switchRow: { flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 10 }, flex: { flex: 1 }, status: { fontFamily: "Outfit_500Medium", fontSize: 11, lineHeight: 16, textAlign: "center", marginTop: 5 }, error: { fontFamily: "Outfit_500Medium", fontSize: 11, lineHeight: 16, textAlign: "center", marginTop: 5 },   resultCard: { borderWidth: 1, borderRadius: 17, padding: 13, marginBottom: 12 }, resultHeader: { flexDirection: "row", alignItems: "flex-start", gap: 8 }, resultSource: { fontFamily: "Outfit_600SemiBold", fontSize: 10, marginTop: 4 }, resultScore: { fontFamily: "Outfit_700Bold", fontSize: 26, marginTop: 12 }, resultScoreUnit: { fontFamily: "Outfit_400Regular", fontSize: 10 }, resultStats: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginTop: 9 }, resultStat: { fontFamily: "Outfit_500Medium", fontSize: 9 }, resultBoundary: { flexDirection: "row", alignItems: "flex-start", gap: 7, borderRadius: 10, paddingHorizontal: 9, paddingVertical: 8, marginTop: 10, marginBottom: 10 }, resultBoundaryText: { flex: 1, fontFamily: "Outfit_400Regular", fontSize: 9, lineHeight: 13 }, queueCard: { flexDirection: "row", alignItems: "flex-start", gap: 8, borderWidth: 1, borderRadius: 14, padding: 12, marginTop: 8 }, queueContent: { flex: 1, gap: 8 }, queueTitle: { fontFamily: "Outfit_700Bold", fontSize: 11 }, queueActions: { flexDirection: "row", alignItems: "center", gap: 12 }, retryButton: { flexDirection: "row", alignItems: "center", gap: 6, borderWidth: 1, borderRadius: 10, paddingHorizontal: 9, paddingVertical: 7 }, retryButtonText: { fontFamily: "Outfit_600SemiBold", fontSize: 10 }, dismissText: { fontFamily: "Outfit_500Medium", fontSize: 10 }, history: { alignSelf: "center", padding: 10 }, historyText: { fontFamily: "Outfit_600SemiBold", fontSize: 11 } });
