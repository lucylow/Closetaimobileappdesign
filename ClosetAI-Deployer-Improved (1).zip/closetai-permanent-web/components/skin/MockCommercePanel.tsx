import { router } from "expo-router";
import React from "react";
import { ActivityIndicator, Alert, Pressable, StyleSheet, Text, View } from "react-native";

import { useMockCommerce } from "@/contexts/MockCommerceContext";
import { activeSkinCommerceProvider, MOCK_COMMERCE_DISCLOSURE, type CommerceListing } from "@/lib/skin-commerce-provider";

type MockCommercePanelProps = {
  productId: string;
  colors: any;
};

function availabilityCopy(listing: CommerceListing) {
  if (listing.availability === "out_of_stock") return "Mock stock: unavailable";
  if (listing.availability === "low_stock") return `Low mock stock: ${listing.availableQuantity} left`;
  return `Mock stock: ${listing.availableQuantity} available`;
}

function availabilityColor(listing: CommerceListing, colors: any) {
  if (listing.availability === "out_of_stock") return colors.textTertiary;
  if (listing.availability === "low_stock") return colors.warning;
  return colors.success;
}

/**
 * Prototype-only commerce display. It never creates a live order or opens a
 * payment checkout. The cart is local, persisted, and deliberately labeled.
 */
export function MockCommercePanel({ productId, colors }: MockCommercePanelProps) {
  const [listing, setListing] = React.useState<CommerceListing | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [adding, setAdding] = React.useState(false);
  const [cartMessage, setCartMessage] = React.useState<string | null>(null);
  const { cart, itemCount, isReady, addItem } = useMockCommerce();
  const cartLine = cart.lines.find((line) => line.productId === productId);

  React.useEffect(() => {
    let active = true;
    setLoading(true);
    activeSkinCommerceProvider.getListing(productId)
      .then((next) => { if (active) setListing(next); })
      .catch(() => { if (active) setListing(null); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [productId]);

  const addToMockCart = async () => {
    setAdding(true);
    try {
      const result = await addItem(productId);
      setCartMessage(result.message);
      if (result.operation === "unavailable" || result.operation === "stock_limit") {
        Alert.alert("Mock cart update", `${result.message}\n\n${result.cart.disclosure}`);
      }
    } catch {
      Alert.alert("Mock cart unavailable", "The prototype cart could not be updated. Please try again.");
    } finally {
      setAdding(false);
    }
  };

  if (loading || !isReady) {
    return <View style={[styles.panel, { backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]}><ActivityIndicator size="small" color={colors.tint} /><Text style={[styles.disclosure, { color: colors.textTertiary }]}>Loading prototype commerce state…</Text><Text style={[styles.disclosure, { color: colors.textTertiary }]}>{MOCK_COMMERCE_DISCLOSURE}</Text></View>;
  }

  if (!listing) {
    return <View style={[styles.panel, { backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]}><Text style={[styles.disclosure, { color: colors.textTertiary }]}>Prototype commerce state is unavailable for this product.</Text><Text style={[styles.disclosure, { color: colors.textTertiary }]}>{MOCK_COMMERCE_DISCLOSURE}</Text></View>;
  }

  const isUnavailable = listing.availability === "out_of_stock";
  const atInventoryLimit = Boolean(cartLine && cartLine.quantity >= listing.availableQuantity);
  const disableAdd = isUnavailable || atInventoryLimit || adding;
  const buttonLabel = isUnavailable
    ? "Mock item unavailable"
    : atInventoryLimit
      ? "Mock inventory limit reached"
      : adding
        ? "Adding to mock cart…"
        : cartLine
          ? "Add another to Mock Cart"
          : "Add to Mock Cart";

  return (
    <View style={[styles.panel, { backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]}> 
      <View style={styles.row}>
        <View>
          <Text style={[styles.label, { color: colors.textTertiary }]}>MOCK PRICE</Text>
          <Text style={[styles.price, { color: colors.text }]}>${listing.unitPrice.toFixed(2)} {listing.currency}</Text>
        </View>
        <View style={[styles.badge, { backgroundColor: availabilityColor(listing, colors) + "18" }]}>
          <Text style={[styles.badgeText, { color: availabilityColor(listing, colors) }]}>{availabilityCopy(listing)}</Text>
        </View>
      </View>
      {cartLine && <Text style={[styles.inCart, { color: colors.tint }]}>In your mock cart: {cartLine.quantity} of {listing.availableQuantity || 0}</Text>}
      <Text style={[styles.disclosure, { color: colors.textTertiary }]}>{listing.disclosure}</Text>
      {cartMessage && <Text style={[styles.cartMessage, { color: cartMessage.includes("unavailable") || cartMessage.includes("limit") ? colors.warning : colors.success }]}>{cartMessage}</Text>}
      <View style={styles.actions}>
        <Pressable onPress={addToMockCart} disabled={disableAdd} style={[styles.button, { backgroundColor: colors.text, opacity: disableAdd ? 0.45 : 1 }]} accessibilityRole="button" accessibilityState={{ disabled: disableAdd }} accessibilityLabel={buttonLabel}>
          <Text style={[styles.buttonText, { color: colors.background }]}>{buttonLabel}</Text>
        </Pressable>
        {itemCount > 0 && <Pressable onPress={() => router.push("/skin/mock-cart")} style={[styles.manageButton, { borderColor: colors.border }]} accessibilityRole="button" accessibilityLabel={`Manage mock cart with ${itemCount} items`}>
          <Text style={[styles.manageButtonText, { color: colors.text }]}>Manage Mock Cart · {itemCount}</Text>
        </Pressable>}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  panel: { borderWidth: 1, borderRadius: 12, padding: 10, marginTop: 10 },
  row: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 8 },
  label: { fontFamily: "Outfit_700Bold", fontSize: 8, letterSpacing: 0.7 },
  price: { fontFamily: "Outfit_700Bold", fontSize: 15, marginTop: 1 },
  badge: { maxWidth: "62%", borderRadius: 10, paddingHorizontal: 7, paddingVertical: 5 },
  badgeText: { fontFamily: "Outfit_600SemiBold", fontSize: 9, textAlign: "right" },
  inCart: { fontFamily: "Outfit_600SemiBold", fontSize: 9, marginTop: 7 },
  disclosure: { fontFamily: "Outfit_400Regular", fontSize: 9, lineHeight: 13, marginTop: 8 },
  cartMessage: { fontFamily: "Outfit_600SemiBold", fontSize: 9, lineHeight: 13, marginTop: 7 },
  actions: { flexDirection: "row", flexWrap: "wrap", gap: 7, marginTop: 9 },
  button: { borderRadius: 9, paddingHorizontal: 10, paddingVertical: 8 },
  buttonText: { fontFamily: "Outfit_700Bold", fontSize: 10 },
  manageButton: { borderWidth: 1, borderRadius: 9, paddingHorizontal: 10, paddingVertical: 8 },
  manageButtonText: { fontFamily: "Outfit_700Bold", fontSize: 10 },
});
