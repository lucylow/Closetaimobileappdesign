import React from "react";
import { StyleSheet, Text, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";

import type { SkinAnalysisResult } from "@/lib/skin-analysis-controller";
import { buildSkinIntelligenceDashboard, type SkinIntelligenceCard } from "@/lib/skin-intelligence-dashboard";

const metricIcons: Record<string, keyof typeof Ionicons.glyphMap> = {
  hydration: "water-outline", oiliness: "contrast-outline", texture: "sparkles-outline", pores: "ellipse-outline", redness: "flame-outline", blemishes: "medical-outline", radiance: "sunny-outline", darkSpots: "color-palette-outline", fineLines: "analytics-outline",
};

function accentFor(card: SkinIntelligenceCard, colors: any) {
  if (card.priority === "focus") return colors.warning;
  if (card.priority === "sustain") return colors.success;
  return colors.tint;
}

function trendIcon(trend: SkinIntelligenceCard["trend"]): keyof typeof Ionicons.glyphMap {
  if (trend === "up") return "trending-up";
  if (trend === "down") return "trending-down";
  if (trend === "steady") return "remove-outline";
  return "sparkles-outline";
}

export function SkinIntelligenceDashboard({ current, history, colors }: { current: SkinAnalysisResult; history: SkinAnalysisResult[]; colors: any }) {
  const dashboard = React.useMemo(() => buildSkinIntelligenceDashboard(current, history), [current, history]);
  const signalCoverageDetail = current.visualSignalCoverage
    ? `${current.visualSignalCoverage.available} of ${current.visualSignalCoverage.total} normalized visual signals are available.`
    : "Only available normalized signals are shown.";
  return <>
    <View style={[styles.sourceCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
      <View style={[styles.sourceIcon, { backgroundColor: `${colors.tint}16` }]}><Ionicons name="analytics-outline" size={18} color={colors.tint} /></View>
      <View style={styles.flex}><Text style={[styles.sourceLabel, { color: colors.text }]}>{dashboard.sourceLabel}</Text><Text style={[styles.sourceText, { color: colors.textSecondary }]}>{dashboard.sourceDetail}</Text></View>
      {dashboard.overallScore !== undefined && <View style={[styles.scorePill, { backgroundColor: `${colors.tint}14` }]}><Text style={[styles.scoreValue, { color: colors.tint }]}>{dashboard.overallScore}</Text><Text style={[styles.scoreCaption, { color: colors.tint }]}>SCORE</Text></View>}
    </View>

    <View style={[styles.coverageCard, { backgroundColor: colors.surfaceSecondary }]}><Ionicons name="shield-checkmark-outline" size={16} color={colors.tint} /><Text style={[styles.coverageText, { color: colors.text }]}>Visual signal coverage {dashboard.coveragePercent}%</Text><Text style={[styles.coverageDetail, { color: colors.textSecondary }]}>{signalCoverageDetail}</Text></View>
    <View style={[styles.privacyNotice, { backgroundColor: `${colors.tint}0D`, borderColor: `${colors.tint}22` }]}><Ionicons name="lock-closed-outline" size={14} color={colors.tint} /><Text style={[styles.privacyText, { color: colors.textSecondary }]}>Progress history stores normalized signal summaries and timestamps, not your original selfie.</Text></View>

    <Text style={[styles.heading, { color: colors.text }]}>AI-prioritized visual insights</Text>
    <Text style={[styles.subheading, { color: colors.textSecondary }]}>Ordered for gentle care planning, not clinical ranking.</Text>
    <View style={styles.priorityStack}>{dashboard.priorities.map((card) => {
      const accent = accentFor(card, colors);
      return <View key={`priority-${card.key}`} style={[styles.priorityCard, { backgroundColor: colors.surface, borderColor: colors.border }]}><View style={[styles.priorityIcon, { backgroundColor: `${accent}16` }]}><Ionicons name={metricIcons[card.key] || "sparkles-outline"} size={17} color={accent} /></View><View style={styles.flex}><View style={styles.cardTitleRow}><Text style={[styles.cardTitle, { color: colors.text }]}>{card.label}</Text><Text style={[styles.priorityLabel, { color: accent }]}>{card.priority.toUpperCase()}</Text></View><Text style={[styles.cardText, { color: colors.textSecondary }]}>{card.plainLanguage}</Text></View></View>;
    })}</View>

    <Text style={[styles.heading, { color: colors.text }]}>Metric dashboard</Text>
    <Text style={[styles.subheading, { color: colors.textSecondary }]}>{dashboard.trendLabel}</Text>
    <View style={styles.grid}>{dashboard.cards.map((card) => {
      const accent = accentFor(card, colors);
      const trendText = card.trend === "new" ? "New" : card.trend === "steady" ? "Steady" : `${card.change && card.change > 0 ? "+" : ""}${card.change ?? 0}`;
      return <View key={card.key} style={[styles.metricCard, { backgroundColor: colors.surface, borderColor: colors.border }]}><View style={styles.metricTop}><View style={[styles.metricIcon, { backgroundColor: `${accent}16` }]}><Ionicons name={metricIcons[card.key] || "sparkles-outline"} size={15} color={accent} /></View><View style={styles.trend}><Ionicons name={trendIcon(card.trend)} size={13} color={accent} /><Text style={[styles.trendText, { color: accent }]}>{trendText}</Text></View></View><Text style={[styles.metricScore, { color: colors.text }]}>{card.score}</Text><Text style={[styles.metricLabel, { color: colors.text }]}>{card.label}</Text><View style={[styles.track, { backgroundColor: colors.borderLight || colors.border }]}><View style={[styles.fill, { backgroundColor: accent, width: `${Math.max(0, Math.min(100, card.score))}%` }]} /></View><Text style={[styles.metricStatus, { color: colors.textSecondary }]}>{card.priority === "sustain" ? "Maintain" : card.priority === "focus" ? "Focus gently" : "Watch over time"}</Text></View>;
    })}</View>
  </>;
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  sourceCard: { flexDirection: "row", alignItems: "center", gap: 10, borderWidth: 1, borderRadius: 17, padding: 13, marginBottom: 9 },
  sourceIcon: { width: 36, height: 36, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  sourceLabel: { fontFamily: "Outfit_700Bold", fontSize: 12 },
  sourceText: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 14, marginTop: 2 },
  scorePill: { alignItems: "center", borderRadius: 12, paddingHorizontal: 9, paddingVertical: 6 },
  scoreValue: { fontFamily: "Outfit_700Bold", fontSize: 18 }, scoreCaption: { fontFamily: "Outfit_700Bold", fontSize: 7, letterSpacing: 0.7 },
  coverageCard: { flexDirection: "row", alignItems: "center", gap: 7, borderRadius: 13, padding: 11, marginBottom: 18, flexWrap: "wrap" },
  coverageText: { fontFamily: "Outfit_600SemiBold", fontSize: 11 }, coverageDetail: { fontFamily: "Outfit_400Regular", fontSize: 10 },
  privacyNotice: { flexDirection: "row", alignItems: "flex-start", gap: 7, borderWidth: 1, borderRadius: 12, padding: 10, marginTop: -10, marginBottom: 16 },
  privacyText: { flex: 1, fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 14 },
  heading: { fontFamily: "Outfit_700Bold", fontSize: 18, marginTop: 3 }, subheading: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 14, marginTop: 2, marginBottom: 9 },
  priorityStack: { gap: 8, marginBottom: 19 }, priorityCard: { flexDirection: "row", gap: 10, borderWidth: 1, borderRadius: 16, padding: 12 }, priorityIcon: { width: 34, height: 34, borderRadius: 11, alignItems: "center", justifyContent: "center" },
  cardTitleRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 8 }, cardTitle: { fontFamily: "Outfit_600SemiBold", fontSize: 12 }, priorityLabel: { fontFamily: "Outfit_700Bold", fontSize: 8, letterSpacing: 0.5 }, cardText: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 14, marginTop: 3 },
  grid: { flexDirection: "row", flexWrap: "wrap", gap: 9, marginBottom: 18 }, metricCard: { width: "48%", borderWidth: 1, borderRadius: 16, padding: 11 }, metricTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" }, metricIcon: { width: 29, height: 29, borderRadius: 10, alignItems: "center", justifyContent: "center" }, trend: { flexDirection: "row", alignItems: "center", gap: 2 }, trendText: { fontFamily: "Outfit_600SemiBold", fontSize: 9 }, metricScore: { fontFamily: "Outfit_700Bold", fontSize: 22, marginTop: 8 }, metricLabel: { fontFamily: "Outfit_600SemiBold", fontSize: 11, marginTop: 1 }, track: { height: 5, borderRadius: 3, overflow: "hidden", marginTop: 9 }, fill: { height: "100%", borderRadius: 3 }, metricStatus: { fontFamily: "Outfit_400Regular", fontSize: 9, marginTop: 6 },
});
