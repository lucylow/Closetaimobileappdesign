import React, { useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Platform,
  Pressable,
  Linking,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system/legacy';
import { LinearGradient } from 'expo-linear-gradient';
import { router, useFocusEffect } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';
import { useApp } from '@/contexts/AppContext';
import { useTheme } from '@/lib/useTheme';
import { getSkinHistory, scanSkin } from '@/lib/skin';
import { demoSkinSnapshot, RoutineStep, SkinConcern, SkinSnapshot } from '@shared/skin';
import { shadows } from '@/constants/colors';
import { mockResultForToday, SKIN_MOCK_RESULT, SkinMockResult } from '@/lib/skin-mock-data';
import { boundedPercent, buildSelfieQualityReport, type SelfieQualityReport } from '@/lib/selfie-quality';
import { skinDemoProfiles } from '@/lib/skin-demo-profiles';
import { MockSkinDashboard } from '@/components/skin/MockSkinDashboard';
import { analyzeSkin } from '@/lib/skin-analysis-controller';
import { MockCommercePanel } from '@/components/skin/MockCommercePanel';

type ScreenState = 'intro' | 'analyzing' | 'results';

async function imageToBase64(uri: string): Promise<string> {
  if (Platform.OS !== 'web') {
    return FileSystem.readAsStringAsync(uri, { encoding: 'base64' as any });
  }
  const response = await fetch(uri);
  const blob = await response.blob();
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const value = String(reader.result || '');
      resolve(value.includes(',') ? value.split(',')[1] : value);
    };
    reader.onerror = () => reject(new Error('Unable to read image'));
    reader.readAsDataURL(blob);
  });
}

export default function SkinScreen({ embedded = false }: { embedded?: boolean }) {
  const { colors, isDark } = useTheme();
  const { demoMode, credits } = useApp();
  const insets = useSafeAreaInsets();
  const [state, setState] = useState<ScreenState>('results');
  const [imageUri, setImageUri] = useState<string | null>(
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=600'
  );
  const [selfieQuality, setSelfieQuality] = useState<SelfieQualityReport | null>(null);
  const [snapshot, setSnapshot] = useState<SkinSnapshot | null>(demoSkinSnapshot);
  const [mockResult, setMockResult] = useState<SkinMockResult | null>(SKIN_MOCK_RESULT);
  const [demoProfileIndex, setDemoProfileIndex] = useState(0);
  const [demoRunCount, setDemoRunCount] = useState(0);
  const [saveSnapshot, setSaveSnapshot] = useState(true);
  const [historyCount, setHistoryCount] = useState(0);
  const [photoPermissionState, setPhotoPermissionState] = useState<'unknown' | 'granted' | 'blocked'>('unknown');
  const [error, setError] = useState('');
  const [analysisStatus, setAnalysisStatus] = useState('');
  const [progressLabel, setProgressLabel] = useState('Uploading your photo');
  const scanRunRef = useRef(0);

  const topInset = insets.top || (Platform.OS === 'web' ? 67 : 16);
  const bottomInset = insets.bottom || (Platform.OS === 'web' ? 34 : 18);
  const contentBottomPadding = bottomInset + (embedded ? 112 : 28);
  const canStartScan = !!imageUri && selfieQuality?.band !== 'retake';
  const demoProfile = skinDemoProfiles[demoProfileIndex];

  useFocusEffect(React.useCallback(() => {
    let active = true;
    void Promise.all([ImagePicker.getCameraPermissionsAsync(), ImagePicker.getMediaLibraryPermissionsAsync()]).then(([camera, library]) => {
      if (!active) return;
      setPhotoPermissionState(camera.granted || library.granted ? 'granted' : 'blocked');
    }).catch(() => {
      if (active) setPhotoPermissionState('unknown');
    });
    return () => { active = false; };
  }, []));

  const openPhotoSettings = async () => {
    try {
      await Linking.openSettings();
    } catch {
      Alert.alert('Open settings manually', 'Photo access can be changed in your device settings. Fictional Demo Mode remains available without photo access.');
    }
  };

  const pickImage = async (camera: boolean) => {
    setError('');
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

    try {
      const permission = camera
        ? await ImagePicker.requestCameraPermissionsAsync()
        : await ImagePicker.requestMediaLibraryPermissionsAsync();

      if (!permission.granted) {
        setPhotoPermissionState('blocked');
        Alert.alert(
          camera ? 'Camera access is off' : 'Photo access is off',
          camera
            ? 'You can choose an existing selfie instead, or enable camera access in device settings.'
            : 'Enable photo-library access to select a selfie, or use the camera instead.',
          [
            { text: 'Continue with Demo', style: 'cancel' },
            { text: 'Open Settings', onPress: () => { void openPhotoSettings(); } },
          ],
        );
        return;
      }
      setPhotoPermissionState('granted');

      const result = camera
        ? await ImagePicker.launchCameraAsync({
            mediaTypes: ['images'],
            cameraType: ImagePicker.CameraType.front,
            allowsEditing: true,
            aspect: [4, 5],
            quality: 0.78,
            exif: false,
          })
        : await ImagePicker.launchImageLibraryAsync({
            mediaTypes: ['images'],
            allowsEditing: true,
            aspect: [4, 5],
            quality: 0.78,
            exif: false,
          });

      if (!result.canceled && result.assets[0]) {
        const asset = result.assets[0];
        setImageUri(asset.uri);
        setSelfieQuality(buildSelfieQualityReport({
          width: asset.width,
          height: asset.height,
          fileSize: asset.fileSize,
        }));
      }
    } catch (captureError) {
      const message = captureError instanceof Error ? captureError.message : 'Try selecting another clear selfie.';
      setError(message);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    }
  };

  const startScan = async () => {
    if (!imageUri) return;
    const runId = scanRunRef.current + 1;
    scanRunRef.current = runId;
    const isCurrentRun = () => scanRunRef.current === runId;
    setError('');
    setAnalysisStatus('');
    setState('analyzing');
    setProgressLabel('Uploading your photo');
    try {
      await new Promise((resolve) => setTimeout(resolve, 650));
      if (!isCurrentRun()) return;
      setProgressLabel('Reading your skin snapshot');
      const base64 = await imageToBase64(imageUri);
      if (!isCurrentRun()) return;
      let result: SkinSnapshot;
      if (demoMode) {
        const normalized = await analyzeSkin({ imageUri, imageBase64: base64, demo: true, saveSnapshot });
        if (!isCurrentRun()) return;
        result = { ...demoSkinSnapshot, id: normalized.id, createdAt: normalized.createdAt, skinType: normalized.skinType ?? demoSkinSnapshot.skinType, source: "demo" };
        const nextIndex = (demoProfileIndex + 1) % skinDemoProfiles.length;
        setDemoProfileIndex(nextIndex);
        setDemoRunCount((count) => count + 1);
        setMockResult(mockResultForToday());
      } else {
        const response = await scanSkin(base64, saveSnapshot);
        if (!isCurrentRun()) return;
        result = response.snapshot;
        setMockResult(null);
      }
      setProgressLabel('Preparing your routine');
      await new Promise((resolve) => setTimeout(resolve, 450));
      if (!isCurrentRun()) return;
      setSnapshot(result);
      setState('results');
      if (demoMode && saveSnapshot) {
        // Demo mode never waits for network or a backend just to show the completed scan.
        setHistoryCount((count) => count + 1);
      } else if (!demoMode) {
        try {
          const history = await getSkinHistory();
          if (!isCurrentRun()) return;
          setHistoryCount(history.length);
        } catch {
          if (!isCurrentRun()) return;
          setHistoryCount((count) => count + 1);
        }
      }
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (scanError: any) {
      if (!isCurrentRun()) return;
      setState('intro');
      setError(scanError?.message || 'We could not complete that scan. Try a clear, well-lit photo.');
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    } finally {
      if (isCurrentRun()) scanRunRef.current = 0;
    }
  };

  const cancelScan = () => {
    scanRunRef.current += 1;
    setState('intro');
    setAnalysisStatus('Analysis cancelled. Your selected photo remains available for review.');
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };

  const reset = () => {
    setState('intro');
    setSnapshot(null);
    setMockResult(null);
    setImageUri(null);
    setSelfieQuality(null);
    setError('');
    setAnalysisStatus('');
    scanRunRef.current += 1;
  };

  const runDemoSkinScan = async () => {
    const runId = scanRunRef.current + 1;
    scanRunRef.current = runId;
    const isCurrentRun = () => scanRunRef.current === runId;
    setError('');
    setAnalysisStatus('');
    setState('analyzing');
    setProgressLabel('Analyzing demo skin profile');
    await new Promise((resolve) => setTimeout(resolve, 850));
    if (!isCurrentRun()) return;
    setProgressLabel('Preparing your demo routine');
    const nextIndex = (demoProfileIndex + 1) % skinDemoProfiles.length;
    setDemoProfileIndex(nextIndex);
    setDemoRunCount((count) => count + 1);
    setSnapshot({ ...demoSkinSnapshot, id: `demo-skin-${Date.now()}`, createdAt: new Date().toISOString() });
    setMockResult(mockResultForToday());
    await new Promise((resolve) => setTimeout(resolve, 350));
    if (!isCurrentRun()) return;
    setState('results');
    scanRunRef.current = 0;
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: topInset + 10 }]}>
        {embedded ? (
          <View style={{ width: 25 }} />
        ) : (
          <Pressable onPress={() => router.back()} hitSlop={12} accessibilityRole="button" accessibilityLabel="Close Skin Care">
            <Ionicons name="close" size={25} color={colors.textSecondary} />
          </Pressable>
        )}
        <View style={styles.headerTitleWrap}>
          <Text style={[styles.headerEyebrow, { color: colors.tint }]}>CLOSET A.I.</Text>
          <Text style={[styles.headerTitle, { color: colors.text }]}>Skin Care</Text>
        </View>
        <View style={styles.headerActions}>
          <Pressable
            onPress={() => Alert.alert("Skin Care demo", "The Skin tab opens with fictional, offline-first prototype data. Add a selfie only when you want to try the optional scan flow.")}
            hitSlop={12}
            accessibilityRole="button"
            accessibilityLabel="About the Skin Care demo"
          >
            <Ionicons name="information-circle-outline" size={21} color={colors.textSecondary} />
          </Pressable>
          <Pressable
            onPress={() => {
              if (photoPermissionState === 'blocked') {
                void openPhotoSettings();
                return;
              }
              Alert.alert(
                photoPermissionState === 'granted' ? 'Photo access available' : 'Photo access status pending',
                photoPermissionState === 'granted' ? 'You can start an optional user-photo scan when you are ready.' : 'The app will re-check photo access when you open the capture flow. Fictional Demo Mode remains available.',
              );
            }}
            hitSlop={12}
            accessibilityRole="button"
            accessibilityLabel={photoPermissionState === 'blocked' ? 'Photo access is off. Open settings' : photoPermissionState === 'granted' ? 'Photo access is available' : 'Checking photo access'}
            accessibilityHint={photoPermissionState === 'blocked' ? 'Opens device settings so you can enable camera or photo-library access.' : 'Shows the current optional photo access status.'}
          >
            <Ionicons name={photoPermissionState === 'blocked' ? 'lock-closed-outline' : photoPermissionState === 'granted' ? 'lock-open-outline' : 'help-circle-outline'} size={20} color={photoPermissionState === 'blocked' ? colors.warning : photoPermissionState === 'granted' ? colors.success : colors.textSecondary} />
          </Pressable>
          <Pressable
            onPress={() => {
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
              reset();
            }}
            hitSlop={12}
            accessibilityRole="button"
            accessibilityLabel="Start a new Skin Care scan"
          >
            <Ionicons name="camera-outline" size={22} color={colors.tint} />
          </Pressable>
        </View>
      </View>

      <ScrollView
        contentContainerStyle={[styles.content, { paddingBottom: contentBottomPadding }]}
        showsVerticalScrollIndicator={false}
      >
        {state === 'intro' && (
          <>
            <LinearGradient
              colors={isDark ? ['#2B1E1A', '#181110'] : ['#F8E3D4', '#FFF8F3']}
              style={styles.hero}
            >
              <View style={styles.heroIcon}><Ionicons name="sparkles" size={23} color="#A85F48" /></View>
              <Text style={[styles.heroTitle, { color: colors.text }]}>A clearer starting point for your look.</Text>
              <Text style={[styles.heroText, { color: colors.textSecondary }]}>
                Get a high-level skin snapshot, a simple AM/PM routine, and styling ideas that work with the clothes you already own.
              </Text>
              <View style={styles.heroPills}>
                {['Hydration', 'Texture', 'Radiance'].map((label) => (
                  <View key={label} style={[styles.pill, { backgroundColor: colors.surface + 'C9' }]}>
                    <Text style={[styles.pillText, { color: colors.tint }]}>{label}</Text>
                  </View>
                ))}
              </View>
            </LinearGradient>

            <View style={[styles.privacyCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              <Ionicons name="lock-closed-outline" size={19} color={colors.tint} />
              <View style={{ flex: 1 }}>
                <Text style={[styles.privacyTitle, { color: colors.text }]}>Privacy-first by design</Text>
                <Text style={[styles.privacyText, { color: colors.textSecondary }]}>
                  Your photo is sent for analysis only. We save the summary, not the original selfie, unless you choose to save a snapshot.
                </Text>
              </View>
            </View>

            {imageUri ? (
              <View style={[styles.previewCard, { backgroundColor: colors.surface }]}>
                <Image source={{ uri: imageUri }} style={styles.previewImage} contentFit="cover" />
                <View pointerEvents="none" style={styles.faceGuide}>
                  <View style={styles.faceGuideOval} />
                  <Text style={styles.faceGuideText}>Face centred in guide</Text>
                </View>
                <Pressable onPress={() => { setImageUri(null); setSelfieQuality(null); }} style={styles.removePreview} hitSlop={8} accessibilityRole="button" accessibilityLabel="Remove selected selfie">
                  <Ionicons name="close" size={16} color="#FFF" />
                </Pressable>
                <Text style={[styles.previewLabel, { color: colors.textSecondary }]}>Ready to scan</Text>
              </View>
            ) : (
              <View style={[styles.photoPlaceholder, { backgroundColor: colors.surface, borderColor: colors.border }]}>
                <View style={[styles.photoIcon, { backgroundColor: colors.tint + '16' }]}>
                  <Ionicons name="person-outline" size={28} color={colors.tint} />
                </View>
                <Text style={[styles.photoTitle, { color: colors.text }]}>Use a clear, front-facing photo</Text>
                <Text style={[styles.photoText, { color: colors.textSecondary }]}>Natural light works best. Avoid heavy filters and face coverings.</Text>
              </View>
            )}

            {selfieQuality && (
              <View style={[styles.qualityCard, { backgroundColor: colors.surface, borderColor: selfieQuality.band === 'ready' ? colors.success : selfieQuality.band === 'review' ? colors.warning : colors.error }]}>
                <View style={styles.qualityHeader}>
                  <View style={[styles.qualityIcon, { backgroundColor: (selfieQuality.band === 'ready' ? colors.success : selfieQuality.band === 'review' ? colors.warning : colors.error) + '18' }]}>
                    <Ionicons name={selfieQuality.band === 'ready' ? 'checkmark-circle-outline' : 'scan-outline'} size={18} color={selfieQuality.band === 'ready' ? colors.success : selfieQuality.band === 'review' ? colors.warning : colors.error} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.qualityTitle, { color: colors.text }]}>{selfieQuality.band === 'ready' ? 'Selfie ready to review' : selfieQuality.band === 'review' ? 'Quick selfie review suggested' : 'Retake suggested'}</Text>
                    <Text style={[styles.qualitySummary, { color: colors.textSecondary }]}>{selfieQuality.summary}</Text>
                  </View>
                </View>
                {selfieQuality.checks.map((check) => (
                  <View key={check.id} style={styles.qualityCheckRow}>
                    <Ionicons name={check.status === 'pass' ? 'checkmark-circle' : 'information-circle-outline'} size={15} color={check.status === 'pass' ? colors.success : check.status === 'review' ? colors.warning : colors.error} />
                    <Text style={[styles.qualityCheckText, { color: colors.textSecondary }]}>{check.label}: {check.detail}</Text>
                  </View>
                ))}
              </View>
            )}

            {photoPermissionState === 'blocked' && (
              <View style={[styles.permissionNotice, { backgroundColor: colors.surface, borderColor: colors.border }]} accessibilityLiveRegion="polite">
                <Ionicons name="lock-closed-outline" size={18} color={colors.tint} />
                <View style={{ flex: 1 }}>
                  <Text style={[styles.qualityTitle, { color: colors.text }]}>Photo access is currently off</Text>
                  <Text style={[styles.qualitySummary, { color: colors.textSecondary }]}>Fictional Demo Mode remains available. Open device settings before trying a live camera or library scan.</Text>
                  <Pressable onPress={openPhotoSettings} style={[styles.secondaryPhotoButton, { borderColor: colors.border }]} accessibilityRole="button" accessibilityLabel="Open photo settings" accessibilityHint="Opens device settings so you can change camera or photo-library access.">
                    <Ionicons name="settings-outline" size={18} color={colors.tint} />
                    <Text style={[styles.secondaryPhotoText, { color: colors.text }]}>Open Photo Settings</Text>
                  </Pressable>
                </View>
              </View>
            )}

            <View style={styles.photoButtons}>
              <Pressable onPress={() => pickImage(true)} style={[styles.primaryPhotoButton, { backgroundColor: colors.tint }]} accessibilityRole="button">
                <Ionicons name="camera-outline" size={20} color="#FFF" />
                <Text style={styles.primaryPhotoText}>Take photo</Text>
              </Pressable>
              <Pressable onPress={() => pickImage(false)} style={[styles.secondaryPhotoButton, { borderColor: colors.border }]} accessibilityRole="button">
                <Ionicons name="images-outline" size={20} color={colors.tint} />
                <Text style={[styles.secondaryPhotoText, { color: colors.text }]}>Choose photo</Text>
              </Pressable>
            </View>

            <Pressable onPress={() => setSaveSnapshot((value) => !value)} style={styles.saveRow}>
              <View style={[styles.checkbox, { borderColor: saveSnapshot ? colors.tint : colors.border, backgroundColor: saveSnapshot ? colors.tint : 'transparent' }]}>
                {saveSnapshot && <Ionicons name="checkmark" size={14} color="#FFF" />}
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.saveTitle, { color: colors.text }]}>Save my Skin Snapshot</Text>
                <Text style={[styles.saveText, { color: colors.textSecondary }]}>Keep the normalized summary for future comparisons.</Text>
              </View>
            </Pressable>

            {imageUri && (
              <Pressable
                onPress={startScan}
                disabled={!canStartScan}
                style={[styles.scanButton, { backgroundColor: colors.text, opacity: canStartScan ? 1 : 0.48 }]}
                accessibilityRole="button"
                accessibilityState={{ disabled: !canStartScan }}
                accessibilityLabel={canStartScan ? 'Create my skin snapshot' : 'Retake selfie before creating a skin snapshot'}
              >
                <Ionicons name={canStartScan ? 'sparkles-outline' : 'refresh-outline'} size={20} color={colors.background} />
                <Text style={[styles.scanButtonText, { color: colors.background }]}>{canStartScan ? 'Create my snapshot' : 'Retake selfie to continue'}</Text>
                <Text style={[styles.scanCost, { color: colors.background + '99' }]}>{demoMode ? 'Demo' : '8 credits'}</Text>
              </Pressable>
            )}
            {!demoMode && typeof credits === 'number' && <Text style={[styles.creditNote, { color: colors.textTertiary }]}>{credits} credits available</Text>}
            {historyCount > 0 && <Text style={[styles.historyNote, { color: colors.textSecondary }]}>{historyCount} saved snapshot{historyCount === 1 ? '' : 's'} available</Text>}
            {!!error && <Text style={[styles.errorText, { color: colors.error }]}>{error}</Text>}
            {!!analysisStatus && <Text accessibilityLiveRegion="polite" style={[styles.historyNote, { color: colors.textSecondary }]}>{analysisStatus}</Text>}
          </>
        )}

        {state === 'analyzing' && (
          <View style={styles.loadingState}>
            {imageUri && <Image source={{ uri: imageUri }} style={styles.loadingImage} contentFit="cover" />}
            <ActivityIndicator size="large" color={colors.tint} />
            <Text style={[styles.loadingTitle, { color: colors.text }]}>{progressLabel}</Text>
            <Text style={[styles.loadingText, { color: colors.textSecondary }]}>This usually takes less than a minute.</Text>
            <Text accessibilityLiveRegion="polite" style={[styles.loadingText, { color: colors.textSecondary }]}>You can cancel and keep the selected photo for review.</Text>
            <Pressable onPress={cancelScan} style={[styles.cancelScanButton, { borderColor: colors.border }]} accessibilityRole="button" accessibilityLabel="Cancel skin analysis" accessibilityHint="Stops analysis and keeps the selected photo available for review.">
              <Ionicons name="close-circle-outline" size={18} color={colors.textSecondary} />
              <Text style={[styles.secondaryPhotoText, { color: colors.text }]}>Cancel analysis</Text>
            </Pressable>
            <View style={styles.loadingSteps}>
              {['Upload', 'Analyze', 'Style plan'].map((step, index) => (
                <View key={step} style={styles.loadingStep}>
                  <View style={[styles.stepDot, { backgroundColor: colors.tint }]} />
                  <Text style={[styles.stepText, { color: colors.textSecondary }]}>{step}</Text>
                  {index < 2 && <View style={[styles.stepLine, { backgroundColor: colors.border }]} />}
                </View>
              ))}
            </View>
          </View>
        )}

        {state === 'results' && snapshot && (
          mockResult ? (
            <MockSkinDashboard
              profile={demoProfile}
              colors={colors}
              isScanning={false}
              hasRunDemo={demoRunCount > 0}
              onRunDemoScan={runDemoSkinScan}
              onAddSelfie={() => router.push("/skin/selfie-scan")}
              onOpenWardrobe={() => router.push('/(tabs)/wardrobe')}
              onBuildLook={() => router.push('/(tabs)/outfits')}
            />
          ) : (
            <ResultsView snapshot={snapshot} mockResult={mockResult} colors={colors} isDark={isDark} onReset={reset} />
          )
        )}
      </ScrollView>
    </View>
  );
}

function ResultsView({ snapshot, mockResult, colors, isDark, onReset }: { snapshot: SkinSnapshot; mockResult: SkinMockResult | null; colors: any; isDark: boolean; onReset: () => void }) {
  const topConcerns = useMemo(() => snapshot.concerns, [snapshot.concerns]);
  const [showProducts, setShowProducts] = useState(true);
  const [showWardrobe, setShowWardrobe] = useState(true);
  const [showProgress, setShowProgress] = useState(false);
  const isDemoResult = !!mockResult;
  return (
    <>
      {isDemoResult && (
        <View style={[styles.demoBanner, { backgroundColor: colors.surface, borderColor: colors.tint + '35' }]}>
          <View style={[styles.demoIcon, { backgroundColor: colors.tint + '16' }]}><Ionicons name="flask-outline" size={17} color={colors.tint} /></View>
          <View style={{ flex: 1 }}>
            <Text style={[styles.demoTitle, { color: colors.text }]}>Demo Skin Snapshot</Text>
            <Text style={[styles.demoText, { color: colors.textSecondary }]}>Fictional preview data for ClosetAI Skin Care. It is not a medical diagnosis or live YouCam analysis.</Text>
          </View>
        </View>
      )}
      <LinearGradient colors={isDark ? ['#2B1E1A', '#181110'] : ['#F8E3D4', '#FFF8F3']} style={styles.resultHero}>
        <View style={styles.resultBadge}><Ionicons name="checkmark" size={15} color="#FFF" /><Text style={styles.resultBadgeText}>SNAPSHOT READY</Text></View>
        <Text style={[styles.resultTitle, { color: colors.text }]}>{mockResult?.headline || 'Your skin, at a glance.'}</Text>
        <Text style={[styles.resultSummary, { color: colors.textSecondary }]}>{mockResult?.summary || snapshot.overallSummary}</Text>
        {!!snapshot.skinType && <Text style={[styles.skinType, { color: colors.tint }]}>{snapshot.skinType} skin profile</Text>}
        {mockResult && <View style={styles.scoreRow}><View><Text style={[styles.scoreValue, { color: colors.text }]}>{mockResult.overallScore}</Text><Text style={[styles.scoreLabel, { color: colors.textSecondary }]}>overall snapshot score</Text></View><View style={styles.confidence}><Ionicons name="shield-checkmark-outline" size={16} color={colors.tint} /><Text style={[styles.confidenceText, { color: colors.tint }]}>{mockResult.confidence}% confidence</Text></View></View>}
      </LinearGradient>

      <View style={styles.resultActions}>
        <Pressable onPress={() => router.push('/(tabs)/outfits')} style={[styles.resultActionPrimary, { backgroundColor: colors.text }]}>
          <Ionicons name="shirt-outline" size={18} color={colors.background} />
          <Text style={[styles.resultActionPrimaryText, { color: colors.background }]}>Build my look</Text>
        </Pressable>
        <Pressable onPress={onReset} style={[styles.resultActionSecondary, { borderColor: colors.border }]}>
          <Ionicons name="refresh-outline" size={18} color={colors.tint} />
          <Text style={[styles.resultActionSecondaryText, { color: colors.text }]}>New scan</Text>
        </Pressable>
      </View>

      <SectionTitle title="Skin signals" subtitle="Visual guidance, not a diagnosis" colors={colors} />
      <View style={styles.concernsGrid}>
        {topConcerns.map((concern) => <ConcernCard key={concern.key} concern={concern} colors={colors} />)}
      </View>

      <SectionTitle title="Your gentle routine" subtitle="Keep it simple and consistent" colors={colors} />
      <RoutineCard routine={snapshot.routine} colors={colors} />

      <SectionTitle title="Skin → style" subtitle="Suggestions, not rules. Your taste comes first." colors={colors} />
      {snapshot.styleInsights.map((insight) => (
        <View key={insight.title} style={[styles.styleCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <View style={[styles.styleIcon, { backgroundColor: colors.tint + '16' }]}><Ionicons name="color-palette-outline" size={18} color={colors.tint} /></View>
          <View style={{ flex: 1 }}>
            <Text style={[styles.styleTitle, { color: colors.text }]}>{insight.title}</Text>
            <Text style={[styles.styleText, { color: colors.textSecondary }]}>{insight.detail}</Text>
            {!!insight.colorFamilies?.length && <View style={styles.colorChips}>{insight.colorFamilies.map((color) => <View key={color} style={[styles.colorChip, { backgroundColor: colors.tint + '12' }]}><Text style={[styles.colorChipText, { color: colors.tint }]}>{color}</Text></View>)}</View>}
          </View>
        </View>
      ))}

      {mockResult && (
        <>
          <SectionTitle title="Real product recommendations" subtitle="Verified manufacturer catalog; demo scan signals remain fictional" colors={colors} />
          <CollapsibleToggle title="View the demo product edit" open={showProducts} onPress={() => setShowProducts((value) => !value)} colors={colors} />
          {showProducts && <View style={styles.productList}>{mockResult.products.map((product) => <ProductCard key={product.id} product={product} colors={colors} />)}</View>}

          <SectionTitle title="Progress to watch" subtitle="A simple way to compare future snapshots" colors={colors} />
          <CollapsibleToggle title="Show snapshot trends" open={showProgress} onPress={() => setShowProgress((value) => !value)} colors={colors} />
          {showProgress && <View style={[styles.progressCard, { backgroundColor: colors.surface }]}>{mockResult.progress.map((item) => <View key={item.label} style={styles.progressRow}><View style={styles.progressHeader}><Text style={[styles.progressLabel, { color: colors.text }]}>{item.label}</Text><Text style={[styles.progressChange, { color: item.change >= 0 ? colors.success : colors.warning }]}>{item.change >= 0 ? '+' : ''}{item.change}%</Text></View><View style={[styles.progressTrack, { backgroundColor: colors.borderLight }]}><View style={[styles.progressFill, { width: `${item.value}%`, backgroundColor: colors.tint }]} /></View></View>)}</View>}

          <SectionTitle title="Skin × wardrobe" subtitle="Style guidance, never style rules" colors={colors} />
          <CollapsibleToggle title="Open wardrobe advice" open={showWardrobe} onPress={() => setShowWardrobe((value) => !value)} colors={colors} />
          {showWardrobe && <View style={[styles.wardrobeAdviceCard, { backgroundColor: colors.surface }]}>{mockResult.wardrobeAdvice.map((advice, index) => <View key={advice} style={styles.adviceRow}><View style={[styles.adviceNumber, { backgroundColor: colors.tint + '16' }]}><Text style={[styles.adviceNumberText, { color: colors.tint }]}>{index + 1}</Text></View><Text style={[styles.adviceText, { color: colors.textSecondary }]}>{advice}</Text></View>)}</View>}
        </>
      )}

      <View style={[styles.disclaimer, { backgroundColor: colors.surfaceSecondary }]}>
        <Ionicons name="information-circle-outline" size={17} color={colors.textTertiary} />
        <Text style={[styles.disclaimerText, { color: colors.textTertiary }]}>This snapshot is general wellness guidance, not medical advice. For persistent or concerning symptoms, consult a qualified professional.</Text>
      </View>
    </>
  );
}

function CollapsibleToggle({ title, open, onPress, colors }: { title: string; open: boolean; onPress: () => void; colors: any }) {
  return <Pressable onPress={onPress} style={[styles.collapsibleToggle, { backgroundColor: colors.surfaceSecondary }]}><Text style={[styles.collapsibleText, { color: colors.text }]}>{title}</Text><Ionicons name={open ? "chevron-up" : "chevron-down"} size={17} color={colors.tint} /></Pressable>;
}

function ProductCard({ product, colors }: { product: SkinMockResult['products'][number]; colors: any }) {
  const icons: Record<string, keyof typeof Ionicons.glyphMap> = { Cleanser: 'water-outline', Serum: 'beaker-outline', Moisturizer: 'heart-outline', SPF: 'sunny-outline', Treatment: 'sparkles-outline' };
  const openOfficialListing = () => Linking.openURL(product.officialUrl).catch(() => Alert.alert('Official listing unavailable', 'We could not open the manufacturer page. Please try again later.'));
  return <View style={[styles.productCard, { backgroundColor: colors.surface, borderColor: colors.border }]}><View style={[styles.productIcon, { backgroundColor: colors.tint + '16' }]}><Ionicons name={icons[product.category] || 'sparkles-outline'} size={19} color={colors.tint} /></View><View style={{ flex: 1 }}><View style={styles.productTitleRow}><Text style={[styles.productName, { color: colors.text }]}>{product.name}</Text><Text style={[styles.productCatalogTag, { color: colors.tint }]}>REAL</Text></View><Text style={[styles.productMeta, { color: colors.textTertiary }]}>{product.brand} · {product.routine} · Manufacturer product page</Text><Text style={[styles.productWhy, { color: colors.textSecondary }]}>Ingredients: {product.primaryIngredients.join(', ')}</Text><Text style={[styles.productWhy, { color: colors.textSecondary }]}>{product.usageNote}</Text><MockCommercePanel productId={product.id} colors={colors} /><View style={styles.productTags}>{product.supports.map((signal) => <View key={signal} style={[styles.productTag, { backgroundColor: colors.tint + '12' }]}><Text style={[styles.productTagText, { color: colors.tint }]}>{signal}</Text></View>)}</View><Text style={[styles.productAvailability, { color: colors.textTertiary }]}>{product.availabilityNotice}</Text><Pressable onPress={openOfficialListing} style={[styles.catalogLink, { borderColor: colors.border }]} accessibilityRole="link"><Text style={[styles.catalogLinkText, { color: colors.text }]}>{product.officialCartAvailable ? 'Add to Cart on Official Site' : 'View Official Listing'}</Text><Ionicons name="open-outline" size={14} color={colors.tint} /></Pressable></View></View>; 
}

function SectionTitle({ title, subtitle, colors }: { title: string; subtitle: string; colors: any }) {
  return <View style={styles.sectionTitleRow}><View><Text style={[styles.sectionTitle, { color: colors.text }]}>{title}</Text><Text style={[styles.sectionSubtitle, { color: colors.textSecondary }]}>{subtitle}</Text></View></View>;
}

function ConcernCard({ concern, colors }: { concern: SkinConcern; colors: any }) {
  const color = concern.severityBand === 'high' ? colors.warning : colors.tint;
  return <View style={[styles.concernCard, { backgroundColor: colors.surface }, shadows.soft]}>
    <View style={styles.concernTop}><Text style={[styles.concernLabel, { color: colors.text }]}>{concern.label}</Text>{concern.score !== null && <Text style={[styles.concernScore, { color }]}>{concern.score}</Text>}</View>
    <View style={[styles.progressTrack, { backgroundColor: colors.borderLight }]}>{concern.score !== null && <View style={[styles.progressFill, { backgroundColor: color, width: `${boundedPercent(concern.score)}%` }]} />}</View>
    <Text style={[styles.concernAction, { color: colors.textSecondary }]} numberOfLines={3}>{concern.action}</Text>
  </View>;
}

function RoutineCard({ routine, colors }: { routine: RoutineStep[]; colors: any }) {
  return <View style={[styles.routineCard, { backgroundColor: colors.surface }, shadows.soft]}>
    {(['AM', 'PM'] as const).map((time) => <View key={time} style={styles.routineGroup}>
      <View style={[styles.timeBadge, { backgroundColor: colors.tint + '14' }]}><Text style={[styles.timeText, { color: colors.tint }]}>{time}</Text></View>
      <View style={styles.routineSteps}>{routine.filter((step) => step.time === time).map((step) => <View key={`${time}-${step.order}`} style={styles.routineStep}>
        <View style={[styles.routineDot, { backgroundColor: colors.tint }]} />
        <View style={{ flex: 1 }}><Text style={[styles.routineCategory, { color: colors.text }]}>{step.category}{step.optional ? ' · optional' : ''}</Text><Text style={[styles.routineNotes, { color: colors.textSecondary }]}>{step.notes}</Text></View>
      </View>)}</View>
    </View>)}
  </View>;
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingBottom: 13 },
  headerTitleWrap: { alignItems: 'center' },
  headerActions: { width: 53, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  headerEyebrow: { fontFamily: 'Outfit_700Bold', fontSize: 9, letterSpacing: 1.3 },
  headerTitle: { fontFamily: 'Outfit_700Bold', fontSize: 20 },
  content: { paddingHorizontal: 20 },
  hero: { borderRadius: 26, padding: 20, marginBottom: 14 },
  heroIcon: { width: 48, height: 48, borderRadius: 17, backgroundColor: 'rgba(255,255,255,0.72)', alignItems: 'center', justifyContent: 'center', marginBottom: 16 },
  heroTitle: { fontFamily: 'Outfit_700Bold', fontSize: 28, lineHeight: 33, maxWidth: 310 },
  heroText: { fontFamily: 'Outfit_400Regular', fontSize: 14, lineHeight: 21, marginTop: 10 },
  heroPills: { flexDirection: 'row', gap: 7, marginTop: 17, flexWrap: 'wrap' },
  pill: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 20 },
  pillText: { fontFamily: 'Outfit_600SemiBold', fontSize: 11 },
  privacyCard: { flexDirection: 'row', gap: 11, padding: 14, borderRadius: 17, borderWidth: 1, marginBottom: 14 },
  privacyTitle: { fontFamily: 'Outfit_600SemiBold', fontSize: 13 },
  privacyText: { fontFamily: 'Outfit_400Regular', fontSize: 11, lineHeight: 16, marginTop: 3 },
  photoPlaceholder: { minHeight: 190, borderRadius: 20, borderWidth: 1, borderStyle: 'dashed', alignItems: 'center', justifyContent: 'center', padding: 24, marginBottom: 12 },
  photoIcon: { width: 58, height: 58, borderRadius: 20, alignItems: 'center', justifyContent: 'center', marginBottom: 12 },
  photoTitle: { fontFamily: 'Outfit_600SemiBold', fontSize: 15, textAlign: 'center' },
  photoText: { fontFamily: 'Outfit_400Regular', fontSize: 12, lineHeight: 17, textAlign: 'center', marginTop: 5, maxWidth: 250 },
  previewCard: { height: 250, borderRadius: 20, overflow: 'hidden', marginBottom: 12 },
  previewImage: { width: '100%', height: '100%' },
  removePreview: { position: 'absolute', top: 12, right: 12, width: 30, height: 30, borderRadius: 15, backgroundColor: 'rgba(0,0,0,0.55)', alignItems: 'center', justifyContent: 'center' },
  previewLabel: { position: 'absolute', left: 12, bottom: 12, backgroundColor: 'rgba(0,0,0,0.55)', color: '#FFF', paddingHorizontal: 10, paddingVertical: 6, borderRadius: 12, overflow: 'hidden', fontFamily: 'Outfit_500Medium', fontSize: 11 },
  faceGuide: { ...StyleSheet.absoluteFillObject, alignItems: 'center', justifyContent: 'center' },
  faceGuideOval: { width: '52%', height: '64%', borderRadius: 999, borderWidth: 2, borderColor: 'rgba(255,255,255,0.88)' },
  faceGuideText: { position: 'absolute', bottom: 18, color: '#FFF', fontFamily: 'Outfit_600SemiBold', fontSize: 10, backgroundColor: 'rgba(0,0,0,0.45)', paddingHorizontal: 9, paddingVertical: 5, borderRadius: 10, overflow: 'hidden' },
  permissionNotice: { borderWidth: 1, borderRadius: 16, padding: 13, marginBottom: 12, flexDirection: 'row', alignItems: 'flex-start', gap: 10 },
  cancelScanButton: { alignSelf: 'center', marginTop: 16, borderWidth: 1, borderRadius: 14, paddingHorizontal: 16, paddingVertical: 10, flexDirection: 'row', alignItems: 'center', gap: 8 },
  qualityCard: { borderWidth: 1, borderRadius: 17, padding: 13, marginBottom: 12 },
  qualityHeader: { flexDirection: 'row', alignItems: 'flex-start', gap: 9, marginBottom: 9 },
  qualityIcon: { width: 34, height: 34, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  qualityTitle: { fontFamily: 'Outfit_600SemiBold', fontSize: 13 },
  qualitySummary: { fontFamily: 'Outfit_400Regular', fontSize: 10, lineHeight: 15, marginTop: 2 },
  qualityCheckRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 6, marginTop: 5 },
  qualityCheckText: { flex: 1, fontFamily: 'Outfit_400Regular', fontSize: 10, lineHeight: 14 },
  photoButtons: { flexDirection: 'row', gap: 10, marginBottom: 15 },
  primaryPhotoButton: { flex: 1, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 7, borderRadius: 15, paddingVertical: 14 },
  primaryPhotoText: { color: '#FFF', fontFamily: 'Outfit_600SemiBold', fontSize: 14 },
  secondaryPhotoButton: { flex: 1, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 7, borderRadius: 15, borderWidth: 1, paddingVertical: 14 },
  secondaryPhotoText: { fontFamily: 'Outfit_600SemiBold', fontSize: 14 },
  saveRow: { flexDirection: 'row', alignItems: 'center', gap: 11, marginBottom: 15 },
  checkbox: { width: 22, height: 22, borderRadius: 7, borderWidth: 1.5, alignItems: 'center', justifyContent: 'center' },
  saveTitle: { fontFamily: 'Outfit_600SemiBold', fontSize: 13 },
  saveText: { fontFamily: 'Outfit_400Regular', fontSize: 11, marginTop: 2 },
  scanButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 9, borderRadius: 16, paddingVertical: 16 },
  scanButtonText: { fontFamily: 'Outfit_700Bold', fontSize: 15 },
  scanCost: { fontFamily: 'Outfit_500Medium', fontSize: 11, marginLeft: 5 },
  creditNote: { textAlign: 'center', fontFamily: 'Outfit_400Regular', fontSize: 11, marginTop: 8 },
  historyNote: { textAlign: 'center', fontFamily: 'Outfit_400Regular', fontSize: 11, marginTop: 13 },
  errorText: { textAlign: 'center', fontFamily: 'Outfit_500Medium', fontSize: 12, lineHeight: 17, marginTop: 12 },
  loadingState: { alignItems: 'center', paddingTop: 25 },
  loadingImage: { width: 190, height: 235, borderRadius: 26, marginBottom: 28 },
  loadingTitle: { fontFamily: 'Outfit_700Bold', fontSize: 20, marginTop: 18 },
  loadingText: { fontFamily: 'Outfit_400Regular', fontSize: 13, marginTop: 6 },
  loadingSteps: { flexDirection: 'row', alignItems: 'center', marginTop: 38 },
  loadingStep: { flexDirection: 'row', alignItems: 'center' },
  stepDot: { width: 8, height: 8, borderRadius: 4 },
  stepText: { fontFamily: 'Outfit_500Medium', fontSize: 11, marginLeft: 5 },
  stepLine: { width: 25, height: 1, marginHorizontal: 8 },
  resultHero: { borderRadius: 26, padding: 20, marginBottom: 15 },
  resultBadge: { flexDirection: 'row', alignItems: 'center', alignSelf: 'flex-start', gap: 5, backgroundColor: '#A85F48', borderRadius: 20, paddingHorizontal: 9, paddingVertical: 6 },
  resultBadgeText: { color: '#FFF', fontFamily: 'Outfit_700Bold', fontSize: 9, letterSpacing: 1 },
  resultTitle: { fontFamily: 'Outfit_700Bold', fontSize: 28, marginTop: 17 },
  resultSummary: { fontFamily: 'Outfit_400Regular', fontSize: 14, lineHeight: 21, marginTop: 8 },
  skinType: { fontFamily: 'Outfit_600SemiBold', fontSize: 12, marginTop: 15 },
  resultActions: { flexDirection: 'row', gap: 10, marginBottom: 24 },
  resultActionPrimary: { flex: 1, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 7, borderRadius: 15, paddingVertical: 14 },
  resultActionPrimaryText: { fontFamily: 'Outfit_600SemiBold', fontSize: 13 },
  resultActionSecondary: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 6, borderWidth: 1, borderRadius: 15, paddingHorizontal: 15 },
  resultActionSecondaryText: { fontFamily: 'Outfit_600SemiBold', fontSize: 13 },
  sectionTitleRow: { marginBottom: 11, marginTop: 5 },
  sectionTitle: { fontFamily: 'Outfit_700Bold', fontSize: 19 },
  sectionSubtitle: { fontFamily: 'Outfit_400Regular', fontSize: 11, marginTop: 2 },
  concernsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 22 },
  concernCard: { width: '48%', borderRadius: 16, padding: 13, minHeight: 116 },
  concernTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  concernLabel: { fontFamily: 'Outfit_600SemiBold', fontSize: 13, flex: 1 },
  concernScore: { fontFamily: 'Outfit_700Bold', fontSize: 19 },
  progressTrack: { height: 5, borderRadius: 3, marginTop: 13, overflow: 'hidden' },
  progressFill: { height: '100%', borderRadius: 3 },
  concernAction: { fontFamily: 'Outfit_400Regular', fontSize: 11, lineHeight: 15, marginTop: 11 },
  routineCard: { borderRadius: 18, padding: 15, marginBottom: 22 },
  routineGroup: { flexDirection: 'row', gap: 13, marginBottom: 15 },
  timeBadge: { width: 34, height: 28, borderRadius: 9, alignItems: 'center', justifyContent: 'center' },
  timeText: { fontFamily: 'Outfit_700Bold', fontSize: 11 },
  routineSteps: { flex: 1, gap: 12 },
  routineStep: { flexDirection: 'row', gap: 9 },
  routineDot: { width: 7, height: 7, borderRadius: 4, marginTop: 5 },
  routineCategory: { fontFamily: 'Outfit_600SemiBold', fontSize: 13 },
  routineNotes: { fontFamily: 'Outfit_400Regular', fontSize: 11, lineHeight: 15, marginTop: 2 },
  styleCard: { flexDirection: 'row', gap: 11, borderWidth: 1, borderRadius: 17, padding: 14, marginBottom: 10 },
  styleIcon: { width: 36, height: 36, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  styleTitle: { fontFamily: 'Outfit_600SemiBold', fontSize: 13 },
  styleText: { fontFamily: 'Outfit_400Regular', fontSize: 12, lineHeight: 17, marginTop: 4 },
  colorChips: { flexDirection: 'row', gap: 6, flexWrap: 'wrap', marginTop: 9 },
  colorChip: { borderRadius: 10, paddingHorizontal: 8, paddingVertical: 4 },
  colorChipText: { fontFamily: 'Outfit_500Medium', fontSize: 10 },
  disclaimer: { flexDirection: 'row', gap: 8, padding: 12, borderRadius: 13, marginTop: 14 },
  disclaimerText: { flex: 1, fontFamily: 'Outfit_400Regular', fontSize: 10, lineHeight: 15 },
  demoBanner: { flexDirection: 'row', gap: 10, padding: 13, borderRadius: 17, borderWidth: 1, marginBottom: 13 },
  demoIcon: { width: 34, height: 34, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  demoTitle: { fontFamily: 'Outfit_700Bold', fontSize: 13 },
  demoText: { fontFamily: 'Outfit_400Regular', fontSize: 11, lineHeight: 16, marginTop: 3 },
  scoreRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end', marginTop: 17 },
  scoreValue: { fontFamily: 'Outfit_700Bold', fontSize: 42, lineHeight: 44 },
  scoreLabel: { fontFamily: 'Outfit_400Regular', fontSize: 10 },
  confidence: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 10, paddingVertical: 7, borderRadius: 14, backgroundColor: 'rgba(255,255,255,0.65)' },
  confidenceText: { fontFamily: 'Outfit_600SemiBold', fontSize: 11 },
  collapsibleToggle: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 14, paddingVertical: 12, borderRadius: 13, marginBottom: 10 },
  collapsibleText: { fontFamily: 'Outfit_600SemiBold', fontSize: 12 },
  productList: { gap: 9, marginBottom: 22 },
  productCard: { flexDirection: 'row', gap: 11, padding: 13, borderRadius: 16, borderWidth: 1 },
  productIcon: { width: 37, height: 37, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  productTitleRow: { flexDirection: 'row', justifyContent: 'space-between', gap: 8 },
  productName: { fontFamily: 'Outfit_600SemiBold', fontSize: 13, flex: 1 },
  productPrice: { fontFamily: 'Outfit_700Bold', fontSize: 13 },
  productCatalogTag: { fontFamily: 'Outfit_700Bold', fontSize: 9, letterSpacing: 0.6 },
  productAvailability: { fontFamily: 'Outfit_400Regular', fontSize: 9, lineHeight: 13, marginTop: 7 },
  catalogLink: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', borderWidth: 1, borderRadius: 10, paddingHorizontal: 10, paddingVertical: 8, marginTop: 9 },
  catalogLinkText: { fontFamily: 'Outfit_600SemiBold', fontSize: 10 },
  productMeta: { fontFamily: 'Outfit_400Regular', fontSize: 10, marginTop: 3 },
  productWhy: { fontFamily: 'Outfit_400Regular', fontSize: 11, lineHeight: 15, marginTop: 5 },
  productTags: { flexDirection: 'row', gap: 5, flexWrap: 'wrap', marginTop: 7 },
  productTag: { borderRadius: 8, paddingHorizontal: 7, paddingVertical: 3 },
  productTagText: { fontFamily: 'Outfit_500Medium', fontSize: 9 },
  progressCard: { padding: 15, borderRadius: 17, marginBottom: 22, gap: 14 },
  progressRow: { gap: 6 },
  progressHeader: { flexDirection: 'row', justifyContent: 'space-between' },
  progressLabel: { fontFamily: 'Outfit_600SemiBold', fontSize: 12 },
  progressChange: { fontFamily: 'Outfit_600SemiBold', fontSize: 11 },
  wardrobeAdviceCard: { padding: 15, borderRadius: 17, marginBottom: 22, gap: 13 },
  adviceRow: { flexDirection: 'row', gap: 9, alignItems: 'flex-start' },
  adviceNumber: { width: 23, height: 23, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
  adviceNumberText: { fontFamily: 'Outfit_700Bold', fontSize: 11 },
  adviceText: { flex: 1, fontFamily: 'Outfit_400Regular', fontSize: 12, lineHeight: 17 },
});