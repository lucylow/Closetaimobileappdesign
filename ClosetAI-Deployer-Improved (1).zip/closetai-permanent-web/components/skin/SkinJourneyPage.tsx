import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import React from "react";
import { Alert, Linking, Pressable, ScrollView, StyleSheet, Switch, Text, TextInput, View } from "react-native";

import { useApp } from "@/contexts/AppContext";
import { useSkinCare } from "@/contexts/SkinCareContext";
import { useSelfieScan } from "@/contexts/SelfieScanContext";
import { careReminders, getMetric, getProduct, progressSeries, savedSnapshots, skinGoals, skinMetrics } from "@/lib/skin-navigation-data";
import { useTheme } from "@/lib/useTheme";
import { buildSkinStylePlan, resolveSkinStyleLookItems } from "@/lib/skin-style-plan";
import { SkinIntelligenceDashboard } from "@/components/skin/SkinIntelligenceDashboard";
import { SkinMetricProgressChart } from "@/components/skin/SkinMetricProgressChart";
import { getCatalogProduct } from "@/lib/skin-product-catalog";
import { buildPersonalizedRoutine, countRoutineCompletions, routineCompletionKey } from "@/lib/personalized-skin-routine";
import { buildRecommendedProducts, type RecommendedProductsRoutineFilter } from "@/lib/recommended-skin-products";
import { MockCommercePanel } from "@/components/skin/MockCommercePanel";
import { UltraLuxurySkinDiscoveryPanel } from "@/components/skin/UltraLuxurySkinDiscoveryPanel";
import { FICTIONAL_PRODUCT_CATEGORY_CARDS } from "@/lib/fictional-demo-scenarios";
import { buildSkinHistoryCards } from "@/lib/skin-history-cards";

const PAGE_META: Record<string, { title: string; subtitle: string; icon: keyof typeof Ionicons.glyphMap }> = {
  scan: { title: "Scan workspace", subtitle: "Choose an optional photo path or return to the demo snapshot at any time.", icon: "camera-outline" },
  "camera-tips": { title: "Photo guidance", subtitle: "A few calm tips for an optional clear, front-facing selfie.", icon: "bulb-outline" },
  results: { title: "Snapshot results", subtitle: "General visual guidance, not a diagnosis.", icon: "sparkles-outline" },
  concerns: { title: "Skin signals", subtitle: "Explore a signal, its calm next step, and related routine guidance.", icon: "analytics-outline" },
  routine: { title: "Routine planner", subtitle: "A light AM and PM sequence you can mark as complete locally.", icon: "list-outline" },
  products: { title: "Personal care plan", subtitle: "Verified catalog products are ranked from normalized visual signals and official ingredient metadata.", icon: "bag-outline" },
  progress: { title: "Progress dashboard", subtitle: "Demo trends and reflections, not clinical measurements.", icon: "trending-up-outline" },
  history: { title: "Snapshot history", subtitle: "Saved normalised summaries—never original selfie previews.", icon: "time-outline" },
  "style-match": { title: "Skin × Style", subtitle: "Use colour direction as inspiration, with your taste in charge.", icon: "shirt-outline" },
  palette: { title: "Colour direction", subtitle: "Palette ideas that connect visual guidance to actual ClosetAI looks.", icon: "color-palette-outline" },
  "outfit-plan": { title: "Outfit plan", subtitle: "Carry optional palette direction into your ClosetAI outfit journey.", icon: "sparkles-outline" },
  goals: { title: "Care goals", subtitle: "Choose the local focus areas that matter most to you right now.", icon: "flag-outline" },
  "check-in": { title: "Weekly check-in", subtitle: "A private local reflection about how your routine feels.", icon: "heart-outline" },
  notifications: { title: "Care reminders", subtitle: "Control the local reminder preference for your care plan.", icon: "notifications-outline" },
  settings: { title: "Skin Care settings", subtitle: "Review your local choices, privacy links, and module preferences.", icon: "settings-outline" },
  privacy: { title: "Privacy and consent", subtitle: "Understand what each Skin Care choice means before you continue.", icon: "shield-checkmark-outline" },
};

function Header({ meta }: { meta: (typeof PAGE_META)[string] }) {
  const { colors } = useTheme();
  return <View style={styles.header}><Pressable onPress={() => router.back()} hitSlop={10} accessibilityRole="button" accessibilityLabel="Go back"><Ionicons name="chevron-back" size={25} color={colors.text} /></Pressable><View style={styles.headerText}><Text style={[styles.eyebrow, { color: colors.tint }]}>CLOSET A.I. · SKIN CARE</Text><Text style={[styles.headerTitle, { color: colors.text }]}>{meta.title}</Text></View><Ionicons name={meta.icon} size={21} color={colors.tint} /></View>;
}

export function SkinJourneyPage({ segments }: { segments: string[] }) {
  const { colors } = useTheme();
  const { wardrobeItems, generateOutfits } = useApp();
  const { completedSteps, savedProductIds, selectedGoals, toggleGoal, toggleRoutineStep, toggleSavedProduct, remindersEnabled, setRemindersEnabled, checkInNote, setCheckIn } = useSkinCare();
  const { result: inMemoryScanResult, savedResults, clearSavedHistory } = useSelfieScan();
  const latestScanResult = inMemoryScanResult || savedResults[0] || null;
  const historyCards = buildSkinHistoryCards(savedResults, savedSnapshots);
  const [isBuildingLook, setIsBuildingLook] = React.useState(false);
  const [styleBuildError, setStyleBuildError] = React.useState<string | null>(null);
  const [productRoutineFilter, setProductRoutineFilter] = React.useState<RecommendedProductsRoutineFilter>("All");
  const [styleOccasion, setStyleOccasion] = React.useState("Everyday");
  const isMountedRef = React.useRef(true);
  const buildLookInFlightRef = React.useRef(false);
  const key = segments[0] ?? "results";
  const id = segments[1];
  const meta = PAGE_META[key] ?? PAGE_META.results;
  const fallbackMetric = getMetric(id);
  const liveMetric = latestScanResult?.source === "youcam" ? latestScanResult.metrics.find((item) => item.key === id || (id === "pores" && item.key === "pores") || (id === "texture" && item.key === "texture")) : undefined;
  const metric = liveMetric ? { label: liveMetric.label, detail: liveMetric.description || "This is a visual signal from your saved snapshot, not a diagnosis.", action: "Use gentle, consistent care and adjust slowly.", score: liveMetric.score } : fallbackMetric;
  const product = getProduct(id);
  const show = (content: React.ReactNode) => <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>{content}</View>;
  const requestClearSavedHistory = () => Alert.alert("Clear saved Skin Care history?", "This removes normalized summaries from this device and clears the local metric trend database. Original selfies, raw provider output, and remote provider data are not stored here and are not affected.", [
    { text: "Cancel", style: "cancel" },
    { text: "Clear saved history", style: "destructive", onPress: () => { void clearSavedHistory().catch(() => Alert.alert("History was not cleared", "We could not clear every local history store. Please try again.")); } },
  ]);

  React.useEffect(() => () => {
    isMountedRef.current = false;
  }, []);

  let body: React.ReactNode;
  if (key === "concerns" || key === "concern") {
    const liveConcerns = latestScanResult?.source === "youcam" ? latestScanResult.metrics.filter((item) => item.available) : null;
    body = <>{key === "concern" ? show(<><Text style={[styles.cardTitle, { color: colors.text }]}>{metric.label}{liveMetric ? ` · ${liveMetric.score}` : ""}</Text><Text style={[styles.cardText, { color: colors.textSecondary }]}>{metric.detail}</Text><Text style={[styles.actionText, { color: colors.tint }]}>{metric.action}</Text><Text style={[styles.cardText, { color: colors.textSecondary }]}>{liveMetric ? "Live snapshot signal. General guidance only, not a diagnosis." : "Demo guidance only. Complete a live scan to replace this preview."}</Text></>) : <>{latestScanResult ? <SkinIntelligenceDashboard current={latestScanResult} history={savedResults} colors={colors} /> : null}{(liveConcerns || skinMetrics).map((item: any) => <Pressable key={item.id || item.key} onPress={() => router.push(`/skin/concern/${item.id || item.key}`)}>{show(<><Text style={[styles.cardTitle, { color: colors.text }]}>{item.label} · {item.score}</Text><Text style={[styles.cardText, { color: colors.textSecondary }]}>{item.detail || item.description || "Visual guidance from your saved snapshot."}</Text>{(item.id || item.key) === "pores" || (item.id || item.key) === "texture" || (item.id || item.key) === "radiance" ? <Text style={[styles.actionText, { color: colors.tint }]}>{liveConcerns ? "Live scan insight" : "Demo preview"}</Text> : null}</>)}</Pressable>)}</>}</>;
  }
  else if (key === "results") body = latestScanResult ? <SkinIntelligenceDashboard current={latestScanResult} history={savedResults} colors={colors} /> : show(<><Text style={[styles.cardTitle, { color: colors.text }]}>Skin Metrics dashboard</Text><Text style={[styles.cardText, { color: colors.textSecondary }]}>Complete a demo scan or optional live scan to see normalized visual metrics, priorities, and future snapshot trends. Raw provider output is never displayed.</Text><Pressable onPress={() => router.push("/skin/selfie-scan")} style={[styles.button, { backgroundColor: colors.text }]}><Text style={[styles.buttonText, { color: colors.background }]}>Start optional selfie flow</Text></Pressable></>);
  else if (key === "routine") {
    const routinePlan = buildPersonalizedRoutine({
      source: latestScanResult?.source === "youcam" ? "youcam" : latestScanResult?.source === "demo" ? "demo" : "none",
      metrics: latestScanResult?.metrics ?? [],
      selectedGoals,
    });
    const totalSteps = routinePlan.morning.length + routinePlan.evening.length;
    const completedToday = countRoutineCompletions(routinePlan, completedSteps);
    body = <>
      {show(<><View style={styles.row}><Ionicons name={routinePlan.source === "youcam" ? "sparkles-outline" : routinePlan.source === "demo" ? "flask-outline" : "leaf-outline"} size={20} color={colors.tint} /><View style={styles.flex}><Text style={[styles.cardTitle, { color: colors.text }]}>{routinePlan.headline}</Text><Text style={[styles.cardText, { color: colors.textSecondary }]}>{routinePlan.sourceLabel}</Text></View></View><Text style={[styles.actionText, { color: colors.tint }]}>Focus: {routinePlan.focusLabels.join(" · ")}</Text><Text style={[styles.cardText, { color: colors.textSecondary }]}>{routinePlan.disclosure}</Text><Pressable onPress={() => router.push("/skin/goals")} style={[styles.outlineButton, { borderColor: colors.border }]} accessibilityRole="button" accessibilityLabel="Adjust local care goals"><Text style={[styles.outlineButtonText, { color: colors.text }]}>Adjust local care goals</Text></Pressable></>)}
      {show(<><View style={styles.row}><Ionicons name={completedToday === totalSteps ? "checkmark-done-circle-outline" : "calendar-outline"} size={20} color={completedToday === totalSteps ? colors.success : colors.tint} /><View style={styles.flex}><Text style={[styles.cardTitle, { color: colors.text }]}>Today’s routine progress</Text><Text style={[styles.cardText, { color: colors.textSecondary }]}>{completedToday} of {totalSteps} routine steps checked today. These are local planning checkmarks, not product-use or outcome confirmation.</Text></View></View></>)}
      {(["AM", "PM"] as const).map((period) => {
        const steps = period === "AM" ? routinePlan.morning : routinePlan.evening;
        return <React.Fragment key={period}>{show(<><Text style={[styles.cardTitle, { color: colors.text }]}>{period === "AM" ? "Morning routine" : "Evening routine"}</Text><Text style={[styles.cardText, { color: colors.textSecondary }]}>{period === "AM" ? "Keep the morning sequence compact and finish with the daily protection step." : "Keep the evening sequence simple and introduce only one optional support step at a time."}</Text>{steps.map((step) => { const done = completedSteps.includes(routineCompletionKey(period, step.id)); const product = step.productId ? getCatalogProduct(step.productId) : undefined; return <View key={step.id} style={styles.routineStep}><Pressable onPress={() => toggleRoutineStep(period, step.id)} style={styles.row} accessibilityRole="checkbox" accessibilityState={{ checked: done }} accessibilityLabel={`Mark ${step.title} ${done ? "incomplete" : "complete"}`}><Ionicons name={done ? "checkmark-circle" : "ellipse-outline"} size={20} color={done ? colors.success : colors.tint} /><View style={styles.flex}><View style={styles.rowTitleLine}><Text style={[styles.rowTitle, { color: colors.text }]}>{step.order}. {step.title}</Text><Text style={[styles.frequencyTag, { color: step.frequency === "daily" ? colors.success : colors.tint }]}>{step.frequency === "daily" ? "DAILY" : "OPTIONAL"}</Text></View><Text style={[styles.rowText, { color: colors.textSecondary }]}>{step.purpose} · {step.guidance}</Text><Text style={[styles.sourceReason, { color: colors.textTertiary }]}>{step.sourceReason}</Text></View></Pressable>{product && <Pressable onPress={() => router.push(`/skin/product/${product.id}`)} style={[styles.productLink, { borderColor: colors.border }]} accessibilityRole="button" accessibilityLabel={`View ${product.name} official catalog details`}><Ionicons name="bag-outline" size={14} color={colors.tint} /><Text style={[styles.productLinkText, { color: colors.textSecondary }]}>{product.brand} · {product.name} · View manufacturer details</Text></Pressable>}</View>; })}</>)}</React.Fragment>;
      })}
    </>;
  }
  else if (key === "products" || key === "product") {
    const productSource = latestScanResult?.source === "youcam" ? "youcam" : latestScanResult?.source === "demo" ? "demo" : "none";
    const recommendedPlan = buildRecommendedProducts({ source: productSource, metrics: latestScanResult?.metrics ?? [], selectedGoals, savedProductIds, routineFilter: productRoutineFilter, limit: 5 });
    const openOfficialListing = (url: string) => Linking.openURL(url).catch(() => Alert.alert("Official listing unavailable", "We could not open the manufacturer product page. Please try again later."));
    body = key === "product"
      ? show(
          <>
            <Text style={[styles.cardTitle, { color: colors.text }]}>{product.name}</Text>
            <Text style={[styles.cardText, { color: colors.textSecondary }]}>{product.brand} · {product.category} · {product.routine}</Text>
            <Text style={[styles.cardText, { color: colors.textSecondary }]}>Manufacturer-highlighted ingredients: {product.primaryIngredients.join(", ")}.</Text>
            <Text style={[styles.cardText, { color: colors.textSecondary }]}>{product.usageNote}</Text>
            <Text style={[styles.cardText, { color: colors.textSecondary }]}>{product.availabilityNotice}</Text>
            <MockCommercePanel productId={product.id} colors={colors} />
            <Pressable onPress={() => toggleSavedProduct(product.id)} style={[styles.button, { backgroundColor: colors.text }]} accessibilityRole="button" accessibilityLabel={savedProductIds.includes(product.id) ? "Remove saved local product reference" : "Save product reference locally"}>
              <Text style={[styles.buttonText, { color: colors.background }]}>{savedProductIds.includes(product.id) ? "Saved locally" : "Save product"}</Text>
            </Pressable>
            <Pressable onPress={() => openOfficialListing(product.officialUrl)} style={[styles.outlineButton, { borderColor: colors.border }]} accessibilityRole="button" accessibilityLabel={`Open official listing for ${product.name}`}>
              <Text style={[styles.outlineButtonText, { color: colors.text }]}>{product.officialCartAvailable ? "Add to Cart on Official Site" : "View Official Listing"}</Text>
            </Pressable>
          </>
        )
      : (
          <>
            <Text style={[styles.cardText, { color: colors.textSecondary }]}>{recommendedPlan.sourceLabel}</Text>
            {show(
              <>
                <Text style={[styles.cardTitle, { color: colors.text }]}>Verified routine references</Text>
                <Text style={[styles.cardText, { color: colors.textSecondary }]}>{recommendedPlan.headline}</Text>
                <Text style={[styles.cardText, { color: colors.textSecondary }]}>{recommendedPlan.disclosure}</Text>
                <View style={styles.filterRow}>
                  {(["All", "AM", "PM"] as RecommendedProductsRoutineFilter[]).map((filter) => (
                    <Pressable key={filter} onPress={() => setProductRoutineFilter(filter)} style={[styles.filterChip, { borderColor: productRoutineFilter === filter ? colors.tint : colors.border, backgroundColor: productRoutineFilter === filter ? `${colors.tint}12` : colors.surface }]} accessibilityRole="radio" accessibilityState={{ checked: productRoutineFilter === filter }} accessibilityLabel={`Show ${filter} routine products`}>
                      <Text style={[styles.filterChipText, { color: productRoutineFilter === filter ? colors.tint : colors.textSecondary }]}>{filter}</Text>
                    </Pressable>
                  ))}
                </View>
                <Pressable onPress={() => router.push("/skin/routine")} style={[styles.outlineButton, { borderColor: colors.border }]} accessibilityRole="button" accessibilityLabel="Open personalized AM PM routine">
                  <Text style={[styles.outlineButtonText, { color: colors.text }]}>Open personalized AM/PM routine</Text>
                </Pressable>
              </>
            )}
            {recommendedPlan.items.map((item) => (
              <Pressable key={item.id} onPress={() => router.push(`/skin/product/${item.id}`)} accessibilityRole="button" accessibilityLabel={`View recommended product ${item.name}`}>
                {show(
                  <>
                    <View style={styles.row}>
                      <Ionicons name={item.savedLocally ? "bookmark" : "bag-outline"} size={20} color={item.savedLocally ? colors.success : colors.tint} />
                      <View style={styles.flex}>
                        <View style={styles.rowTitleLine}>
                          <Text style={[styles.cardTitle, { color: colors.text }]}>{item.name}</Text>
                          <Text style={[styles.frequencyTag, { color: colors.tint }]}>{item.routineContext}</Text>
                        </View>
                        <Text style={[styles.cardText, { color: colors.textSecondary }]}>{item.brand} · {item.category} · Manufacturer product page</Text>
                      </View>
                    </View>
                    <Text style={[styles.actionText, { color: colors.tint }]}>{item.primaryIngredients.join(" · ")}</Text>
                    {item.recommendationReasons.map((reason) => <Text key={reason} style={[styles.reasonText, { color: colors.textSecondary }]}>• {reason}</Text>)}
                    <Text style={[styles.compatibilityText, { color: colors.textTertiary }]}>{item.compatibilityNotes[0]}</Text>
                    <Text style={[styles.productAction, { color: colors.tint }]}>Review manufacturer details</Text>
                  </>
                )}
              </Pressable>
            ))}
            {show(
              <>
                <Text style={[styles.cardTitle, { color: colors.text }]}>Fictional category ideas</Text>
                <Text style={[styles.cardText, { color: colors.textSecondary }]}>These category cards are fictional Demo Mode references only. The newest fictional set is shown for interface exploration. They do not replace the verified catalog, create inventory claims, or trigger checkout.</Text>
                {FICTIONAL_PRODUCT_CATEGORY_CARDS.slice(-10).map((card) => (
                  <View key={card.id} style={[styles.productReference, { borderColor: colors.border, backgroundColor: colors.surfaceSecondary }]} accessibilityRole="text">
                    <View style={styles.row}>
                      <Ionicons name={card.category === "SPF" ? "sunny-outline" : card.category === "Cleanser" ? "water-outline" : card.category === "Serum" ? "beaker-outline" : "leaf-outline"} size={16} color={colors.tint} />
                      <View style={styles.flex}>
                        <Text style={[styles.cardTitle, { color: colors.text }]}>{card.title}</Text>
                        <Text style={[styles.cardText, { color: colors.textSecondary }]}>{card.persona} · {card.category} · {card.routineTime}</Text>
                      </View>
                    </View>
                    <Text style={[styles.cardText, { color: colors.textSecondary }]}>{card.textureCue} · {card.labelPrompt}</Text>
                  </View>
                ))}
                <Text style={[styles.compatibilityText, { color: colors.textTertiary }]}>{FICTIONAL_PRODUCT_CATEGORY_CARDS[0]?.disclosure}</Text>
              </>
            )}
            <UltraLuxurySkinDiscoveryPanel colors={colors} />
          </>
        );
  }
  else if (key === "progress" || key === "history" || key === "snapshot") body = <>{key === "progress" ? <><SkinMetricProgressChart colors={colors} />{show(<><Text style={[styles.cardTitle, { color: colors.text }]}>Demo history preview</Text><Text style={[styles.cardText, { color: colors.textSecondary }]}>The cards below are fictional Demo Mode reference values. They are separate from the local SQLite chart above.</Text></>)}{progressSeries.map((item) => show(<><Text style={[styles.cardTitle, { color: colors.text }]}>{item.label} · {item.value}</Text><Text style={[styles.cardText, { color: colors.textSecondary }]}>Demo trend: +{item.change} from the previous reference.</Text></>))}</> : <>{savedResults.length > 0 && <Pressable onPress={requestClearSavedHistory} style={[styles.outlineButton, { borderColor: colors.border }]} accessibilityRole="button" accessibilityLabel="Clear saved Skin Care history" accessibilityHint="Removes normalized summaries and local metric trends from this device after confirmation"><Text style={[styles.outlineButtonText, { color: colors.text }]}>Clear saved history</Text></Pressable>}{historyCards.map((item) => show(<><View style={styles.row}><View style={styles.flex}><Text style={[styles.cardTitle, { color: colors.text }]}>{item.date} · {item.scoreLabel}</Text><Text style={[styles.cardText, { color: colors.textSecondary }]}>{item.summary}</Text></View><Text style={[styles.frequencyTag, { color: item.sourceLabel === "Live visual analysis" ? colors.success : colors.tint }]}>{item.sourceLabel === "Live visual analysis" ? "LIVE" : "DEMO"}</Text></View><Text style={[styles.compatibilityText, { color: colors.textTertiary }]}>{item.disclosure}</Text></>))}</>}</>;
  else if (key === "goals") body = <>{skinGoals.map((goal) => <Pressable key={goal.id} onPress={() => toggleGoal(goal.id)}>{show(<View style={styles.row}><Ionicons name={selectedGoals.includes(goal.id) ? "checkmark-circle" : goal.icon} size={20} color={selectedGoals.includes(goal.id) ? colors.success : colors.tint} /><View style={styles.flex}><Text style={[styles.rowTitle, { color: colors.text }]}>{goal.title}</Text><Text style={[styles.rowText, { color: colors.textSecondary }]}>{goal.description}</Text></View></View>)}</Pressable>)}</>;
  else if (key === "notifications" || key === "settings" || key === "privacy") body = key === "notifications" ? show(<View style={styles.row}><View style={styles.flex}><Text style={[styles.cardTitle, { color: colors.text }]}>Care reminders</Text><Text style={[styles.cardText, { color: colors.textSecondary }]}>{careReminders.map((item) => item.title).join(" · ")}</Text></View><Switch value={remindersEnabled} onValueChange={setRemindersEnabled} /></View>) : show(<><Text style={[styles.cardTitle, { color: colors.text }]}>{key === "privacy" ? "Your choices stay clear" : "Local Skin Care preferences"}</Text><Text style={[styles.cardText, { color: colors.textSecondary }]}>{key === "privacy" ? "History shows normalised summaries, not original selfies. Live analysis credentials remain server-side. Demo mode does not call an external service." : "Goals, completed routine steps, saved product IDs, reminder preference, and weekly notes are stored as local interface state."}</Text><Pressable onPress={() => router.push("/skin/privacy")} style={[styles.button, { backgroundColor: colors.text }]}><Text style={[styles.buttonText, { color: colors.background }]}>Review privacy choices</Text></Pressable></>);
  else if (key === "check-in") body = show(<><Text style={[styles.cardTitle, { color: colors.text }]}>How did this week feel?</Text><TextInput value={checkInNote} onChangeText={setCheckIn} multiline placeholder="A private local note" placeholderTextColor={colors.textTertiary} style={[styles.input, { color: colors.text, borderColor: colors.border }]} /><Pressable onPress={() => { setCheckIn(checkInNote); Alert.alert("Check-in saved", "Your local reflection was saved."); }} style={[styles.button, { backgroundColor: colors.text }]}><Text style={[styles.buttonText, { color: colors.background }]}>Save check-in</Text></Pressable></>);
  else if (key === "palette" || key === "style-match" || key === "outfit-plan") {
    const styleSource = latestScanResult?.source === "youcam" ? "youcam" : latestScanResult?.source === "demo" ? "demo" : "none";
    const stylePlan = buildSkinStylePlan({ source: styleSource, metrics: latestScanResult?.metrics ?? [], selectedGoals, wardrobe: wardrobeItems, occasion: styleOccasion });
    const buildLook = async () => {
      if (buildLookInFlightRef.current) return;
      if (wardrobeItems.length < 2) {
        Alert.alert("Add wardrobe pieces first", "Add at least two items to ClosetAI, then Skin × Style can build a live look from pieces you own. No stock or fictional outfit is shown.");
        router.push("/(tabs)/wardrobe");
        return;
      }
      buildLookInFlightRef.current = true;
      setStyleBuildError(null);
      setIsBuildingLook(true);
      try {
        await generateOutfits(styleOccasion);
        if (isMountedRef.current) router.push("/(tabs)/outfits");
      } catch (error) {
        if (isMountedRef.current) setStyleBuildError(error instanceof Error ? error.message : "Your wardrobe remains available. Please try again.");
      } finally {
        buildLookInFlightRef.current = false;
        if (isMountedRef.current) setIsBuildingLook(false);
      }
    };
    body = <>{show(<><View style={styles.row}><Ionicons name={stylePlan.source === "youcam" ? "sparkles-outline" : stylePlan.source === "demo" ? "flask-outline" : "shirt-outline"} size={20} color={colors.tint} /><View style={styles.flex}><Text style={[styles.cardTitle, { color: colors.text }]}>{stylePlan.headline}</Text><Text style={[styles.cardText, { color: colors.textSecondary }]}>{stylePlan.sourceLabel}</Text></View></View><Text style={[styles.cardText, { color: colors.textSecondary }]}>{stylePlan.disclosure}</Text><Text style={[styles.sectionLabel, { color: colors.text }]}>Occasion</Text><View style={styles.filterRow}>{["Everyday", "Office", "Weekend", "Dinner", "Active"].map((occasion) => <Pressable key={occasion} disabled={isBuildingLook} onPress={() => { setStyleBuildError(null); setStyleOccasion(occasion); }} style={[styles.filterChip, { borderColor: styleOccasion === occasion ? colors.tint : colors.border, backgroundColor: styleOccasion === occasion ? `${colors.tint}12` : colors.surface, opacity: isBuildingLook ? 0.55 : 1 }]} accessibilityRole="radio" accessibilityState={{ checked: styleOccasion === occasion, disabled: isBuildingLook }} accessibilityLabel={`Select ${occasion} occasion`} accessibilityHint={isBuildingLook ? "Occasion choices are unavailable while ClosetAI builds from your wardrobe." : "Sets the occasion used for a wardrobe-only outfit request."}><Text style={[styles.filterChipText, { color: styleOccasion === occasion ? colors.tint : colors.textSecondary }]}>{occasion}</Text></Pressable>)}</View><Text style={[styles.sectionLabel, { color: colors.text }]}>Optional palette direction</Text><View style={styles.paletteRow}>{stylePlan.palette.map((color) => <View key={color} style={[styles.paletteChip, { backgroundColor: `${colors.tint}12`, borderColor: colors.border }]}><Text style={[styles.filterChipText, { color: colors.textSecondary }]}>{color}</Text></View>)}</View>{stylePlan.reasons.map((reason) => <Text key={reason} style={[styles.reasonText, { color: colors.textSecondary }]}>• {reason}</Text>)}<Text style={[styles.compatibilityText, { color: colors.textTertiary }]}>{stylePlan.weatherNote}</Text></>)}{styleBuildError && <View style={[styles.errorNotice, { borderColor: "#D94C4C40", backgroundColor: "#D94C4C12" }]} accessibilityRole="alert" accessibilityLiveRegion="assertive"><Ionicons name="alert-circle-outline" size={17} color="#D94C4C" /><Text style={[styles.errorNoticeText, { color: colors.textSecondary }]}>{styleBuildError}</Text></View>}{stylePlan.emptyMessage ? show(<><Text style={[styles.cardTitle, { color: colors.text }]}>Build from your own wardrobe</Text><Text style={[styles.cardText, { color: colors.textSecondary }]}>{stylePlan.emptyMessage}</Text><Pressable onPress={() => router.push("/(tabs)/wardrobe")} style={[styles.button, { backgroundColor: colors.text }]} accessibilityRole="button" accessibilityLabel="Open my wardrobe"><Text style={[styles.buttonText, { color: colors.background }]}>Open my wardrobe</Text></Pressable></>) : <>{stylePlan.looks.map((look) => { const lookItems = resolveSkinStyleLookItems(look, wardrobeItems); return show(<View key={look.itemIds.join("|")}><Text style={[styles.cardTitle, { color: colors.text }]}>{look.name}</Text><Text style={[styles.cardText, { color: colors.textSecondary }]}>{look.reason}</Text><Text style={[styles.actionText, { color: colors.tint }]}>Your items: {lookItems.map((item) => item.name).join(" · ")}</Text><Text style={[styles.compatibilityText, { color: colors.textTertiary }]}>Occasion: {look.occasion} · {look.tags.join(" · ")}</Text></View>); })}<Pressable onPress={buildLook} disabled={isBuildingLook} style={[styles.button, { backgroundColor: colors.text, opacity: isBuildingLook ? 0.6 : 1 }]} accessibilityRole="button" accessibilityState={{ disabled: isBuildingLook, busy: isBuildingLook }} accessibilityLabel={isBuildingLook ? "Building live outfits from your wardrobe" : "Generate live outfits from my wardrobe"} accessibilityHint={isBuildingLook ? "Wait while ClosetAI builds from the pieces you own." : "Builds outfits from your own wardrobe. No stock or fictional outfit is shown."}><Text style={[styles.buttonText, { color: colors.background }]}>{isBuildingLook ? "Building from your wardrobe…" : "Generate from my wardrobe"}</Text></Pressable><Pressable onPress={() => router.push("/(tabs)/wardrobe")} disabled={isBuildingLook} style={[styles.outlineButton, { borderColor: colors.border, opacity: isBuildingLook ? 0.55 : 1 }]} accessibilityRole="button" accessibilityState={{ disabled: isBuildingLook }} accessibilityLabel="Explore my wardrobe"><Text style={[styles.outlineButtonText, { color: colors.text }]}>Explore my wardrobe</Text></Pressable></>}</>;
  }
  else body = show(<><Text style={[styles.cardTitle, { color: colors.text }]}>Demo scan workspace</Text><Text style={[styles.cardText, { color: colors.textSecondary }]}>The demo snapshot remains available even without a photo, permission, network, or API.</Text><Pressable onPress={() => router.push("/skin")} style={[styles.button, { backgroundColor: colors.text }]}><Text style={[styles.buttonText, { color: colors.background }]}>Return to Skin Care hub</Text></Pressable></>);

  return <View style={[styles.page, { backgroundColor: colors.background }]}><ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}><Header meta={meta} /><Text style={[styles.subtitle, { color: colors.textSecondary }]}>{meta.subtitle}</Text>{body}</ScrollView></View>;
}

const styles = StyleSheet.create({ page: { flex: 1 }, content: { padding: 20, paddingBottom: 50 }, header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }, headerText: { alignItems: "center" }, eyebrow: { fontFamily: "Outfit_700Bold", fontSize: 8, letterSpacing: 1 }, headerTitle: { fontFamily: "Outfit_700Bold", fontSize: 19 }, subtitle: { fontFamily: "Outfit_400Regular", fontSize: 12, lineHeight: 18, marginBottom: 16 }, card: { borderRadius: 17, borderWidth: 1, padding: 14, marginBottom: 10 }, cardTitle: { fontFamily: "Outfit_600SemiBold", fontSize: 14 }, cardText: { fontFamily: "Outfit_400Regular", fontSize: 11, lineHeight: 16, marginTop: 4 }, actionText: { fontFamily: "Outfit_600SemiBold", fontSize: 11, lineHeight: 16, marginTop: 8 }, row: { flexDirection: "row", alignItems: "center", gap: 10, paddingVertical: 5 }, flex: { flex: 1 }, rowTitleLine: { flexDirection: "row", alignItems: "center", flexWrap: "wrap", gap: 6 }, rowTitle: { fontFamily: "Outfit_600SemiBold", fontSize: 12 }, rowText: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 14, marginTop: 2 }, sourceReason: { fontFamily: "Outfit_400Regular", fontSize: 9, lineHeight: 13, marginTop: 4 }, frequencyTag: { fontFamily: "Outfit_700Bold", fontSize: 8, letterSpacing: 0.5 }, routineStep: { marginTop: 10 }, productLink: { marginLeft: 30, marginTop: 4, borderWidth: 1, borderRadius: 10, paddingVertical: 7, paddingHorizontal: 9, flexDirection: "row", alignItems: "center", gap: 6 }, productLinkText: { flex: 1, fontFamily: "Outfit_500Medium", fontSize: 9, lineHeight: 13 }, productReference: { borderWidth: 1, borderRadius: 13, padding: 10, marginTop: 8 }, filterRow: { flexDirection: "row", flexWrap: "wrap", gap: 7, marginTop: 12 }, filterChip: { borderWidth: 1, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 7 }, filterChipText: { fontFamily: "Outfit_700Bold", fontSize: 10 }, paletteRow: { flexDirection: "row", flexWrap: "wrap", gap: 7, marginTop: 8 }, paletteChip: { borderWidth: 1, borderRadius: 12, paddingHorizontal: 10, paddingVertical: 7 }, sectionLabel: { fontFamily: "Outfit_600SemiBold", fontSize: 11, marginTop: 13 }, reasonText: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 15, marginTop: 5 }, compatibilityText: { fontFamily: "Outfit_400Regular", fontSize: 9, lineHeight: 13, marginTop: 8 }, productAction: { fontFamily: "Outfit_700Bold", fontSize: 10, marginTop: 10 }, button: { alignSelf: "flex-start", borderRadius: 12, paddingHorizontal: 12, paddingVertical: 9, marginTop: 12 }, buttonText: { fontFamily: "Outfit_700Bold", fontSize: 11 }, outlineButton: { alignSelf: "flex-start", borderRadius: 12, borderWidth: 1, paddingHorizontal: 12, paddingVertical: 9, marginTop: 8 }, outlineButtonText: { fontFamily: "Outfit_700Bold", fontSize: 11 }, errorNotice: { flexDirection: "row", alignItems: "flex-start", gap: 9, borderWidth: 1, borderRadius: 14, padding: 12, marginBottom: 10 }, errorNoticeText: { flex: 1, fontFamily: "Outfit_400Regular", fontSize: 11, lineHeight: 16 }, input: { minHeight: 96, borderWidth: 1, borderRadius: 12, padding: 10, fontFamily: "Outfit_400Regular", fontSize: 12, textAlignVertical: "top", marginTop: 10 } });
