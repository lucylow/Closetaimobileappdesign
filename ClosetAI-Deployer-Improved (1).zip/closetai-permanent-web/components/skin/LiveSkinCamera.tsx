import React from "react";
import { ActivityIndicator, Alert, Linking, Platform, Pressable, StyleSheet, Switch, Text, View } from "react-native";
import { Camera, CameraType, CameraView, useCameraPermissions } from "expo-camera";
let FaceDetector: any = null;
try {
  FaceDetector = require("expo-face-detector");
} catch {
  FaceDetector = null;
}
import { Ionicons } from "@expo/vector-icons";
import { router, useFocusEffect } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";

import { useSelfieScan } from "@/contexts/SelfieScanContext";
import { useTheme } from "@/lib/useTheme";
import { interaction } from "@/constants/colors";
import { AR_OVERLAY_INTENSITIES, AR_VISUAL_MODES, AR_VISUAL_PREVIEW_DISCLOSURE, type ArOverlayIntensity, type ArVisualMode } from "@/lib/ar-skin-preview";

export function LiveSkinCamera() {
  const { colors } = useTheme();
  const { choose, setStage } = useSelfieScan();
  const cameraRef = React.useRef<CameraView>(null);
  const [permission, requestPermission] = useCameraPermissions();
  const [focusPermissionGranted, setFocusPermissionGranted] = React.useState<boolean | null>(null);
  const [ready, setReady] = React.useState(false);
  const [capturing, setCapturing] = React.useState(false);
  const [facing, setFacing] = React.useState<CameraType>("front");
  const [detectorNotice, setDetectorNotice] = React.useState("Face guidance will verify the captured frame before review.");
  const [visualPreviewConsent, setVisualPreviewConsent] = React.useState(false);
  const [visualMode, setVisualMode] = React.useState<ArVisualMode>(AR_VISUAL_MODES[0]);
  const [overlayIntensity, setOverlayIntensity] = React.useState<ArOverlayIntensity>(AR_OVERLAY_INTENSITIES[1]);
  const captureRunRef = React.useRef(0);

  useFocusEffect(React.useCallback(() => {
    let active = true;
    void Camera.getCameraPermissionsAsync().then((nextPermission) => {
      if (active) setFocusPermissionGranted(nextPermission.granted);
    }).catch(() => {
      if (active) setFocusPermissionGranted(null);
    });
    return () => { active = false; };
  }, []));

  React.useEffect(() => () => {
    captureRunRef.current += 1;
  }, []);

  const openCameraSettings = async () => {
    try {
      await Linking.openSettings();
    } catch {
      Alert.alert("Open settings manually", "Camera access can be changed in your device settings. You can use a selected photo instead.");
    }
  };

  const requestCamera = async () => {
    const nextPermission = await requestPermission();
    setFocusPermissionGranted(nextPermission.granted);
  };

  const capture = async () => {
    if (!cameraRef.current || !ready || capturing || !(permission?.granted || focusPermissionGranted === true)) return;
    const runId = ++captureRunRef.current;
    const isCurrentCapture = () => captureRunRef.current === runId;
    setCapturing(true);
    try {
      const photo = await cameraRef.current.takePictureAsync({ quality: 0.72, exif: false, base64: false });
      if (!isCurrentCapture()) return;
      if (!photo?.uri) throw new Error("The camera did not return a photo. Please try again.");
      let faceValidated = false;
      if (Platform.OS !== "web" && FaceDetector?.detectFacesAsync) {
        try {
          const detection = await FaceDetector.detectFacesAsync(photo.uri, {
            mode: FaceDetector.FaceDetectorMode?.fast ?? 1,
            detectLandmarks: FaceDetector.FaceDetectorLandmarks?.none ?? 0,
            runClassifications: FaceDetector.FaceDetectorClassifications?.none ?? 0,
          });
          if (!isCurrentCapture()) return;
          if (detection?.faces && detection.faces.length === 0) {
            setDetectorNotice("No face was detected in that frame. Center your face in the guide and try again.");
            return;
          }
          if (detection?.faces && detection.faces.length > 1) {
            setDetectorNotice("More than one face was detected. Capture a single, front-facing face for this optional scan.");
            return;
          }
          faceValidated = true;
          setDetectorNotice("One face detected. Your captured frame is ready for review.");
        } catch {
          setDetectorNotice("Face detection is unavailable in this runtime. Review the frame manually before continuing.");
        }
      } else {
        setDetectorNotice("Camera capture is active. Review the frame manually before continuing.");
      }
      if (!isCurrentCapture()) return;
      choose({ uri: photo.uri, source: "camera", width: photo.width, height: photo.height });
      setStage("review");
      router.replace("/skin/selfie-review");
      if (!faceValidated && Platform.OS !== "web") {
        // No blocking behavior: user can review the photo if this optional device feature is unavailable.
      }
    } catch (error) {
      const message = error instanceof Error ? error.message : "We could not capture that frame. Please try again.";
      Alert.alert("Camera capture unavailable", message);
    } finally {
      if (isCurrentCapture()) setCapturing(false);
    }
  };

  const cancelCapture = () => {
    if (!capturing) return;
    captureRunRef.current += 1;
    setCapturing(false);
    setDetectorNotice("Capture cancelled. The camera stream remains local and no frame was sent for review.");
  };

  const cameraPermissionGranted = permission?.granted || focusPermissionGranted === true;

  if (!permission) return <View style={[styles.center, { backgroundColor: colors.background }]}><ActivityIndicator color={colors.tint} /></View>;
  if (!cameraPermissionGranted) return <View style={[styles.center, { backgroundColor: colors.background }]}><Ionicons name="camera-outline" size={36} color={colors.tint} /><Text style={[styles.permissionTitle, { color: colors.text }]}>Camera access is optional</Text><Text style={[styles.permissionText, { color: colors.textSecondary }]}>Enable the front camera to capture a live skin-scan frame. You can still choose a photo instead.</Text><Pressable onPress={() => { void requestCamera(); }} accessibilityRole="button" accessibilityLabel="Enable optional live camera" accessibilityHint="Requests camera permission. You can use photo selection instead." style={({ pressed }) => [styles.permissionButton, { backgroundColor: colors.text, opacity: pressed ? 0.82 : 1, transform: [{ scale: pressed ? interaction.primaryPressScale : 1 }] }]}><Text style={[styles.permissionButtonText, { color: colors.background }]}>Enable camera</Text></Pressable><Pressable onPress={() => { void openCameraSettings(); }} accessibilityRole="button" accessibilityLabel="Open camera settings" accessibilityHint="Opens device settings so you can recover camera access after denying it." style={({ pressed }) => [styles.settingsButton, { borderColor: colors.border, opacity: pressed ? 0.7 : 1 }]}><Text style={[styles.settingsText, { color: colors.tint }]}>Open Settings</Text></Pressable><Pressable onPress={() => router.back()} accessibilityRole="button" accessibilityLabel="Use another photo option" style={({ pressed }) => [styles.cancelButton, { opacity: pressed ? 0.7 : 1 }]}><Text style={[styles.cancelText, { color: colors.tint }]}>Use another option</Text></Pressable></View>;

  return <View style={[styles.container, { backgroundColor: "#000" }]}>
    <CameraView ref={cameraRef} style={StyleSheet.absoluteFillObject} facing={facing} mirror={facing === "front"} onCameraReady={() => setReady(true)} onMountError={(event) => setDetectorNotice(`Camera preview unavailable: ${event.message}`)} />
    <View style={styles.topBar}><Pressable onPress={() => router.back()} style={({ pressed }) => [styles.iconButton, { opacity: pressed ? 0.7 : 1 }]} accessibilityRole="button" accessibilityLabel="Close live camera"><Ionicons name="close" size={23} color="#FFF" /></Pressable><View style={styles.statusPill} accessible accessibilityLabel="Live camera guidance. The camera stream is not stored."><Ionicons name="scan-outline" size={15} color="#FFF" accessibilityElementsHidden /><Text style={styles.statusText}>Live camera guidance</Text></View><Pressable onPress={() => setFacing((value) => value === "front" ? "back" : "front")} style={({ pressed }) => [styles.iconButton, { opacity: pressed ? 0.7 : 1 }]} accessibilityRole="button" accessibilityLabel="Switch camera direction"><Ionicons name="camera-reverse-outline" size={22} color="#FFF" /></Pressable></View>
    <View style={styles.pipelineCard} accessible accessibilityRole="summary" accessibilityLabel="Live Skin camera pipeline. Camera stream stays local. Only the frame you approve continues to review and an optional YouCam request after consent. Face presence guidance is not identity classification.">
      <Text style={styles.pipelineEyebrow}>CAPTURE BOUNDARY</Text>
      <Text style={styles.pipelineTitle}>Camera → Review → Optional YouCam</Text>
      <View style={styles.pipelineSteps}>
        <View style={styles.pipelineStep}><Text style={styles.pipelineStepNumber}>1</Text><Text style={styles.pipelineStepText}>Local stream</Text></View>
        <Ionicons name="arrow-forward" size={12} color="rgba(255,255,255,0.58)" accessibilityElementsHidden />
        <View style={styles.pipelineStep}><Text style={styles.pipelineStepNumber}>2</Text><Text style={styles.pipelineStepText}>You approve</Text></View>
        <Ionicons name="arrow-forward" size={12} color="rgba(255,255,255,0.58)" accessibilityElementsHidden />
        <View style={styles.pipelineStep}><Text style={styles.pipelineStepNumber}>3</Text><Text style={styles.pipelineStepText}>Consent + request</Text></View>
      </View>
      <Text style={styles.pipelineDetail}>Face presence helps framing only. No identity classification, hidden upload, or diagnosis is performed in the camera view.</Text>
    </View>
    {visualPreviewConsent && visualMode.id !== "guide" && <><LinearGradient colors={visualMode.overlay} locations={[0, 0.55, 1]} style={[StyleSheet.absoluteFillObject, { opacity: overlayIntensity.opacity }]} pointerEvents="none" /><View style={[styles.visualHighlight, { opacity: overlayIntensity.opacity }]} pointerEvents="none" /></>}
    <View style={styles.guideWrap}><View style={styles.faceOval} /><Text style={styles.guideTitle}>Center one face in the guide</Text><Text style={styles.guideText}>Keep a neutral expression and use even lighting. Face presence is checked after capture when supported.</Text>{visualPreviewConsent && <Text style={styles.visualLabel}>{visualMode.title} · {overlayIntensity.title.toLowerCase()} visual overlay only</Text>}</View>
    <View style={styles.bottomPanel}><Text style={styles.detectorNotice} accessibilityLiveRegion="polite">{detectorNotice}</Text><View style={styles.visualConsentRow}><View style={styles.visualConsentCopy}><Text style={styles.visualConsentTitle}>Camera visual overlay</Text><Text style={styles.visualConsentText}>{AR_VISUAL_PREVIEW_DISCLOSURE}</Text></View><Switch value={visualPreviewConsent} onValueChange={setVisualPreviewConsent} accessibilityRole="switch" accessibilityLabel="Enable local camera visual overlay" accessibilityHint="Shows a cosmetic-style screen overlay only. It does not analyse your skin or change the captured photo." /></View>{visualPreviewConsent && <><View style={styles.modeRow} accessibilityRole="radiogroup" accessibilityLabel="Camera visual overlay modes">{AR_VISUAL_MODES.map((mode) => { const selected = mode.id === visualMode.id; return <Pressable key={mode.id} onPress={() => setVisualMode(mode)} accessibilityRole="radio" accessibilityState={{ selected }} accessibilityLabel={`${mode.title}: ${mode.description}${selected ? ", selected" : ""}`} style={[styles.modeChip, { borderColor: selected ? "#FFF" : "rgba(255,255,255,0.34)", backgroundColor: selected ? "rgba(255,255,255,0.2)" : "rgba(0,0,0,0.25)" }]}><Text style={styles.modeText}>{mode.title}</Text></Pressable>; })}</View><View style={styles.modeRow} accessibilityRole="radiogroup" accessibilityLabel="Camera visual overlay intensity">{AR_OVERLAY_INTENSITIES.map((intensity) => { const selected = intensity.id === overlayIntensity.id; return <Pressable key={intensity.id} onPress={() => setOverlayIntensity(intensity)} accessibilityRole="radio" accessibilityState={{ selected }} accessibilityLabel={`${intensity.title}: ${intensity.description}${selected ? ", selected" : ""}`} style={[styles.modeChip, { borderColor: selected ? "#FFF" : "rgba(255,255,255,0.34)", backgroundColor: selected ? "rgba(255,255,255,0.2)" : "rgba(0,0,0,0.25)" }]}><Text style={styles.modeText}>{intensity.title}</Text></Pressable>; })}</View></>}<Pressable onPress={capture} disabled={!ready || capturing} accessibilityRole="button" accessibilityState={{ disabled: !ready || capturing, busy: capturing }} accessibilityLabel={capturing ? "Checking captured camera frame" : "Capture camera frame for review"} accessibilityHint="The live camera stream is not stored. You review the captured photo before it can continue." style={({ pressed }) => [styles.captureButton, { opacity: ready && !capturing ? (pressed ? 0.82 : 1) : interaction.disabledOpacity, transform: [{ scale: pressed && ready && !capturing ? interaction.primaryPressScale : 1 }] }]}>{capturing ? <ActivityIndicator color="#171717" /> : <View style={styles.captureInner} />}</Pressable><Text style={styles.captureLabel}>{capturing ? "Checking frame…" : "Capture and review"}</Text>{capturing && <Pressable onPress={cancelCapture} accessibilityRole="button" accessibilityLabel="Cancel live AR capture" accessibilityHint="Stops capture and keeps the camera stream local without sending a frame for review." style={({ pressed }) => [styles.captureCancel, { opacity: pressed ? 0.7 : 1 }]}><Text style={styles.captureCancelText}>Cancel capture</Text></Pressable>}<Text style={styles.privacyText}>The camera view is not stored. Only the photo you approve continues to the optional scan flow.</Text></View>
  </View>;
}

const styles = StyleSheet.create({
  container: { flex: 1 }, center: { flex: 1, alignItems: "center", justifyContent: "center", padding: 28 },
  permissionTitle: { fontFamily: "Outfit_700Bold", fontSize: 20, marginTop: 12 }, permissionText: { fontFamily: "Outfit_400Regular", fontSize: 13, lineHeight: 19, textAlign: "center", marginTop: 7, maxWidth: 300 }, permissionButton: { marginTop: 20, borderRadius: 15, paddingHorizontal: 18, paddingVertical: 13 }, permissionButtonText: { fontFamily: "Outfit_700Bold", fontSize: 13 }, settingsButton: { marginTop: 12, borderWidth: 1, borderRadius: 15, paddingHorizontal: 18, paddingVertical: 12 }, settingsText: { fontFamily: "Outfit_600SemiBold", fontSize: 12 }, cancelButton: { marginTop: 16, padding: 8 }, cancelText: { fontFamily: "Outfit_600SemiBold", fontSize: 12 },
  topBar: { position: "absolute", top: 58, left: 20, right: 20, flexDirection: "row", justifyContent: "space-between", alignItems: "center" }, iconButton: { width: 42, height: 42, alignItems: "center", justifyContent: "center", borderRadius: 21, backgroundColor: "rgba(0,0,0,0.46)" }, statusPill: { flexDirection: "row", gap: 6, alignItems: "center", backgroundColor: "rgba(0,0,0,0.46)", borderRadius: 16, paddingHorizontal: 10, paddingVertical: 8 }, statusText: { color: "#FFF", fontFamily: "Outfit_600SemiBold", fontSize: 11 },
  pipelineCard: { position: "absolute", top: 112, left: 20, right: 20, borderRadius: 16, paddingHorizontal: 12, paddingVertical: 10, backgroundColor: "rgba(0,0,0,0.52)" }, pipelineEyebrow: { color: "rgba(255,255,255,0.7)", fontFamily: "Outfit_700Bold", fontSize: 8, letterSpacing: 1.05 }, pipelineTitle: { color: "#FFF", fontFamily: "Outfit_700Bold", fontSize: 12, marginTop: 3 }, pipelineSteps: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 4, marginTop: 8 }, pipelineStep: { flexDirection: "row", alignItems: "center", gap: 4 }, pipelineStepNumber: { width: 16, height: 16, borderRadius: 8, textAlign: "center", lineHeight: 16, color: "#111", backgroundColor: "#FFF", fontFamily: "Outfit_700Bold", fontSize: 9 }, pipelineStepText: { color: "rgba(255,255,255,0.84)", fontFamily: "Outfit_600SemiBold", fontSize: 8 }, pipelineDetail: { color: "rgba(255,255,255,0.68)", fontFamily: "Outfit_400Regular", fontSize: 8, lineHeight: 11, marginTop: 8 },
  guideWrap: { position: "absolute", top: "18%", left: 30, right: 30, alignItems: "center" }, faceOval: { width: 230, height: 300, borderRadius: 150, borderWidth: 2, borderColor: "rgba(255,255,255,0.92)" }, guideTitle: { color: "#FFF", fontFamily: "Outfit_700Bold", fontSize: 16, marginTop: 17 }, guideText: { color: "rgba(255,255,255,0.88)", fontFamily: "Outfit_400Regular", fontSize: 11, textAlign: "center", lineHeight: 16, marginTop: 5, maxWidth: 290 }, visualLabel: { color: "#FFF", backgroundColor: "rgba(0,0,0,0.5)", fontFamily: "Outfit_700Bold", fontSize: 9, borderRadius: 10, overflow: "hidden", paddingHorizontal: 8, paddingVertical: 5, marginTop: 9 }, visualHighlight: { position: "absolute", top: "19%", left: "-14%", width: "128%", height: "22%", borderRadius: 999, backgroundColor: "rgba(255,255,255,0.12)", transform: [{ rotate: "-16deg" }] },
  bottomPanel: { position: "absolute", bottom: 0, left: 0, right: 0, alignItems: "center", paddingHorizontal: 20, paddingTop: 14, paddingBottom: 27, backgroundColor: "rgba(0,0,0,0.58)" }, detectorNotice: { color: "rgba(255,255,255,0.88)", textAlign: "center", fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 14, maxWidth: 320 }, visualConsentRow: { width: "100%", flexDirection: "row", gap: 8, alignItems: "center", marginTop: 9 }, visualConsentCopy: { flex: 1 }, visualConsentTitle: { color: "#FFF", fontFamily: "Outfit_700Bold", fontSize: 10 }, visualConsentText: { color: "rgba(255,255,255,0.74)", fontFamily: "Outfit_400Regular", fontSize: 8, lineHeight: 11, marginTop: 2 }, modeRow: { width: "100%", flexDirection: "row", flexWrap: "wrap", gap: 6, marginTop: 8 }, modeChip: { borderWidth: 1, borderRadius: 10, paddingHorizontal: 8, paddingVertical: 5 }, modeText: { color: "#FFF", fontFamily: "Outfit_600SemiBold", fontSize: 9 }, captureButton: { width: 60, height: 60, borderRadius: 30, marginTop: 12, backgroundColor: "#FFF", alignItems: "center", justifyContent: "center" }, captureInner: { width: 48, height: 48, borderRadius: 24, borderWidth: 2, borderColor: "#171717" }, captureLabel: { color: "#FFF", fontFamily: "Outfit_600SemiBold", fontSize: 11, marginTop: 7 }, captureCancel: { paddingHorizontal: 10, paddingVertical: 6, marginTop: 2 }, captureCancelText: { color: "rgba(255,255,255,0.9)", fontFamily: "Outfit_600SemiBold", fontSize: 10 }, privacyText: { color: "rgba(255,255,255,0.68)", fontFamily: "Outfit_400Regular", fontSize: 8, textAlign: "center", lineHeight: 12, marginTop: 7, maxWidth: 310 },
});
