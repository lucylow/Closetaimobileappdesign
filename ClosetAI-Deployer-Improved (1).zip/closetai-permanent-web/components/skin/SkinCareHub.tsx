import React from "react";
import { ActivityIndicator, Alert, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";

import { useSelfieScan } from "@/contexts/SelfieScanContext";
import { useTheme } from "@/lib/useTheme";
import { SkinIntelligenceDashboard } from "@/components/skin/SkinIntelligenceDashboard";
import { interaction } from "@/constants/colors";

const SOURCE_COPY = {
  youcam: { badge: "YOUCAM", detail: "Live visual analysis from your saved scan. General guidance only, not a diagnosis." },
  cached: { badge: "SAVED", detail: "Saved normalized visual summary. Your original selfie is not kept in dashboard history." },
  demo: { badge: "DEMO", detail: "Fictional preview data for exploring the Skin Care experience. It is not live analysis." },
} as const;

const EXPLORE_TOOLS = [
  { label: "Cosmetic preview", detail: "Optional creative visualization", icon: "sparkles-outline", route: "/skin/simulation", accent: "#A85F48", accessibilityLabel: "Open optional cosmetic visualization preview", adultOnly: false },
  { label: "Color tones", detail: "Optional palette direction", icon: "color-wand-outline", route: "/skin/color-tones", accent: "#7155C7", accessibilityLabel: "Analyze optional facial color tones", adultOnly: false },
  { label: "Face styling", detail: "Optional visual geometry", icon: "scan-outline", route: "/skin/face-attributes", accent: "#2C9C91", accessibilityLabel: "Explore optional face styling attributes", adultOnly: false },
  { label: "Aging visualization", detail: "Temporary creative stages", icon: "hourglass-outline", route: "/skin/aging", accent: "#B47752", accessibilityLabel: "Open optional creative age progression visualization", adultOnly: false },
  { label: "Skin-tone profile", detail: "Optional visual profile", icon: "color-palette-outline", route: "/skin/fitzpatrick", accent: "#C17F59", accessibilityLabel: "Open optional Fitzpatrick skin-tone profile", adultOnly: false },
  { label: "Face refinement", detail: "Optional cosmetic preview", icon: "sparkles-outline", route: "/skin/face-lift", accent: "#A85F48", accessibilityLabel: "Open optional cosmetic face refinement preview", adultOnly: false },
  { label: "AI smile", detail: "Optional creative expression", icon: "happy-outline", route: "/skin/ai-smile", accent: "#D35D8F", accessibilityLabel: "Open optional creative smile preview", adultOnly: false },
  { label: "Cosmetic body preview · 18+", detail: "Adult-only creative preview", icon: "body-outline", route: "/skin/breast-shape", accent: "#C0526C", adultOnly: true, accessibilityLabel: "Open adult-only optional cosmetic body preview" },
  { label: "Cosmetic abs", detail: "Adult-only creative preview", icon: "fitness-outline", route: "/skin/abs-filter", accent: "#4B8F76", adultOnly: true, accessibilityLabel: "Open adult-only optional cosmetic abdominal preview" },
] as const;

import { analyzeSkin, type SkinAnalysisResult } from "@/lib/skin-analysis-controller";

export function SkinCareHub() {
  const { colors, isDark } = useTheme();
  const { result, savedResults, setStage, finish, fail } = useSelfieScan();
  const [isRunningDemo, setIsRunningDemo] = React.useState(false);
  const [showAllTools, setShowAllTools] = React.useState(false);
  
  // Ensure fresh installs or empty states never show an empty dashboard by falling back to a clearly labeled demo snapshot
  const [demoFallback, setDemoFallback] = React.useState<SkinAnalysisResult | null>(null);
  React.useEffect(() => {
    if (!result && savedResults.length === 0 && !demoFallback) {
      analyzeSkin({ demo: true, saveSnapshot: false }).then(setDemoFallback).catch(() => {});
    }
  }, [result, savedResults, demoFallback]);

  const latestResult = result || savedResults[0] || demoFallback || null;
  const sourceCopy = latestResult ? SOURCE_COPY[latestResult.source] : SOURCE_COPY.demo;
  const visibleTools = showAllTools ? EXPLORE_TOOLS : EXPLORE_TOOLS.slice(0, 4);

  const openExploreTool = (route: string) => {
    switch (route) {
      case "/skin/simulation": return router.push("/skin/simulation");
      case "/skin/color-tones": return router.push("/skin/color-tones");
      case "/skin/face-attributes": return router.push("/skin/face-attributes");
      case "/skin/aging": return router.push("/skin/aging");
      case "/skin/fitzpatrick": return router.push("/skin/fitzpatrick");
      case "/skin/face-lift": return router.push("/skin/face-lift");
      case "/skin/ai-smile": return router.push("/skin/ai-smile");
      case "/skin/breast-shape": return router.push("/skin/breast-shape");
      case "/skin/abs-filter": return router.push("/skin/abs-filter");
      default: return undefined;
    }
  };

  const runDemo = async () => {
    setIsRunningDemo(true);
    setStage("analysing");
    try {
      const demo = await analyzeSkin({ demo: true, saveSnapshot: true });
      finish(demo);
    } catch (error) {
      fail(error instanceof Error ? error.message : "The demo scan could not be prepared. Please try again.");
      Alert.alert("Demo unavailable", "We could not prepare the demo scan. Please try again.");
    } finally {
      setIsRunningDemo(false);
    }
  };

  return (
    <View style={[styles.page, { backgroundColor: colors.background }]}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <LinearGradient
          colors={isDark ? ["#251B17", "#11100F"] : ["#F4E6DA", "#FCF8F3"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={[styles.hero, { borderColor: `${colors.tint}20` }]}
        >
          <View style={styles.heroTopRow}>
            <View style={styles.headerCopy}>
              <Text style={[styles.eyebrow, { color: colors.tint }]}>CLOSET A.I. · SKIN CARE</Text>
              <Text style={[styles.title, { color: colors.text }]}>A more considered daily check-in.</Text>
              <Text style={[styles.subtitle, { color: colors.textSecondary }]}>Begin with a private demo or an optional selfie, then connect your routine to the rest of your style.</Text>
            </View>
            <View style={[styles.headerIcon, { backgroundColor: `${colors.tint}16` }]} accessibilityElementsHidden importantForAccessibility="no-hide-descendants">
              <Ionicons name="sparkles-outline" size={22} color={colors.tint} />
            </View>
          </View>
          <View style={[styles.heroPill, { backgroundColor: isDark ? "rgba(255,255,255,0.07)" : "rgba(255,255,255,0.72)" }]}>
            <Ionicons name="lock-closed-outline" size={13} color={colors.tint} />
            <Text style={[styles.heroPillText, { color: colors.textSecondary }]}>Optional photo · normalized summaries only</Text>
          </View>
        </LinearGradient>

        <View style={[styles.privacyCard, { backgroundColor: colors.surface, borderColor: colors.border }]}> 
          <View style={[styles.privacyIcon, { backgroundColor: `${colors.tint}12` }]}>
            <Ionicons name="shield-checkmark-outline" size={17} color={colors.tint} />
          </View>
          <View style={styles.flex}>
            <Text style={[styles.cardTitle, { color: colors.text }]}>Clear boundaries, by design</Text>
            <Text style={[styles.cardText, { color: colors.textSecondary }]}>Live analysis happens only after you choose a photo and consent to general guidance. Saved history keeps normalized summaries, not the original selfie.</Text>
          </View>
        </View>

        <View
          style={[styles.providerEvidenceCard, { backgroundColor: colors.surface, borderColor: colors.border }]}
          accessible
          accessibilityRole="summary"
          accessibilityLabel={`YouCam Skin Analysis implementation path. ${latestResult?.source === "youcam" ? "A live consented scan is represented." : latestResult?.source === "demo" ? "A fictional demo snapshot is represented without a provider call." : latestResult?.source === "cached" ? "A normalized local summary is represented without re-running the provider." : "Choose demo data or a selfie to inspect the path."}`}
        >
          <View style={styles.providerEvidenceHeader}>
            <View style={[styles.providerEvidenceIcon, { backgroundColor: `${colors.tint}12` }]}>
              <Ionicons name="analytics-outline" size={16} color={colors.tint} />
            </View>
            <View style={styles.providerEvidenceTitleWrap}>
              <Text style={[styles.providerEvidenceEyebrow, { color: colors.tint }]}>IMPLEMENTATION PATH</Text>
              <Text style={[styles.providerEvidenceTitle, { color: colors.text }]}>YouCam Skin Analysis, made inspectable</Text>
            </View>
          </View>
          <Text style={[styles.providerEvidenceCopy, { color: colors.textSecondary }]}>{latestResult?.source === "youcam" ? "Live path: after you choose a photo and consent, ClosetAI requests a YouCam Skin Analysis result for general visual guidance. Local progress keeps normalized summaries, not the original selfie." : latestResult?.source === "demo" ? "Demo path: this fictional snapshot lets you explore the downstream experience without a provider call or a selfie. It is not live analysis." : latestResult?.source === "cached" ? "Saved path: this view uses normalized summary fields from a previous scan. It does not re-run the provider and does not retain the original selfie." : "Choose a demo or optional selfie to inspect how ClosetAI separates provider-backed analysis from offline exploration."}</Text>
          <View style={styles.providerEvidenceRows}>
            <View style={styles.providerEvidenceRow}>
              <Text style={[styles.providerEvidenceLabel, { color: colors.textTertiary }]}>Provider</Text>
              <Text style={[styles.providerEvidenceValue, { color: colors.text }]}>{latestResult?.source === "youcam" ? "Perfect Corp. YouCam Skin Analysis" : latestResult?.source === "demo" ? "Fictional Demo Signals" : latestResult?.source === "cached" ? "Normalized local summary" : "Not selected yet"}</Text>
            </View>
            <View style={styles.providerEvidenceRow}>
              <Text style={[styles.providerEvidenceLabel, { color: colors.textTertiary }]}>Inputs</Text>
              <Text style={[styles.providerEvidenceValue, { color: colors.text }]}>{latestResult?.source === "youcam" ? "Selected selfie + explicit consent" : latestResult?.source === "demo" ? "No photo required" : latestResult?.source === "cached" ? "Normalized metrics only" : "Optional demo or selfie"}</Text>
            </View>
            <View style={styles.providerEvidenceRow}>
              <Text style={[styles.providerEvidenceLabel, { color: colors.textTertiary }]}>Output</Text>
              <Text style={[styles.providerEvidenceValue, { color: colors.text }]}>General visual guidance; never a diagnosis</Text>
            </View>
          </View>
          <View style={[styles.providerEvidenceImpact, { backgroundColor: `${colors.tint}08` }]}>
            <Ionicons name="sparkles-outline" size={13} color={colors.tint} />
            <Text style={[styles.providerEvidenceImpactText, { color: colors.textSecondary }]}>Consumer value: turn a bounded visual check-in into a source-aware routine and style handoff without pretending to offer medical certainty.</Text>
          </View>
        </View>

        <Pressable
          onPress={() => router.push({ pathname: "/agents", params: { mode: "skincare" } } as any)}
          style={({ pressed }) => [styles.agentCard, { backgroundColor: colors.surface, borderColor: colors.border, opacity: pressed ? 0.78 : 1, transform: [{ scale: pressed ? interaction.cardPressScale : 1 }] }]}
          accessibilityRole="button"
          accessibilityLabel="Open Skin Routine Companion agent"
          accessibilityHint="Creates a general cosmetic routine outline from choices you make. It does not require a selfie and is not medical advice."
        >
          <View style={[styles.agentIcon, { backgroundColor: "#A85F4814" }]}><Ionicons name="sparkles-outline" size={19} color="#A85F48" /></View>
          <View style={styles.flex}>
            <Text style={[styles.agentKicker, { color: "#A85F48" }]}>NEW · AGENT STUDIO</Text>
            <Text style={[styles.agentTitle, { color: colors.text }]}>Ask the Routine Companion</Text>
            <Text style={[styles.agentText, { color: colors.textSecondary }]}>Organize a general AM/PM cosmetic outline from your selected goal. A selfie is optional and never required.</Text>
          </View>
          <Ionicons name="arrow-forward" size={17} color={colors.tint} />
        </Pressable>

        <View style={[styles.startCard, { backgroundColor: colors.surface, borderColor: colors.border }]}> 
          <View style={styles.startHeader}>
            <View style={[styles.startIcon, { backgroundColor: `${colors.tint}16` }]}>
              <Ionicons name="camera-outline" size={21} color={colors.tint} />
            </View>
            <View style={styles.flex}>
              <Text style={[styles.startKicker, { color: colors.tint }]}>START HERE</Text>
              <Text style={[styles.startTitle, { color: colors.text }]}>Your Skin Scan</Text>
              <Text style={[styles.cardText, { color: colors.textSecondary }]}>Choose the private route that fits today. Both options lead to source-aware, general-care guidance.</Text>
            </View>
          </View>
          <Pressable
            onPress={() => router.push("/skin/selfie-scan")}
            style={({ pressed }) => [styles.primaryButton, { backgroundColor: colors.text, transform: [{ scale: pressed ? interaction.primaryPressScale : 1 }] }]}
            accessibilityRole="button"
            accessibilityLabel="Start optional selfie skin scan"
            accessibilityHint="Opens the private photo selection and consent flow."
          >
            <Ionicons name="camera-outline" size={18} color={colors.background} />
            <Text numberOfLines={1} style={[styles.primaryButtonText, { color: colors.background }]}>Take or choose a selfie</Text>
            <Ionicons name="arrow-forward" size={16} color={colors.background} />
          </Pressable>
          <Pressable
            onPress={runDemo}
            disabled={isRunningDemo}
            style={({ pressed }) => [styles.demoButton, { borderColor: colors.border, backgroundColor: colors.surfaceSecondary, opacity: isRunningDemo ? 0.6 : pressed ? 0.78 : 1 }]}
            accessibilityRole="button"
            accessibilityState={{ disabled: isRunningDemo, busy: isRunningDemo }}
            accessibilityLabel="Run fictional demo skin scan"
            accessibilityHint="Prepares fictional data for exploring Skin Care features without using a selfie."
          >
            <View style={[styles.demoIcon, { backgroundColor: `${colors.tint}12` }]}>
              {isRunningDemo ? <ActivityIndicator size="small" color={colors.tint} /> : <Ionicons name="flask-outline" size={16} color={colors.tint} />}
            </View>
            <View style={styles.flex}>
              <Text style={[styles.demoButtonTitle, { color: colors.text }]}>{isRunningDemo ? "Preparing demo…" : "Explore with demo data"}</Text>
              <Text style={[styles.demoButtonDetail, { color: colors.textSecondary }]}>Fictional preview signals. No photo required.</Text>
            </View>
            <Ionicons name="chevron-forward" size={17} color={colors.textTertiary} />
          </Pressable>
        </View>

        {isRunningDemo && (
          <View style={[styles.loadingCard, { backgroundColor: `${colors.tint}12` }]} accessibilityLiveRegion="polite" accessibilityRole="progressbar" accessibilityState={{ busy: true }} accessibilityLabel="Preparing fictional Skin Care demo">
            <ActivityIndicator size="small" color={colors.tint} />
            <Text style={[styles.loadingText, { color: colors.textSecondary }]}>Preparing fictional demo signals and a general-care preview…</Text>
          </View>
        )}

        {latestResult && sourceCopy ? (
          <View style={styles.snapshotSection}>
            <View style={styles.snapshotHeader}>
              <View style={styles.flex}>
                <Text style={[styles.sectionKicker, { color: colors.tint }]}>YOUR LATEST SNAPSHOT</Text>
                <Text style={[styles.sectionTitle, { color: colors.text }]}>Keep the signal in context.</Text>
                <Text style={[styles.cardText, { color: colors.textSecondary }]}>{sourceCopy.detail}</Text>
              </View>
              <View style={[styles.sourceBadge, { backgroundColor: latestResult.source === "youcam" ? `${colors.success}18` : `${colors.tint}16` }]} accessible accessibilityLabel={`Snapshot source: ${sourceCopy.badge}. ${sourceCopy.detail}`}>
                <Text style={[styles.sourceText, { color: latestResult.source === "youcam" ? colors.success : colors.tint }]}>{sourceCopy.badge}</Text>
              </View>
            </View>
            <SkinIntelligenceDashboard current={latestResult} history={savedResults} colors={colors} />
            <View style={styles.actionRow}>
              <Pressable onPress={() => router.push("/skin/results")} style={({ pressed }) => [styles.compactButton, { backgroundColor: colors.text, opacity: pressed ? 0.88 : 1, transform: [{ scale: pressed ? interaction.compactPressScale : 1 }] }]} accessibilityRole="button" accessibilityLabel="View detailed skin scan results" accessibilityHint="Opens the source-aware detail view for this snapshot.">
                <Text style={[styles.compactButtonText, { color: colors.background }]}>View details</Text>
                <Ionicons name="arrow-forward" size={14} color={colors.background} />
              </Pressable>
              <Pressable onPress={() => router.push("/skin/style-match")} style={({ pressed }) => [styles.compactButton, { borderColor: colors.border, borderWidth: 1, backgroundColor: colors.surface, opacity: pressed ? 0.76 : 1, transform: [{ scale: pressed ? interaction.compactPressScale : 1 }] }]} accessibilityRole="button" accessibilityLabel="Open Skin and Style suggestions" accessibilityHint="Connects your saved general-care context to wardrobe styling ideas.">
                <Text style={[styles.compactButtonText, { color: colors.text }]}>Skin × Style</Text>
                <Ionicons name="sparkles-outline" size={14} color={colors.tint} />
              </Pressable>
            </View>
          </View>
        ) : (
          <View style={[styles.emptyCard, { backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]}>
            <View style={[styles.emptyIcon, { backgroundColor: `${colors.tint}14` }]}><Ionicons name="analytics-outline" size={19} color={colors.tint} /></View>
            <View style={styles.flex}>
              <Text style={[styles.cardTitle, { color: colors.text }]}>Your first snapshot starts here</Text>
              <Text style={[styles.cardText, { color: colors.textSecondary }]}>Use a private demo to preview the experience, or choose a selfie when you are ready. The Skin Care tab remains useful without provider credentials or network access.</Text>
            </View>
          </View>
        )}

        <View style={styles.exploreSection}>
          <View style={styles.exploreHeader}>
            <View style={styles.flex}>
              <Text style={[styles.sectionKicker, { color: colors.tint }]}>OPTIONAL EXPLORATIONS</Text>
              <Text style={[styles.sectionTitle, { color: colors.text }]}>Explore with intention.</Text>
              <Text style={[styles.cardText, { color: colors.textSecondary }]}>Creative and informational tools are optional; each carries its own scope and disclosure.</Text>
            </View>
            <View style={[styles.exploreCount, { backgroundColor: `${colors.tint}12` }]}>
              <Text style={[styles.exploreCountText, { color: colors.tint }]}>{EXPLORE_TOOLS.length}</Text>
            </View>
          </View>
          <View style={styles.toolsGrid}>
            {visibleTools.map((tool) => (
              <Pressable
                key={tool.route}
                onPress={() => openExploreTool(tool.route)}
                style={({ pressed }) => [styles.toolCard, { backgroundColor: colors.surface, borderColor: colors.border, opacity: pressed ? 0.78 : 1, transform: [{ scale: pressed ? interaction.cardPressScale : 1 }] }]}
                accessibilityRole="button"
                accessibilityLabel={tool.accessibilityLabel}
                accessibilityHint={tool.adultOnly ? "This is an adult-only optional creative preview." : tool.detail}
              >
                <View style={[styles.toolIcon, { backgroundColor: `${tool.accent}14` }]}><Ionicons name={tool.icon as any} size={18} color={tool.accent} /></View>
                <View style={styles.toolCopy}>
                  <Text style={[styles.toolTitle, { color: colors.text }]} numberOfLines={1}>{tool.label}</Text>
                  <Text style={[styles.toolDetail, { color: colors.textSecondary }]} numberOfLines={1}>{tool.detail}</Text>
                </View>
                {tool.adultOnly ? <Text style={[styles.adultBadge, { color: tool.accent }]}>18+</Text> : <Ionicons name="chevron-forward" size={15} color={colors.textTertiary} />}
              </Pressable>
            ))}
          </View>
          <Pressable
            onPress={() => setShowAllTools((current) => !current)}
            style={({ pressed }) => [styles.showMoreButton, { borderColor: colors.border, backgroundColor: colors.surfaceSecondary, opacity: pressed ? 0.76 : 1, transform: [{ scale: pressed ? interaction.compactPressScale : 1 }] }]}
            accessibilityRole="button"
            accessibilityState={{ expanded: showAllTools }}
            accessibilityLabel={showAllTools ? "Show fewer optional Skin Care tools" : "Show all optional Skin Care tools"}
          >
            <Text style={[styles.showMoreText, { color: colors.text }]}>{showAllTools ? "Show fewer tools" : `Show ${EXPLORE_TOOLS.length - visibleTools.length} more tools`}</Text>
            <Ionicons name={showAllTools ? "chevron-up" : "chevron-down"} size={16} color={colors.tint} />
          </Pressable>
        </View>

        <View style={[styles.footer, { backgroundColor: colors.surfaceSecondary }]}>
          <Ionicons name="information-circle-outline" size={16} color={colors.textTertiary} />
          <Text style={[styles.footerText, { color: colors.textTertiary }]}>Cosmetic and informational insights only. This feature is not medical advice or a diagnosis.</Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1 },
  content: { padding: 18, paddingBottom: 126, gap: 14 },
  flex: { flex: 1 },
  hero: { borderWidth: 1, borderRadius: 28, padding: 19, gap: 16, overflow: "hidden", marginTop: 8 },
  heroTopRow: { flexDirection: "row", gap: 14, alignItems: "flex-start" },
  headerCopy: { flex: 1 },
  eyebrow: { fontFamily: "Outfit_700Bold", fontSize: 9, letterSpacing: 1.2 },
  title: { fontFamily: "Outfit_700Bold", fontSize: 25, lineHeight: 31, letterSpacing: -0.45, marginTop: 5 },
  subtitle: { fontFamily: "Outfit_400Regular", fontSize: 12, lineHeight: 18, marginTop: 7 },
  headerIcon: { width: 46, height: 46, borderRadius: 16, alignItems: "center", justifyContent: "center" },
  heroPill: { alignSelf: "flex-start", flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 10, paddingVertical: 7, borderRadius: 999 },
  heroPillText: { fontFamily: "Outfit_500Medium", fontSize: 10 },
  privacyCard: { flexDirection: "row", alignItems: "flex-start", gap: 10, borderWidth: 1, borderRadius: 18, padding: 13 },
  privacyIcon: { width: 32, height: 32, borderRadius: 11, alignItems: "center", justifyContent: "center" },
  providerEvidenceCard: { borderWidth: 1, borderRadius: 18, padding: 13, marginTop: 12 },
  providerEvidenceHeader: { flexDirection: "row", alignItems: "center", gap: 9 },
  providerEvidenceIcon: { width: 30, height: 30, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  providerEvidenceTitleWrap: { flex: 1 },
  providerEvidenceEyebrow: { fontFamily: "Outfit_700Bold", fontSize: 8, letterSpacing: 1.05 },
  providerEvidenceTitle: { fontFamily: "Outfit_700Bold", fontSize: 13, lineHeight: 17, marginTop: 2 },
  providerEvidenceCopy: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 15, marginTop: 9 },
  providerEvidenceRows: { gap: 7, marginTop: 12 },
  providerEvidenceRow: { flexDirection: "row", alignItems: "flex-start", gap: 10 },
  providerEvidenceLabel: { width: 46, fontFamily: "Outfit_600SemiBold", fontSize: 9, textTransform: "uppercase", letterSpacing: 0.45 },
  providerEvidenceValue: { flex: 1, fontFamily: "Outfit_500Medium", fontSize: 10, lineHeight: 14 },
  providerEvidenceImpact: { flexDirection: "row", alignItems: "flex-start", gap: 7, borderRadius: 10, paddingHorizontal: 9, paddingVertical: 8, marginTop: 12 },
  providerEvidenceImpactText: { flex: 1, fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 14 },
  agentCard: { borderWidth: 1, borderRadius: 18, padding: 13, flexDirection: "row", alignItems: "center", gap: 10 },
  agentIcon: { width: 38, height: 38, borderRadius: 13, alignItems: "center", justifyContent: "center" },
  agentKicker: { fontFamily: "Outfit_700Bold", fontSize: 9, letterSpacing: 1.05 },
  agentTitle: { fontFamily: "Outfit_700Bold", fontSize: 14, marginTop: 2 },
  agentText: { fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 15, marginTop: 2 },
  cardTitle: { fontFamily: "Outfit_700Bold", fontSize: 14 },
  cardText: { fontFamily: "Outfit_400Regular", fontSize: 11, lineHeight: 16, marginTop: 3 },
  startCard: { borderWidth: 1, borderRadius: 23, padding: 15, gap: 11 },
  startHeader: { flexDirection: "row", alignItems: "flex-start", gap: 11, marginBottom: 2 },
  startIcon: { width: 42, height: 42, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  startKicker: { fontFamily: "Outfit_700Bold", fontSize: 9, letterSpacing: 1.1, marginTop: 1 },
  startTitle: { fontFamily: "Outfit_700Bold", fontSize: 17, marginTop: 2 },
  primaryButton: { minHeight: 53, paddingHorizontal: 12, borderRadius: 15, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7 },
  primaryButtonText: { fontFamily: "Outfit_700Bold", fontSize: 13, flexShrink: 1 },
  demoButton: { minHeight: 58, borderWidth: 1, borderRadius: 15, paddingHorizontal: 11, flexDirection: "row", alignItems: "center", gap: 10 },
  demoIcon: { width: 34, height: 34, borderRadius: 11, alignItems: "center", justifyContent: "center" },
  demoButtonTitle: { fontFamily: "Outfit_700Bold", fontSize: 12 },
  demoButtonDetail: { fontFamily: "Outfit_400Regular", fontSize: 10, marginTop: 1 },
  loadingCard: { minHeight: 49, flexDirection: "row", gap: 10, alignItems: "center", borderRadius: 15, paddingHorizontal: 13 },
  loadingText: { flex: 1, fontFamily: "Outfit_500Medium", fontSize: 11, lineHeight: 16 },
  snapshotSection: { gap: 11, marginTop: 3 },
  snapshotHeader: { flexDirection: "row", alignItems: "flex-start", gap: 10 },
  sectionKicker: { fontFamily: "Outfit_700Bold", fontSize: 9, letterSpacing: 1.15 },
  sectionTitle: { fontFamily: "Outfit_700Bold", fontSize: 19, lineHeight: 24, letterSpacing: -0.25, marginTop: 3 },
  sourceBadge: { borderRadius: 9, paddingHorizontal: 8, paddingVertical: 5, marginTop: 3 },
  sourceText: { fontFamily: "Outfit_700Bold", fontSize: 9, letterSpacing: 0.7 },
  actionRow: { flexDirection: "row", gap: 9 },
  compactButton: { flex: 1, minHeight: 46, borderRadius: 14, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 7 },
  compactButtonText: { fontFamily: "Outfit_700Bold", fontSize: 12 },
  emptyCard: { flexDirection: "row", alignItems: "flex-start", gap: 11, borderWidth: 1, borderRadius: 18, padding: 14 },
  emptyIcon: { width: 35, height: 35, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  exploreSection: { marginTop: 4, gap: 11 },
  exploreHeader: { flexDirection: "row", alignItems: "flex-start", gap: 10 },
  exploreCount: { width: 31, height: 31, borderRadius: 11, justifyContent: "center", alignItems: "center", marginTop: 3 },
  exploreCountText: { fontFamily: "Outfit_700Bold", fontSize: 12 },
  toolsGrid: { gap: 9 },
  toolCard: { borderWidth: 1, borderRadius: 16, padding: 11, minHeight: 64, flexDirection: "row", alignItems: "center", gap: 10 },
  toolIcon: { width: 38, height: 38, borderRadius: 13, alignItems: "center", justifyContent: "center" },
  toolCopy: { flex: 1 },
  toolTitle: { fontFamily: "Outfit_700Bold", fontSize: 12 },
  toolDetail: { fontFamily: "Outfit_400Regular", fontSize: 10, marginTop: 2 },
  adultBadge: { fontFamily: "Outfit_700Bold", fontSize: 10, letterSpacing: 0.4, paddingHorizontal: 4 },
  showMoreButton: { minHeight: 45, borderWidth: 1, borderRadius: 14, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 7 },
  showMoreText: { fontFamily: "Outfit_700Bold", fontSize: 12 },
  footer: { flexDirection: "row", alignItems: "flex-start", gap: 8, borderRadius: 15, padding: 12, marginTop: 2 },
  footerText: { flex: 1, fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 15 },
});
