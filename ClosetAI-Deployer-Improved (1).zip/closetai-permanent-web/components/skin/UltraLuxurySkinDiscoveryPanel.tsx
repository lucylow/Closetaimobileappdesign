import { Ionicons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { router } from 'expo-router';
import React, { useMemo, useState } from 'react';
import { Alert, Linking, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';

import { useMockCommerce } from '@/contexts/MockCommerceContext';
import {
  ULTRA_LUXURY_SKIN_DISCOVERY_DISCLOSURE,
  ULTRA_LUXURY_SKIN_DISCOVERY_RECORDS,
  type UltraLuxurySkinBrand,
  type UltraLuxurySkinDiscoveryRecord,
} from '@/lib/ultra-luxury-skin-discovery';

type Props = { colors: any };

export function UltraLuxurySkinDiscoveryPanel({ colors }: Props) {
  const brands = useMemo(() => Array.from(new Set(ULTRA_LUXURY_SKIN_DISCOVERY_RECORDS.map((item) => item.brand))) as UltraLuxurySkinBrand[], []);
  const [selectedBrand, setSelectedBrand] = useState<UltraLuxurySkinBrand>(brands[0]);
  const [cartMessage, setCartMessage] = useState<string | null>(null);
  const { addItem, itemCount } = useMockCommerce();
  const records = ULTRA_LUXURY_SKIN_DISCOVERY_RECORDS.filter((item) => item.brand === selectedBrand);

  const openOfficialDestination = async (record: UltraLuxurySkinDiscoveryRecord) => {
    try {
      const supported = await Linking.canOpenURL(record.officialUrl);
      if (!supported) throw new Error('Unsupported external destination');
      await Linking.openURL(record.officialUrl);
    } catch {
      Alert.alert('Official link unavailable', 'We could not open this official brand destination on this device. Please try again later.');
    }
  };

  const addExternalReferenceToMockCart = async (record: UltraLuxurySkinDiscoveryRecord) => {
    try {
      const result = await addItem(record.id);
      setCartMessage(result.message);
      if (result.operation === 'unavailable' || result.operation === 'stock_limit') {
        Alert.alert('Mock cart update', `${result.message}\n\n${record.disclosure}`);
      }
    } catch {
      Alert.alert('Mock cart unavailable', 'The fictional cart could not be updated. No transaction was attempted.');
    }
  };

  return (
    <View style={[styles.panel, { backgroundColor: colors.surface, borderColor: colors.border }]}>
      <View style={styles.headingRow}>
        <View style={[styles.iconWrap, { backgroundColor: `${colors.tint}14` }]}><Ionicons name="diamond-outline" size={18} color={colors.tint} /></View>
        <View style={styles.flex}>
          <Text style={[styles.kicker, { color: colors.tint }]}>EXTERNAL DISCOVERY · OPTIONAL</Text>
          <Text style={[styles.title, { color: colors.text }]}>Ultra-luxury skincare references</Text>
        </View>
      </View>
      <Text style={[styles.disclosure, { color: colors.textSecondary }]}>{ULTRA_LUXURY_SKIN_DISCOVERY_DISCLOSURE}</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.brandRow} accessibilityRole="radiogroup" accessibilityLabel="Ultra-luxury skin-care brand references">
        {brands.map((brand) => {
          const selected = brand === selectedBrand;
          return <Pressable key={brand} onPress={() => setSelectedBrand(brand)} accessibilityRole="radio" accessibilityState={{ selected }} accessibilityLabel={`${brand} ultra-luxury skin-care references${selected ? ', selected' : ''}`} style={[styles.brandChip, { borderColor: selected ? colors.tint : colors.border, backgroundColor: selected ? `${colors.tint}12` : colors.surfaceSecondary }]}><Text style={[styles.brandText, { color: selected ? colors.tint : colors.textSecondary }]}>{brand}</Text></Pressable>;
        })}
      </ScrollView>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.cardsRow}>
        {records.map((record) => <View key={record.id} style={[styles.card, { backgroundColor: colors.surfaceSecondary, borderColor: colors.border }]}>
          <Image source={{ uri: record.genericVisualUrl }} style={styles.image} contentFit="cover" />
          <View style={styles.cardCopy}>
            <Text style={[styles.brandLabel, { color: colors.tint }]}>{record.brand}</Text>
            <Text style={[styles.productName, { color: colors.text }]} numberOfLines={2}>{record.productName}</Text>
            <Text style={[styles.detail, { color: colors.textSecondary }]} numberOfLines={2}>{record.discoveryFocus}</Text>
            <Pressable onPress={() => openOfficialDestination(record)} accessibilityRole="link" accessibilityLabel={`Open ${record.officialSourceLabel} on the official ${record.brand} website`} accessibilityHint="Opens an external official brand destination. ClosetAI does not provide local price, inventory, checkout, or medical guidance." style={styles.linkRow}><Text style={[styles.linkText, { color: colors.tint }]}>Official destination</Text><Ionicons name="open-outline" size={13} color={colors.tint} /></Pressable>
            <Pressable onPress={() => addExternalReferenceToMockCart(record)} accessibilityRole="button" accessibilityLabel={`Add fictional ${record.brand} ${record.productName} reference to mock cart`} accessibilityHint="Adds a fictional local prototype line. It does not reserve, purchase, or order the external product." style={[styles.mockCartButton, { borderColor: colors.border }]}><Ionicons name="bag-add-outline" size={13} color={colors.text} /><Text style={[styles.mockCartText, { color: colors.text }]}>Add to mock cart</Text></Pressable>
          </View>
        </View>)}
      </ScrollView>
      {cartMessage && <Text style={[styles.cartMessage, { color: cartMessage.includes('unavailable') || cartMessage.includes('limit') ? colors.warning : colors.success }]} accessibilityLiveRegion="polite">{cartMessage}</Text>}
      <View style={styles.bottomActions}>
        <Pressable onPress={() => router.push('/skin/texture-preview')} accessibilityRole="button" accessibilityLabel="Open cosmetic texture preview using my own photo" accessibilityHint="Opens a consent-based local visual overlay. It never uses a stock model or claims to reproduce a brand formula." style={[styles.previewButton, { backgroundColor: colors.text }]}><Ionicons name="color-wand-outline" size={15} color={colors.background} /><Text style={[styles.previewButtonText, { color: colors.background }]}>Try a cosmetic texture preview</Text></Pressable>
        {itemCount > 0 && <Pressable onPress={() => router.push('/skin/mock-cart')} accessibilityRole="button" accessibilityLabel={`Manage mock cart with ${itemCount} items`} style={[styles.cartLink, { borderColor: colors.border }]}><Text style={[styles.cartLinkText, { color: colors.text }]}>Mock cart · {itemCount}</Text></Pressable>}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  panel: { borderWidth: 1, borderRadius: 16, padding: 12, gap: 10, marginTop: 10 },
  headingRow: { flexDirection: 'row', alignItems: 'center', gap: 9 },
  iconWrap: { width: 36, height: 36, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  flex: { flex: 1 },
  kicker: { fontFamily: 'Outfit_700Bold', fontSize: 8, letterSpacing: 0.8 },
  title: { fontFamily: 'Outfit_700Bold', fontSize: 14, marginTop: 2 },
  disclosure: { fontFamily: 'Outfit_400Regular', fontSize: 10, lineHeight: 15 },
  brandRow: { gap: 7 },
  brandChip: { borderWidth: 1, borderRadius: 15, paddingHorizontal: 10, paddingVertical: 7 },
  brandText: { fontFamily: 'Outfit_600SemiBold', fontSize: 10 },
  cardsRow: { gap: 9 },
  card: { width: 194, borderWidth: 1, borderRadius: 13, overflow: 'hidden' },
  image: { width: '100%', height: 104 },
  cardCopy: { padding: 10, gap: 4 },
  brandLabel: { fontFamily: 'Outfit_700Bold', fontSize: 9, letterSpacing: 0.4, textTransform: 'uppercase' },
  productName: { fontFamily: 'Outfit_700Bold', fontSize: 13, lineHeight: 17 },
  detail: { fontFamily: 'Outfit_400Regular', fontSize: 10, lineHeight: 14, minHeight: 28 },
  linkRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 3, alignSelf: 'flex-start' },
  linkText: { fontFamily: 'Outfit_700Bold', fontSize: 10 },
  mockCartButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5, borderWidth: 1, borderRadius: 8, paddingVertical: 7, marginTop: 7 },
  mockCartText: { fontFamily: 'Outfit_700Bold', fontSize: 9 },
  cartMessage: { fontFamily: 'Outfit_600SemiBold', fontSize: 10, lineHeight: 14 },
  bottomActions: { gap: 7 },
  previewButton: { alignSelf: 'flex-start', borderRadius: 10, paddingHorizontal: 10, paddingVertical: 8, flexDirection: 'row', alignItems: 'center', gap: 6 },
  previewButtonText: { fontFamily: 'Outfit_700Bold', fontSize: 10 },
  cartLink: { alignSelf: 'flex-start', borderWidth: 1, borderRadius: 10, paddingHorizontal: 10, paddingVertical: 8 },
  cartLinkText: { fontFamily: 'Outfit_700Bold', fontSize: 10 },
});
