import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import * as Haptics from 'expo-haptics';

import { useTheme } from '@/lib/useTheme';
import { interaction, shadows } from '@/constants/colors';

export type PremiumTier = 'pro' | 'enterprise';

const TIER_RANK: Record<string, number> = { free: 0, pro: 1, enterprise: 2 };

export function hasRequiredTier(currentTier: string, requiredTier: PremiumTier): boolean {
  return (TIER_RANK[currentTier] ?? 0) >= TIER_RANK[requiredTier];
}

type MonetizationPaywallProps = {
  requiredTier: PremiumTier;
  title: string;
  description: string;
  benefits: readonly string[];
  source: 'agent_studio' | 'brand_analytics';
  continueLabel: string;
  onContinue: () => void;
};

export function MonetizationPaywall({
  requiredTier,
  title,
  description,
  benefits,
  source,
  continueLabel,
  onContinue,
}: MonetizationPaywallProps) {
  const { colors, isDark } = useTheme();
  const tierLabel = requiredTier === 'enterprise' ? 'Enterprise' : 'Pro';

  const openPlanReview = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    router.push({ pathname: '/subscription', params: { source } });
  };

  return (
    <View style={[styles.page, { backgroundColor: colors.background }]}>
      <View style={styles.content}>
        <Pressable
          onPress={() => router.back()}
          accessibilityRole="button"
          accessibilityLabel="Go back"
          accessibilityHint="Returns to the previous ClosetAI screen."
          style={({ pressed }) => [styles.backButton, { backgroundColor: colors.surface, borderColor: colors.border, opacity: pressed ? 0.72 : 1 }]}
        >
          <Ionicons name="arrow-back" size={18} color={colors.text} />
        </Pressable>

        <LinearGradient
          colors={requiredTier === 'enterprise'
            ? (isDark ? ['#2B221A', '#121110'] : ['#F8E7D8', '#FFF9F4'])
            : (isDark ? ['#25203A', '#11100F'] : ['#ECE7FF', '#FBF9FF'])}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={[styles.hero, { borderColor: requiredTier === 'enterprise' ? '#C17F5940' : '#6E4AE040' }]}
        >
          <View style={[styles.iconWrap, { backgroundColor: requiredTier === 'enterprise' ? '#C17F5920' : '#6E4AE020' }]}>
            <Ionicons name={requiredTier === 'enterprise' ? 'business-outline' : 'sparkles-outline'} size={24} color={requiredTier === 'enterprise' ? '#C17F59' : '#6E4AE0'} />
          </View>
          <Text style={[styles.eyebrow, { color: requiredTier === 'enterprise' ? '#C17F59' : '#6E4AE0' }]}>{tierLabel.toUpperCase()} FEATURE</Text>
          <Text style={[styles.title, { color: colors.text }]}>{title}</Text>
          <Text style={[styles.description, { color: colors.textSecondary }]}>{description}</Text>
        </LinearGradient>

        <View style={[styles.benefitCard, { backgroundColor: colors.surface, borderColor: colors.border }, shadows.soft]}>
          <Text style={[styles.benefitTitle, { color: colors.text }]}>Consumer & Retail Value with {tierLabel}</Text>
          <Text style={[styles.benefitSubtitle, { color: colors.textSecondary, fontSize: 12, marginBottom: 8, lineHeight: 17 }]}>Save time getting dressed, turn wardrobe clutter into styled outfits, and discover retail gaps without guesswork.</Text>
          {benefits.map((benefit) => (
            <View key={benefit} style={styles.benefitRow}>
              <Ionicons name="checkmark-circle" size={17} color={requiredTier === 'enterprise' ? '#C17F59' : '#6E4AE0'} />
              <Text style={[styles.benefitText, { color: colors.textSecondary }]}>{benefit}</Text>
            </View>
          ))}
        </View>

        <View style={[styles.disclosure, { backgroundColor: `${colors.tint}10`, borderColor: `${colors.tint}24` }]} accessibilityLabel="Billing disclosure">
          <Ionicons name="shield-checkmark-outline" size={17} color={colors.tint} />
          <Text style={[styles.disclosureText, { color: colors.textSecondary }]}>This screen only controls feature access and opens plan review. It does not collect card, wallet, address, or payment details, and it does not confirm a charge.</Text>
        </View>

        <Pressable
          onPress={openPlanReview}
          accessibilityRole="button"
          accessibilityLabel={`Review ${tierLabel} plans`}
          accessibilityHint="Opens the plan review screen. Payment is not collected or confirmed from this paywall."
          style={({ pressed }) => [styles.primaryButton, { transform: [{ scale: pressed ? interaction.primaryPressScale : 1 }], opacity: pressed ? 0.88 : 1 }]}
        >
          <LinearGradient colors={requiredTier === 'enterprise' ? ['#C17F59', '#D4A574'] : ['#6E4AE0', '#9B6DFF']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.primaryGradient}>
            <Text style={styles.primaryText}>Review {tierLabel} plans</Text>
            <Ionicons name="arrow-forward" size={18} color="#FFF" />
          </LinearGradient>
        </Pressable>

        <Pressable
          onPress={onContinue}
          accessibilityRole="button"
          accessibilityLabel={continueLabel}
          accessibilityHint="Continues with an available ClosetAI tool without opening plan review."
          style={({ pressed }) => [styles.secondaryButton, { borderColor: colors.border, backgroundColor: colors.surface, opacity: pressed ? 0.72 : 1 }]}
        >
          <Text style={[styles.secondaryText, { color: colors.text }]}>{continueLabel}</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1 },
  content: { flex: 1, padding: 20, justifyContent: 'center', gap: 14 },
  backButton: { width: 40, height: 40, borderWidth: 1, borderRadius: 14, alignItems: 'center', justifyContent: 'center', alignSelf: 'flex-start' },
  hero: { borderWidth: 1, borderRadius: 24, padding: 19, gap: 7 },
  iconWrap: { width: 48, height: 48, borderRadius: 16, alignItems: 'center', justifyContent: 'center', marginBottom: 3 },
  eyebrow: { fontFamily: 'Outfit_700Bold', fontSize: 10, letterSpacing: 1.1 },
  title: { fontFamily: 'Outfit_700Bold', fontSize: 25, lineHeight: 31, letterSpacing: -0.3 },
  description: { fontFamily: 'Outfit_400Regular', fontSize: 13, lineHeight: 19 },
  benefitCard: { borderWidth: 1, borderRadius: 20, padding: 16, gap: 11 },
  benefitTitle: { fontFamily: 'Outfit_700Bold', fontSize: 15, marginBottom: 2 },
  benefitSubtitle: { fontFamily: 'Outfit_400Regular', fontSize: 12, lineHeight: 17, marginBottom: 4 },
  benefitRow: { flexDirection: 'row', alignItems: 'center', gap: 9 },
  benefitText: { flex: 1, fontFamily: 'Outfit_400Regular', fontSize: 12, lineHeight: 17 },
  disclosure: { flexDirection: 'row', alignItems: 'flex-start', gap: 9, borderWidth: 1, borderRadius: 15, padding: 12 },
  disclosureText: { flex: 1, fontFamily: 'Outfit_400Regular', fontSize: 11, lineHeight: 16 },
  primaryButton: { borderRadius: 16, overflow: 'hidden' },
  primaryGradient: { minHeight: 54, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8 },
  primaryText: { fontFamily: 'Outfit_700Bold', fontSize: 14, color: '#FFF' },
  secondaryButton: { minHeight: 48, borderWidth: 1, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  secondaryText: { fontFamily: 'Outfit_600SemiBold', fontSize: 13 },
});
