import {
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  type KeyboardAvoidingViewProps,
  type ScrollViewProps,
} from "react-native";

type Props = ScrollViewProps &
  Pick<KeyboardAvoidingViewProps, "behavior" | "enabled" | "keyboardVerticalOffset">;

/**
 * Expo Go-compatible keyboard-aware scrolling. It intentionally relies only on React Native
 * primitives so the app does not require a custom development build for form screens.
 */
export function KeyboardAwareScrollViewCompat({
  children,
  keyboardShouldPersistTaps = "handled",
  behavior,
  enabled = true,
  keyboardVerticalOffset = 0,
  ...props
}: Props) {
  const scrollView = (
    <ScrollView keyboardShouldPersistTaps={keyboardShouldPersistTaps} {...props}>
      {children}
    </ScrollView>
  );

  if (Platform.OS === "web") return scrollView;

  return (
    <KeyboardAvoidingView
      enabled={enabled}
      behavior={behavior ?? (Platform.OS === "ios" ? "padding" : "height")}
      keyboardVerticalOffset={keyboardVerticalOffset}
      style={styles.container}
    >
      {scrollView}
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});
