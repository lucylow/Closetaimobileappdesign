import { Ionicons } from "@expo/vector-icons";
import { StyleSheet, Text, View } from "react-native";

export type MediaStatusKind = "user-photo" | "reference" | "temporary-result" | "local-only";

type MediaStatusCardProps = {
  kind: MediaStatusKind;
  title: string;
  detail: string;
  tint: string;
  surface: string;
  border: string;
};

const STATUS_CONFIG: Record<MediaStatusKind, { icon: keyof typeof Ionicons.glyphMap; prefix: string }> = {
  "user-photo": { icon: "person-circle-outline", prefix: "Selected user photo" },
  reference: { icon: "image-outline", prefix: "Selected reference image" },
  "temporary-result": { icon: "sparkles-outline", prefix: "Temporary generated result" },
  "local-only": { icon: "phone-portrait-outline", prefix: "Local media status" },
};

/**
 * A compact, source-aware media status treatment. It deliberately labels media
 * provenance rather than implying that an image is stock, verified, saved, or persistent.
 */
export function MediaStatusCard({ kind, title, detail, tint, surface, border }: MediaStatusCardProps) {
  const config = STATUS_CONFIG[kind];
  return (
    <View
      style={[styles.container, { backgroundColor: surface, borderColor: border }]}
      accessible
      accessibilityLabel={`${config.prefix}. ${title}. ${detail}`}
    >
      <View style={[styles.iconWrap, { backgroundColor: `${tint}14` }]} accessibilityElementsHidden importantForAccessibility="no-hide-descendants">
        <Ionicons name={config.icon} size={16} color={tint} />
      </View>
      <View style={styles.copy}>
        <Text style={[styles.title, { color: tint }]}>{title}</Text>
        <Text style={styles.detail}>{detail}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { minHeight: 48, borderWidth: 1, borderRadius: 14, paddingHorizontal: 11, paddingVertical: 9, flexDirection: "row", alignItems: "center", gap: 9 },
  iconWrap: { width: 29, height: 29, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  copy: { flex: 1 },
  title: { fontFamily: "Outfit_700Bold", fontSize: 10, letterSpacing: 0.25 },
  detail: { color: "#7B7470", fontFamily: "Outfit_400Regular", fontSize: 10, lineHeight: 14, marginTop: 2 },
});
