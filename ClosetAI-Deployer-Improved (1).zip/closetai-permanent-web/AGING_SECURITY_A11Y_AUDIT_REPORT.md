# ClosetAI AI Aging Visualization: Security and Accessibility Audit

**Audit date:** August 12, 2026  
**Author:** Manus AI  
**Scope:** `app/skin/aging.tsx`, `components/skin/SkinCareHub.tsx`, `server/routes.ts`, `server/aging-upload-security.ts`, `server/youcam-skin-v2.ts`, and the associated shared aging contract.

## Executive Summary

This audit reviewed the optional **AI aging visualization** workflow in the cumulative ClosetAI Expo mobile application. The review focused on handling of a user-selected selfie from the point of submission through the server-only YouCam task workflow, and on the accessibility of the aging screen and the Skin Care Hub entry point.

The workflow now applies a narrowly scoped server-side image boundary: it accepts only bounded JPEG data, validates canonical Base64 and JPEG start/end markers, uses an authenticated server-side request to obtain a signed upload target, refuses non-HTTPS signed URLs, prevents redirects during provider interactions, and overwrites the transient server image buffer immediately after the upload completes. The mobile response remains deliberately minimal: it contains normalized, HTTPS temporary preview URLs and never returns raw provider output, inferred current age, or the selected source image.

| Assessment area | Audit outcome | Important constraint |
|---|---|---|
| Credentials and provider calls | **Implemented** | Provider credentials remain server-only environment variables; the client application does not receive them. |
| Temporary selfie validation | **Hardened** | The aging route accepts only a bounded JPEG payload with canonical Base64 and JPEG marker checks. |
| Transport and upload target | **Hardened** | Provider API and signed upload calls use HTTPS; signed upload targets are rejected unless their scheme is `https:`. |
| In-memory raw photo lifetime | **Hardened** | The raw `Buffer` is overwritten after upload and in a `finally` path for failure cases. |
| Response minimization | **Implemented** | The app exposes normalized simulation data only; raw provider payloads and inferred current age are not propagated. |
| Accessibility semantics | **Improved** | Loading, errors, consent, temporary previews, stage choices, provenance, and decorative content now have explicit assistive-technology treatment. |
| Formal conformance | **Not claimed** | This is a code and regression-test audit, not a substitute for full device, assistive-technology, penetration, or third-party privacy review. |

> The aging feature is deliberately framed as an **optional, non-predictive creative visualization**. It does not estimate the user’s current age or predict a future appearance, and it does not substitute a stock or demo face.

## Scope, Method, and Boundaries

The review combined source inspection with code hardening and an executable regression check. It examined the Express route that receives the photo, the signed-upload helper shared with YouCam v2 workflows, the task polling boundary, the data normalization contract, and the React Native components that surface consent, progress, errors, images, and mutually exclusive creative stages.

The audit validates controls that are present in this repository. It does **not** independently verify a cloud load balancer’s TLS policy, production environment-variable manager, provider-side encryption at rest, provider file-retention configuration, deployment logging configuration, or the runtime behavior of every accessibility service. These deployment responsibilities are explicitly separated in the production follow-up section.

| Included in code audit | Outside repository-only verification |
|---|---|
| Server-only use of `PERFECT_YOUCAM_SKIN_V2_API_KEY` | TLS termination and HSTS at the deployed public edge |
| HTTPS-only static provider base URL and signed upload scheme check | Provider storage encryption, retention, and deletion guarantees |
| Request timeouts, bounded polling, redirect rejection, no-store requests | Web application firewall, rate limits, DDoS controls, and monitoring configuration |
| JPEG/Base64 validation and explicit buffer overwrite | Operating-system memory forensics and swap-encryption policy |
| Mobile labels, roles, states, hints, live regions, and static regression coverage | Manual VoiceOver/TalkBack testing on the supported physical-device matrix |

## Audited Data Flow

The workflow begins only after a user selects their own selfie and checks an explicit non-predictive consent control. The Expo client converts the selected local asset into Base64 for the authenticated request. The mobile client has no YouCam secret and is never told the signed upload URL, upload headers, provider raw task result, or credential-bearing authorization header.

At the server boundary, the aging route confirms the consent flag, passes the submitted string to `decodeAgingJpegUpload`, then creates a private provider file record and uploads the validated buffer. The buffer is overwritten as soon as the upload finishes and is also overwritten in the route’s `finally` clause when an error interrupts the workflow. The route starts an aging task using the opaque provider file ID, polls at most 30 times with a maximum per-wait interval of five seconds, and returns only the normalized output when a terminal success is reported.

| Step | Data handled | Control present in the implementation | Exposure prevented |
|---|---|---|---|
| 1. Selection and consent | User-selected local selfie; boolean consent | The route requires `consent === true`; there is no demo or stock-image substitution path. | Unconsented processing and fabricated visual output. |
| 2. Request intake | Base64 JPEG candidate | Minimum/maximum string boundary, Base64 grammar validation, canonical Base64 round-trip check, and JPEG start/end marker validation. | Malformed payloads, mislabeled non-JPEG inputs, and oversized payloads. |
| 3. File preparation | Validated raw JPEG `Buffer` | Server-only API key requests a provider file target; credentials are not shared with Expo. | Secret disclosure to mobile clients. |
| 4. Signed upload | Raw JPEG bytes and provider-issued signed URL | URL scheme must be `https:`; upload uses `cache: "no-store"` and `redirect: "error"`. | Accidental insecure upload targets, caching of sensitive requests, and redirect-based destination changes. |
| 5. Buffer lifecycle | In-memory raw JPEG bytes | `eraseTransientAgingImage` fills the buffer with zeroes after upload and in `finally`. | Avoidable retention of raw image bytes in the JavaScript buffer. |
| 6. Provider task polling | Opaque task ID and normalized status | 15-second request abort boundary, encoded task IDs, bounded retry count, and capped wait intervals. | Unbounded requests or polling loops. |
| 7. App response | Normalized temporary image URLs and creative stage labels | Raw provider output and inferred current age are excluded by the shared normalizer; insecure preview URLs are rejected. | Unnecessary provider metadata and age inference exposure. |
| 8. History behavior | Generated output | Aging results are not written into the skin-scan history flow. | Persistence of the creative preview as a scan-history record. |

## Security Controls and Review Findings

### Credential isolation and API transport

The YouCam v2 client reads `PERFECT_YOUCAM_SKIN_V2_API_KEY` only in server code. The key is attached in the server request’s Authorization header and is not represented in any Expo client file or mobile response. The provider base URL is defined as `https://yce-api-01.makeupar.com`; the request helper also uses a 15-second `AbortController` timeout. This yields a meaningful failure boundary rather than allowing a provider request to remain indefinitely pending.

Signed uploads are a distinct trust boundary because their URLs originate from an external provider response. The shared upload client now parses the signed target URL and rejects it unless `signedUrl.protocol === "https:"`. It also sets `redirect: "error"` for authenticated provider requests and signed uploads, so the request is not silently followed to a different destination. `cache: "no-store"` communicates that these sensitive calls should not be cached by the fetch layer.

### Content validation and resource control

The prior aging route decoded any Base64-like input with `Buffer.from` and defaulted the content type to JPEG. The hardened boundary narrows acceptance to one documented input category: a JPEG image. The helper rejects payloads that are not strings, are shorter than a plausible image, exceed the bounded Base64 character limit, fail Base64 grammar validation, fail canonical decoding, exceed the approximately 10 MB byte limit, or do not carry both JPEG start (`FF D8 FF`) and end (`FF D9`) marker sequences.

These checks are intentionally layered. A filename or claimed media type is not trusted. The JPEG marker validation is inexpensive and catches obvious content-type mismatches before the private upload begins; canonical Base64 validation prevents permissive decoder behavior from accepting altered or malformed encodings. Marker checks are not a full image-parser security solution, so the production follow-up section retains defense-in-depth recommendations.

### Temporary data minimization

The aging route stores the input photo only as a local `Buffer` during provider upload. Immediately after `uploadSkinV2Image` returns, the route calls `eraseTransientAgingImage(imageBuffer)` and clears the variable. A second call in `finally` covers provider errors, timeouts, task-creation errors, and early exits after successful decode. Explicit overwriting minimizes the lifetime of this application-owned buffer; it does not by itself guarantee that all runtime, operating-system, network, or provider copies are erased.

The application does not save the aging image to skin history. The screen says that result URLs are provider-issued and temporary, and the shared normalizer admits only HTTPS preview URLs with stage labels. Provider data fields that could imply the user’s current age are purposefully omitted from the application model.

### Error behavior and logging

Client-facing errors remain concise, disclose the non-predictive feature boundary, and do not echo Base64 data, signed URLs, task IDs, API keys, or raw provider response content. Server logging records the error message rather than request bodies. In production, the HTTP access logger and error-monitoring integration must likewise be configured to redact request bodies and sensitive headers before launch.

| Finding | Status after remediation | Evidence in source |
|---|---|---|
| Server-only provider secret | Implemented | `server/youcam-skin-v2.ts` reads the environment variable inside server code only. |
| Provider request timeout | Implemented | Shared 15-second `AbortController` timeout. |
| Private upload URL scheme | Implemented | Signed URL is parsed and must use `https:`. |
| Redirect protection | Implemented | Provider API and signed upload use `redirect: "error"`. |
| Cache avoidance directive | Implemented | Provider API and signed upload use `cache: "no-store"`. |
| Image type validation | Hardened | JPEG marker, Base64 grammar, canonicalization, and byte-size checks in `server/aging-upload-security.ts`. |
| Raw buffer erasure | Hardened | Explicit zero fill after upload and in aging route `finally`. |
| Bounded polling | Implemented | Maximum 30 attempts with max five-second wait interval. |
| Raw provider response disclosure | Avoided | Only normalized `simulation` output is returned to the app. |
| Photo history persistence | Avoided for aging visualization | No aging result is added to the skin snapshot history flow. |

## Accessibility Audit and Remediations

React Native documents `accessibilityLabel`, `accessibilityHint`, `accessibilityRole`, `accessibilityState`, and live-region properties for interaction context and dynamic updates. It specifically lists `radio`, `radiogroup`, `progressbar`, and `alert` among supported roles, and describes `polite` and `assertive` live-region behavior on Android.[1] The implementation uses these native semantics without moving focus unexpectedly.

Before this audit, the aging interface already had useful baseline coverage: pressable controls generally declared button roles and labels; consent used checkbox role and checked state; controls could represent disabled state; the optional nature of the feature was visible; and the screen presented non-predictive and no-stock-image language. The remediation focused on dynamic feedback, grouped selection semantics, action consequences, and meaningful nonvisual context.

| Interface concern | Existing behavior | Remediation applied | Expected assistive-technology outcome |
|---|---|---|---|
| Aging generation in progress | Button text changed while a provider task was running. | Added a visible, politely announced `progressbar` region with `busy: true` and a clear temporary-preview label. | TalkBack can announce that preview generation is under way without forcing an interruption. |
| Generation failure | Error card was visible but had no explicit dynamic announcement. | Added `accessibilityLiveRegion="assertive"` and `accessibilityRole="alert"`. | A failure becomes immediately perceivable without relying on color or visual scanning. |
| Creative-stage choice | Mutually exclusive stage chips were generic buttons. | Added a labeled `radiogroup`; each stage is a `radio` with checked and selected state. | Users can understand that exactly one creative stage is selected. |
| Consent action | Consent had a label and checked state. | Added an accessibility hint explaining that enabling the control permits temporary previews from the selected selfie. | The control’s consequence is available beyond the visible explanatory paragraph. |
| Result image context | The image label named only the stage. | Label now states that the image is temporary, provider-generated, creative, and not a future-appearance prediction. | Users receive the privacy and non-predictive qualifier in the image’s accessible name. |
| Hub demo work | The demo loading card was visual-only status text. | Added polite live-region, progressbar role, busy state, and a descriptive label. | Dynamic demo preparation is surfaced without an unnecessary interrupt. |
| Snapshot provenance | The short visual badge did not contain a specific accessibility label. | The badge now reports source category and the associated source explanation. | A screen reader has the same source context as a sighted user. |
| Decorative header sparkles | A decorative icon could create redundant focus. | The container uses `accessibilityElementsHidden` and Android `importantForAccessibility="no-hide-descendants"`. | VoiceOver and TalkBack ignore non-informative decorative content. |

The loading and error controls align with the objective of WCAG’s status-message guidance: important changes that do not take focus should be programmatically discoverable to assistive technology.[2] The verbose text error card also supports WCAG’s error-identification objective, which requires an error to be identified and described in text rather than solely conveyed by color or styling.[3]

> This implementation is designed to support WCAG 2.1/2.2-aligned patterns; it is **not a claim of product-wide WCAG conformance**. The final product still requires supported-device testing with VoiceOver, TalkBack, Dynamic Type or font scaling, keyboard navigation on Expo web, and color-contrast checks across every theme state.

## Automated Regression Evidence

A dedicated executable test, `tests/aging-security-a11y-audit.test.ts`, was added. It directly exercises the upload-validation helper and inspects the integrated source for the required privacy and accessibility controls. It complements the existing `aging-simulation-contract.test.ts`, which protects the feature’s non-predictive contract, secure temporary URL requirement, consent boundary, no-fabricated-fallback behavior, and Skin Care Hub navigation.

| Regression assertion | Verification method |
|---|---|
| Valid bounded JPEG handling | Decodes a synthetic JPEG data URI and asserts `image/jpeg` content type and expected buffer length. |
| Non-JPEG rejection | Rejects a PNG-labeled/non-JPEG byte payload. |
| Malformed Base64 rejection | Rejects invalid Base64 characters. |
| JPEG structural boundary | Rejects data that lacks the JPEG end marker. |
| Oversized input rejection | Rejects a Base64 string above the server boundary. |
| Buffer overwriting | Retains the returned buffer reference and asserts every byte is zero after `eraseTransientAgingImage`. |
| Route integration | Confirms the aging route invokes the validation and erasure helpers and includes a `finally` safeguard. |
| HTTPS and redirect transport controls | Confirms the shared provider client contains HTTPS signed-URL enforcement, `redirect: "error"`, and `cache: "no-store"`. |
| Aging accessibility | Confirms polite and assertive live regions, radio/radiogroup roles, consent hint, and temporary-result labeling. |
| Hub accessibility | Confirms demo live-region handling, snapshot source label, and decorative icon hiding. |

The focused audit test passed after the changes. Strict TypeScript validation passed. The corrected full-suite runner executed **37 of 37** test files successfully, including all earlier mobile, privacy, product, fashion, and progress contracts. An Expo web export also completed successfully to `/tmp/closetai-security-a11y-export`.

## Remaining Production Considerations

The implemented controls reduce risk at the application boundary, but a production release should treat image privacy and accessibility as ongoing operational responsibilities. The following items are intentionally retained as required deployment follow-up rather than represented as completed repository controls.

| Priority | Production action | Rationale and acceptance evidence |
|---|---|---|
| High | Enforce HTTPS and HSTS at the public API gateway; block plaintext upstream routing. | The source uses HTTPS for provider calls, while the deployed public edge must independently enforce secure browser-to-API transport. Confirm with deployment configuration and external TLS testing. |
| High | Configure body and authorization-header redaction in access logs, observability, crash reporting, and support tooling. | The route does not log raw photo content, but infrastructure can otherwise collect sensitive request bodies. Test log redaction with a deliberately identifiable synthetic marker. |
| High | Apply per-user rate limits, payload limits at the reverse proxy, and abuse monitoring to the aging endpoint. | In-process validation is not a substitute for edge resource protection. Confirm with integration tests and monitoring alerts. |
| High | Verify provider data-processing terms, at-rest encryption, deletion mechanism, signed URL expiry, and file-retention period. | These are provider and account-level guarantees that source inspection cannot prove. Document the contractual policy and operational deletion process. |
| Medium | Use a managed secret store with rotation, least-privilege access, audit logs, and environment separation. | An environment variable boundary is correct in code, but production secret governance requires platform configuration and rotation procedure. |
| Medium | Consider image re-encoding or a hardened image decoder in an isolated service before upload if threat modeling identifies malicious-file risk. | JPEG marker validation rejects obvious mismatches but is not a complete malware or image-parser defense. |
| Medium | Test VoiceOver and TalkBack on supported OS versions; verify live-region behavior, radio selection state, and consent hint verbosity. | React Native semantics can differ by platform and assistive-technology version.[1] Record device/OS/screen-reader outcomes before release. |
| Medium | Perform visual accessibility checks with large text, bold text, reduced motion, dark and light themes, high contrast, and Expo web keyboard navigation. | Static roles and labels do not verify layout clipping, contrast, focus order, or touch-target size. |
| Low | Add an accessible success confirmation when temporary previews become available. | Current preview content appears visibly; a brief completion status could improve parity when results arrive below the control without focus movement, if validated not to become overly verbose.[2] |

## Conclusion

The aging workflow now has a tighter privacy boundary than its prior implementation. It validates the one supported image class before a private upload, blocks insecure signed upload URLs and redirect following, bounds provider activity, minimizes raw photo memory lifetime, and preserves the feature’s non-predictive and non-persistent response contract. The accessibility work makes the most consequential changes—work in progress, errors, consent consequences, mutually exclusive selections, source provenance, and temporary result meaning—programmatically available to assistive technologies.

The remaining items should be completed in the production deployment and device-test tracks. They are not evidence of a code regression; they are controls that require real infrastructure, provider-account verification, and end-user assistive-technology testing beyond what a source-level audit can prove. The repository release gate for this delivery completed successfully with strict TypeScript validation, **37/37** independent regression-test files, and a production Expo web export.

## References

[1]: https://reactnative.dev/docs/accessibility "React Native Accessibility"
[2]: https://www.w3.org/WAI/WCAG22/Understanding/status-messages.html "W3C: Understanding Success Criterion 4.1.3 Status Messages"
[3]: https://www.w3.org/WAI/WCAG22/Understanding/error-identification.html "W3C: Understanding Success Criterion 3.3.1 Error Identification"
