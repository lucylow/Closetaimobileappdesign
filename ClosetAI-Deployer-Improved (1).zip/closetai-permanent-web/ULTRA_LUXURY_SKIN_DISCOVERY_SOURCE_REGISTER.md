# Ultra-Luxury Skin Care Discovery Source Register

ClosetAI uses these as external discovery destinations only. All associated mobile records are mock discovery data, use generic product-category visuals instead of copied brand photography, and must not expose local price, inventory, checkout, medical advice, or efficacy guarantees.

| Brand | Official destination | Verified discovery context |
| --- | --- | --- |
| La Prairie | https://www.laprairie.com/en-us/collections/skin-caviar | The official Skin Caviar collection page presents products including Luxe Cream, Essence-in-Lotion, and Nighttime Oil. |
| Guerlain | https://www.guerlain.com/us/en-us/skincare/by-collection/orchidee-imperiale-black/ | The official Orchidée Impériale Black collection page presents The Cream, The Treatment, The Symbioserum, and the n-Fusion Lotion. |
| La Mer | https://www.cremedelamer.com/product/5834/12343/face/moisturizers/creme-de-la-mer | The official Crème de la Mer page presents the brand’s named moisturizing cream. |
| Augustinus Bader | https://augustinusbader.com/int/en/the-rich-cream | The official The Rich Cream page presents the brand’s named moisturizer and TFC8® technology. |
| MBR | https://mbrcare.com/ | The official MBR Medical Beauty Research USA site presents product categories including cleansers and toners, moisturizers, and serums and concentrates. |
| Valmont | https://www.lamaisonvalmont.com/en/ | The official Maison Valmont site presents its skincare destination and named external product references such as Prime Renewing Pack. |

Records preserve brand and product-family names as external discovery references only. They do not repeat quoted product prices or other commerce values because those can vary by region, product, and time.
