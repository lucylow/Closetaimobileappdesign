# Weather API source notes

Source: https://open-meteo.com/en/docs

The Open-Meteo Weather Forecast API documents a `GET /v1/forecast` endpoint that accepts latitude and longitude. Current conditions can include temperature at 2 m, apparent temperature, precipitation, weather code, wind speed, and wind gusts. The API supports a `current` variable list and can use `timezone=auto`. These fields are sufficient for ClosetAI to derive clothing-oriented weather tags such as cold, warm, rainy, windy, or clear. The implementation should treat weather data as optional styling context, use a short cache, and fall back to user-entered weather text if the request is unavailable.

No location is sent until the user explicitly grants device location permission in the mobile client.

Reference: [Open-Meteo Forecast API Documentation](https://open-meteo.com/en/docs)
