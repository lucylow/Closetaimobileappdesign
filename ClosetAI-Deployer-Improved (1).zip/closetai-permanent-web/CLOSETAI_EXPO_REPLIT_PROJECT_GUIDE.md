# ClosetAI Expo Mobile Project Guide

**ClosetAI** is a React Native mobile application built with **Expo SDK 54**, **Expo Router**, TypeScript, and a small Express server for server-only integrations. The project remains mobile-first: it can run through Expo Go on a physical phone, as an Expo web preview in Replit, or in a local Expo development environment. It is not a website replacement.

> **Important boundary:** ClosetAI's skin-care and commerce features provide user-directed visual exploration and product discovery. They do not diagnose, prescribe, predict outcomes, verify live inventory, accept payment, or create real orders.

## 1. Project capabilities

| Area | What the app does | Important boundary |
| --- | --- | --- |
| Wardrobe | Stores user wardrobe data locally and supports clearly labeled fictional adult demo wardrobes. | Demo Mode remains visibly fictional and is never presented as a real user’s inventory. |
| Outfits | Creates wardrobe-aware outfit suggestions using local context and available server-side integrations. | Outfit suggestions are styling ideas, not guarantees. |
| Virtual try-on | Uses a user-selected photo only when a user chooses to test an owned garment. | No stock model substitute is permitted. |
| Skin Care | Provides optional selfie scan, demo data, 9 named metrics, AM/PM routines, progress, and product discovery. | General visual guidance only; no medical diagnosis or treatment claim. |
| Ultra-luxury discovery | Provides external-only brand references with generic non-branded visuals. | Price, stock, cart, checkout, affiliation, and availability are fictional prototype data. |
| Mock checkout | Simulates a four-step cart confirmation locally. | No payment, address, email, order, inventory reservation, or store contact is collected or performed. |
| AR cosmetic preview | Provides local camera or user-photo cosmetic-style overlays. | The overlay is not face tracking, analysis, color correction evidence, prediction, efficacy proof, or brand-formula replication. |

## 2. Prerequisites

Install a current Node.js LTS release. The project is configured for Node.js 20 or later and uses npm-compatible scripts. Install the latest **Expo Go** application on a physical Android or iPhone device before testing the camera, image-picker, and live preview flows. Expo’s development tooling and device guidance are documented by Expo. [1] [2]

| Tool | Minimum expectation | Reason |
| --- | --- | --- |
| Node.js | 20+ | Runs the project scripts, Expo CLI, TypeScript, and Express server. |
| npm | Bundled with Node.js | Installs the locked project dependency graph. |
| Expo Go | Current store version | Opens the tunnel QR code on a physical phone. |
| Replit account | Optional | Runs the Expo web preview and combined Expo Go/API command in the cloud. |
| Perfect Corp / YouCam credentials | Optional | Required only for live server-side skin or fashion provider calls. |
| OpenAI key | Optional | Required only where the server-side image fallback is intentionally enabled. |

## 3. First local installation

Clone or unpack the project, then install dependencies from the project root.

```bash
cd Closetaimobileappdesign_improved
npm install
```

Do **not** commit or share `.env` files, access tokens, generated `node_modules`, local Expo state, or a physical-device photo. The delivered ZIP intentionally omits these folders and values.

### Standard Expo development session

Run the regular Expo menu locally.

```bash
npm start
```

Expo prints development choices such as Android, iOS, and web. If the phone and development computer are not on a dependable local network, use the tunnel command instead.

```bash
npm run expo:dev
```

Open the QR code with **Expo Go**. Approve camera and library permissions only when you want to test a relevant optional feature. If permission is denied, the app retains a safe recovery route to demo or non-camera experiences.

## 4. Replit workflow

The project contains a `.replit` configuration and dedicated scripts. Replit should use a Node.js workspace with the repository root as the working directory.

### Replit Run button and Expo Go

The default Replit **Run** command starts the Expo Go path. It first checks that Replit supplied its active workspace domain and that the database-backed server has a `DATABASE_URL`. It then starts the Express API and Metro tunnel together. Use the Expo QR code printed in the Replit console to open the mobile app in Expo Go.

```bash
npm run replit:expo
```

The preflight never prints a secret value. Replit supplies `REPLIT_DEV_DOMAIN`; add `DATABASE_URL` in **Tools → Secrets**. Provider credentials are optional for non-live flows and must remain server-only.

### Optional Replit web preview

When you need the responsive web representation instead of Expo Go, stop the active process, then run:

```bash
npm run replit:web
```

This command builds the static Expo web bundle and serves it with the existing Express API. It is suitable for navigation, disclosure, accessibility, and non-camera review. A physical device remains the correct target for camera and Expo Go behavior.

| Script | Use |
| --- | --- |
| `npm run replit:web` | Optional Replit static Expo web preview plus Express API. |
| `npm run replit:web:dev` | Metro web UI iteration. |
| `npm run replit:expo` | Replit Expo Go tunnel plus server-only API. |
| `npm run replit:expo:check` | Verifies the Replit workspace domain and `DATABASE_URL` before launching Metro. |
| `npm run expo:dev` | Local Expo Go tunnel. |
| `npm start` | Standard local Expo interactive menu. |
| `npm run replit:build` | Builds the static Expo bundle and server output for Replit deployment configuration. |
| `npm run server:dev` | Runs the local Express API for server-only feature work. |

Replit supplies `PORT`, `REPLIT_DEV_DOMAIN`, and `REPLIT_DOMAINS` at runtime. Do not manually enter those values as Replit Secrets.

## 5. Replit Secrets and credential isolation

Open **Tools → Secrets** in Replit. Add secrets there, never in source files and never as `EXPO_PUBLIC_*` values. Expo public variables are visible in the client bundle, so AI provider credentials must remain server-only.

| Secret | Required only for | Guidance |
| --- | --- | --- |
| `PERFECT_YOUCAM_API_KEY` | Core live YouCam skin analysis | Add the credential from the authorized Perfect Corp account. |
| `PERFECT_YOUCAM_SECRET_KEY` | Core server-side YouCam authentication | Pair with the matching API key. |
| `PERFECT_YOUCAM_SKIN_V2_API_KEY` | Opt-in Skin v2 cosmetic visualization routes | Keep server-only. |
| `PERFECT_YOUCAM_FASHION_API_KEY` | Authorized fashion/try-on endpoints | Optional when the core credentials cover the needed endpoint. |
| `AI_INTEGRATIONS_OPENAI_API_KEY` | Server-side image fallback, only if enabled | Keep server-only. |
| `AI_INTEGRATIONS_OPENAI_BASE_URL` | Non-default compatible API gateway | Optional override only. |
| `DATABASE_URL` | Database-backed server routes, if configured | Use the environment’s authorized PostgreSQL URL. |
| `DEMO_MODE` | Intentional labeled demo responses | Set to `true` only for controlled demonstration sessions. |

If an API key is absent or invalid, the interface should display a clear error/recovery state. It must not silently substitute a stock model photo, invent a provider result, or expose a raw provider payload.

## 6. Physical-device test plan

Use a real phone for the complete mobile flow.

| Test area | Steps | Expected result |
| --- | --- | --- |
| Navigation | Open Home, Wardrobe, Outfits, Try-On, and Skin Care. | Each route loads with a readable empty, demo, or recovery state. |
| Demo Mode | Enable Demo Mode, choose Maya, Sofia, Aisha, Leila, or Nora. | The fictional disclosure remains visible; the demo data never presents itself as a live scan or real wardrobe. |
| Selfie scan | Select a photo or open the camera, then read the consent and privacy controls. | A selfie remains optional; history stores normalized summaries rather than original photo previews. |
| Live camera | Approve camera access, frame one face, optionally enable a visual overlay, and capture. | Camera guidance is optional; age, gender, and identity classification are not requested. |
| AR texture preview | Open **Skin Care → Personal care plan → Try a cosmetic texture preview**. Pick your own photo, turn on consent, select an overlay, then clear the photo. | The overlay is local, non-predictive, and removable; no stock model, upload, formula recreation, diagnosis, or efficacy statement appears. |
| Ultra-luxury cart | Add an external reference to Mock Cart, then open the cart. | All values show mock labels and disclosure text. |
| Mock checkout | Start Mock Checkout, choose a fictional delivery label and fictional payment label, then simulate payment. | No input fields request address, email, card number, expiry, CVV, billing, or wallet data. Confirmation is a local `SIM-…` reference only. |
| Try-on | Use only a photo and garment image that you own or have permission to use. | The app must never show a stock model substitute. |

## 7. Skin Care and AR safety model

### Optional selfie and camera flows

The optional selfie scan is a user-controlled flow. Camera and image-library permissions are requested at the time a user selects a source. The live camera is used for a preview and captured frame review; it does not persist a camera stream. The app uses a single-face frame check where supported, but it does not request demographic attributes, beauty scoring, age, gender, or identity classification.

### Cosmetic visual overlays

The camera and texture-preview modes offer **Guide Only**, **Dewy Light**, **Satin Veil**, and **Soft-Focus Glow**. These are interface-level visual overlays. They intentionally do not simulate how a treatment will change a user’s skin over days or weeks.

> **The visual overlay is not a treatment forecast.** It is not a medical, dermatological, or product-performance statement.

The AR preview permits optional session-local environment and comfort labels. These labels alter only the product categories displayed for discovery. They are not live weather measurements, skin measurements, a medical assessment, a suitability judgment, or a personalized prescription.

### Product discovery hierarchy

1. **Verified routine references** use the existing CeraVe, La Roche-Posay, and The Ordinary manufacturer links.
2. **Ultra-luxury external discovery** uses source-labeled external brand destinations with generic non-branded still-life images.
3. **Mock cart and checkout** use fictional local data only. They cannot create a real transaction.

The app keeps discovery links separate from its visual overlays to avoid implying that a visual effect comes from a named product, brand, or formula.

## 8. Multi-step mock checkout specification

The mock checkout is a deliberate test harness for a future authorized commerce provider. It uses no payment SDK, no hosted checkout, no WebView, and no form fields.

| Step | Interaction | Data boundary |
| --- | --- | --- |
| 1. Cart | Review fictional lines and mock subtotal. | Local persisted mock-cart state only. |
| 2. Prototype delivery | Choose “Prototype studio handoff” or “Digital order summary.” | No address, email, phone, or fulfillment request. |
| 3. Mock payment | Choose “Mock card ending 4242” or “Mock wallet.” | Pre-filled fictional labels only; no card number, expiry, CVV, token, wallet, or billing data. |
| 4. Confirmation | Press “Simulate mock payment.” | A local `SIM-…` reference is shown. No payment, order, reservation, inventory modification, or external communication occurs. |

The mock checkout pauses if a fictional cart line is unavailable. It does not attempt to solve that condition by querying a real brand catalog.

## 9. Database and server notes

The project contains an Express server and database-oriented code. Server-side APIs own credentialed operations such as YouCam calls, OpenAI fallback routes, strict upload validation, request timeouts, and provider response normalization. The Expo client is intentionally limited to application-safe response models.

When configuring a database-backed environment, provide `DATABASE_URL` through an approved secret mechanism. Do not paste database credentials into the application code or a client-facing Expo variable. Database migration and schema changes should be reviewed separately because destructive database operations are not recoverable.

## 10. Validation commands

Run the complete validation set after code changes:

```bash
npx tsc --noEmit
npx tsx tests/*.test.ts
npx expo-doctor
npx expo export --platform web
```

The automated contract suite protects Expo dependency alignment, fictional-demo disclosures, product-link boundaries, mock commerce, user-photo-only media behavior, AR overlay safety, and Replit run configuration. `expo-doctor` validates the Expo project configuration, while a web export catches Router and bundling issues before using Replit’s web preview.

## 11. Troubleshooting

| Symptom | Likely cause | Safe recovery |
| --- | --- | --- |
| Expo Go cannot open the QR code | Tunnel command is not running or the device lacks internet access. | Re-run `npm run expo:dev` or `npm run replit:expo`, then scan the new QR code. |
| API-dependent feature reports unavailable | A server-only secret is missing, invalid, or not authorized for the endpoint. | Check Replit Secrets; do not add the value to `EXPO_PUBLIC_*`. Use the clearly labeled demo or recovery state. |
| Camera preview is unavailable | Device permission is denied or the device does not expose the requested camera. | Choose a photo or continue with Demo Mode. |
| AR texture preview has no overlay | Visual-preview consent has not been switched on, or no self-selected photo exists. | Choose your own photo, read the disclosure, then enable consent. |
| Mock checkout pauses | A fictional mock-cart line is marked unavailable. | Remove the unavailable line or return to the cart. Never attempt to infer external inventory. |
| Replit Run stops before Expo starts | The preflight found a missing Replit workspace domain or database connection string. | Launch from an active Replit workspace and add `DATABASE_URL` in Tools → Secrets. Never add a provider credential to `EXPO_PUBLIC_*`. |
| Replit preview cannot reach API | The Replit API and Expo session were started separately or the domain variable is missing. | Use `npm run replit:web` for web preview or `npm run replit:expo` for Expo Go. |

## 12. Release checklist

Before sharing a build or source archive, confirm the following.

- [ ] Strict TypeScript completes without errors.
- [ ] All contract tests pass.
- [ ] `expo-doctor` reports no project-health issues.
- [ ] `npx expo export --platform web` completes.
- [ ] Demo Mode disclosures remain visible.
- [ ] No provider secrets appear in client source or public environment variables.
- [ ] Virtual try-on and texture preview use a user-selected image only.
- [ ] No stock model, real payment field, real order, or live price/inventory claim appears.
- [ ] The checkout confirmation remains local and fictional.

## References

[1] [Expo documentation — Get started with Expo](https://docs.expo.dev/get-started/start-developing/)

[2] [Expo documentation — Expo Camera](https://docs.expo.dev/versions/latest/sdk/camera/)
