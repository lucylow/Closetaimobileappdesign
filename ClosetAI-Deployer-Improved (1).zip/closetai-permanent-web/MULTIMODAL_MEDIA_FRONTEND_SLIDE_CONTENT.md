## Cover

# ClosetAI Multimodal Media Frontend

### Accessibility, source clarity, and trustworthy temporary results

DeveloperWeek 2026 Hackathon · Expo Mobile Application

## Slide 1

# Media workflows now answer three questions

- **Which media did I select?** User photo, product reference, or wardrobe context is named before generation.
- **What is happening now?** Capture, analysis, and rendering expose visible and assistive-technology feedback.
- **What happens to the result?** Temporary provider output is labeled with non-persistence and non-guarantee boundaries.

## Slide 2

# Source-aware media is now a reusable pattern

- `MediaStatusCard` is a shared React Native component for provenance—not a data-storage layer.
- Four semantic kinds: **user photo**, **reference**, **temporary result**, and **local-only context**.
- Each card combines a stable icon, explicit title, contextual detail, and one grouped accessible announcement.

## Slide 3

# Provenance appears at every decision point

- **Add Item:** confirms the exact garment photo that will be saved.
- **Selfie review:** states that only the selected selfie can continue after consent.
- **Primary Try-On:** names the selected user photo and selected wardrobe-item context.
- **AI Shoes:** separates the target person photo from the shoe product reference.

## Slide 4

# Live camera feedback is explicit and non-blocking

- Permission is clearly optional, with a return path to other photo choices.
- Persistent status says the live camera stream is **not stored**.
- `accessibilityLiveRegion="polite"` announces frame guidance: no face, multiple faces, one face, or manual review.
- Capture control exposes disabled and busy state while frame validation is in progress.

## Slide 5

# Selfie review makes consent and analysis legible

- Selected preview receives an accessible description and a user-photo status card.
- Consent switch explains the general-guidance boundary and that consent unlocks analysis.
- Summary-save switch states that written guidance may persist while the original selfie does not enter history.
- Analysis uses a polite progress-bar announcement; errors use an assertive alert.

## Slide 6

# Generation states provide continuous feedback

- Try-On and AI Shoes actions communicate prerequisites before they are enabled.
- Action controls expose `disabled` and `busy` state to assistive technology.
- Temporary render creation is announced through a polite `progressbar` status.
- Failures become assertive alerts with recovery text—never an unexplained spinner or silent failure.

## Slide 7

# Temporary results are clearly scoped

- Provider-rendered results carry a **temporary-result** source card.
- UI states that results are not saved to history where applicable.
- Copy avoids fit, size, comfort, purchase, identity, or diagnostic claims.
- Result views provide a direct “Try another look” recovery action.

## Slide 8

# Accessible semantics match interaction intent

- Buttons use descriptive labels and outcome-focused hints.
- `progressbar` plus `busy` state communicates asynchronous camera and generation work.
- `alert` plus assertive live feedback communicates errors that change the next action.
- Decorative guide layers and icons are hidden from screen readers to prevent duplicate announcements.

## Slide 9

# Privacy and no-substitution boundaries remain intact

- User-selected media remains the foundation of the virtual try-on flow.
- No stock model, demo image, stale result, or fabricated fallback is shown on live-processing failure.
- AI Shoes retains target-photo confirmation, reference-image confirmation, and explicit creative-visualization consent.
- Camera streaming, original-selfie history, and temporary provider result boundaries remain visible in context.

## Slide 10

# Validation confirms a safe frontend upgrade

- **40 / 40** independently executed regression contracts passed.
- Release gate passed strict TypeScript and an Expo web export.
- New contract checks provenance labels, user-owned media guarantees, accessible feedback, consent, and temporary-result handling.
- Final manual release recommendation: validate VoiceOver and TalkBack announcements on physical devices.

## Slide 11

# References

[1] React Native, “Accessibility.” https://reactnative.dev/docs/accessibility

[2] W3C, “Understanding Success Criterion 4.1.3: Status Messages.” https://www.w3.org/WAI/WCAG22/Understanding/status-messages.html

[3] ClosetAI internal validation: `staging_validation/multimodal-media-complete-test-suite.log` — 40/40 passing contracts.
