# ClosetAI Mobile Design System and UI Component Reference

**Product:** ClosetAI — Personal Wardrobe Stylist and Skin Care Companion  
**Platform:** React Native, Expo SDK 54, Expo Router 6  
**Reference status:** Implemented-system documentation for the cumulative mobile application  
**Audience:** Product design, mobile engineering, QA, hackathon demonstration, and future contributors

> **Design intent:** ClosetAI combines fashion and skin-care workflows through a warm editorial visual system. The interface is calm, source-aware, and explicit about whether information is local, live, fictional Demo Mode, prototype commerce, or creative visualization.

## 1. System overview

ClosetAI uses a **warm neutral foundation**, restrained accent colors, round-cornered elevated surfaces, and Outfit typography. The visual language should make wardrobe, outfit, Skin Care, product discovery, and AI-assistive features feel connected while retaining clear boundaries for privacy-sensitive analysis and mock/prototype data.

| System layer | Implementation source | Purpose |
|---|---|---|
| Runtime theme | `constants/colors.ts`, `lib/useTheme.ts` | Light/dark semantic color resolution. |
| Typography | `@expo-google-fonts/outfit` usage across screens | Editorial but readable hierarchy. |
| Navigation | `app/(tabs)`, Expo Router routes | Top-level task switching and deep links. |
| Shared state | `contexts/AppContext.tsx`, `SkinCareContext.tsx`, `SelfieScanContext.tsx` | Wardrobe, appearance mode, care goals, completion state, scan summaries. |
| UI modules | `components/skin/*`, screens under `app/*` | Reusable flows, cards, charts, privacy disclosures, and detail surfaces. |
| Source-aware contracts | `shared/*`, `lib/*` | Keeps provider, demo, local, and mock data distinguishable. |

## 2. Core principles

The design system follows six operating principles.

1. **Source clarity.** A user should know whether an experience uses their local wardrobe, live normalized provider context, fictional Demo Mode data, or mock commerce values.
2. **User ownership.** Fashion recommendations and Try-On outputs must use user-selected source images and user-owned wardrobe inventory where promised.
3. **Calm complexity.** Dense functionality is arranged into small cards, compact chips, clear labels, and one primary next action.
4. **Privacy by interface.** The UI states what is local, what is temporary, what is not saved, and what the app does not infer.
5. **Non-medical language.** Skin visual signals are presented as cosmetic/wellness reflection guidance, never as diagnosis or treatment claims.
6. **Accessible feedback.** Buttons, chips, toggles, loading states, empty states, errors, and status labels expose their purpose visually and through accessibility roles.

## 3. Color foundations

The active implementation resolves semantic colors by light and dark appearance mode. Use semantic names (`colors.text`, `colors.surface`, `colors.tint`) in components rather than hard-coding one palette value.

### 3.1 Brand palette

| Token | Hex | Primary meaning |
|---|---:|---|
| `rose` | `#D4A574` | Warm brand neutral, dark-mode tint. |
| `accent` | `#C17F59` | Primary interactive color in light mode. |
| `roseLight` | `#E8C9A8` | Soft warm emphasis and gradient end. |
| `charcoal` | `#1A1A1A` | Primary dark text and deep surfaces. |
| `offWhite` | `#F5F0EB` | Warm neutral support surface. |
| `cream` | `#FAF7F2` | Light app background. |
| `violet` | `#6E4AE0` | Feature/AI accent. |
| `teal` | `#00C9B7` | Fresh secondary signal accent. |
| `blush` | `#F28B82` | Gentle visual highlight. |
| `gold` | `#F5C842` | Premium/warm highlight. |
| `success` | `#27AE60` | Complete, saved, or successful action state. |
| `warning` | `#F39C12` | Caution, demo, or limited-state signal. |
| `error` | `#E74C3C` | Failed action or destructive status. |

### 3.2 Light semantic tokens

| Semantic token | Value | Use |
|---|---:|---|
| `background` | `#FAF7F2` | Full-page canvas. |
| `backgroundSecondary` | `#F0EBE4` | Section and subtle contextual surface. |
| `surface` / `card` | `#FFFFFF` | Primary cards and controls. |
| `surfaceSecondary` | `#F5F0EB` | Nested cards, charts, and subdued actions. |
| `text` | `#1A1A1A` | Primary headings and body text. |
| `textSecondary` | `#6B6560` | Supporting descriptions. |
| `textTertiary` | `#9B9590` | Metadata, notes, and visual source detail. |
| `tint` / `primary` | `#C17F59` | Calls to action, selected states, icons. |
| `border` | `#E8E3DC` | Card outlines and control boundaries. |

### 3.3 Dark semantic tokens

| Semantic token | Value | Use |
|---|---:|---|
| `background` | `#0D0D0D` | Full-page canvas. |
| `backgroundSecondary` | `#1A1A1A` | Secondary sections. |
| `surface` | `#1A1A1A` | Cards and primary controls. |
| `surfaceSecondary` | `#242424` | Nested cards and charts. |
| `text` | `#F5F0EB` | Primary readable text. |
| `textSecondary` | `#9B9590` | Supporting text. |
| `textTertiary` | `#666666` | Metadata and low-emphasis labels. |
| `tint` | `#D4A574` | Selected controls and primary actions. |
| `border` | `#2A2A2A` | Dividers and cards. |

### 3.4 Gradients and shadows

The system includes `primary`, `violet`, `teal`, `warm`, `sunset`, and glass gradients for hero or immersive feature surfaces. Use gradients sparingly: one visual focus per screen. The standard shadows are `soft`, `medium`, and `elevated`; `glow(color)` is reserved for interactive or AI-feature emphasis.

```ts
const primaryGradient = ["#C17F59", "#D4A574"] as const;
const softShadow = {
  shadowColor: "#000",
  shadowOffset: { width: 0, height: 2 },
  shadowOpacity: 0.06,
  shadowRadius: 8,
  elevation: 2,
};
```

## 4. Typography

ClosetAI uses the **Outfit** family. Font weights establish hierarchy without switching families.

| Role | Font | Typical size | Typical line height | Use |
|---|---|---:|---:|---|
| Hero/title | `Outfit_700Bold` | 19–30 | 1.2× | Screen titles, key dashboard value. |
| Section/card title | `Outfit_600SemiBold` | 14–18 | 1.3× | Cards, group headings, list labels. |
| Action/selected label | `Outfit_700Bold` or `600SemiBold` | 9–12 | 1.3× | Chips, buttons, direction badges. |
| Body | `Outfit_400Regular` | 10–14 | 1.4× | Guidance, explanations, privacy notes. |
| Metadata | `Outfit_400Regular` / `500Medium` | 8–10 | 1.4× | Source labels, timestamps, provider notes. |
| Eyebrow | `Outfit_700Bold` | 8 | 1.2× | `CLOSET A.I. · SKIN CARE` context label. |

Typography rules: use sentence case for explanatory labels; use all caps only for compact status tokens such as `DAILY`, `OPTIONAL`, or a constrained provenance tag. Supporting text must maintain sufficient line height and avoid low-contrast tint-only body copy.

## 5. Spacing, shape, and elevation

The implemented visual rhythm uses a compact 4-point-related scale.

| Token concept | Typical values | Use |
|---|---:|---|
| Micro gap | 4–6 | Icon/text and metadata alignment. |
| Compact gap | 8–10 | Inside chips, rows, cards. |
| Standard gap | 12–14 | Card padding, grouped content. |
| Section gap | 16–20 | Between major cards or screen areas. |
| Page padding | 20 | `SkinJourneyPage` and detailed mobile flows. |
| Button radius | 10–12 | Buttons, chips, compact action containers. |
| Card radius | 17–18 | Primary feature cards and progress surfaces. |
| Surface border | 1 | Warm neutral or dark semantic border. |

A standard card uses `backgroundColor: colors.surface`, `borderColor: colors.border`, `borderWidth: 1`, `borderRadius: 17–18`, and `padding: 14`. Preserve this treatment for new cards unless a screen intentionally uses a hero or full-bleed media surface.

## 6. Navigation architecture

The application uses Expo Router. Primary sections use tab navigation; specialized features use routes and deep links.

| Destination | Route pattern | Purpose |
|---|---|---|
| Home | `/(tabs)/index` | Personal style and product entry experience. |
| Wardrobe | `/(tabs)/wardrobe` | User-owned item inventory and garment metadata. |
| Outfits | `/(tabs)/outfits` | Generated and saved user-wardrobe looks. |
| Try-On | `/(tabs)/tryon` | Fashion feature entry and specialized shoe try-on link. |
| Skin Care | `/(tabs)/skin` | Canonical Skin Care hub. |
| Skin journey | `/skin/[...page]` | Results, routine, products, progress, goals, style match, privacy. |
| Specialized Skin AI | `/skin/*` | Aging, simulation, color tones, face attributes, face lift, AI smile, abs filter, and related consent-based tools. |
| Shoe try-on | `/tryon/shoes` | User-target plus shoe-reference workflow. |

Navigation rules: every destination must have a visible return path; deep screens use a header back control; routes that work with user-selected images must state ownership/consent before the call to action.

## 7. Shared interaction patterns

### 7.1 Primary action

Use a filled tint or text-colored button with high-contrast label. Primary actions are single-purpose: start an optional scan, generate from wardrobe, save a check-in, or build a look.

```tsx
<Pressable
  onPress={onPrimaryAction}
  style={[styles.button, { backgroundColor: colors.text }]}
  accessibilityRole="button"
>
  <Text style={[styles.buttonText, { color: colors.background }]}>Generate from my wardrobe</Text>
</Pressable>
```

### 7.2 Secondary / outline action

Use a bordered surface for education, local settings, manufacturer details, or secondary navigation.

```tsx
<Pressable style={[styles.outlineButton, { borderColor: colors.border }]}>
  <Text style={[styles.outlineButtonText, { color: colors.text }]}>Review privacy choices</Text>
</Pressable>
```

### 7.3 Chips and segmented choices

Chips are used for metrics, routines, occasions, AM/PM filters, and feature styles. Selected state applies tint border and low-alpha tint background. Use `accessibilityRole="radio"` and `accessibilityState={{ checked }}` for mutually exclusive controls.

### 7.4 Checkable routine rows

Routine rows pair an icon state with title, general-care guidance, reason, and optional catalog link. Completion represents **local planning state**, never confirmed use or an outcome.

### 7.5 Loading, error, and empty states

| State | Visual treatment | Required copy boundary |
|---|---|---|
| Loading | Native `ActivityIndicator`, quiet surface. | State that data is loading; do not show invented values. |
| Error | Supporting text plus retry action. | Explain the unavailable operation; preserve local flow. |
| Empty | Calm explanation and next action. | Never replace missing user inventory or live provider output with a stock result. |
| Demo | Flask/source badge and fictional label. | State that values are fictional and not a personal assessment. |
| Mock commerce | Mandatory disclosure. | State price, inventory, cart, and checkout values are fictional prototype data. |

## 8. Source and privacy status language

Source labels are a first-class component pattern. They appear in Skin Care results, recommended products, Skin × Style, progress, cosmetic visualization, and Try-On.

| Context | Preferred label | Never claim |
|---|---|---|
| Live normalized context | “Live normalized visual context.” | Diagnosis, age, identity, attractiveness, treatment result. |
| Demo Mode | “Fictional Demo Mode.” | That the demo is the user’s personal result. |
| No scan | “Built from local goals only.” | Fabricated visual precision. |
| Local history | “Saved normalized scores only.” | That original selfies are in history. |
| Temporary provider image | “Temporary provider preview.” | Persistent storage if it is not saved. |
| Mock commerce | Mandatory prototype disclosure. | Live stock, price, checkout, or transaction. |

## 9. Core mobile UI components

### 9.1 `SkinCareHub`

**Location:** `components/skin/SkinCareHub.tsx`  
**Role:** Canonical Skin Care landing surface.  
**Composition:** Header, core care actions, privacy-safe analysis entry points, demo/live scan choices, optional advanced feature routes.

Use it for high-level wayfinding. Every advanced feature must have a clear capability and consent label. Do not bury a cosmetic simulation within a medical-sounding diagnostic card.

### 9.2 `SkinJourneyPage`

**Location:** `components/skin/SkinJourneyPage.tsx`  
**Role:** Multi-route detail renderer for results, concerns, routine, products, progress, goals, check-in, settings, and Skin × Style.

It is the main reference for card, header, action, chip, disclosure, and source-reason styling. New care subroutes should reuse its semantic colors, 20-point page padding, compact cards, and explicit state labels.

### 9.3 `SkinIntelligenceDashboard`

**Location:** `components/skin/SkinIntelligenceDashboard.tsx`  
**Role:** Turns normalized skin data into an intelligible dashboard rather than raw provider payload.

Rules: display source, availability/coverage, signal priorities, and non-diagnostic explanations. Never render raw service JSON, masks, original images, or provider-specific score semantics directly.

### 9.4 `SkinMetricProgressChart`

**Location:** `components/skin/SkinMetricProgressChart.tsx`  
**Role:** Your Progress local snapshot view.

The current component provides an overview, source badge, metric selector, direction label, chart bars, accessibility labels, reflection prompt, refresh, and explicit local-history clearing. It uses `Up`, `Down`, `Steady`, `Mixed sources`, and `More snapshots needed` as neutral display directions.

### 9.5 `MockCommercePanel`

**Location:** `components/skin/MockCommercePanel.tsx`  
**Role:** Demonstrates provider-like listing/cart behavior without claiming live commerce.

All use must retain the source-of-truth mock commerce disclosure. Do not reuse it in a non-prototype environment without an approved server-side provider adapter.

### 9.6 `LiveSkinCamera`

**Location:** `components/skin/LiveSkinCamera.tsx`  
**Role:** Optional live image capture with face-presence guidance and review flow.

Design rules: camera permissions are explicit; image choice remains user-controlled; errors preserve manual-review options; original image storage must follow the scan privacy policy.

## 10. Fashion and wardrobe components

### 10.1 Wardrobe inventory

A `WardrobeItem` is the fashion source of truth for Skin × Style and outfit generation. Item cards use category, color, tags, brand, notes, usage count, and last-worn metadata. Do not display a suggested look with an item that is not present in the user’s inventory.

### 10.2 Outfit recommendation cards

Outfit cards show user-owned item names, occasion, tags, reasoning, and optional weather readiness. The UI should frame a look as an edit or inspiration—not a mandated outfit.

### 10.3 Virtual Try-On

The Try-On surface makes provider readiness and user-image ownership visible. Dedicated shoe try-on uses separate target and shoe-reference selection. Results must not fall back to a stock model image when a user image or provider result is unavailable.

## 11. Skin Care workflow reference

| Feature | Primary UI pattern | Required disclosure / rule |
|---|---|---|
| Optional selfie scan | Permission and photo-quality guidance | General visual guidance, not medical advice. |
| Demo Mode | Preloaded profile and source badge | Fictional values, separate from live analysis. |
| Personalized AM/PM routine | Daily/optional steps, goal links, completion checks | Completion is local planning state. |
| Recommended Products | Source header, reasons, AM/PM filters, catalog detail link | Manufacturer references; no suitability, price, stock, or efficacy claim. |
| Your Progress | Overview, metric chips, bars, source direction, clear action | Local normalized values only; no clinical progress claim. |
| Skin × Style | Occasion chips, optional palette, user-owned look cards | Inspiration only; no identity or color-season inference. |
| Cosmetic visualizations | Consent card, bounded controls, temporary preview | User photo only; non-medical; no fabricated fallback. |

## 12. Iconography

The app primarily uses Ionicons. Match icon meaning to an action or state rather than adding decorative icon noise.

| Meaning | Existing icon examples |
|---|---|
| Navigation back | `chevron-back` |
| Scan / capture | `camera-outline` |
| Care planner | `list-outline` |
| Product / catalog | `bag-outline` |
| Wardrobe / style | `shirt-outline` |
| Progress | `trending-up-outline`, `calendar-outline` |
| Privacy | `shield-checkmark-outline` |
| Successful completion | `checkmark-circle`, `checkmark-done-circle-outline` |
| Demo Mode | `flask-outline` |
| Live AI context | `sparkles-outline` |

Icons should be accompanied by visible labels for non-obvious actions and accessibility labels on interactive icon controls.

## 13. Accessibility reference

1. Provide `accessibilityRole="button"` for actions and `accessibilityRole="radio"` for exclusive choices.
2. For checkable routine steps, use `accessibilityRole="checkbox"` with `accessibilityState={{ checked }}`.
3. Chart bars need summary labels containing the metric, score, date, and source.
4. Preserve non-color indicators: text labels such as `Demo`, `Live`, `Daily`, or `Optional` accompany color states.
5. Keep description text readable: body copy uses adequate line height and semantic text colors.
6. Ensure error, unavailable, and empty states explain the next possible action.
7. Do not use an image alone to communicate the state of a consent-required or privacy-sensitive action.

## 14. Content and voice guidelines

The app voice is warm, direct, and careful with claims.

| Do | Do not |
|---|---|
| “Optional palette direction. Your taste stays in charge.” | “These colors are proven to suit you.” |
| “Normalized snapshot direction for reflection.” | “Your skin has clinically improved.” |
| “Fictional Demo Mode reference values.” | “Your results” for demo data. |
| “Review manufacturer details.” | “Buy the best product for your skin.” |
| “Generated result is not saved to history.” | Assume a temporary provider preview is persistent. |
| “Add items you own to build a look.” | Show a fictional wardrobe look as a fallback. |

## 15. New component contribution checklist

Before adding a screen or component, confirm the following.

```text
[ ] Uses semantic `useTheme()` colors, not a hard-coded light-only palette.
[ ] Uses Outfit typography and the standard card/button/chip rhythm.
[ ] Has a clear loading, unavailable, and empty state.
[ ] Uses appropriate accessibility role and state for interactive controls.
[ ] States whether data is local, live, fictional demo, mock, or temporary.
[ ] Avoids raw provider output, diagnostic language, and stock-image fallbacks.
[ ] Routes actions to an existing or newly validated destination.
[ ] Adds regression coverage for relevant source, privacy, and navigation rules.
[ ] Passes strict TypeScript and Expo web export.
```

## 16. QA visual review checklist

| Area | Visual check |
|---|---|
| Light mode | Warm background, white cards, accent contrast, readable metadata. |
| Dark mode | No dark-mode gaps, clear surface separation, accent visibility. |
| Long content | Text wraps without clipping, controls remain visible. |
| Small screens | Page padding remains 20 or appropriately responsive; chip rows wrap. |
| Loading/error | No fake chart, product, wardrobe, or provider output. |
| Demo Mode | Flask/source language remains visible in headers and trend notes. |
| Privacy | Original image and raw provider content never appear in progress/history UI. |
| Buttons | Every action has a complete navigation, save, retry, or state result. |
| Try-On | User-selected source is visible; no stock-model fallback. |
| Commerce | Mock values carry the mandatory prototype disclosure. |

## 17. Maintainer references

| Reference file | Why it matters |
|---|---|
| `constants/colors.ts` | Canonical palette, gradients, shadows, and semantic light/dark colors. |
| `lib/useTheme.ts` | Runtime light/dark token resolution. |
| `components/skin/SkinJourneyPage.tsx` | Standard detailed Skin Care surface, action, card, chip, and disclosure patterns. |
| `components/skin/SkinCareHub.tsx` | Canonical module entry and feature wayfinding. |
| `components/skin/SkinMetricProgressChart.tsx` | Privacy-safe snapshot-trend interaction reference. |
| `lib/skin-progress-trends.ts` | Source-aware progress contract and non-clinical direction labels. |
| `lib/personalized-skin-routine.ts` | AM/PM routine vocabulary and local completion treatment. |
| `lib/recommended-skin-products.ts` | Explainable catalog recommendation pattern. |
| `lib/skin-style-plan.ts` | Wardrobe-only, source-aware style planning pattern. |
| `shared/outfit-recommendations.ts` | Actual wardrobe outfit composition contract. |

## 18. Versioning and governance

Treat the design system as a product contract. Token changes should be made in `constants/colors.ts`; global typography changes should be evaluated across the Skin Care, wardrobe, outfits, and Try-On surfaces. New AI features must add a source label, disclosure, error state, and test coverage before being added to the hub.

For hackathon delivery, this document is the baseline reference. For production, maintain a changelog with token changes, accessibility review outcomes, privacy disclosure changes, and supported platform variations.
