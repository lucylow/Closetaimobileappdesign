# ClosetAI Skin Care: Active Expo Mock-First Experience

## Active Expo routing repair

The repository included both a root React Native Expo Router application at `app/` and a separate Figma web source tree at `src/app/`. Expo Router prioritised the `src/app/` path, so it tried to load the unrelated React Router web prototype rather than the mobile app. The Figma source has been preserved under `legacy-figma-source/app/`, allowing the root `app/` directory to be the active Expo Router tree.

## Completed mobile Skin Care implementation

The active native and classic tab layouts include a dedicated **Skin** destination. Opening this tab immediately renders a complete, scrollable, offline-first mock Skin Care dashboard. It does not require a selfie, camera permission, internet connection, API key, account, backend, database, or YouCam availability.

The dashboard includes three typed, rotating demo profiles—Combination, Dry, and Oily—plus a polished Demo Mode banner, score card, profile headline, focused priorities, nine visual mock metrics, expandable AM and PM routines, fictional demo product recommendations, three Skin × Wardrobe palette ideas, outfit and wardrobe handoffs, demo history progress bars, product-preview alerts, and a dedicated information control. All mock values are labelled as fictional prototype guidance, never as medical diagnosis or live YouCam output.

An optional selfie journey remains available through the camera action and **Add Selfie** control. It supports camera and library permission recovery, front-camera capture, EXIF suppression, local image-readiness feedback, face-centering guidance, retake gating for insufficient images, and fast demo-mode analysis. The demo dashboard is unaffected if a selfie is never provided or photo permission is denied.

## Key source additions

| File | Responsibility |
|---|---|
| `app/(tabs)/skin.tsx` | Active direct Skin tab route. |
| `app/(tabs)/_layout.tsx` | Registers Skin in classic and native tab bars. |
| `app/skin.tsx` | Keeps the modal-compatible Skin route. |
| `components/skin/SkinScreen.tsx` | Shared active Skin experience, optional selfie flow, mock-scan orchestration, and tab-safe header. |
| `components/skin/MockSkinDashboard.tsx` | Mock-first dashboard with reusable metric, routine, priority, product, palette, and progress UI. |
| `lib/skin-demo-profiles.ts` | Typed Combination, Dry, and Oily rotating mock profiles. |
| `lib/skin-demo-content.ts` | Typed offline priority, product, wardrobe-palette, and progress content. |
| `lib/selfie-quality.ts` | Local selfie-readiness and safe bounded-progress helpers. |
| `legacy-figma-source/app/` | Preserved inactive Figma web-source tree, moved outside Expo Router precedence. |

## Validation

The changed route, shared Skin Care components, and mock-data modules pass targeted ESLint. The active root Expo Router application also completed a successful web export with `npx expo export --platform web`, confirming that the extended mobile Skin Care experience bundles from the intended `app/` route tree.
