import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useContext, useEffect, useMemo, useState } from "react";

import { type SkinGoalId } from "@/lib/skin-navigation-data";
import { keepTodayRoutineCompletions, routineCompletionKey } from "@/lib/personalized-skin-routine";

type RoutinePeriod = "AM" | "PM";

interface SkinCareState {
  selectedGoals: SkinGoalId[];
  remindersEnabled: boolean;
  savedProductIds: string[];
  completedSteps: string[];
  checkInNote: string;
  lastCheckIn: string | null;
  setSelectedGoals: (goals: SkinGoalId[]) => void;
  toggleGoal: (goal: SkinGoalId) => void;
  setRemindersEnabled: (enabled: boolean) => void;
  toggleSavedProduct: (productId: string) => void;
  toggleRoutineStep: (period: RoutinePeriod, stepId: string) => void;
  setCheckIn: (note: string) => void;
}

const STORAGE_KEY = "closetai-skin-care-preferences-v1";

const SkinCareContext = createContext<SkinCareState | null>(null);

export function SkinCareProvider({ children }: { children: React.ReactNode }) {
  const [selectedGoals, setSelectedGoals] = useState<SkinGoalId[]>(["hydration", "radiance"]);
  const [remindersEnabled, setRemindersEnabled] = useState(true);
  const [savedProductIds, setSavedProductIds] = useState<string[]>([]);
  const [completedSteps, setCompletedSteps] = useState<string[]>([]);
  const [checkInNote, setCheckInNote] = useState("");
  const [lastCheckIn, setLastCheckIn] = useState<string | null>(null);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY)
      .then((raw) => {
        if (!raw) return;
        const saved = JSON.parse(raw);
        setSelectedGoals(saved.selectedGoals ?? ["hydration", "radiance"]);
        setRemindersEnabled(saved.remindersEnabled ?? true);
        setSavedProductIds(saved.savedProductIds ?? []);
        setCompletedSteps(keepTodayRoutineCompletions(saved.completedSteps ?? []));
        setCheckInNote(saved.checkInNote ?? "");
        setLastCheckIn(saved.lastCheckIn ?? null);
      })
      .catch(() => undefined)
      .finally(() => setHydrated(true));
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    AsyncStorage.setItem(
      STORAGE_KEY,
      JSON.stringify({ selectedGoals, remindersEnabled, savedProductIds, completedSteps: keepTodayRoutineCompletions(completedSteps), checkInNote, lastCheckIn }),
    ).catch(() => undefined);
  }, [selectedGoals, remindersEnabled, savedProductIds, completedSteps, checkInNote, lastCheckIn, hydrated]);

  const value = useMemo<SkinCareState>(
    () => ({
      selectedGoals,
      remindersEnabled,
      savedProductIds,
      completedSteps,
      checkInNote,
      lastCheckIn,
      setSelectedGoals,
      toggleGoal: (goal) => {
        setSelectedGoals((current) =>
          current.includes(goal) ? current.filter((item) => item !== goal) : [...current, goal],
        );
      },
      setRemindersEnabled,
      toggleSavedProduct: (productId) => {
        setSavedProductIds((current) =>
          current.includes(productId) ? current.filter((item) => item !== productId) : [...current, productId],
        );
      },
      toggleRoutineStep: (period, stepId) => {
        const key = routineCompletionKey(period, stepId);
        setCompletedSteps((current) =>
          current.includes(key) ? current.filter((item) => item !== key) : [...current, key],
        );
      },
      setCheckIn: (note) => {
        setCheckInNote(note);
        setLastCheckIn(new Date().toISOString());
      },
    }),
    [selectedGoals, remindersEnabled, savedProductIds, completedSteps, checkInNote, lastCheckIn],
  );

  return <SkinCareContext.Provider value={value}>{children}</SkinCareContext.Provider>;
}

export function useSkinCare() {
  const context = useContext(SkinCareContext);
  if (!context) throw new Error("useSkinCare must be used within SkinCareProvider");
  return context;
}
