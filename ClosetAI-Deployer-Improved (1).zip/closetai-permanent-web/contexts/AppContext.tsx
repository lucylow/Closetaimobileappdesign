import React, { createContext, useContext, useState, useEffect, useCallback, useMemo, ReactNode } from 'react';
import { Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Crypto from 'expo-crypto';
import * as FileSystem from 'expo-file-system';
import {
  WardrobeItem,
  Outfit,
  TryOnResult,
  CaptionResult,
  demoCaptions,
  demoWardrobeItems,
  cloneFictionalAdultWomenDemoExample,
  FICTIONAL_ADULT_WOMEN_DEMO_DISCLOSURE,
} from '@/lib/demo-data';
import { type LanguageCode, translate } from '@/lib/i18n';
// @ts-ignore
import * as Localization from 'expo-localization';
import { apiRequest, setAuthToken, clearAuthToken, getAuthToken } from '@/lib/query-client';
import { buildWardrobeRecommendations } from '@shared/outfit-recommendations';
import { derivePersonalStyleProfile, normalizePersonalStyleProfile, type PersonalStyleProfile } from '@shared/personal-style-profile';
import { defaultFashionTryOnDisclosure, fashionProviderFromJobStatus, type FashionTryOnResultProvider } from '@shared/fashion-tryon-result';

export interface SubscriptionTier {
  id: string;
  name: string;
  price: number;
  monthlyCredits: number;
  features: string[];
}

export const SUBSCRIPTION_TIERS: SubscriptionTier[] = [
  {
    id: 'free',
    name: 'Free Tier',
    price: 0,
    monthlyCredits: 25,
    features: ['3 Virtual Try-Ons/Day', 'Basic Wardrobe Organization', 'Standard AI Style Suggestions', '25 Credits/Month'],
  },
  {
    id: 'pro',
    name: 'Pro Creator & Stylist',
    price: 19.99,
    monthlyCredits: 1500,
    features: ['Unlimited Virtual Try-On & AR', 'HD High-Resolution Renders', 'Priority YouCam / OpenAI Pipeline', '1,500 Monthly Credits', 'Affiliate Revenue Sharing', 'Advanced Agent Studio Access'],
  },
  {
    id: 'enterprise',
    name: 'Enterprise & Brand',
    price: 499.0,
    monthlyCredits: 100000,
    features: ['White-Label Storefront Integration', 'Direct API Access', 'Custom Model Fine-Tuning', '100,000 Monthly Credits', 'Brand Analytics Dashboard', 'Dedicated Account Manager'],
  },
];

interface AppState {
  isGuest: boolean;
  demoMode: boolean;
  isDark: boolean;
  language: LanguageCode;
  isLanguageSwitching: boolean;
  hasSeenOnboarding: boolean;
  wardrobeItems: WardrobeItem[];
  outfits: Outfit[];
  savedOutfits: Outfit[];
  isLoading: boolean;
  credits: number;
  isAuthenticated: boolean;
  subscriptionTier: string;
  creditsUsed: number;
  monthlyCredits: number;
  recommendationSource: 'idle' | 'live-ai' | 'hybrid' | 'youcam-live-ai' | 'youcam-wardrobe' | 'wardrobe-fallback' | 'unavailable';
  recommendationNotice: string | null;
  styleProfile: PersonalStyleProfile;
}

interface AppContextValue extends AppState {
  setDemoMode: (v: boolean) => void;
  setLanguage: (lang: LanguageCode) => Promise<void>;
  t: (key: string, fallback?: string) => string;
  clearBlankLiveState: () => Promise<void>;
  /** Loads an explicitly chosen, clearly fictional adult women’s demo wardrobe only in Demo Mode. */
  loadFictionalAdultWomenDemoExample: (id: string) => Promise<void>;
  toggleTheme: () => void;
  setHasSeenOnboarding: (v: boolean) => void;
  signInAsGuest: () => void;
  signOut: () => void;
  addWardrobeItem: (item: Omit<WardrobeItem, 'id' | 'createdAt' | 'usageCount' | 'lastWorn'>) => Promise<void>;
  removeWardrobeItem: (id: string) => Promise<void>;
  updateWardrobeItem: (id: string, data: Partial<WardrobeItem>) => Promise<void>;
  markItemWorn: (id: string) => Promise<void>;
  rateOutfit: (id: string, rating: 'like' | 'neutral' | 'dislike') => void;
  saveOutfit: (id: string) => void;
  unsaveOutfit: (id: string) => void;
  generateOutfits: (occasion?: string, weather?: string, colorPalette?: string[]) => Promise<void>;
  getExplanation: (id: string) => string;
  generateCaption: (outfitId: string, tone?: string, platform?: string) => Promise<CaptionResult>;
  createTryOn: (selfieUri: string, garmentIds: string[]) => Promise<TryOnResult>;
  refreshWardrobe: () => Promise<void>;
  getStyleInsight: () => Promise<{ insight: string; dominantStyle: string; suggestion: string }>;
  upgradeTier: (tier: string) => Promise<void>;
  canUseCredit: () => boolean;
  trackAffiliate: (productName: string, productUrl: string, source: string) => Promise<void>;
  updateStyleProfile: (profile: PersonalStyleProfile) => Promise<void>;
}

const AppContext = createContext<AppContextValue | null>(null);

const STORAGE_KEYS = {
  WARDROBE: '@closetai_wardrobe',
  OUTFITS: '@closetai_outfits',
  SAVED_OUTFITS: '@closetai_saved_outfits',
  ONBOARDING: '@closetai_onboarding',
  THEME: '@closetai_theme',
  DEMO: '@closetai_demo',
  GUEST: '@closetai_guest',
  STYLE_PROFILE: '@closetai_style_profile',
  LANGUAGE: '@closetai_language',
};

type CompletedTryOnJobResponse = {
  id?: unknown;
  status?: unknown;
  resultImageUrl?: unknown;
  errorMessage?: unknown;
  createdAt?: unknown;
};

function createUserPhotoTryOnFallback(
  selfieUri: string,
  garmentIds: string[],
  jobId?: string,
  disclosure = 'Live virtual try-on did not provide a completed render. Your selected photo preview is shown instead; no stock model or unrelated image was used.',
): TryOnResult {
  return {
    id: jobId || Crypto.randomUUID(),
    selfieUri,
    garmentIds,
    resultImageUrl: selfieUri,
    status: 'done',
    createdAt: new Date().toISOString(),
    isUserPhotoPreview: true,
    disclosure,
    provider: 'photo-preview',
  };
}

function isSafeCompletedTryOnImageUrl(value: unknown): value is string {
  return typeof value === 'string'
    && (value.startsWith('https://') || /^data:image\/(?:png|jpe?g);base64,[A-Za-z0-9+/]+={0,2}$/.test(value));
}

function isTerminalTryOnJobStatus(value: unknown): boolean {
  if (typeof value !== 'string') return false;
  const status = value.toLowerCase();
  return status.startsWith('completed') || ['done', 'success', 'failed', 'error', 'cancelled'].includes(status);
}

function getTryOnPollingStatus(value: unknown): string | null {
  if (!value || typeof value !== 'object') return null;
  const status = (value as { status?: unknown }).status;
  if (typeof status !== 'string' || status.trim().length === 0) return null;
  return status.trim().toLowerCase();
}

function normalizeCompletedTryOnJob(
  response: CompletedTryOnJobResponse,
  selfieUri: string,
  garmentIds: string[],
): TryOnResult | null {
  const provider = fashionProviderFromJobStatus(typeof response.status === 'string' ? response.status : undefined);
  const jobId = typeof response.id === 'string' && response.id.trim().length > 0 ? response.id : undefined;
  if (!provider) return null;
  if (provider === 'photo-preview') {
    return createUserPhotoTryOnFallback(
      selfieUri,
      garmentIds,
      jobId,
      'Live virtual try-on is unavailable for this completed job. Your selected photo preview is shown instead; no stock model or unrelated image was used.',
    );
  }
  if (!jobId || !isSafeCompletedTryOnImageUrl(response.resultImageUrl)) {
    return createUserPhotoTryOnFallback(
      selfieUri,
      garmentIds,
      jobId,
      'Live virtual try-on returned an incomplete result. Your selected photo preview is shown instead; no stock model or unrelated image was used.',
    );
  }
  return {
    id: jobId,
    selfieUri,
    garmentIds,
    resultImageUrl: response.resultImageUrl,
    status: 'done',
    createdAt: typeof response.createdAt === 'string' ? response.createdAt : new Date().toISOString(),
    isUserPhotoPreview: false,
    disclosure: defaultFashionTryOnDisclosure(provider as FashionTryOnResultProvider),
    provider,
  };
}

type TryOnRequestRecovery =
  | { kind: 'actionable'; message: string }
  | { kind: 'photo-preview'; disclosure: string };

function resolveTryOnRequestRecovery(error: unknown): TryOnRequestRecovery {
  const message = error instanceof Error ? error.message : '';
  const statusMatch = message.match(/^[0-9]{3}:/);
  const status = statusMatch ? Number(message.slice(0, 3)) : null;
  if (message.includes('EXPO_PUBLIC_DOMAIN is not set')) {
    return { kind: 'actionable', message: 'Live try-on is not configured for this session. Check the Expo/Replit API address or continue in Demo Mode.' };
  }
  if (status === 401 || status === 403) {
    return { kind: 'actionable', message: 'Your live try-on session needs to be refreshed before you can try again. Your selected photo was not replaced.' };
  }
  if (status === 400 || status === 404 || status === 409 || status === 413 || status === 422) {
    return { kind: 'actionable', message: 'Your selected photo or wardrobe choice needs attention before live try-on can continue. Choose a clear photo of yourself and available wardrobe items, then try again.' };
  }
  if (status === 402) {
    return { kind: 'actionable', message: 'Live virtual try-on needs 10 available credits. Review your plan or continue in Demo Mode.' };
  }
  if (status === 408 || status === 504) {
    return { kind: 'actionable', message: 'Live virtual try-on timed out before a rendered result was produced. Please retry when the provider is responsive.' };
  }
  if (status === 429) {
    return { kind: 'actionable', message: 'Live virtual try-on is temporarily busy. Please retry in a moment.' };
  }
  if (status !== null && status >= 500 && status <= 599) {
    return { kind: 'actionable', message: 'Live virtual try-on is temporarily unavailable. No rendered result was produced; please retry later.' };
  }
  return { kind: 'actionable', message: 'Live virtual try-on could not be completed. No rendered result was produced; please retry.' };
}

function mapApiItemToLocal(apiItem: any): WardrobeItem {
  return {
    id: apiItem.id,
    name: apiItem.name,
    category: apiItem.category,
    color: apiItem.color || '',
    brand: apiItem.brand || '',
    imageUrl: apiItem.imageUrl || '',
    tags: apiItem.tags || [],
    usageCount: apiItem.usageCount || 0,
    lastWorn: apiItem.lastWornAt || null,
    notes: apiItem.notes || '',
    createdAt: apiItem.createdAt,
  };
}

function mapApiOutfitToLocal(apiOutfit: any, wardrobeItems: WardrobeItem[]): Outfit {
  const itemIds: string[] = apiOutfit.itemIds || [];
  const items = itemIds.map(id => wardrobeItems.find(w => w.id === id)).filter(Boolean) as WardrobeItem[];
  return {
    id: apiOutfit.id,
    name: apiOutfit.name || 'Untitled Outfit',
    items,
    tags: apiOutfit.tags || [],
    reason: apiOutfit.reason || '',
    occasion: apiOutfit.occasion || '',
    rating: apiOutfit.rating || null,
    saved: apiOutfit.saved || false,
    explanation: apiOutfit.explanation || '',
    score: apiOutfit.score ? parseFloat(apiOutfit.score) : 0.8,
  };
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [isGuest, setIsGuest] = useState(true);
  const [demoMode, setDemoModeState] = useState(true);
  const [isDark, setIsDark] = useState(false);
  const [language, setLanguageState] = useState<LanguageCode>('en');
  const [isLanguageSwitching, setIsLanguageSwitching] = useState(false);
  const [hasSeenOnboarding, setHasSeenOnboardingState] = useState(false);
  const [wardrobeItems, setWardrobeItems] = useState<WardrobeItem[]>([]);
  const [outfits, setOutfits] = useState<Outfit[]>([]);
  const [savedOutfits, setSavedOutfits] = useState<Outfit[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [credits, setCredits] = useState(100);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [subscriptionTier, setSubscriptionTier] = useState('free');
  const [creditsUsed, setCreditsUsed] = useState(0);
  const [monthlyCredits, setMonthlyCredits] = useState(25);
  const [recommendationSource, setRecommendationSource] = useState<'idle' | 'live-ai' | 'hybrid' | 'youcam-live-ai' | 'youcam-wardrobe' | 'wardrobe-fallback' | 'unavailable'>('idle');
  const [recommendationNotice, setRecommendationNotice] = useState<string | null>(null);
  const [styleProfile, setStyleProfile] = useState<PersonalStyleProfile>({ colors: [], styles: [], fitPrefs: [] });

  useEffect(() => {
    loadStoredState();
  }, []);

  const loadStoredState = async () => {
    try {
      const [onboarding, theme, demo, guest, wardrobe, saved, storedStyleProfile, storedLang] = await Promise.all([
        AsyncStorage.getItem(STORAGE_KEYS.ONBOARDING),
        AsyncStorage.getItem(STORAGE_KEYS.THEME),
        AsyncStorage.getItem(STORAGE_KEYS.DEMO),
        AsyncStorage.getItem(STORAGE_KEYS.GUEST),
        AsyncStorage.getItem(STORAGE_KEYS.WARDROBE),
        AsyncStorage.getItem(STORAGE_KEYS.SAVED_OUTFITS),
        AsyncStorage.getItem(STORAGE_KEYS.STYLE_PROFILE),
        AsyncStorage.getItem(STORAGE_KEYS.LANGUAGE),
      ]);

      if (onboarding === 'true') setHasSeenOnboardingState(true);
      if (theme === 'dark') setIsDark(true);
      if (demo === 'false') setDemoModeState(false);
      if (guest === 'true') setIsGuest(true);
      if (storedLang && ['en', 'es', 'fr', 'ja', 'zh'].includes(storedLang)) {
        setLanguageState(storedLang as LanguageCode);
      } else {
        // Automatically detect device language on first startup with fallback to English
        try {
          const locales = Localization?.getLocales?.();
          const primaryLocale = locales && locales.length > 0 ? locales[0].languageCode : 'en';
          const detected: LanguageCode = primaryLocale === 'zh' ? 'zh' : 'en';
          setLanguageState(detected);
          await AsyncStorage.setItem(STORAGE_KEYS.LANGUAGE, detected);
        } catch {
          setLanguageState('en');
        }
      }

      const token = await getAuthToken();
      const isLive = demo !== 'true' && demo !== null ? demo === 'false' : false;

      if (token && isLive) {
        setIsAuthenticated(true);
        try {
          await fetchRemoteData();
          return;
        } catch {
          setIsAuthenticated(false);
        }
      }

      let activeWardrobe: WardrobeItem[] = [];
      if (wardrobe) {
        activeWardrobe = JSON.parse(wardrobe) as WardrobeItem[];
        setWardrobeItems(activeWardrobe);
        setStyleProfile(derivePersonalStyleProfile(activeWardrobe, storedStyleProfile ? JSON.parse(storedStyleProfile) : undefined));
      } else {
        // Seed default rich demo wardrobe for hackathon video submission so demo mode is immediately populated
        activeWardrobe = demoWardrobeItems.slice(0, 10);
        setWardrobeItems(activeWardrobe);
        setStyleProfile(derivePersonalStyleProfile(activeWardrobe, storedStyleProfile ? JSON.parse(storedStyleProfile) : undefined));
        void AsyncStorage.setItem(STORAGE_KEYS.WARDROBE, JSON.stringify(activeWardrobe));
      }

      if (saved) {
        setSavedOutfits(JSON.parse(saved));
      }

      // Seed preset demo outfits with rich preset images so demo mode immediately feels visual and rich
      const presetSuggestions = buildWardrobeRecommendations(
        activeWardrobe.map((item) => ({
          id: item.id,
          name: item.name,
          category: item.category,
          color: item.color,
          tags: item.tags,
          usageCount: item.usageCount,
          lastWornAt: item.lastWorn,
        })),
        'Casual Day',
        'Sunny 72°F',
      );
      const presetOutfits = presetSuggestions.map((suggestion, idx) => ({
        id: `preset-${idx + 1}`,
        name: suggestion.name,
        items: suggestion.itemIds.map((id) => activeWardrobe.find((item) => item.id === id)).filter(Boolean) as WardrobeItem[],
        tags: suggestion.tags,
        reason: suggestion.reason,
        occasion: suggestion.occasion,
        rating: idx === 0 ? ('like' as const) : null,
        saved: idx === 0,
        explanation: `Curated preset demonstration outfit featuring ${suggestion.itemIds.length} coordinated pieces.`,
        score: suggestion.score,
        imageUrl: activeWardrobe[idx % activeWardrobe.length]?.imageUrl || 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=600',
      }));
      setOutfits(presetOutfits);
      if (!saved && presetOutfits.length > 0) {
        setSavedOutfits(presetOutfits.filter(o => o.saved));
      }
    } catch {
      setWardrobeItems([]);
      setOutfits([]);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchRemoteData = async () => {
    try {
      const [wardrobeRes, outfitsRes, creditsRes, profileRes] = await Promise.all([
        apiRequest('GET', '/api/wardrobe'),
        apiRequest('GET', '/api/outfits'),
        apiRequest('GET', '/api/credits'),
        apiRequest('GET', '/api/user/style-profile'),
      ]);

      const apiItems: any[] = await wardrobeRes.json();
      const localItems = apiItems.map(mapApiItemToLocal);
      setWardrobeItems(localItems);
      try {
        setStyleProfile(derivePersonalStyleProfile(localItems, await profileRes.json()));
      } catch {
        setStyleProfile(derivePersonalStyleProfile(localItems));
      }

      const apiOutfits: any[] = await outfitsRes.json();
      const localOutfits = apiOutfits.map(o => mapApiOutfitToLocal(o, localItems));
      setOutfits(localOutfits);
      setSavedOutfits(localOutfits.filter(o => o.saved));

      const creditsData = await creditsRes.json();
      setCredits(creditsData.credits || 0);

      try {
        const subRes = await apiRequest('GET', '/api/subscription');
        const subData = await subRes.json();
        setSubscriptionTier(subData.tier || 'free');
        setCreditsUsed(subData.creditsUsed || 0);
        setMonthlyCredits(subData.monthlyCredits || 25);
      } catch { /* subscription fetch optional */ }
    } catch (err) {
      console.warn('Failed to fetch remote data; keeping the local collection available:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const persistWardrobe = useCallback(async (items: WardrobeItem[]) => {
    await AsyncStorage.setItem(STORAGE_KEYS.WARDROBE, JSON.stringify(items));
  }, []);

  const persistSaved = useCallback(async (items: Outfit[]) => {
    await AsyncStorage.setItem(STORAGE_KEYS.SAVED_OUTFITS, JSON.stringify(items));
  }, []);

  const setDemoMode = useCallback(async (v: boolean) => {
    setDemoModeState(v);
    await AsyncStorage.setItem(STORAGE_KEYS.DEMO, v ? 'true' : 'false');

    if (!v) {
      try {
        const token = await getAuthToken();
        if (!token) {
          const res = await apiRequest('POST', '/api/auth/guest');
          const data = await res.json();
          await setAuthToken(data.token);
          setIsAuthenticated(true);
        }
        await fetchRemoteData();
      } catch (err) {
        console.warn('Failed to connect to backend:', err);
        setDemoModeState(true);
        await AsyncStorage.setItem(STORAGE_KEYS.DEMO, 'true');
      }
    } else {
      // Demo mode remains fully usable with the user’s local collection.
      setWardrobeItems((current) => current);
      setOutfits((current) => current);
    }
  }, []);

  const loadFictionalAdultWomenDemoExample = useCallback(async (id: string) => {
    if (!demoMode) {
      throw new Error('Fictional example wardrobes are available only while Demo Mode is active.');
    }
    const example = cloneFictionalAdultWomenDemoExample(id);
    if (!example) {
      throw new Error('That fictional demo wardrobe is unavailable. Please choose another example.');
    }
    setWardrobeItems(example.wardrobe);
    setOutfits([]);
    setSavedOutfits([]);
    setStyleProfile(derivePersonalStyleProfile(example.wardrobe));
    setRecommendationSource('idle');
    setRecommendationNotice(`${example.audienceLabel}: ${example.displayName} · ${example.styleContext} ${FICTIONAL_ADULT_WOMEN_DEMO_DISCLOSURE}`);
    await Promise.all([
      persistWardrobe(example.wardrobe),
      persistSaved([]),
      AsyncStorage.setItem(STORAGE_KEYS.STYLE_PROFILE, JSON.stringify(derivePersonalStyleProfile(example.wardrobe))),
    ]);
  }, [demoMode, persistSaved, persistWardrobe]);

  const toggleTheme = useCallback(async () => {
    setIsDark(prev => {
      const next = !prev;
      AsyncStorage.setItem(STORAGE_KEYS.THEME, next ? 'dark' : 'light');
      return next;
    });
  }, []);

  const setLanguage = useCallback(async (lang: LanguageCode) => {
    if (lang === language) return;
    setIsLanguageSwitching(true);
    // Simulate smooth transition loading animation feedback
    await new Promise(resolve => setTimeout(resolve, 350));
    setLanguageState(lang);
    await AsyncStorage.setItem(STORAGE_KEYS.LANGUAGE, lang);
    setIsLanguageSwitching(false);
  }, [language]);

  const t = useCallback((key: string, fallback?: string) => {
    return translate(language, key, fallback);
  }, [language]);

  const setHasSeenOnboarding = useCallback(async (v: boolean) => {
    setHasSeenOnboardingState(v);
    await AsyncStorage.setItem(STORAGE_KEYS.ONBOARDING, v ? 'true' : 'false');
  }, []);

  const signInAsGuest = useCallback(async () => {
    setIsGuest(true);
    setDemoModeState(true);
    AsyncStorage.setItem(STORAGE_KEYS.GUEST, 'true');
    AsyncStorage.setItem(STORAGE_KEYS.DEMO, 'true');

    try {
      const res = await apiRequest('POST', '/api/auth/guest');
      const data = await res.json();
      await setAuthToken(data.token);
      setIsAuthenticated(true);
    } catch {
      setIsAuthenticated(false);
    }
  }, []);

  const signOut = useCallback(async () => {
    setIsGuest(true);
    setDemoModeState(true);
    setHasSeenOnboardingState(false);
    setWardrobeItems([]);
    setOutfits([]);
    setSavedOutfits([]);
    setStyleProfile({ colors: [], styles: [], fitPrefs: [] });
    setIsAuthenticated(false);
    setCredits(100);
    await clearAuthToken();
    await AsyncStorage.multiRemove(Object.values(STORAGE_KEYS));
  }, []);

  const clearBlankLiveState = useCallback(async () => {
    setWardrobeItems([]);
    setOutfits([]);
    setSavedOutfits([]);
    setStyleProfile({ colors: [], styles: [], fitPrefs: [] });
    await Promise.all([
      persistWardrobe([]),
      persistSaved([]),
      AsyncStorage.removeItem(STORAGE_KEYS.WARDROBE),
      AsyncStorage.removeItem(STORAGE_KEYS.SAVED_OUTFITS),
    ]);
  }, [persistSaved, persistWardrobe]);

  const addWardrobeItem = useCallback(async (item: Omit<WardrobeItem, 'id' | 'createdAt' | 'usageCount' | 'lastWorn'>) => {
    if (!demoMode && isAuthenticated) {
      try {
        const res = await apiRequest('POST', '/api/wardrobe', {
          name: item.name,
          category: item.category,
          color: item.color,
          brand: item.brand,
          notes: item.notes,
          imageUrl: item.imageUrl,
          tags: item.tags,
        });
        const apiItem = await res.json();
        const localItem = mapApiItemToLocal(apiItem);
        setWardrobeItems(prev => {
          const next = [localItem, ...prev];
          persistWardrobe(next);
          return next;
        });
        return;
      } catch (err) {
        console.warn('API add failed, falling back to local:', err);
      }
    }

    const newItem: WardrobeItem = {
      ...item,
      id: Crypto.randomUUID(),
      createdAt: new Date().toISOString(),
      usageCount: 0,
      lastWorn: null,
    };
    setWardrobeItems(prev => {
      const next = [newItem, ...prev];
      persistWardrobe(next);
      return next;
    });
  }, [persistWardrobe, demoMode, isAuthenticated]);

  const removeWardrobeItem = useCallback(async (id: string) => {
    if (!demoMode && isAuthenticated) {
      try {
        await apiRequest('DELETE', `/api/wardrobe/${id}`);
      } catch (err) {
        console.warn('API delete failed:', err);
      }
    }
    setWardrobeItems(prev => {
      const next = prev.filter(i => i.id !== id);
      persistWardrobe(next);
      return next;
    });
  }, [persistWardrobe, demoMode, isAuthenticated]);

  const updateWardrobeItemFn = useCallback(async (id: string, data: Partial<WardrobeItem>) => {
    if (!demoMode && isAuthenticated) {
      try {
        await apiRequest('PUT', `/api/wardrobe/${id}`, data);
      } catch (err) {
        console.warn('API update failed:', err);
      }
    }
    setWardrobeItems(prev => {
      const next = prev.map(i => i.id === id ? { ...i, ...data } : i);
      persistWardrobe(next);
      return next;
    });
  }, [persistWardrobe, demoMode, isAuthenticated]);

  const markItemWorn = useCallback(async (id: string) => {
    if (!demoMode && isAuthenticated) {
      try {
        const res = await apiRequest('POST', `/api/wardrobe/${id}/mark-worn`);
        const updated = await res.json();
        setWardrobeItems(prev => {
          const next = prev.map(i => i.id === id ? mapApiItemToLocal(updated) : i);
          persistWardrobe(next);
          return next;
        });
        return;
      } catch (err) {
        console.warn('API mark-worn failed:', err);
      }
    }
    setWardrobeItems(prev => {
      const next = prev.map(i => i.id === id ? {
        ...i,
        usageCount: (i.usageCount || 0) + 1,
        lastWorn: new Date().toISOString(),
      } : i);
      persistWardrobe(next);
      return next;
    });
  }, [persistWardrobe, demoMode, isAuthenticated]);

  const rateOutfit = useCallback((id: string, rating: 'like' | 'neutral' | 'dislike') => {
    setOutfits(prev => prev.map(o => o.id === id ? { ...o, rating } : o));
    if (!demoMode && isAuthenticated) {
      apiRequest('PUT', `/api/outfits/${id}`, { rating }).catch(() => {});
    }
  }, [demoMode, isAuthenticated]);

  const saveOutfit = useCallback((id: string) => {
    setOutfits(prev => {
      const updated = prev.map(o => o.id === id ? { ...o, saved: true } : o);
      const outfit = updated.find(o => o.id === id);
      if (outfit) {
        setSavedOutfits(s => {
          const next = [...s.filter(so => so.id !== id), outfit];
          persistSaved(next);
          return next;
        });
      }
      return updated;
    });
    if (!demoMode && isAuthenticated) {
      apiRequest('PUT', `/api/outfits/${id}`, { saved: true }).catch(() => {});
    }
  }, [persistSaved, demoMode, isAuthenticated]);

  const unsaveOutfit = useCallback((id: string) => {
    setOutfits(prev => prev.map(o => o.id === id ? { ...o, saved: false } : o));
    setSavedOutfits(prev => {
      const next = prev.filter(o => o.id !== id);
      persistSaved(next);
      return next;
    });
    if (!demoMode && isAuthenticated) {
      apiRequest('PUT', `/api/outfits/${id}`, { saved: false }).catch(() => {});
    }
  }, [persistSaved, demoMode, isAuthenticated]);

  const generateOutfits = useCallback(async (occasion?: string, weather?: string, colorPalette?: string[]) => {
    setRecommendationNotice(null);
    if (!demoMode && isAuthenticated) {
      try {
        const body: Record<string, string> = {};
        if (occasion) body.occasion = occasion;
        if (weather) body.weather = weather;
        if (colorPalette?.length) body.colorPalette = colorPalette as any;
        const res = await apiRequest('POST', '/api/outfits/suggest', body);
        const apiOutfits: any[] = await res.json();
        const localOutfits = apiOutfits
          .map(o => mapApiOutfitToLocal(o, wardrobeItems))
          .filter(outfit => outfit.items.length >= 2);
        if (localOutfits.length > 0) {
          const sourceHeader = res.headers.get('X-ClosetAI-Recommendation-Source');
          const source = sourceHeader === 'live-ai' || sourceHeader === 'hybrid' || sourceHeader === 'youcam-live-ai' || sourceHeader === 'youcam-wardrobe' || sourceHeader === 'wardrobe-fallback'
            ? sourceHeader
            : 'live-ai';
          setOutfits(localOutfits);
          setRecommendationSource(source);
          setRecommendationNotice(
            source === 'youcam-live-ai'
              ? 'Live styling recommendations were enriched with your saved YouCam color direction and current wardrobe.'
              : source === 'youcam-wardrobe'
                ? 'Wardrobe recommendations were enriched with your saved YouCam color direction.'
                : source === 'live-ai'
                  ? 'Live AI recommendations are based on your current wardrobe.'
                  : source === 'hybrid'
                    ? 'Live AI suggestions were completed with wardrobe-based recommendations.'
                    : 'Wardrobe-based recommendations were used because live AI is unavailable.',
          );
          return;
        }
      } catch (err) {
        console.warn('Live outfit recommendation failed:', err);
      }
    }

    // The offline/demo path reuses the same deterministic engine as the server and never injects
    // a catalog look, placeholder garment, or pre-authored mock outfit.
    const fallbackSuggestions = buildWardrobeRecommendations(
      wardrobeItems.map((item) => ({
        id: item.id,
        name: item.name,
        category: item.category,
        color: item.color,
        tags: item.tags,
        usageCount: item.usageCount,
        lastWornAt: item.lastWorn,
      })),
      occasion,
      weather,
      colorPalette,
    );
    const fallbackOutfits = fallbackSuggestions.map((suggestion) => ({
      id: Crypto.randomUUID(),
      name: suggestion.name,
      items: suggestion.itemIds.map((id) => wardrobeItems.find((item) => item.id === id)).filter(Boolean) as WardrobeItem[],
      tags: suggestion.tags,
      reason: suggestion.reason,
      occasion: suggestion.occasion,
      rating: null,
      saved: false,
      explanation: `Built only from ${suggestion.itemIds.length} item${suggestion.itemIds.length === 1 ? '' : 's'} in your wardrobe.${weather ? ` Context: ${weather}.` : ''}`,
      score: suggestion.score,
    }));
    setOutfits(fallbackOutfits);
    setRecommendationSource(fallbackOutfits.length > 0 ? 'wardrobe-fallback' : 'unavailable');
    setRecommendationNotice(
      fallbackOutfits.length > 0
        ? 'Local wardrobe-based recommendations are shown. Connect to live AI for refreshed styling insight.'
        : 'Add at least two compatible items to your wardrobe before generating an outfit.',
    );
  }, [demoMode, isAuthenticated, wardrobeItems]);

  const getExplanation = useCallback((id: string) => {
    const outfit = outfits.find(o => o.id === id) || savedOutfits.find(o => o.id === id);
    return outfit?.explanation || 'No generated explanation is available for this outfit yet.';
  }, [outfits, savedOutfits]);

  const generateCaption = useCallback(async (outfitId: string, tone: string = 'casual', platform: string = 'instagram'): Promise<CaptionResult> => {
    if (!demoMode && isAuthenticated) {
      try {
        const createRes = await apiRequest('POST', '/api/content', {
          outfitId,
          tone,
          platform,
        });
        const job = await createRes.json();

        let attempts = 0;
        while (attempts < 15) {
          await new Promise(r => setTimeout(r, 1000));
          const statusRes = await apiRequest('GET', `/api/content/${job.id}`);
          const status = await statusRes.json();
          if (status.status === 'completed') {
            return {
              caption: status.caption || 'Looking great today!',
              hashtags: status.hashtags || ['#OOTD', '#Fashion', '#ClosetAI'],
                source: 'live-ai',
            };
          }
          if (status.status === 'failed') break;
          attempts++;
        }
      } catch (err) {
        console.warn('Content generation failed:', err);
      }
    }

    const idx = Math.abs(outfitId.charCodeAt(outfitId.length - 1)) % demoCaptions.length;
    return {
      ...demoCaptions[idx],
      source: 'demo',
      fallbackReason: demoMode
        ? 'Demo Mode is enabled.'
        : 'Live AI caption generation is unavailable.',
    };
  }, [demoMode, isAuthenticated]);

  const createTryOn = useCallback(async (selfieUri: string, garmentIds: string[]): Promise<TryOnResult> => {
    if (!demoMode && isAuthenticated) {
      try {
        let selfieBase64: string | undefined;
        if (Platform.OS !== 'web' && selfieUri.startsWith('file://')) {
          selfieBase64 = await FileSystem.readAsStringAsync(selfieUri, {
            encoding: 'base64' as any,
          });
        } else if (selfieUri.startsWith('data:')) {
          selfieBase64 = selfieUri.split(',')[1];
        } else if (Platform.OS === 'web') {
          try {
            const resp = await fetch(selfieUri);
            const blob = await resp.blob();
            selfieBase64 = await new Promise<string>((resolve) => {
              const reader = new FileReader();
              reader.onloadend = () => {
                const result = reader.result as string;
                resolve(result.split(',')[1]);
              };
              reader.readAsDataURL(blob);
            });
          } catch {
            selfieBase64 = undefined;
          }
        }

        const createRes = await apiRequest('POST', '/api/tryon', {
          selfieUrl: selfieUri,
          selfieBase64,
          garmentItemIds: garmentIds,
        });
        const job = await createRes.json() as { id?: unknown };
        if (typeof job?.id !== 'string' || job.id.trim().length === 0) {
          throw new Error('Live virtual try-on could not start a valid provider job. No rendered result was produced; please retry.');
        }

        let attempts = 0;
        let invalidOrUnrecognizedStatusResponses = 0;
        while (attempts < 30) {
          await new Promise(r => setTimeout(r, 2000));
          const statusRes = await apiRequest('GET', `/api/tryon/${job.id}`);
          const response = await statusRes.json() as unknown;
          const pollingStatus = getTryOnPollingStatus(response);
          if (!pollingStatus) {
            invalidOrUnrecognizedStatusResponses += 1;
            if (invalidOrUnrecognizedStatusResponses >= 3) {
              throw new Error('Live virtual try-on returned incomplete status updates. No rendered result was produced; please retry.');
            }
            attempts++;
            continue;
          }
          const status = response as CompletedTryOnJobResponse;
          const completedResult = normalizeCompletedTryOnJob(status, selfieUri, garmentIds);
          if (completedResult) return completedResult;
          if (isTerminalTryOnJobStatus(pollingStatus)) {
            const statusObj = response as CompletedTryOnJobResponse;
            const providerError = typeof statusObj.errorMessage === 'string' && statusObj.errorMessage.trim().length > 0
              ? statusObj.errorMessage
              : 'Live virtual try-on did not complete a usable rendered result.';
            throw new Error(providerError);
          }
          if (!['queued', 'processing'].includes(pollingStatus)) {
            invalidOrUnrecognizedStatusResponses += 1;
            if (invalidOrUnrecognizedStatusResponses >= 3) {
              throw new Error('Live virtual try-on returned unrecognized provider status repeatedly. No rendered result was produced; please retry.');
            }
          } else {
            invalidOrUnrecognizedStatusResponses = 0;
          }
          attempts++;
        }
        throw new Error('Live virtual try-on is taking longer than expected. No rendered result was produced; please retry.');
      } catch (err) {
        const recovery = resolveTryOnRequestRecovery(err);
        if (recovery.kind === 'actionable') {
          throw new Error(recovery.message);
        }
        throw new Error(recovery.disclosure || 'Live virtual try-on request could not be completed.');
      }
    }

    await new Promise(r => setTimeout(r, 2500));
    return createUserPhotoTryOnFallback(
      selfieUri,
      garmentIds,
      undefined,
      'Photo preview shown. Live virtual try-on is not available in this demo session.',
    );
  }, [demoMode, isAuthenticated]);

  const getStyleInsight = useCallback(async () => {
    if (!demoMode && isAuthenticated) {
      try {
        const res = await apiRequest('POST', '/api/ai/style-insight');
        return await res.json();
      } catch {
        // fallback
      }
    }
    const categoryCounts = wardrobeItems.reduce<Record<string, number>>((counts, item) => {
      counts[item.category] = (counts[item.category] || 0) + 1;
      return counts;
    }, {});
    const [dominantCategory, dominantCount = 0] = Object.entries(categoryCounts)
      .sort(([, left], [, right]) => right - left)[0] || [];
    const categoryCount = Object.keys(categoryCounts).length;
    return {
      insight: wardrobeItems.length > 0
        ? `Your active wardrobe contains ${wardrobeItems.length} item${wardrobeItems.length === 1 ? '' : 's'} across ${categoryCount} category${categoryCount === 1 ? '' : 'ies'}.`
        : 'No wardrobe items are available yet.',
      dominantStyle: dominantCategory ? `Most-owned category: ${dominantCategory}` : 'Not available',
      suggestion: dominantCount > 0
        ? `Generate an outfit to explore combinations using your ${dominantCategory} pieces.`
        : 'Add at least two wardrobe items to start generating recommendations.',
    };
  }, [demoMode, isAuthenticated, wardrobeItems]);

  const upgradeTier = useCallback(async (tier: string) => {
    const tierConfig: Record<string, number> = { free: 25, pro: 1000, enterprise: 100000 };
    if (!demoMode && isAuthenticated) {
      try {
        const res = await apiRequest('POST', '/api/subscription/upgrade', { tier });
        const sub = await res.json();
        setSubscriptionTier(sub.tier);
        setCreditsUsed(sub.creditsUsed || 0);
        setMonthlyCredits(sub.monthlyCredits || tierConfig[tier] || 25);
        return;
      } catch (err) {
        console.warn('Upgrade failed:', err);
      }
    }
    setSubscriptionTier(tier);
    setCreditsUsed(0);
    setMonthlyCredits(tierConfig[tier] || 25);
  }, [demoMode, isAuthenticated]);

  const canUseCredit = useCallback(() => {
    return creditsUsed < monthlyCredits;
  }, [creditsUsed, monthlyCredits]);

  const updateStyleProfile = useCallback(async (nextProfile: PersonalStyleProfile) => {
    const normalized = normalizePersonalStyleProfile(nextProfile);
    setStyleProfile(normalized);
    await AsyncStorage.setItem(STORAGE_KEYS.STYLE_PROFILE, JSON.stringify(normalized));
    if (!demoMode && isAuthenticated) {
      try {
        const response = await apiRequest('PUT', '/api/user/style-profile', normalized);
        if (response.ok) setStyleProfile(normalizePersonalStyleProfile(await response.json()));
      } catch {
        // The locally persisted profile remains available and will be retried on a later live session.
      }
    }
  }, [demoMode, isAuthenticated]);

  const trackAffiliate = useCallback(async (productName: string, productUrl: string, source: string) => {
    if (!demoMode && isAuthenticated) {
      try {
        await apiRequest('POST', '/api/affiliate/click', { productName, productUrl, source });
      } catch { /* silent */ }
    }
  }, [demoMode, isAuthenticated]);

  const refreshWardrobe = useCallback(async () => {
    if (!demoMode && isAuthenticated) {
      try {
        const res = await apiRequest('GET', '/api/wardrobe');
        const apiItems: any[] = await res.json();
        const localItems = apiItems.map(mapApiItemToLocal);
        setWardrobeItems(localItems);
        return;
      } catch {
        // fall through to local
      }
    }
    const stored = await AsyncStorage.getItem(STORAGE_KEYS.WARDROBE);
    if (stored) {
      setWardrobeItems(JSON.parse(stored));
    }
  }, [demoMode, isAuthenticated]);

  const value = useMemo((): AppContextValue => ({
    isGuest,
    demoMode,
    isDark,
    hasSeenOnboarding,
    wardrobeItems,
    outfits,
    savedOutfits,
    isLoading,
    credits,
    isAuthenticated,
    subscriptionTier,
    creditsUsed,
    monthlyCredits,
    recommendationSource,
    recommendationNotice,
    styleProfile,
    language,
    isLanguageSwitching,
    setDemoMode,
    setLanguage,
    t,
    clearBlankLiveState,
    loadFictionalAdultWomenDemoExample,
    toggleTheme,
    setHasSeenOnboarding,
    signInAsGuest,
    signOut,
    addWardrobeItem,
    removeWardrobeItem,
    updateWardrobeItem: updateWardrobeItemFn,
    markItemWorn,
    rateOutfit,
    saveOutfit,
    unsaveOutfit,
    generateOutfits,
    getExplanation,
    generateCaption,
    createTryOn,
    refreshWardrobe,
    getStyleInsight,
    upgradeTier,
    canUseCredit,
    trackAffiliate,
    updateStyleProfile,
  }), [
    isGuest, demoMode, isDark, hasSeenOnboarding, wardrobeItems, outfits, savedOutfits, isLoading,
    credits, isAuthenticated, subscriptionTier, creditsUsed, monthlyCredits, recommendationSource, recommendationNotice, styleProfile,
    setDemoMode, loadFictionalAdultWomenDemoExample, toggleTheme, setHasSeenOnboarding, signInAsGuest, signOut,
    addWardrobeItem, removeWardrobeItem, updateWardrobeItemFn, markItemWorn, rateOutfit, saveOutfit, unsaveOutfit,
    generateOutfits, getExplanation, generateCaption, createTryOn, refreshWardrobe, getStyleInsight,
    upgradeTier, canUseCredit, trackAffiliate, updateStyleProfile,
  ]);

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
