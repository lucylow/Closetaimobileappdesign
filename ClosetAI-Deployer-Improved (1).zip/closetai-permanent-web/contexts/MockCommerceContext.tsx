import AsyncStorage from "@react-native-async-storage/async-storage";
import React from "react";

import { activeSkinCommerceProvider } from "@/lib/skin-commerce-provider";
import { addMockCartItem, emptyMockCart, MOCK_COMMERCE_DISCLOSURE, mockCartItemCount, mockCartSubtotal, removeMockCartItem, setMockCartItemQuantity, type MockCartOperationResult, type MockCartState } from "@/lib/mock-commerce-cart";

const STORAGE_KEY = "@closetai_mock_commerce_cart";

type MockCommerceContextValue = {
  cart: MockCartState;
  itemCount: number;
  subtotal: number;
  isReady: boolean;
  addItem: (productId: string) => Promise<MockCartOperationResult>;
  setItemQuantity: (productId: string, quantity: number) => Promise<MockCartOperationResult>;
  removeItem: (productId: string) => Promise<MockCartOperationResult>;
  clearCart: () => Promise<void>;
};

const MockCommerceContext = React.createContext<MockCommerceContextValue | null>(null);

function unavailableResult(cart: MockCartState, message: string): MockCartOperationResult {
  return { cart, operation: "unavailable", message };
}

function sanitizeStoredCart(raw: string | null): MockCartState {
  if (!raw) return emptyMockCart();
  try {
    const parsed = JSON.parse(raw) as Partial<MockCartState>;
    if (!Array.isArray(parsed.lines)) return emptyMockCart();
    const lines = parsed.lines.filter((line: any) => (
      line && typeof line.productId === "string" && typeof line.title === "string" &&
      typeof line.unitPrice === "number" && Number.isFinite(line.unitPrice) &&
      typeof line.quantity === "number" && Number.isInteger(line.quantity) && line.quantity > 0 &&
      typeof line.availableQuantity === "number" && Number.isInteger(line.availableQuantity) && line.availableQuantity >= 0 &&
      (line.availability === "in_stock" || line.availability === "low_stock" || line.availability === "out_of_stock")
    ));
    return {
      cartId: typeof parsed.cartId === "string" ? parsed.cartId : "mock-cart-local",
      lines,
      currency: "USD",
      updatedAt: typeof parsed.updatedAt === "string" ? parsed.updatedAt : new Date().toISOString(),
      disclosure: MOCK_COMMERCE_DISCLOSURE,
    };
  } catch {
    return emptyMockCart();
  }
}

export function MockCommerceProvider({ children }: { children: React.ReactNode }) {
  const [cart, setCart] = React.useState<MockCartState>(() => emptyMockCart());
  const [isReady, setIsReady] = React.useState(false);
  const cartRef = React.useRef(cart);

  const commit = React.useCallback(async (next: MockCartState) => {
    cartRef.current = next;
    setCart(next);
    try {
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    } catch {
      // The current session remains usable even if persistence is unavailable.
    }
  }, []);

  React.useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY)
      .then((stored) => {
        const next = sanitizeStoredCart(stored);
        cartRef.current = next;
        setCart(next);
      })
      .catch(() => undefined)
      .finally(() => setIsReady(true));
  }, []);

  const addItem = React.useCallback(async (productId: string) => {
    const listing = await activeSkinCommerceProvider.getListing(productId);
    if (!listing) return unavailableResult(cartRef.current, "The mock commerce listing is unavailable. Please try again.");
    const result = addMockCartItem(cartRef.current, listing);
    if (result.cart !== cartRef.current) await commit(result.cart);
    return result;
  }, [commit]);

  const setItemQuantity = React.useCallback(async (productId: string, quantity: number) => {
    const listing = await activeSkinCommerceProvider.getListing(productId);
    if (!listing) return unavailableResult(cartRef.current, "The mock commerce listing is unavailable. You can remove the saved line from your cart.");
    const result = setMockCartItemQuantity(cartRef.current, listing, quantity);
    if (result.cart !== cartRef.current) await commit(result.cart);
    return result;
  }, [commit]);

  const removeItem = React.useCallback(async (productId: string) => {
    const result = removeMockCartItem(cartRef.current, productId);
    if (result.cart !== cartRef.current) await commit(result.cart);
    return result;
  }, [commit]);

  const clearCart = React.useCallback(async () => {
    await commit(emptyMockCart());
  }, [commit]);

  const value = React.useMemo<MockCommerceContextValue>(() => ({
    cart,
    itemCount: mockCartItemCount(cart),
    subtotal: mockCartSubtotal(cart),
    isReady,
    addItem,
    setItemQuantity,
    removeItem,
    clearCart,
  }), [cart, isReady, addItem, setItemQuantity, removeItem, clearCart]);

  return <MockCommerceContext.Provider value={value}>{children}</MockCommerceContext.Provider>;
}

export function useMockCommerce() {
  const context = React.useContext(MockCommerceContext);
  if (!context) throw new Error("useMockCommerce must be used within MockCommerceProvider");
  return context;
}
