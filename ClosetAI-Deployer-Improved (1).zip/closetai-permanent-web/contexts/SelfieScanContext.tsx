import React, { createContext, useContext, useEffect, useMemo, useState } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

import type { SkinAnalysisResult } from "@/lib/skin-analysis-controller";
import { toPersistedSkinAnalysisSummary } from "@/lib/skin-analysis-persistence";
import { readPersistedSkinResults } from "@/lib/skin-scan-persistence";
import { buildSelfieQualityReport, type SelfieQualityReport } from "@/lib/selfie-quality";
import { clearSkinMetricHistory, saveSkinMetricHistory } from "@/lib/skin-metric-history";
import { clearSkinAnalysisRetryQueue } from "@/lib/skin-analysis-retry-queue";

export interface SelfieAsset {
  uri: string;
  source: "camera" | "library";
  width: number;
  height: number;
  fileSize?: number | null;
  mimeType?: string | null;
}

type SelfieStage = "capture" | "review" | "analysing" | "complete" | "failed";

interface SelfieScanState {
  asset: SelfieAsset | null;
  quality: SelfieQualityReport | null;
  acceptsGuidance: boolean;
  saveSummary: boolean;
  stage: SelfieStage;
  result: SkinAnalysisResult | null;
  savedResults: SkinAnalysisResult[];
  error: string | null;
  choose: (asset: SelfieAsset) => void;
  setAcceptsGuidance: (value: boolean) => void;
  setSaveSummary: (value: boolean) => void;
  setStage: (stage: SelfieStage) => void;
  finish: (result: SkinAnalysisResult) => void;
  fail: (message: string) => void;
  reset: () => void;
  clearSavedHistory: () => Promise<void>;
}

const SelfieScanContext = createContext<SelfieScanState | null>(null);
const SAVED_RESULTS_KEY = "@closetai_saved_skin_results";

export function SelfieScanProvider({ children }: { children: React.ReactNode }) {
  const [asset, setAsset] = useState<SelfieAsset | null>(null);
  const [acceptsGuidance, setAcceptsGuidance] = useState(false);
  const [saveSummary, setSaveSummary] = useState(true);
  const [stage, setStage] = useState<SelfieStage>("capture");
  const [result, setResult] = useState<SkinAnalysisResult | null>(null);
  const [savedResults, setSavedResults] = useState<SkinAnalysisResult[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [hydrated, setHydrated] = useState(false);
  const quality = asset ? buildSelfieQualityReport(asset) : null;

  useEffect(() => {
    AsyncStorage.getItem(SAVED_RESULTS_KEY)
      .then((stored) => { if (stored) setSavedResults(readPersistedSkinResults(stored)); })
      .catch(() => undefined)
      .finally(() => setHydrated(true));
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    AsyncStorage.setItem(SAVED_RESULTS_KEY, JSON.stringify(savedResults.map(toPersistedSkinAnalysisSummary))).catch(() => undefined);
  }, [savedResults, hydrated]);

  const value = useMemo<SelfieScanState>(() => ({
    asset, quality, acceptsGuidance, saveSummary, stage, result, savedResults, error,
    choose: (next) => { setAsset(next); setStage("review"); setError(null); },
    setAcceptsGuidance,
    setSaveSummary,
    setStage,
    finish: (next) => { setResult(next); setStage("complete"); setError(null); if (saveSummary) { const summary = toPersistedSkinAnalysisSummary(next); setSavedResults((current) => [summary, ...current.filter((item) => item.id !== summary.id)].slice(0, 20)); saveSkinMetricHistory(next).catch(() => undefined); } },
    fail: (message) => { setError(message); setStage("failed"); },
    reset: () => { setAsset(null); setResult(null); setError(null); setStage("capture"); setAcceptsGuidance(false); },
    clearSavedHistory: async () => {
      await clearSkinMetricHistory();
      await AsyncStorage.removeItem(SAVED_RESULTS_KEY);
      await clearSkinAnalysisRetryQueue();
      setSavedResults([]);
    },
  }), [asset, quality, acceptsGuidance, saveSummary, stage, result, savedResults, error]);

  return <SelfieScanContext.Provider value={value}>{children}</SelfieScanContext.Provider>;
}

export function useSelfieScan() {
  const context = useContext(SelfieScanContext);
  if (!context) throw new Error("useSelfieScan must be used within SelfieScanProvider.");
  return context;
}
