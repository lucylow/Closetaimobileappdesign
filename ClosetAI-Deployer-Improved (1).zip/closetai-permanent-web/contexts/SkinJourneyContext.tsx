import React, { createContext, useContext, useMemo, useState } from "react";

interface SkinJourneyState {
  completedStepIds: string[];
  savedProductIds: string[];
  goals: string[];
  remindersEnabled: boolean;
  toggleRoutineStep: (id: string) => void;
  toggleSavedProduct: (id: string) => void;
  toggleGoal: (id: string) => void;
  setRemindersEnabled: (value: boolean) => void;
}

const SkinJourneyContext = createContext<SkinJourneyState | null>(null);

function toggle(values: string[], id: string) {
  return values.includes(id) ? values.filter((item) => item !== id) : [...values, id];
}

export function SkinJourneyProvider({ children }: { children: React.ReactNode }) {
  const [completedStepIds, setCompletedStepIds] = useState<string[]>([]);
  const [savedProductIds, setSavedProductIds] = useState<string[]>([]);
  const [goals, setGoals] = useState<string[]>(["hydration", "radiance"]);
  const [remindersEnabled, setRemindersEnabled] = useState(true);

  const value = useMemo<SkinJourneyState>(() => ({
    completedStepIds,
    savedProductIds,
    goals,
    remindersEnabled,
    toggleRoutineStep: (id) => setCompletedStepIds((current) => toggle(current, id)),
    toggleSavedProduct: (id) => setSavedProductIds((current) => toggle(current, id)),
    toggleGoal: (id) => setGoals((current) => toggle(current, id)),
    setRemindersEnabled,
  }), [completedStepIds, savedProductIds, goals, remindersEnabled]);

  return <SkinJourneyContext.Provider value={value}>{children}</SkinJourneyContext.Provider>;
}

export function useSkinJourney() {
  const context = useContext(SkinJourneyContext);
  if (!context) throw new Error("useSkinJourney must be used within SkinJourneyProvider.");
  return context;
}
