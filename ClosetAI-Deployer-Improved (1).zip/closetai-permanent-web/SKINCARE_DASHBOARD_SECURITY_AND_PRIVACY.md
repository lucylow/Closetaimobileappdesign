# Skincare Dashboard Security and Privacy Walkthrough

## Security Model at a Glance

The skincare dashboard is designed around **data minimization**, **source-aware presentation**, and **server-side provider isolation**. The application treats a selfie as sensitive input for a requested analysis operation, then transforms the provider response into a limited dashboard model. The dashboard is intentionally unable to access raw provider payloads, external API credentials, face masks, original image buffers, or diagnostic inferences.

> The dashboard presents normalized visual signals and general-care context. It does not diagnose a condition, assess clinical risk, or claim an accuracy/confidence score.

| Protection layer | Implementation | Why it matters |
|---|---|---|
| Credential isolation | Perfect YouCam credentials are read only by `server/youcam.ts` from server environment variables. | The Expo client cannot receive or expose provider secrets. |
| Server-side provider calls | The server routes create upload/task requests and poll YouCam. | The mobile screen interacts with app API responses rather than directly with the third-party provider. |
| Normalization boundary | `lib/skin-analysis-controller.ts` maps provider snapshot concerns into a fixed `SkinAnalysisResult` contract. | The UI receives only required app fields, rather than raw provider data. |
| Bounded presentation model | `lib/skin-intelligence-dashboard.ts` derives priorities, trend labels, source labels, and coverage. | The dashboard excludes source-image data, provider payloads, masks, and medical interpretation. |
| Local history minimization | SQLite metric-history utilities persist normalized metric scores and timestamps only. | Progress charts can work without retaining original selfies. |
| Explicit source labels | Live YouCam, saved/cached, Demo Mode, and fallback states have distinct text. | A user is not misled into thinking demo or fallback data is live provider output. |

## End-to-End Data Flow

The first step is a user-initiated selfie scan. The app validates that a photo exists and prepares it only for the requested analysis. In a live session, the server receives the encoded photo, obtains a provider upload target, sends the image to the provider, creates a task, and polls task status. The mobile application never receives provider credentials during this process.

After the provider returns a result, the server creates a normalized `SkinSnapshot`. The app-side analysis controller then converts the snapshot into `SkinAnalysisResult`, which contains metric keys, labels, bounded scores, availability, general descriptions, source, and safe routine guidance. It can also include a `visualSignalCoverage` object that tells the UI how many expected normalized signal fields were available.

| Stage | Sensitive input | Output forwarded to the next stage | Excluded from the dashboard |
|---|---|---|---|
| User scan request | User-selected selfie | Requested analysis input | Provider secrets and dashboard state do not receive secrets. |
| Provider processing | Encoded image and server-only authentication | Provider task result | Raw task payload is not rendered in Expo. |
| Server snapshot normalization | Raw provider result | Fixed skin concern/routine snapshot | Provider-specific response shape, upload target, task internals, and image artifacts. |
| App analysis normalization | Saved snapshot | `SkinAnalysisResult` with normalized signals | Raw selfie content, face masks, and provider payload. |
| Dashboard derivation | Normalized result and previous normalized result | Cards, priorities, source label, and trends | Image URI, raw payload, clinical interpretation, and diagnostic language. |
| Local history | Approved normalized signal summary | Score/time series for local progress chart | Original selfie is not written into SQLite metric history. |

## How Source-Aware Summaries Work

The app does not use a generic “AI result” label. `SkinAnalysisResult.source` is one of `youcam`, `cached`, or `demo`, and this source is propagated to the dashboard builder.

| Source | Dashboard label | Meaning |
|---|---|---|
| `youcam` | **Live visual analysis** | The result was normalized from a live saved provider snapshot. |
| `cached` | **Saved visual analysis** | The result represents an already saved normalized snapshot. |
| `demo` | **Demo visual analysis** | The values are fictional preview data and are explicitly labeled as such. |

The source summary can say that a live provider result returned a count of normalized visual signals, such as “9 of 9.” This is **coverage/completeness metadata only**. It does not mean the provider is 100% accurate, and the UI does not display it as a medical or model-confidence score.

When live analysis is unavailable, `analyzeSkin` produces a visibly labeled Demo Mode fallback with `fallbackReason`. The fallback summary explicitly explains that fictional data is being shown instead of live YouCam analysis. This protects against a common privacy and product-integrity failure: silently displaying mock data as if it were the user’s live result.

## Local Persistence Rules

The application separates user-visible history from original photo retention. `SelfieScanContext` saves approved normalized results for dashboard continuity, while the metric-history storage modules save only normalized score/timestamp entries needed for progression charts. The relevant data model is intentionally small:

```ts
{
  metricKey: "hydration" | "radiance" | "texture" | "pores";
  normalizedScore: number;
  recordedAt: string;
}
```

The chart store does not need the selfie itself, image bytes, or raw external response. This reduces local exposure while still supporting a useful history experience.

## User-Visible Safety Controls

The product experience reinforces the implementation boundaries with visible copy. The skincare dashboard says that it offers visual/general guidance rather than a diagnosis. Demo Mode identifies fictional values. Missing or partial signal coverage is described as unavailable normalized fields rather than an inferred health conclusion. The optional selfie workflow includes permission handling and user choice around saving snapshots.

| User-facing state | Secure behavior |
|---|---|
| Permission denied | Explains the permission issue and allows the user to choose an alternate path. |
| Image too large or invalid | Rejects before a live task is created. |
| Live provider task fails | Returns a clear temporary-unavailable message or a labeled fictional fallback. |
| Provider output is partial | Shows only available normalized signals and coverage metadata. |
| Progress history | Uses normalized local metrics rather than original selfies. |
| Demo Mode | Clearly labels fictional profile and metric values. |

## Verification Coverage

The security-sensitive presentation boundary is protected by `tests/skin-intelligence-dashboard.test.ts`. The regression test asserts the expected live source label and coverage behavior and confirms the dashboard model contains normalized visual summaries rather than raw API payload or medical claims. The full mobile build also passed strict TypeScript validation and Expo web export after the integration updates.

## Practical Review Checklist

Before modifying this feature, verify the following conditions remain true.

- [ ] No client code imports provider API credentials or third-party authorization tokens.
- [ ] No dashboard type includes raw provider task data, image masks, or full selfie content.
- [ ] SQLite metric history stores only normalized values and timestamps.
- [ ] Live, cached/saved, demo, and fallback sources remain visually distinct.
- [ ] Coverage is described as available normalized fields, not accuracy or clinical confidence.
- [ ] All skin guidance remains non-diagnostic.
- [ ] Errors fail safely and do not replace a missing live result with unlabelled mock data.
