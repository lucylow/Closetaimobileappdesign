# AI Abs Filter Provider Source Notes

## Official sources

- [Perfect Corp. AI Abs Filter overview](https://docs.perfectcorp.com/reference/ai_abs_filter)
- [Perfect Corp. AI Abs Filter OpenAPI schema](https://docs.perfectcorp.com/_bundle/reference/ai_abs_filter.yaml?download)

| Item | Verified provider detail | ClosetAI implementation choice |
|---|---|---|
| Task creation | `POST /s2s/v2.0/task/abs-shape` | Server-only request with the existing YouCam v2 credential helper. |
| Task status | `GET /s2s/v2.0/task/abs-shape/{task_id}` | Bounded server polling; device receives no task ID or provider credential. |
| Source photo | `src_file_id` or public URL | Private signed upload plus `src_file_id`; never require public photo hosting. |
| Modes | `Six-pack` and `Vest-line` | Only the two documented enum values are exposed. |
| Intensity | `1` and `2`, with `2` stronger | Only documented values are exposed, starting at level 1. |
| Output | A single provider result URL, documented valid for two hours | Return only a verified HTTPS temporary URL; do not persist it. |
| Input | JPG/PNG, smaller than 10MB, long side no larger than 4096; upper- or full-body photo | UI requests a clothed adult upper-body or full-body photo; route validates payload and image MIME. |
| Provider multi-person behavior | Provider may select a person with largest visible shoulder area | ClosetAI requires a user confirmation that the selected image contains only them and does not offer group-image behavior. |
| Error conditions | Size, pose, NSFW, parameter, download, and decode errors | Clear no-fallback error messages; no stock/demo/generated alternative output after a failure. |

## ClosetAI safety and product boundary

This optional feature is an **adult-only cosmetic photo visualization**. It is not medical advice, a health or fitness assessment, body-fat or anatomy measurement, diagnosis, treatment, dietary/exercise guidance, attractiveness rating, or a promise of an actual outcome. The app requires adult confirmation and explicit consent, requests a clothed photo of the user only, does not persist the original or temporary result in history, and never substitutes stock, demo, stale, or fabricated imagery.
