# ClosetAI Mobile Privacy-Reset Review

## Scope

The full React Native/Expo regression suite contains **91 contract and integration tests**. Five tests are directly relevant to Skin Care privacy resets and local retry metadata; adjacent progress, persistence, permission, cancellation, and fallback contracts provide additional coverage for the same privacy boundary.

## Privacy-reset edge cases covered

| Test or contract | Edge case covered | Expected behavior |
|---|---|---|
| `tests/skin-history-clear-contract.test.ts` | Clear-history action is missing or not asynchronous | The context must expose `clearSavedHistory: () => Promise<void>`. |
| `tests/skin-history-clear-contract.test.ts` | Only one persistence layer is cleared | The reset must clear normalized metric rows, AsyncStorage summaries, queued retry metadata, and in-memory `savedResults` together. |
| `tests/skin-history-clear-contract.test.ts` | Accidental destructive action | The UI must show an explicit destructive confirmation with Cancel and Clear saved history actions. |
| `tests/skin-history-clear-contract.test.ts` | Misleading privacy explanation | The confirmation must state that original selfies, raw provider output, and remote provider data are not stored in local history. |
| `tests/live-camera-sqlite-history-contract.test.ts` | Raw photo/provider fields enter SQLite | Native history must reject or omit `image_uri`, `raw_response`, `face_mask`, and `base64`; only normalized metric history is allowed. |
| `tests/skin-progress-trends-contract.test.ts` | Sparse history is presented as a treatment claim | One snapshot must be labeled insufficient rather than showing a personal trend. |
| `tests/skin-progress-trends-contract.test.ts` | Demo and live sources are combined | Mixed-source history must not calculate a combined personal direction. |
| `tests/skin-progress-trends.integration.test.ts` | Normalized rows do not flow correctly into progress UI | The integration must preserve chronological ordering, source labels, local-clear controls, Demo Mode disclosure, and no-photo/raw-payload storage. |
| `tests/offline-skin-analysis-queue-contract.test.ts` | YouCam is unavailable during a live scan | The app may show clearly labeled fictional Demo Mode guidance and save only bounded retry metadata for a later live retry. |
| `tests/offline-skin-analysis-queue-contract.test.ts` | Retry metadata grows stale or contains unsafe data | Entries expire after 24 hours, validate the selfie URI length, require explicit consent, and never include image bytes or provider credentials. |
| `tests/offline-skin-analysis-queue-contract.test.ts` | Consent or summary preference changes after a failure | The queued retry is cleared when the user changes consent or the save-summary choice. |

The full suite also covers cancellation, stale-result protection, focus-aware permission refresh, Demo Mode labeling, user-photo-only behavior, and no-fabrication behavior. The complete suite passed with **91/91 tests**.

## Code changes

### 1. The context now owns the coordinated privacy reset

File: `contexts/SelfieScanContext.tsx`

```tsx
import { clearSkinMetricHistory, saveSkinMetricHistory } from "@/lib/skin-metric-history";
import { clearSkinAnalysisRetryQueue } from "@/lib/skin-analysis-retry-queue";
```

The clear-history action now deletes all four relevant local states:

```tsx
clearSavedHistory: async () => {
  await clearSkinMetricHistory();
  await AsyncStorage.removeItem(SAVED_RESULTS_KEY);
  await clearSkinAnalysisRetryQueue();
  setSavedResults([]);
},
```

The important detail is that the retry queue is cleared in the same async action as SQLite metric history and normalized AsyncStorage summaries. This prevents a privacy reset from removing visible history while leaving a recoverable selected-selfie retry entry behind.

### 2. The retry queue stores only bounded local metadata

File: `lib/skin-analysis-retry-queue.ts`

```tsx
export type SkinAnalysisRetryQueueEntry = {
  selfieUri: string;
  saveSnapshot: boolean;
  acceptsGuidance: true;
  queuedAt: string;
  reason: "youcam-unavailable";
};

const STORAGE_KEY = "@closetai_skin_analysis_retry_queue_v1";
const MAX_QUEUE_AGE_MS = 24 * 60 * 60 * 1000;
```

Validation rejects empty or oversized URIs, missing consent, unknown reasons, invalid timestamps, future timestamps, and entries older than 24 hours:

```tsx
function isValidEntry(value: unknown): value is SkinAnalysisRetryQueueEntry {
  if (!value || typeof value !== "object") return false;
  const entry = value as Partial<SkinAnalysisRetryQueueEntry>;
  if (!isValidUri(entry.selfieUri) || typeof entry.saveSnapshot !== "boolean") return false;
  if (entry.acceptsGuidance !== true || entry.reason !== "youcam-unavailable" || typeof entry.queuedAt !== "string") return false;
  const queuedAt = Date.parse(entry.queuedAt);
  return Number.isFinite(queuedAt)
    && Date.now() - queuedAt >= 0
    && Date.now() - queuedAt <= MAX_QUEUE_AGE_MS;
}
```

Invalid or expired entries are removed when loaded:

```tsx
if (!isValidEntry(parsed)) {
  await AsyncStorage.removeItem(STORAGE_KEY);
  return null;
}
```

### 3. The user-facing confirmation remains explicit

File: `components/skin/SkinJourneyPage.tsx`

```tsx
const requestClearSavedHistory = () => Alert.alert(
  "Clear saved Skin Care history?",
  "This removes normalized summaries from this device and clears the local metric trend database. Original selfies, raw provider output, and remote provider data are not stored here and are not affected.",
  [
    { text: "Cancel", style: "cancel" },
    {
      text: "Clear saved history",
      style: "destructive",
      onPress: () => {
        void clearSavedHistory().catch(() =>
          Alert.alert(
            "History was not cleared",
            "We could not clear every local history store. Please try again."
          )
        );
      },
    },
  ]
);
```

This preserves a safe failure mode: if any local store cannot be cleared, the user receives an error instead of a false success signal.

## What is not covered by these contract tests

These are source-level contract and integration tests rather than device-level behavioral tests. They do not prove that AsyncStorage succeeds on every physical device, that a provider outage is reproduced identically on iOS and Android, or that a user can complete the entire reset flow under OS-level storage pressure. Physical Expo Go testing should still verify: create a live-scan fallback entry, open Skin Care history, confirm Clear saved history, return to the selfie flow, and confirm the retry card is gone.
