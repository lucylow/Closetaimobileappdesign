# ClosetAI External Wellness-Progress Sync API Integration Guide

**Document status:** Architecture and implementation guide.  
**Audience:** Mobile, backend, privacy, and QA teams.  
**Scope:** User-authorized sync of the ClosetAI **Your Progress** feature with external wellness applications or platforms.  
**Out of scope:** Medical diagnosis, clinical decision support, EHR/clinical-record sync, background transfer without consent, and transfer of source selfies or raw provider responses.

> **Core boundary:** ClosetAI skin-progress values are normalized cosmetic/wellness reflection signals. They must not be represented as diagnoses, clinical measurements, treatment outcomes, or medical records in an external health platform.

## 1. Executive summary

ClosetAI’s local Your Progress workflow stores normalized metric points, timestamps, and source labels in local history. It intentionally excludes original selfies, image URIs, masks, raw provider output, task IDs, and credentials. Any external integration must preserve that data-minimization contract.

A safe initial production design is a **user-initiated, consented wellness-summary export**. The export should include a limited date range, snapshot count, optional routine-completion reflection, and source context. It should **not** export images, raw signal scores by default, inferred traits, diagnoses, or unverified “improvement” claims. Apple HealthKit requires fine-grained read/share authorization per data type, and Android Health Connect requires declared and granted permissions for each requested data type.[1][2]

| Integration target | Recommended first action | Do not do |
|---|---|---|
| Wellness app with OAuth API | Send a user-approved, minimal wellness reflection envelope through ClosetAI’s backend. | Upload selfies, raw provider JSON, or silent background sync. |
| Apple HealthKit | Evaluate whether an approved, semantically valid HealthKit type exists; request only that type after explicit consent. | Invent a custom HealthKit skin-score record or frame it as a clinical measurement. |
| Android Health Connect | Evaluate a supported, semantically valid record type and declared permission; provide a sync toggle and Manage Access route. | Request unrelated data types or continue syncing after the user pauses/revokes access. |
| Clinical/EHR system | Require a separate regulated integration, legal/privacy review, and explicit user workflow. | Treat the current cosmetic reflection feature as an EHR export. |

## 2. Current ClosetAI progress data contract

The local progress feature is intentionally small and privacy-safe.

```ts
export type SkinMetricHistoryPoint = {
  scanId: string;
  capturedAt: string;
  source: "demo" | "youcam" | "cached";
  overallScore?: number;
  metricKey: string;
  score: number;
};
```

The application’s trend layer then derives non-clinical directions such as **Up**, **Down**, **Steady**, **Mixed sources**, or **More snapshots needed**. Those labels are display aids, not outcome claims. A production integration must preserve each point’s source boundary:

| Source | External-sync policy |
|---|---|
| `youcam` | May be summarized only after explicit user consent; label as normalized cosmetic/wellness context. |
| `demo` | **Never export as personal progress.** It is fictional prototype reference data. |
| `cached` | Export only if the user explicitly chooses it and the payload labels it as cached local context. |
| `mixed` | Do not create a combined trend claim; require source-specific selection or omit the direction. |

## 3. Recommended external data model

Start with a user-controlled **reflection envelope**, rather than a skin diagnostic record. The following request is a documented example for a future ClosetAI backend endpoint; it is not a claim that the endpoint exists today.

```ts
export type WellnessProgressExport = {
  schemaVersion: "1.0";
  exportId: string;                 // UUID generated on the server
  subjectReference: string;         // Provider-specific opaque ID; never an email in payload logs
  capturedWindow: {
    start: string;                  // ISO-8601 timestamp
    end: string;
    timezone: string;
  };
  provenance: {
    producer: "ClosetAI";
    feature: "your_progress";
    mode: "user_initiated";
    sourceContext: "youcam" | "cached";
    disclaimer: string;
  };
  reflection: {
    snapshotCount: number;
    captureDayCount: number;
    routineCompletionCount?: number;
    routineStepCount?: number;
    userNote?: string;              // Optional, separately consented, capped length
  };
  metricDirections?: Array<{
    metricKey: "hydration" | "radiance" | "texture" | "pores" | "redness" | "blemishes" | "darkSpots" | "fineLines";
    direction: "up" | "down" | "steady" | "insufficient";
    pointCount: number;
    source: "youcam" | "cached";
    label: "normalized cosmetic/wellness snapshot direction";
  }>;
};
```

The model intentionally omits `imageUri`, base64 image data, raw provider responses, facial attributes, inferred age, gender, ethnicity, health conditions, product-purchase history, access tokens, and diagnostic labels.

## 4. Consent and source-selection UX

A sync must be initiated from a dedicated **Wellness Sync** settings screen. The screen must state exactly what will be sent, to which provider, for which date range, and how the user can pause or revoke the connection.

```tsx
<Switch value={syncEnabled} onValueChange={setSyncEnabled} />
<Text>
  Share a selected local wellness reflection summary. Original selfies, raw analysis,
  fictional Demo Mode values, and medical information are never included.
</Text>
```

Consent should be granular. A user can select a provider, date range, source context, whether to include an optional note, and whether to include optional normalized direction labels. The defaults should be **off**, **user initiated**, and **minimum data**.

> Apple states that HealthKit uses fine-grained authorization and that an app must request permission to read and share each data type before using it.[1]

| User action | Required behavior |
|---|---|
| Enable connection | Present a pre-consent explanation, then platform/provider authorization. |
| Export now | Show a review screen with the exact number of snapshot days and fields being transmitted. |
| Pause connection | Stop future transfers immediately; retain only the local consent preference needed to render the paused state. |
| Revoke provider access | Link to provider/platform settings and remove local refresh credentials server-side. |
| Change date range | Recompute summary locally; do not upload until user confirms. |
| Attempt Demo Mode export | Block with a clear explanation that fictional reference data cannot be exported as personal progress. |

## 5. Apple HealthKit integration considerations

HealthKit access must be explicitly configured in the native iOS project. Apple documents that an app needs the HealthKit capability, usage descriptions, a device-availability check, and fine-grained authorization for the requested read/share types.[1]

ClosetAI must not create an arbitrary “skin health score” in HealthKit. Before writing any value, the team must confirm that a platform-supported data type accurately represents the exact user-authorized wellness concept and that the product/legal review approves the mapping. If no semantically appropriate type exists, use a separate provider API or a local-only reflection rather than misclassifying a cosmetic signal as health data.

```swift
let isAvailable = HKHealthStore.isHealthDataAvailable()

// Pseudocode only: define only approved, semantically valid types.
try await healthStore.requestAuthorization(
  toShare: approvedShareTypes,
  read: approvedReadTypes
)
```

Apple notes that a person may grant only a recent window of data and that an app should not interpret missing older samples as evidence that no data exists.[1] ClosetAI should therefore record an authorization-window note and avoid producing completeness claims.

## 6. Android Health Connect integration considerations

Health Connect uses type-specific declared and granted permissions. Android’s documentation says apps should check availability, declare only the required permissions, provide a privacy-policy rationale, and check permissions before performing operations because access can be revoked at any time.[2]

The app’s Android settings must include a user-visible sync toggle and a **Manage access** route. Android’s Health Connect guidance explicitly recommends these controls so people can pause or resume synchronization and manage app permissions.[3]

```kotlin
// Pseudocode only: request only review-approved record-type permissions.
val granted = healthConnectClient.permissionController.getGrantedPermissions()
if (!granted.containsAll(approvedPermissions)) {
  permissionLauncher.launch(approvedPermissions)
}
```

Do not use Heart Rate, Steps, Nutrition, or another unrelated type merely because it is available. The selected type must accurately describe the user-authorized information. If no appropriate supported type exists, do not write to Health Connect.

## 7. Generic OAuth 2.1 wellness-provider flow

For a wellness app that exposes an OAuth-based API, use an authorization-code flow with PKCE. Tokens must be exchanged and stored on ClosetAI’s server only; the Expo client must never hold a long-lived provider client secret.

```text
Mobile app
  → opens provider authorization URL with PKCE
  → provider redirects to ClosetAI callback
  → backend exchanges authorization code
  → backend encrypts refresh token at rest
  → user reviews selected export
  → mobile requests server-side export
  → backend posts signed minimal envelope to provider API
```

Recommended authorization request parameters:

```text
response_type=code
client_id=<public-client-id>
redirect_uri=closetai://wellness-sync/callback
code_challenge=<S256-pkce-challenge>
code_challenge_method=S256
scope=wellness.progress.write
state=<short-lived-CSRF-state>
```

The exact scope string varies by provider. ClosetAI should request the narrowest documented scope and show it in the user’s pre-consent UI.

## 8. Illustrative server API

A future server-only integration can expose an authenticated route that validates consent, excludes Demo Mode, computes a bounded local summary, and writes through a provider adapter.

```ts
app.post("/api/wellness-progress/exports", requireAuth, async (req, res) => {
  const payload = validateProgressExportRequest(req.body);

  if (payload.consent !== true) {
    return res.status(400).json({ message: "Explicit sync consent is required." });
  }
  if (payload.sourceContext === "demo") {
    return res.status(400).json({ message: "Fictional Demo Mode values cannot be exported as personal progress." });
  }

  const exportEnvelope = buildMinimalWellnessProgressExport(payload);
  const result = await providerAdapter.exportProgress(exportEnvelope);
  return res.status(201).json(result);
});
```

The route should accept a date range with a strict maximum, a provider connection ID, source selection, and specific inclusion switches. It should reject raw image fields and unknown metric keys at schema validation.

## 9. Idempotency, retries, and failure handling

External sync must be resilient without silently duplicating data. Each export requires an idempotency key generated on the server and associated with the provider connection, user, source window, and normalized payload hash.

```ts
const idempotencyKey = sha256(
  `${providerConnectionId}:${windowStart}:${windowEnd}:${payloadHash}`,
);
```

| Failure | Required behavior |
|---|---|
| User denied authorization | Keep sync disabled; explain how to enable it later. |
| Permission revoked | Stop sync immediately; show a reconnect action. |
| Provider timeout | Mark export retryable; do not invent success. |
| 401/invalid token | Remove unusable token server-side; require reconnection. |
| 409/duplicate | Treat as idempotent success only after provider response validation. |
| 429/rate limit | Respect `Retry-After`; do not loop on the mobile UI thread. |
| Schema mismatch | Quarantine the export and alert internal monitoring without logging sensitive payload fields. |

A failure must not convert the local ClosetAI dashboard into fictional external-sync status. The local progress view remains available even if the provider is offline.

## 10. Logging and observability

Logs must record only operational metadata: provider name, opaque connection ID, export ID, timestamp, status class, retry count, and schema version. Never log the source selfie, raw signal payload, access token, refresh token, optional user reflection text, or full wellness-export body.

```ts
logger.info({
  event: "wellness_progress_export_completed",
  provider: connection.provider,
  exportId,
  statusCode: response.status,
  schemaVersion: "1.0",
});
```

Monitoring should track connection success rate, authorization failures, revocations, provider latency, validation rejection rate, and duplicate suppression. It must not aggregate or display individual cosmetic-signal values as health outcomes.

## 11. Retention, deletion, and revocation

ClosetAI should retain no export body longer than necessary to complete the request and resolve a short operational support window. Persist only a minimal immutable receipt:

```ts
export type ProgressExportReceipt = {
  exportId: string;
  provider: string;
  connectionId: string;
  createdAt: string;
  status: "queued" | "sent" | "failed" | "revoked";
  schemaVersion: "1.0";
};
```

On connection removal, delete refresh tokens and pause queued jobs. The UI should clearly distinguish “disconnected from ClosetAI” from “data previously received by an external provider may need to be managed in that provider’s settings.” Apple and Android both provide user-facing permission management paths.[1][3]

## 12. API security checklist

| Control | Requirement |
|---|---|
| Transport | TLS for every provider and ClosetAI endpoint. |
| Authentication | User session on ClosetAI endpoint; OAuth authorization code with PKCE for supported providers. |
| Token storage | Server-side encryption at rest; no long-lived secret in Expo client. |
| Validation | Strict schema, known metric enum, bounded window, Demo Mode rejection, optional-note length cap. |
| Consent | Explicit, timestamped, provider-specific, revocable, with inclusion controls. |
| Rate limiting | Per-user and per-provider quotas with retry backoff. |
| Idempotency | Server-generated idempotency key and payload-hash deduplication. |
| Logging | Minimal operational metadata only; never raw payload, image, token, or note. |
| Review | Product/privacy/legal review before exposing a health-platform data type. |

## 13. Expo implementation path

The existing ClosetAI app is Expo-based. A true HealthKit or Health Connect integration requires an approved native module, platform configuration, and a development build; it should not be implemented as an unreviewed JavaScript-only mock.

1. Keep the existing local Your Progress feature fully functional without any connection.
2. Add a new server-managed `WellnessConnections` settings area only after provider approval.
3. Use a native bridge for HealthKit/Health Connect and guard it with platform availability checks.
4. Keep OAuth exchanges and refresh tokens on the Express server.
5. Add source-specific export validation and receipts.
6. Ship with user-facing pause, disconnect, manage-access, and export-review flows.
7. Add contract, negative-path, permission-revocation, idempotency, and retention tests.

## 14. Test plan

```bash
# Existing local progress safety suite
npm run test:progress

# Future server sync tests
npx tsx tests/wellness-progress-export-contract.test.ts
npx tsx tests/wellness-progress-oauth-revocation.test.ts
npx tsx tests/wellness-progress-idempotency.test.ts
```

Minimum automated assertions:

1. Demo Mode payloads are rejected for personal-progress export.
2. A missing consent flag is rejected.
3. An image URI, base64 field, raw response, or unknown metric key is rejected.
4. Payload date ranges are bounded.
5. Mixed source values do not create a combined direction export.
6. OAuth tokens never reach the Expo client or logs.
7. A retry preserves one idempotency key.
8. Revocation blocks subsequent sync requests.
9. The local Your Progress feature remains functional when every external provider is unavailable.

## 15. Product wording

Use these user-facing phrases:

| Prefer | Avoid |
|---|---|
| “Share a selected wellness reflection summary.” | “Send your health diagnosis.” |
| “Normalized cosmetic/wellness snapshot direction.” | “Clinical skin measurement.” |
| “Fictional Demo Mode values cannot be shared as personal progress.” | “Demo data is your health history.” |
| “You can pause or disconnect at any time.” | “We continuously sync in the background.” |
| “Verify the provider’s permissions and privacy policy.” | “Your data is automatically safe everywhere.” |

## References

[1]: https://developer.apple.com/documentation/healthkit/authorizing-access-to-health-data "Apple Developer: Authorizing access to health data"
[2]: https://developer.android.com/health-and-fitness/health-connect/get-started "Android Developers: Get started with Health Connect"
[3]: https://developer.android.com/health-and-fitness/health-connect/ui/permissions "Android Developers: Health Connect permissions and data access"
