import type { FaceLiftFeatures } from "@shared/face-lift-simulation";
import { requestYouCamSkinV2 } from "./youcam-skin-v2";

type YouCamTask = { taskId: string; pollingInterval: number };

function taskStatus(data: any): string {
  return String(data?.task_status || data?.status || (typeof data?.url === "string" ? "success" : "running")).toLowerCase();
}

export async function startYouCamFaceLiftPreprocess(fileId: string): Promise<YouCamTask> {
  const response = await requestYouCamSkinV2("/s2s/v2.0/task/face-lift/pre-process", { method: "POST", body: JSON.stringify({ src_file_id: fileId }) });
  const taskId = response.data?.data?.task_id || response.data?.task_id;
  if (!response.ok || typeof taskId !== "string" || !taskId) throw new Error(`YouCam face-lift pre-process creation failed (${response.status})`);
  return { taskId, pollingInterval: 3 };
}

export async function getYouCamFaceLiftPreprocess(taskId: string): Promise<{ status: string; faceCount?: number; error?: string }> {
  const response = await requestYouCamSkinV2(`/s2s/v2.0/task/face-lift/pre-process/${encodeURIComponent(taskId)}`);
  if (!response.ok) throw new Error(`YouCam face-lift pre-process status failed (${response.status})`);
  const data = response.data?.data || response.data || {};
  const result = data?.results?.result || data?.result;
  return { status: taskStatus(data), faceCount: Array.isArray(result) ? result.length : undefined, error: data.error || data.error_message };
}

export async function startYouCamFaceLiftTask(fileId: string, features: FaceLiftFeatures): Promise<YouCamTask> {
  const response = await requestYouCamSkinV2("/s2s/v2.0/task/face-lift", {
    method: "POST",
    body: JSON.stringify({ src_file_id: fileId, version: "1.0", index: 0, type: "custom", features }),
  });
  const taskId = response.data?.data?.task_id || response.data?.task_id;
  if (!response.ok || typeof taskId !== "string" || !taskId) throw new Error(`YouCam face-lift task creation failed (${response.status})`);
  return { taskId, pollingInterval: 3 };
}

export async function getYouCamFaceLiftTask(taskId: string): Promise<{ status: string; output?: unknown; error?: string }> {
  const response = await requestYouCamSkinV2(`/s2s/v2.0/task/face-lift/${encodeURIComponent(taskId)}`);
  if (!response.ok) throw new Error(`YouCam face-lift task status failed (${response.status})`);
  const data = response.data?.data || response.data || {};
  return { status: taskStatus(data), output: data, error: data.error || data.error_message };
}
