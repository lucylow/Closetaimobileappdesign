import type { FaceAngleStrictness } from "@shared/facial-color-tones";
import { requestYouCamSkinV2 } from "./youcam-skin-v2";

export type SkinToneAnalysisTask = { taskId: string; pollingInterval: number };

export async function startYouCamSkinToneAnalysisTask(fileId: string, faceAngleStrictness: FaceAngleStrictness): Promise<SkinToneAnalysisTask> {
  const response = await requestYouCamSkinV2("/s2s/v2.0/task/skin-tone-analysis", {
    method: "POST",
    body: JSON.stringify({ src_file_id: fileId, face_angle_strictness_level: faceAngleStrictness }),
  });
  const taskId = response.data?.data?.task_id || response.data?.task_id;
  if (!response.ok || !taskId) throw new Error(`YouCam facial color-tone task creation failed (${response.status})`);
  return { taskId, pollingInterval: 3 };
}

export async function getYouCamSkinToneAnalysisTask(taskId: string): Promise<{ status: string; colors?: unknown; error?: string }> {
  const response = await requestYouCamSkinV2(`/s2s/v2.0/task/skin-tone-analysis/${encodeURIComponent(taskId)}`);
  if (!response.ok) throw new Error(`YouCam facial color-tone status failed (${response.status})`);
  const data = response.data?.data || response.data || {};
  return {
    status: String(data.task_status || data.status || "running").toLowerCase(),
    colors: data.results?.color || data.color,
    error: data.error || data.error_message || data.error_code,
  };
}
