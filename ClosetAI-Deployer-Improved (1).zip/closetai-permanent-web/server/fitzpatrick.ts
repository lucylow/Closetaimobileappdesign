import { FITZPATRICK_DISCLOSURE, type FitzpatrickCapability } from "@shared/fitzpatrick-profile";

/**
 * Perfect Corp.'s public product material confirms product availability but does not expose a
 * verified public task schema or endpoint. Keep the capability transparent until an account-level
 * provider contract is configured; never estimate a classification locally from a selfie.
 */
export function getFitzpatrickCapability(): FitzpatrickCapability {
  const configured = Boolean(process.env.PERFECT_YOUCAM_FITZPATRICK_ENDPOINT && process.env.PERFECT_YOUCAM_FITZPATRICK_API_KEY);
  return configured
    ? {
        available: false,
        state: "configured",
        sourceLabel: "Provider contract pending verification",
        message: "A Fitzpatrick provider endpoint is configured, but its account-specific request schema must be verified before live classification is enabled.",
        disclosure: FITZPATRICK_DISCLOSURE,
      }
    : {
        available: false,
        state: "not_configured",
        sourceLabel: "No live provider connected",
        message: "No verified Fitzpatrick provider contract is connected. ClosetAI will not estimate a classification from your photo.",
        disclosure: FITZPATRICK_DISCLOSURE,
      };
}
