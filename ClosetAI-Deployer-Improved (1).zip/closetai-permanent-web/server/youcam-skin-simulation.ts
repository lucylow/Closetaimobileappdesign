import type { SkinSimulationAdjustments } from "@shared/skin-simulation";
import { requestYouCamSkinV2 } from "./youcam-skin-v2";

export type SkinSimulationTask = { taskId: string; pollingInterval: number };

export async function startYouCamSkinSimulationTask(fileId: string, adjustments: SkinSimulationAdjustments): Promise<SkinSimulationTask> {
  const response = await requestYouCamSkinV2("/s2s/v2.0/task/skin-simulation", {
    method: "POST",
    body: JSON.stringify({ src_file_id: fileId, ...adjustments }),
  });
  const taskId = response.data?.data?.task_id || response.data?.task_id;
  if (!response.ok || !taskId) throw new Error(`YouCam skin simulation task creation failed (${response.status})`);
  return { taskId, pollingInterval: 3 };
}

export async function getYouCamSkinSimulationTask(taskId: string): Promise<{ status: string; resultUrl?: string; error?: string }> {
  const response = await requestYouCamSkinV2(`/s2s/v2.0/task/skin-simulation/${encodeURIComponent(taskId)}`);
  if (!response.ok) throw new Error(`YouCam skin simulation status failed (${response.status})`);
  const data = response.data?.data || response.data || {};
  return {
    status: String(data.task_status || data.status || "running").toLowerCase(),
    resultUrl: data.url || data.result_url,
    error: data.error || data.error_message || data.error_code,
  };
}
