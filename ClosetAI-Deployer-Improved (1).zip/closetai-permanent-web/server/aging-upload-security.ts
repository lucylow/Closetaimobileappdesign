const MAX_AGING_IMAGE_BYTES = 9_999_999;
const MAX_AGING_IMAGE_BASE64_CHARS = 14_000_000;
const OPTIONAL_JPEG_DATA_URI = /^data:image\/(?:jpeg|jpg);base64,/i;
const BASE64 = /^[A-Za-z0-9+/]*={0,2}$/;

export type ValidatedAgingImage = {
  buffer: Buffer;
  contentType: "image/jpeg";
};

/**
 * Validates only the documented AI Aging input class before a server-only signed upload.
 * The caller owns the returned buffer and must erase it with `eraseTransientAgingImage`.
 */
export function decodeAgingJpegUpload(value: unknown): ValidatedAgingImage {
  if (typeof value !== "string" || value.length < 100) {
    throw new Error("Choose a clear JPEG selfie before creating an age-progression visualization.");
  }
  if (value.length > MAX_AGING_IMAGE_BASE64_CHARS) {
    throw new Error("That image is too large. Choose a JPEG photo under 10 MB.");
  }

  const encoded = value.replace(OPTIONAL_JPEG_DATA_URI, "");
  if (!encoded || !BASE64.test(encoded) || encoded.length % 4 === 1) {
    throw new Error("The selected photo is not a valid JPEG upload.");
  }

  const buffer = Buffer.from(encoded, "base64");
  const canonical = buffer.toString("base64").replace(/=+$/, "");
  const inputCanonical = encoded.replace(/=+$/, "");
  const isJpeg = buffer.length >= 4 && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff && buffer[buffer.length - 2] === 0xff && buffer[buffer.length - 1] === 0xd9;

  if (canonical !== inputCanonical || !isJpeg || buffer.length >= MAX_AGING_IMAGE_BYTES) {
    buffer.fill(0);
    throw new Error("Use a clear JPEG selfie under 10 MB for this age-progression visualization.");
  }

  return { buffer, contentType: "image/jpeg" };
}

/** Minimizes the in-memory lifetime of a raw selected photo after the signed upload finishes. */
export function eraseTransientAgingImage(image: Buffer | null | undefined): void {
  image?.fill(0);
}

export const AGING_UPLOAD_SECURITY_BOUNDARY =
  "The aging route accepts only validated JPEG bytes below the documented provider limit, uploads them through a server-only HTTPS signed URL, and erases the raw server buffer after upload.";
