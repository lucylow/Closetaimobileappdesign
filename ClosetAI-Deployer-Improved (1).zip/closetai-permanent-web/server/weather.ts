import { BoundedTtlCache } from "./youcam-cache";

export type WeatherStyleContext = {
  source: "open-meteo";
  cached: boolean;
  observedAt: string;
  temperatureF: number;
  apparentTemperatureF: number;
  windMph: number;
  weatherCode: number;
  condition: string;
  stylingText: string;
  tags: string[];
};

const weatherCache = new BoundedTtlCache<Omit<WeatherStyleContext, "cached">>(120);
const WEATHER_TIMEOUT_MS = 8_000;

function numberInRange(value: unknown, minimum: number, maximum: number): number | null {
  const parsed = typeof value === "number" ? value : Number(value);
  return Number.isFinite(parsed) && parsed >= minimum && parsed <= maximum ? parsed : null;
}

function describeWeatherCode(code: number): string {
  if ([0, 1].includes(code)) return "clear";
  if ([2, 3].includes(code)) return "cloudy";
  if ([45, 48].includes(code)) return "foggy";
  if ([51, 53, 55, 56, 57].includes(code)) return "drizzle";
  if ([61, 63, 65, 66, 67, 80, 81, 82].includes(code)) return "rain";
  if ([71, 73, 75, 77, 85, 86].includes(code)) return "snow";
  if ([95, 96, 99].includes(code)) return "stormy";
  return "mixed conditions";
}

function buildStylingContext(current: any): Omit<WeatherStyleContext, "cached"> {
  const temperatureF = Math.round(Number(current?.temperature_2m));
  const apparentTemperatureF = Math.round(Number(current?.apparent_temperature ?? current?.temperature_2m));
  const windMph = Math.round(Number(current?.wind_speed_10m ?? 0));
  const weatherCode = Number(current?.weather_code ?? -1);
  const condition = describeWeatherCode(weatherCode);
  const tags = new Set<string>([condition]);
  if (apparentTemperatureF <= 50) tags.add("cold");
  else if (apparentTemperatureF >= 80) tags.add("warm");
  else tags.add("mild");
  if (windMph >= 18) tags.add("windy");
  if (["rain", "drizzle", "snow", "stormy"].includes(condition)) tags.add("wet-weather");
  const additions = [
    tags.has("cold") ? "layering" : tags.has("warm") ? "breathable fabrics" : "light layers",
    tags.has("wet-weather") ? "a weather-ready outer layer" : null,
    tags.has("windy") ? "a scarf or secure bag" : null,
  ].filter(Boolean).join(", ");
  return {
    source: "open-meteo",
    observedAt: typeof current?.time === "string" ? current.time : new Date().toISOString(),
    temperatureF,
    apparentTemperatureF,
    windMph,
    weatherCode,
    condition,
    stylingText: `${condition} · feels like ${apparentTemperatureF}°F · consider ${additions}`,
    tags: [...tags],
  };
}

/**
 * Fetches live weather only for an explicit client-provided coordinate pair. Coordinates are
 * rounded for the cache key and are not persisted. When unavailable, callers should retain the
 * user's manually entered weather preference rather than inventing a live condition.
 */
export async function getLiveWeatherStyleContext(latitude: unknown, longitude: unknown): Promise<WeatherStyleContext> {
  const lat = numberInRange(latitude, -90, 90);
  const lon = numberInRange(longitude, -180, 180);
  if (lat === null || lon === null) throw new Error("Valid latitude and longitude are required for live weather.");
  const key = `${lat.toFixed(2)},${lon.toFixed(2)}`;
  const cached = weatherCache.get(key);
  if (cached.value) return { ...cached.value, cached: true };

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), WEATHER_TIMEOUT_MS);
  try {
    const params = new URLSearchParams({
      latitude: String(lat),
      longitude: String(lon),
      current: "temperature_2m,apparent_temperature,weather_code,wind_speed_10m",
      temperature_unit: "fahrenheit",
      wind_speed_unit: "mph",
      timezone: "auto",
    });
    const response = await fetch(`https://api.open-meteo.com/v1/forecast?${params.toString()}`, { signal: controller.signal });
    if (!response.ok) throw new Error(`Weather provider returned ${response.status}.`);
    const payload = await response.json();
    if (!payload?.current) throw new Error("Weather provider did not return current conditions.");
    const context = buildStylingContext(payload.current);
    weatherCache.set(key, context, 15 * 60 * 1000);
    return { ...context, cached: false };
  } catch (error) {
    const reason = error instanceof Error ? error.message : "weather provider unavailable";
    throw new Error(`Live weather is unavailable: ${reason}`);
  } finally {
    clearTimeout(timeout);
  }
}
