import type { FaceAttributeAction } from "@shared/face-attributes";
import type { FaceAngleStrictness } from "@shared/facial-color-tones";
import { requestYouCamSkinV2 } from "./youcam-skin-v2";

export type FaceAttributesTask = { taskId: string; pollingInterval: number };
let nextRequestId = 0;

export async function startYouCamFaceAttributesTask(fileId: string, actions: FaceAttributeAction[], faceAngleStrictness: FaceAngleStrictness): Promise<FaceAttributesTask> {
  const requestId = nextRequestId++;
  const response = await requestYouCamSkinV2("/s2s/v2.0/task/face-attr-analysis", {
    method: "POST",
    body: JSON.stringify({
      request_id: requestId,
      payload: {
        file_sets: { src_ids: [fileId] },
        actions: [{ id: 0, params: { face_angle_strictness_level: faceAngleStrictness }, dst_actions: actions }],
      },
    }),
  });
  const taskId = response.data?.data?.task_id || response.data?.task_id;
  if (!response.ok || !taskId) throw new Error(`YouCam face attributes task creation failed (${response.status})`);
  return { taskId, pollingInterval: 3 };
}

export async function getYouCamFaceAttributesTask(taskId: string): Promise<{ status: string; results?: unknown; error?: string }> {
  const response = await requestYouCamSkinV2(`/s2s/v2.0/task/face-attr-analysis/${encodeURIComponent(taskId)}`);
  if (!response.ok) throw new Error(`YouCam face attributes status failed (${response.status})`);
  const data = response.data?.data || response.data || {};
  return { status: String(data.task_status || data.status || "running").toLowerCase(), results: data.results, error: data.error || data.error_message || data.error_code };
}
