import { requestYouCamSkinV2 } from "./youcam-skin-v2";

export type AgingTask = { taskId: string; pollingInterval: number };

export async function startYouCamAgingTask(fileId: string): Promise<AgingTask> {
  const response = await requestYouCamSkinV2("/s2s/v2.0/task/aging", {
    method: "POST",
    body: JSON.stringify({ src_file_id: fileId }),
  });
  const taskId = response.data?.data?.task_id || response.data?.task_id;
  if (!response.ok || !taskId) throw new Error(`YouCam aging task creation failed (${response.status})`);
  return { taskId, pollingInterval: 3 };
}

export async function getYouCamAgingTask(taskId: string): Promise<{ status: string; output?: unknown; error?: string }> {
  const response = await requestYouCamSkinV2(`/s2s/v2.0/task/aging/${encodeURIComponent(taskId)}`);
  if (!response.ok) throw new Error(`YouCam aging task status failed (${response.status})`);
  const data = response.data?.data || response.data || {};
  return { status: String(data.task_status || data.status || "running").toLowerCase(), output: data.results || data, error: data.error || data.error_message || data.error_code };
}
