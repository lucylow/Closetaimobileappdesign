import type { BreastShapeIntensity } from "@shared/breast-shape-simulation";
import { requestYouCamSkinV2 } from "./youcam-skin-v2";

export type BreastShapeTask = { taskId: string; pollingInterval: number };

export async function startYouCamBreastShapeTask(fileId: string, intensity: BreastShapeIntensity): Promise<BreastShapeTask> {
  const response = await requestYouCamSkinV2("/s2s/v2.0/task/breast-shape", {
    method: "POST",
    body: JSON.stringify({ src_file_id: fileId, intensity }),
  });
  const taskId = response.data?.data?.task_id || response.data?.task_id;
  if (!response.ok || typeof taskId !== "string" || !taskId) {
    throw new Error(`YouCam cosmetic visualization task creation failed (${response.status})`);
  }
  return { taskId, pollingInterval: 3 };
}

export async function getYouCamBreastShapeTask(taskId: string): Promise<{ status: string; output?: unknown; error?: string }> {
  const response = await requestYouCamSkinV2(`/s2s/v2.0/task/breast-shape/${encodeURIComponent(taskId)}`);
  if (!response.ok) throw new Error(`YouCam cosmetic visualization task status failed (${response.status})`);
  const raw = response.data?.data || response.data || {};
  const status = String(raw.task_status || raw.status || (typeof raw.url === "string" ? "success" : "running")).toLowerCase();
  return { status, output: raw, error: typeof raw.error === "string" ? raw.error : typeof raw.error_message === "string" ? raw.error_message : undefined };
}
