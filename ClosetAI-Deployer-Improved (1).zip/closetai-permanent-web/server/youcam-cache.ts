export type CacheStatus = "hit" | "miss" | "stale";

type CacheEntry<T> = {
  value: T;
  expiresAt: number;
};

/**
 * Small in-memory cache for completed server-to-server YouCam responses. It is deliberately
 * process-local, stores no raw images or credentials, and is bounded to prevent unbounded memory
 * growth. Cache loss on deployment or restart is safe because callers still use live requests.
 */
export class BoundedTtlCache<T> {
  private readonly entries = new Map<string, CacheEntry<T>>();

  constructor(private readonly maxEntries = 100) {}

  get(key: string): { value?: T; status: CacheStatus } {
    const entry = this.entries.get(key);
    if (!entry) return { status: "miss" };
    if (entry.expiresAt <= Date.now()) {
      this.entries.delete(key);
      return { status: "stale" };
    }
    // Refresh recency without extending expiry.
    this.entries.delete(key);
    this.entries.set(key, entry);
    return { value: entry.value, status: "hit" };
  }

  set(key: string, value: T, ttlMs: number): void {
    if (ttlMs <= 0) return;
    this.entries.delete(key);
    this.entries.set(key, { value, expiresAt: Date.now() + ttlMs });
    while (this.entries.size > this.maxEntries) {
      const oldestKey = this.entries.keys().next().value as string | undefined;
      if (!oldestKey) break;
      this.entries.delete(oldestKey);
    }
  }

  delete(key: string): void {
    this.entries.delete(key);
  }

  clear(): void {
    this.entries.clear();
  }

  size(): number {
    return this.entries.size;
  }
}
