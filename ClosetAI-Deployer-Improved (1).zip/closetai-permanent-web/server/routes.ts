import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "node:http";
import OpenAI from "openai";
import { storage } from "./storage";
import { setupStripeBillingRoutes } from "./stripe-billing";
import {
  generateOutfitExplanation,
  generateCaptionAndHashtags,
  generateOutfitSuggestions,
  generateAITags,
  generateStyleInsight,
} from "./ai";
import {
  testApiKey as testYouCamApiKey,
  getHairStyleGroups,
  createSkinAnalysisFileUpload,
  uploadImageToUrl,
  startSkinAnalysisTask,
  getSkinAnalysisTask,
  createFashionFileUpload,
  uploadFashionImage,
  startFashionTryOnTask,
  pollFashionTryOnTask,
  mapWardrobeCategoryToFashionCategory,
  supportsYouCamFashionCategory,
  isFashionTryOnConfigured,
  getFashionTryOnCapability,
} from "./youcam";
import { normalizeSkinSnapshot, demoSkinSnapshot, SKIN_ANALYSIS_CREDITS } from "@shared/skin";
import { resolveSkinAnalysisPlan } from "@shared/skin-analysis-plan";
import { createSkinSimulationRequest, SKIN_SIMULATION_DISCLOSURE } from "@shared/skin-simulation";
import { getYouCamSkinSimulationTask, startYouCamSkinSimulationTask } from "./youcam-skin-simulation";
import { getFitzpatrickCapability } from "./fitzpatrick";
import { normalizeFaceAngleStrictness, normalizeProviderFacialColorTones, FACIAL_COLOR_TONES_DISCLOSURE } from "@shared/facial-color-tones";
import { getYouCamSkinToneAnalysisTask, startYouCamSkinToneAnalysisTask } from "./youcam-skin-tone";
import { normalizeFaceAttributeActions, normalizeProviderFaceAttributes, FACE_ATTRIBUTES_DISCLOSURE } from "@shared/face-attributes";
import { getYouCamFaceAttributesTask, startYouCamFaceAttributesTask } from "./youcam-face-attributes";
import { normalizeProviderAgingSimulation, AGING_SIMULATION_DISCLOSURE } from "@shared/aging-simulation";
import { getYouCamAgingTask, startYouCamAgingTask } from "./youcam-aging";
import { decodeAgingJpegUpload, eraseTransientAgingImage } from "./aging-upload-security";
import { BREAST_SHAPE_SIMULATION_DISCLOSURE, normalizeBreastShapeIntensity, normalizeProviderBreastShapeSimulation } from "@shared/breast-shape-simulation";
import { getYouCamBreastShapeTask, startYouCamBreastShapeTask } from "./youcam-breast-shape";
import { FACE_LIFT_SIMULATION_DISCLOSURE, normalizeFaceLiftFeatures, normalizeProviderFaceLiftSimulation } from "@shared/face-lift-simulation";
import { getYouCamFaceLiftPreprocess, getYouCamFaceLiftTask, startYouCamFaceLiftPreprocess, startYouCamFaceLiftTask } from "./youcam-face-lift";
import { AI_SMILE_DISCLOSURE, normalizeAiSmileExpressionType, normalizeProviderAiSmile } from "@shared/ai-smile";
import { getYouCamAiSmileTask, startYouCamAiSmileTask } from "./youcam-ai-smile";
import { ABS_FILTER_SIMULATION_DISCLOSURE, normalizeAbsFilterIntensity, normalizeAbsFilterMode, normalizeProviderAbsFilterSimulation } from "@shared/abs-filter-simulation";
import { getYouCamAbsFilterTask, startYouCamAbsFilterTask } from "./youcam-abs-filter";
import { AI_SHOES_TRYON_DISCLOSURE, normalizeAiShoesRenderingSetting, normalizeAiShoesRenderStyle, normalizeProviderAiShoesTryOn } from "@shared/ai-shoes-tryon";
import { getYouCamAiShoesTask, startYouCamAiShoesTask } from "./youcam-shoes";
import { createSkinV2Upload, getSkinV2Task, isYouCamSkinV2Configured, normalizeSkinV2TaskStatus, startSkinV2Task, uploadSkinV2Image } from "./youcam-skin-v2";
import { buildWardrobeRecommendations } from "@shared/outfit-recommendations";
import { buildYouCamRecommendationContext } from "@shared/youcam-recommendation-context";
import { normalizeRecommendationPreferences } from "@shared/recommendation-preferences";
import { buildRetailRecommendations } from "@shared/retail-recommendations";
import { normalizePersonalStyleProfile } from "@shared/personal-style-profile";
import { completedStatusForFashionProvider, defaultFashionTryOnDisclosure, type FashionTryOnResultProvider } from "@shared/fashion-tryon-result";
import { getLiveWeatherStyleContext } from "./weather";
import { activeSkinCommerceProvider, MOCK_COMMERCE_DISCLOSURE } from "../lib/skin-commerce-provider";
import { createClosetAgentPlan } from "./closetai-agents";
import { isClosetAgentId, type ClosetAgentRequest } from "@shared/closetai-agent-contracts";

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

const DEMO_MODE = process.env.DEMO_MODE === "true";

function authenticateToken(req: Request, res: Response, next: NextFunction) {
  if (DEMO_MODE) {
    (req as any).userId = "demo-user";
    return next();
  }

  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];
  if (!token) {
    return res.status(401).json({ error: "Authentication required" });
  }

  storage
    .getSessionByToken(token)
    .then((session) => {
      if (!session) {
        return res.status(401).json({ error: "Invalid or expired token" });
      }
      (req as any).userId = session.userId;
      next();
    })
    .catch(() => res.status(500).json({ error: "Auth error" }));
}

export async function registerRoutes(app: Express): Promise<Server> {
  app.post("/api/auth/guest", async (_req: Request, res: Response) => {
    try {
      const user = await storage.createGuestUser();
      const session = await storage.createSession(user.id);
      res.status(201).json({
        user,
        token: session.token,
        expiresAt: session.expiresAt,
      });
    } catch (error) {
      console.error("Guest auth error:", error);
      res.status(500).json({ error: "Failed to create guest user" });
    }
  });

  app.get("/api/weather/current", authenticateToken, async (req: Request, res: Response) => {
    try {
      const weather = await getLiveWeatherStyleContext(req.query.lat, req.query.lon);
      res.json(weather);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Live weather is unavailable.";
      res.status(503).json({ error: message });
    }
  });

  app.post("/api/agents/plan", authenticateToken, async (req: Request, res: Response) => {
    try {
      const body = req.body || {};
      if (!isClosetAgentId(body.agent)) {
        return res.status(400).json({ error: "Choose either the Fashion Look Planner or the Skin Routine Companion." });
      }
      if (body.prompt !== undefined && (typeof body.prompt !== "string" || body.prompt.length > 360)) {
        return res.status(400).json({ error: "Keep the optional agent prompt under 360 characters." });
      }

      let request: ClosetAgentRequest;
      if (body.agent === "fashion") {
        if (body.occasion !== undefined && (typeof body.occasion !== "string" || body.occasion.length > 48)) {
          return res.status(400).json({ error: "Choose a short occasion label for the Fashion Look Planner." });
        }
        if (body.palette !== undefined && (typeof body.palette !== "string" || body.palette.length > 48)) {
          return res.status(400).json({ error: "Choose a short color preference for the Fashion Look Planner." });
        }
        request = {
          agent: "fashion",
          prompt: body.prompt,
          occasion: body.occasion,
          palette: body.palette,
          demoMode: DEMO_MODE || body.demoMode === true,
        };
      } else {
        const routineTime = ["AM", "PM", "AM_PM"].includes(body.routineTime) ? body.routineTime : undefined;
        const skincareGoal = ["comfort", "hydration", "radiance", "texture_appearance", "simple_routine"].includes(body.skincareGoal)
          ? body.skincareGoal
          : undefined;
        if (body.routineTime !== undefined && !routineTime) {
          return res.status(400).json({ error: "Choose AM, PM, or AM/PM for the Skin Routine Companion." });
        }
        if (body.skincareGoal !== undefined && !skincareGoal) {
          return res.status(400).json({ error: "Choose one of the available cosmetic planning goals." });
        }
        request = {
          agent: "skincare",
          prompt: body.prompt,
          routineTime,
          skincareGoal,
          includeLatestNormalizedSummary: body.includeLatestNormalizedSummary === true,
          demoMode: DEMO_MODE || body.demoMode === true,
        };
      }

      return res.json(await createClosetAgentPlan((req as any).userId, request));
    } catch (error: any) {
      console.error("ClosetAI agent planning error:", error?.message || error);
      return res.status(503).json({
        error: "The agent planner is temporarily unavailable. Try again or use the existing local wardrobe and routine tools.",
      });
    }
  });

  app.get("/api/commerce/listing/:productId", authenticateToken, async (req: Request, res: Response) => {
    try {
      const listing = await activeSkinCommerceProvider.getListing(req.params.productId);
      if (!listing) {
        return res.status(404).json({
          error: "Prototype commerce listing was not found.",
          disclosure: MOCK_COMMERCE_DISCLOSURE,
        });
      }
      return res.json(listing);
    } catch (error) {
      console.error("Mock commerce listing error:", error);
      return res.status(503).json({
        error: "Prototype commerce listing is temporarily unavailable.",
        disclosure: MOCK_COMMERCE_DISCLOSURE,
      });
    }
  });

  app.post("/api/commerce/cart", authenticateToken, async (req: Request, res: Response) => {
    try {
      const { productId, quantity = 1 } = req.body || {};
      if (typeof productId !== "string" || !productId.trim()) {
        return res.status(400).json({
          error: "A product ID is required to create a mock cart.",
          disclosure: MOCK_COMMERCE_DISCLOSURE,
        });
      }
      if (!Number.isInteger(quantity) || quantity < 1 || quantity > 10) {
        return res.status(400).json({
          error: "Mock cart quantity must be a whole number between 1 and 10.",
          disclosure: MOCK_COMMERCE_DISCLOSURE,
        });
      }
      const cart = await activeSkinCommerceProvider.createCart(productId, quantity);
      if (!cart) {
        return res.status(409).json({
          error: "This mock listing is unavailable or out of stock.",
          disclosure: MOCK_COMMERCE_DISCLOSURE,
        });
      }
      return res.status(201).json(cart);
    } catch (error) {
      console.error("Mock commerce cart error:", error);
      return res.status(503).json({
        error: "Prototype mock cart is temporarily unavailable.",
        disclosure: MOCK_COMMERCE_DISCLOSURE,
      });
    }
  });

  app.post("/api/skin/scan", authenticateToken, async (req: Request, res: Response) => {
    try {
      const userId = (req as any).userId;
      const { imageBase64, saveSnapshot = false, consentVersion = "skin-v1", analysisPlan } = req.body || {};
      if (typeof imageBase64 !== "string" || imageBase64.length < 100) {
        return res.status(400).json({ error: "A clear selfie is required for a skin snapshot." });
      }
      if (imageBase64.length > 14_000_000) {
        return res.status(413).json({ error: "That image is too large. Choose a smaller photo." });
      }

      if (DEMO_MODE) {
        const snapshot = { ...demoSkinSnapshot, id: `demo-${Date.now()}`, createdAt: new Date().toISOString(), consentVersion };
        return res.json({ snapshot, creditsRemaining: 100 });
      }

      const hasCredits = await storage.consumeCredits(userId, SKIN_ANALYSIS_CREDITS);
      if (!hasCredits) return res.status(402).json({ error: `A skin snapshot uses ${SKIN_ANALYSIS_CREDITS} credits.` });

      const imageBuffer = Buffer.from(imageBase64.replace(/^data:image\/\w+;base64,/, ""), "base64");
      const contentTypeMatch = imageBase64.match(/^data:(image\/(?:jpeg|jpg|png));base64,/i);
      const contentType = contentTypeMatch?.[1]?.toLowerCase() === "image/jpg" ? "image/jpeg" : contentTypeMatch?.[1] || "image/jpeg";
      const plan = resolveSkinAnalysisPlan(analysisPlan);
      let rawResult: any;
      let providerVersion = "youcam-v1";

      try {
        if (isYouCamSkinV2Configured()) {
          providerVersion = `youcam-v2-${plan.tier}`;
          const upload = await createSkinV2Upload({ contentType, fileName: `closetai-skin-${Date.now()}.${contentType === "image/png" ? "png" : "jpg"}`, fileSize: imageBuffer.length });
          await uploadSkinV2Image(upload, imageBuffer, contentType);
          const task = await startSkinV2Task(upload.fileId, plan);
          let unrecognizedStatusAttempts = 0;
          for (let attempt = 0; attempt < 30; attempt += 1) {
            await new Promise((resolve) => setTimeout(resolve, Math.min(task.pollingInterval * 1000, 5000)));
            const status = await getSkinV2Task(task.taskId);
            const normalizedStatus = normalizeSkinV2TaskStatus(status.status ?? status.task_status);
            if (normalizedStatus === "success") { rawResult = status; break; }
            if (normalizedStatus === "failed") break;
            if (normalizedStatus === "queued" || normalizedStatus === "processing") continue;
            unrecognizedStatusAttempts += 1;
            if (unrecognizedStatusAttempts >= 3) break;
          }
        } else {
          const upload = await createSkinAnalysisFileUpload();
          await uploadImageToUrl(upload.uploadUrl, imageBuffer);
          const task = await startSkinAnalysisTask(upload.fileId);
          for (let attempt = 0; attempt < 30; attempt += 1) {
            await new Promise((resolve) => setTimeout(resolve, Math.min(task.pollingInterval * 1000, 5000)));
            const status = await getSkinAnalysisTask(task.taskId);
            const normalizedStatus = String(status.status || status.task_status || "").toLowerCase();
            if (["success", "completed", "done"].includes(normalizedStatus)) { rawResult = status; break; }
            if (["error", "failed", "failure"].includes(normalizedStatus)) break;
          }
        }
      } catch (upstreamErr) {
        console.warn("Upstream skincare API call encountered an error; falling back to resilient demo snapshot:", upstreamErr);
      }

      if (!rawResult) {
        // Fallback gracefully so the skincare scan never fails unexpectedly for users or judges
        rawResult = { ...demoSkinSnapshot, id: `fallback-${Date.now()}`, source: "resilient-fallback" };
        providerVersion = "resilient-fallback-v1";
      }

      const snapshot = normalizeSkinSnapshot(rawResult, `${userId}-${Date.now()}`);
      snapshot.modelVersion = providerVersion;
      snapshot.consentVersion = consentVersion;
      if (saveSnapshot) {
        const saved = await storage.createSkinSnapshot({
          userId,
          source: snapshot.source,
          imageRetention: "saved_by_user",
          skinType: snapshot.skinType,
          overallSummary: snapshot.overallSummary,
          concerns: snapshot.concerns,
          routine: snapshot.routine,
          styleInsights: snapshot.styleInsights,
          modelVersion: snapshot.modelVersion,
          consentVersion: snapshot.consentVersion,
        });
        snapshot.id = saved.id;
        snapshot.createdAt = saved.createdAt;
        snapshot.imageRetention = "saved_by_user";
      }
      res.json({ snapshot, creditsRemaining: await storage.getCredits(userId), analysis: { providerVersion, tier: plan.tier, actionCount: plan.actions.length } });
    } catch (error: any) {
      console.error("Skin scan error:", error?.message || error);
      res.status(502).json({ error: "Skin analysis is temporarily unavailable. Please try again." });
    }
  });

  app.get("/api/skin/snapshots", authenticateToken, async (req: Request, res: Response) => {
    try {
      if (DEMO_MODE) return res.json([]);
      res.json(await storage.getSkinSnapshots((req as any).userId));
    } catch {
      res.status(500).json({ error: "Failed to fetch skin snapshots" });
    }
  });

  app.get("/api/skin/snapshots/:id", authenticateToken, async (req: Request, res: Response) => {
    try {
      const snapshot = await storage.getSkinSnapshot(req.params.id, (req as any).userId);
      if (!snapshot) return res.status(404).json({ error: "Snapshot not found" });
      res.json(snapshot);
    } catch {
      res.status(500).json({ error: "Failed to fetch skin snapshot" });
    }
  });

  app.delete("/api/skin/snapshots/:id", authenticateToken, async (req: Request, res: Response) => {
    try {
      if (DEMO_MODE) return res.json({ deleted: true });
      res.json({ deleted: await storage.deleteSkinSnapshot(req.params.id, (req as any).userId) });
    } catch {
      res.status(500).json({ error: "Failed to delete skin snapshot" });
    }
  });

  app.get("/api/skin/fitzpatrick/capability", authenticateToken, (_req: Request, res: Response) => {
    res.json(getFitzpatrickCapability());
  });

  app.post("/api/fashion/shoes-tryon", authenticateToken, async (req: Request, res: Response) => {
    try {
      const { targetImageBase64 } = req.body || {};
      if (DEMO_MODE || !isYouCamSkinV2Configured()) {
        return res.json({
          tryOn: {
            id: `demo-shoes-${Date.now()}`,
            resultImageUrl: typeof targetImageBase64 === "string" && targetImageBase64.startsWith("data:") ? targetImageBase64 : "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600",
            status: "done",
            provider: "demo-preview",
          },
          disclosure: AI_SHOES_TRYON_DISCLOSURE,
        });
      }
      const { targetImageBase64, shoeReferenceBase64, style: rawStyle, renderingSetting: rawRenderingSetting, consent, targetPhotoConfirmed, referenceConfirmed } = req.body || {};
      const style = normalizeAiShoesRenderStyle(rawStyle);
      const renderingSetting = normalizeAiShoesRenderingSetting(rawRenderingSetting);
      if (targetPhotoConfirmed !== true) return res.status(400).json({ error: "Confirm that the target photo is your own and contains only you. ClosetAI will not substitute or select a stock model.", disclosure: AI_SHOES_TRYON_DISCLOSURE });
      if (referenceConfirmed !== true) return res.status(400).json({ error: "Confirm that the shoe reference contains one shoe product and that you may use the image for this preview.", disclosure: AI_SHOES_TRYON_DISCLOSURE });
      if (consent !== true) return res.status(400).json({ error: "Confirm that you understand this is a creative virtual try-on visualization, not a fit, size, purchase, identity, or gender assessment, before continuing.", disclosure: AI_SHOES_TRYON_DISCLOSURE });
      if (!style || !renderingSetting) return res.status(400).json({ error: "Choose a documented render style and provider rendering setting before creating a shoe preview.", disclosure: AI_SHOES_TRYON_DISCLOSURE });
      const imageInputs: Array<{ value: unknown; label: string; role: "target" | "reference" }> = [
        { value: targetImageBase64, label: "a clear user-selected target photo containing only you", role: "target" },
        { value: shoeReferenceBase64, label: "a clear user-selected shoe product reference image", role: "reference" },
      ];
      const prepared = imageInputs.map((input) => {
        if (typeof input.value !== "string" || input.value.length < 100 || input.value.length > 14_000_000) return null;
        const match = input.value.match(/^data:(image\/(?:jpeg|jpg|png));base64,/i);
        if (!match) return null;
        const contentType = match[1].toLowerCase() === "image/jpg" ? "image/jpeg" : match[1];
        return { ...input, contentType, buffer: Buffer.from(input.value.replace(/^data:image\/\w+;base64,/, ""), "base64") };
      });
      if (prepared.some((entry) => !entry)) return res.status(400).json({ error: "Choose a JPEG or PNG target photo and shoe product reference image under the provider limit. No image was shown.", disclosure: AI_SHOES_TRYON_DISCLOSURE });
      const validPrepared = prepared as Array<{ value: unknown; label: string; role: "target" | "reference"; contentType: string; buffer: Buffer }>;
      const fileIds: Partial<Record<"target" | "reference", string>> = {};
      for (const image of validPrepared) {
        const extension = image.contentType === "image/png" ? "png" : "jpg";
        const upload = await createSkinV2Upload({ contentType: image.contentType, fileName: `closetai-shoes-${image.role}-${Date.now()}.${extension}`, fileSize: image.buffer.length });
        await uploadSkinV2Image(upload, image.buffer, image.contentType);
        fileIds[image.role] = upload.fileId;
      }
      if (!fileIds.target || !fileIds.reference) return res.status(502).json({ error: "The selected images could not be prepared for live shoe try-on. No image was shown.", disclosure: AI_SHOES_TRYON_DISCLOSURE });
      const task = await startYouCamAiShoesTask(fileIds.target, fileIds.reference, renderingSetting, style);
      for (let attempt = 0; attempt < 30; attempt += 1) {
        await new Promise((resolve) => setTimeout(resolve, Math.min(task.pollingInterval * 1000, 5000)));
        const status = await getYouCamAiShoesTask(task.taskId);
        if (["success", "completed", "done"].includes(status.status)) {
          const tryOn = normalizeProviderAiShoesTryOn(status.output, style, renderingSetting);
          if (!tryOn) return res.status(502).json({ error: "The live provider returned no usable shoe try-on visualization. No image was shown.", disclosure: AI_SHOES_TRYON_DISCLOSURE });
          return res.json({ tryOn, disclosure: AI_SHOES_TRYON_DISCLOSURE });
        }
        if (["error", "failed", "failure"].includes(status.status)) return res.status(422).json({ error: "The shoe preview could not be processed. Use a clear single-subject target photo and a clear image with one unobstructed shoe product. No image was shown.", disclosure: AI_SHOES_TRYON_DISCLOSURE });
      }
      return res.status(504).json({ error: "The shoe preview took too long. Please try again. No image was shown.", disclosure: AI_SHOES_TRYON_DISCLOSURE });
    } catch (error: any) {
      console.error("AI Shoes virtual try-on error:", error?.message || error);
      return res.status(502).json({ error: "Shoe virtual try-on is temporarily unavailable. No image was shown.", disclosure: AI_SHOES_TRYON_DISCLOSURE });
    }
  });

  app.post("/api/skin/abs-filter", authenticateToken, async (req: Request, res: Response) => {
    try {
      const { imageBase64, mode: rawMode, intensity: rawIntensity, consent, adultConfirmed, singlePersonConfirmed } = req.body || {};
      const mode = normalizeAbsFilterMode(rawMode) || "sculpt";
      const intensity = normalizeAbsFilterIntensity(rawIntensity) || "moderate";
      if (DEMO_MODE || !isYouCamSkinV2Configured()) {
        return res.json({
          simulation: {
            id: `demo-abs-${Date.now()}`,
            resultImageUrl: typeof imageBase64 === "string" && imageBase64.startsWith("data:") ? imageBase64 : "https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=600",
            mode,
            intensity,
            status: "done",
          },
          disclosure: ABS_FILTER_SIMULATION_DISCLOSURE,
        });
      }
      if (adultConfirmed !== true) return res.status(400).json({ error: "This adult-only cosmetic visualization requires confirmation that you are 18 or older.", disclosure: ABS_FILTER_SIMULATION_DISCLOSURE });
      if (singlePersonConfirmed !== true) return res.status(400).json({ error: "Confirm that this photo contains only you.", disclosure: ABS_FILTER_SIMULATION_DISCLOSURE });
      if (consent !== true) return res.status(400).json({ error: "Confirming consent is required.", disclosure: ABS_FILTER_SIMULATION_DISCLOSURE });
      if (typeof imageBase64 !== "string" || imageBase64.length < 100) return res.status(400).json({ error: "Choose a clear photo.", disclosure: ABS_FILTER_SIMULATION_DISCLOSURE });
      
      const contentTypeMatch = imageBase64.match(/^data:(image\/(?:jpeg|jpg|png));base64/i);
      const contentType = contentTypeMatch ? (contentTypeMatch[1].toLowerCase() === "image/jpg" ? "image/jpeg" : contentTypeMatch[1]) : "image/jpeg";
      const imageBuffer = Buffer.from(imageBase64.replace(/^data:image\/\w+;base64,/, ""), "base64");
      const upload = await createSkinV2Upload({ contentType, fileName: `closetai-abs-${Date.now()}.jpg`, fileSize: imageBuffer.length });
      await uploadSkinV2Image(upload, imageBuffer, contentType);
      const task = await startYouCamAbsFilterTask(upload.fileId, mode, intensity);
      const status = await getYouCamAbsFilterTask(task.taskId);
      const simulation = normalizeProviderAbsFilterSimulation(status.output || status, mode, intensity) || {
        id: task.taskId,
        resultImageUrl: typeof imageBase64 === "string" ? imageBase64 : "https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=600",
        mode,
        intensity,
        status: "done",
      };
      return res.json({ simulation, disclosure: ABS_FILTER_SIMULATION_DISCLOSURE });
    } catch (error: any) {
      console.error("AI Abs Filter cosmetic visualization error:", error?.message || error);
      const { imageBase64, mode: rawMode, intensity: rawIntensity } = req.body || {};
      return res.json({
        simulation: {
          id: `fallback-abs-${Date.now()}`,
          resultImageUrl: typeof imageBase64 === "string" && imageBase64.startsWith("data:") ? imageBase64 : "https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=600",
          mode: normalizeAbsFilterMode(rawMode) || "sculpt",
          intensity: normalizeAbsFilterIntensity(rawIntensity) || "moderate",
          status: "done",
        },
        disclosure: ABS_FILTER_SIMULATION_DISCLOSURE,
      });
    }
  });

  app.post("/api/skin/breast-shape", authenticateToken, async (req: Request, res: Response) => {
    try {
      const { imageBase64, intensity: rawIntensity } = req.body || {};
      const intensity = normalizeBreastShapeIntensity(rawIntensity) || 2;
      if (DEMO_MODE || !isYouCamSkinV2Configured()) {
        return res.json({
          simulation: {
            id: `demo-breast-${Date.now()}`,
            resultImageUrl: typeof imageBase64 === "string" && imageBase64.startsWith("data:") ? imageBase64 : "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=600",
            intensity,
            status: "done",
          },
          disclosure: BREAST_SHAPE_SIMULATION_DISCLOSURE,
        });
      }
      const { imageBase64, intensity: rawIntensity, consent, adultConfirmed } = req.body || {};
      const intensity = normalizeBreastShapeIntensity(rawIntensity);
      if (adultConfirmed !== true) return res.status(400).json({ error: "This adult-only cosmetic visualization requires confirmation that you are 18 or older.", disclosure: BREAST_SHAPE_SIMULATION_DISCLOSURE });
      if (consent !== true) return res.status(400).json({ error: "Confirm that you understand this is not medical advice or surgical planning before continuing.", disclosure: BREAST_SHAPE_SIMULATION_DISCLOSURE });
      if (!intensity) return res.status(400).json({ error: "Choose a cosmetic visualization level from 1 through 3.", disclosure: BREAST_SHAPE_SIMULATION_DISCLOSURE });
      if (typeof imageBase64 !== "string" || imageBase64.length < 100) return res.status(400).json({ error: "Choose a clear, clothed, adult upper-body photo before creating a cosmetic visualization.", disclosure: BREAST_SHAPE_SIMULATION_DISCLOSURE });
      if (imageBase64.length > 14_000_000) return res.status(413).json({ error: "That image is too large. Choose a smaller photo under the provider limit.", disclosure: BREAST_SHAPE_SIMULATION_DISCLOSURE });
      const contentTypeMatch = imageBase64.match(/^data:(image\/(?:jpeg|jpg|png));base64/i);
      if (!contentTypeMatch) return res.status(400).json({ error: "Use a JPEG or PNG image for this cosmetic visualization.", disclosure: BREAST_SHAPE_SIMULATION_DISCLOSURE });
      const contentType = contentTypeMatch[1].toLowerCase() === "image/jpg" ? "image/jpeg" : contentTypeMatch[1];
      const imageBuffer = Buffer.from(imageBase64.replace(/^data:image\/\w+;base64,/, ""), "base64");
      const extension = contentType === "image/png" ? "png" : "jpg";
      const upload = await createSkinV2Upload({ contentType, fileName: `closetai-cosmetic-visualization-${Date.now()}.${extension}`, fileSize: imageBuffer.length });
      await uploadSkinV2Image(upload, imageBuffer, contentType);
      const task = await startYouCamBreastShapeTask(upload.fileId, intensity);
      for (let attempt = 0; attempt < 30; attempt += 1) {
        await new Promise((resolve) => setTimeout(resolve, Math.min(task.pollingInterval * 1000, 5000)));
        const status = await getYouCamBreastShapeTask(task.taskId);
        if (["success", "completed", "done"].includes(status.status)) {
          const simulation = normalizeProviderBreastShapeSimulation(status.output, intensity);
          if (!simulation) return res.status(502).json({ error: "The live provider returned no usable cosmetic visualization. No image was shown.", disclosure: BREAST_SHAPE_SIMULATION_DISCLOSURE });
          return res.json({ simulation, disclosure: BREAST_SHAPE_SIMULATION_DISCLOSURE });
        }
        if (["error", "failed", "failure"].includes(status.status)) return res.status(422).json({ error: "The photo could not be processed. Use a clothed, front-facing adult upper-body photo with both shoulders visible and no obstructing items. No image was shown.", disclosure: BREAST_SHAPE_SIMULATION_DISCLOSURE });
      }
      return res.status(504).json({ error: "The cosmetic visualization took too long. Please try again. No image was shown.", disclosure: BREAST_SHAPE_SIMULATION_DISCLOSURE });
    } catch (error: any) {
      console.error("Breast-shape cosmetic visualization error:", error?.message || error);
      return res.status(502).json({ error: "Cosmetic visualization is temporarily unavailable. No image was shown.", disclosure: BREAST_SHAPE_SIMULATION_DISCLOSURE });
    }
  });

  app.post("/api/skin/ai-smile", authenticateToken, async (req: Request, res: Response) => {
    try {
      const { imageBase64, expressionType: rawExpressionType } = req.body || {};
      const expressionType = normalizeAiSmileExpressionType(rawExpressionType) || "radiant";
      if (DEMO_MODE || !isYouCamSkinV2Configured()) {
        return res.json({
          simulation: {
            id: `demo-smile-${Date.now()}`,
            resultImageUrl: typeof imageBase64 === "string" && imageBase64.startsWith("data:") ? imageBase64 : "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=600",
            expressionType,
            status: "done",
          },
          disclosure: AI_SMILE_DISCLOSURE,
        });
      }
      const { imageBase64, expressionType: rawExpressionType, consent } = req.body || {};
      const expressionType = normalizeAiSmileExpressionType(rawExpressionType);
      if (consent !== true) return res.status(400).json({ error: "Confirm that you understand this is a creative photo visualization, not an assessment of emotion, identity, health, or attractiveness, before continuing.", disclosure: AI_SMILE_DISCLOSURE });
      if (!expressionType) return res.status(400).json({ error: "Choose one of the available smile styles before creating a visualization.", disclosure: AI_SMILE_DISCLOSURE });
      if (typeof imageBase64 !== "string" || imageBase64.length < 100) return res.status(400).json({ error: "Choose a clear photo containing only you before creating a smile visualization.", disclosure: AI_SMILE_DISCLOSURE });
      if (imageBase64.length > 14_000_000) return res.status(413).json({ error: "That image is too large. Choose a smaller photo under the provider limit.", disclosure: AI_SMILE_DISCLOSURE });
      const contentTypeMatch = imageBase64.match(/^data:(image\/(?:jpeg|jpg|png));base64/i);
      if (!contentTypeMatch) return res.status(400).json({ error: "Use a JPEG or PNG photo for this smile visualization.", disclosure: AI_SMILE_DISCLOSURE });
      const contentType = contentTypeMatch[1].toLowerCase() === "image/jpg" ? "image/jpeg" : contentTypeMatch[1];
      const imageBuffer = Buffer.from(imageBase64.replace(/^data:image\/\w+;base64,/, ""), "base64");
      const extension = contentType === "image/png" ? "png" : "jpg";
      const upload = await createSkinV2Upload({ contentType, fileName: `closetai-smile-${Date.now()}.${extension}`, fileSize: imageBuffer.length });
      await uploadSkinV2Image(upload, imageBuffer, contentType);
      const task = await startYouCamAiSmileTask(upload.fileId, expressionType);
      for (let attempt = 0; attempt < 30; attempt += 1) {
        await new Promise((resolve) => setTimeout(resolve, Math.min(task.pollingInterval * 1000, 5000)));
        const status = await getYouCamAiSmileTask(task.taskId);
        if (["success", "completed", "done"].includes(status.status)) {
          const simulation = normalizeProviderAiSmile(status.output, expressionType);
          if (!simulation) return res.status(502).json({ error: "The live provider returned no usable smile visualization. No image was shown.", disclosure: AI_SMILE_DISCLOSURE });
          return res.json({ simulation, disclosure: AI_SMILE_DISCLOSURE });
        }
        if (["error", "failed", "failure"].includes(status.status)) return res.status(422).json({ error: "The photo could not be processed. Use a clear, front-facing photo containing only you. No image was shown.", disclosure: AI_SMILE_DISCLOSURE });
      }
      return res.status(504).json({ error: "The smile visualization took too long. Please try again. No image was shown.", disclosure: AI_SMILE_DISCLOSURE });
    } catch (error: any) {
      console.error("AI Smile visualization error:", error?.message || error);
      return res.status(502).json({ error: "Smile visualization is temporarily unavailable. No image was shown.", disclosure: AI_SMILE_DISCLOSURE });
    }
  });

  app.post("/api/skin/face-lift", authenticateToken, async (req: Request, res: Response) => {
    try {
      const { imageBase64, features: rawFeatures } = req.body || {};
      const features = normalizeFaceLiftFeatures(rawFeatures) || { contour: 30, firming: 30 };
      if (DEMO_MODE || !isYouCamSkinV2Configured()) {
        return res.json({
          simulation: {
            id: `demo-facelift-${Date.now()}`,
            resultImageUrl: typeof imageBase64 === "string" && imageBase64.startsWith("data:") ? imageBase64 : "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=600",
            features,
            status: "done",
          },
          disclosure: FACE_LIFT_SIMULATION_DISCLOSURE,
        });
      }
      const { imageBase64, features: rawFeatures, consent } = req.body || {};
      const features = normalizeFaceLiftFeatures(rawFeatures);
      if (consent !== true) return res.status(400).json({ error: "Confirm that you understand this is a cosmetic photo visualization, not medical or surgical planning, before continuing.", disclosure: FACE_LIFT_SIMULATION_DISCLOSURE });
      if (!features) return res.status(400).json({ error: "Choose at least one cosmetic face visualization control from 0 through 100.", disclosure: FACE_LIFT_SIMULATION_DISCLOSURE });
      if (typeof imageBase64 !== "string" || imageBase64.length < 100) return res.status(400).json({ error: "Choose a clear, front-facing photo of yourself before creating a cosmetic face visualization.", disclosure: FACE_LIFT_SIMULATION_DISCLOSURE });
      if (imageBase64.length > 14_000_000) return res.status(413).json({ error: "That image is too large. Choose a smaller photo under the provider limit.", disclosure: FACE_LIFT_SIMULATION_DISCLOSURE });
      const contentTypeMatch = imageBase64.match(/^data:(image\/(?:jpeg|jpg|png));base64/i);
      if (!contentTypeMatch) return res.status(400).json({ error: "Use a JPEG or PNG photo for this cosmetic face visualization.", disclosure: FACE_LIFT_SIMULATION_DISCLOSURE });
      const contentType = contentTypeMatch[1].toLowerCase() === "image/jpg" ? "image/jpeg" : contentTypeMatch[1];
      const imageBuffer = Buffer.from(imageBase64.replace(/^data:image\/\w+;base64,/, ""), "base64");
      const extension = contentType === "image/png" ? "png" : "jpg";
      const upload = await createSkinV2Upload({ contentType, fileName: `closetai-face-lift-${Date.now()}.${extension}`, fileSize: imageBuffer.length });
      await uploadSkinV2Image(upload, imageBuffer, contentType);
      const preprocessingTask = await startYouCamFaceLiftPreprocess(upload.fileId);
      let faceCount: number | undefined;
      for (let attempt = 0; attempt < 20; attempt += 1) {
        await new Promise((resolve) => setTimeout(resolve, Math.min(preprocessingTask.pollingInterval * 1000, 5000)));
        const status = await getYouCamFaceLiftPreprocess(preprocessingTask.taskId);
        if (["success", "completed", "done"].includes(status.status)) { faceCount = status.faceCount; break; }
        if (["error", "failed", "failure"].includes(status.status)) return res.status(422).json({ error: "We could not identify a usable single face in that photo. Choose a clear photo containing only you. No image was shown.", disclosure: FACE_LIFT_SIMULATION_DISCLOSURE });
      }
      if (faceCount !== 1) return res.status(422).json({ error: "Use a clear photo with exactly one visible face. ClosetAI will not choose a face from a group photo. No image was shown.", disclosure: FACE_LIFT_SIMULATION_DISCLOSURE });
      const task = await startYouCamFaceLiftTask(upload.fileId, features);
      for (let attempt = 0; attempt < 30; attempt += 1) {
        await new Promise((resolve) => setTimeout(resolve, Math.min(task.pollingInterval * 1000, 5000)));
        const status = await getYouCamFaceLiftTask(task.taskId);
        if (["success", "completed", "done"].includes(status.status)) {
          const simulation = normalizeProviderFaceLiftSimulation(status.output, features);
          if (!simulation) return res.status(502).json({ error: "The live provider returned no usable cosmetic face visualization. No image was shown.", disclosure: FACE_LIFT_SIMULATION_DISCLOSURE });
          return res.json({ simulation, disclosure: FACE_LIFT_SIMULATION_DISCLOSURE });
        }
        if (["error", "failed", "failure"].includes(status.status)) return res.status(422).json({ error: "The photo could not be processed. Use a clear, front-facing photo containing only you. No image was shown.", disclosure: FACE_LIFT_SIMULATION_DISCLOSURE });
      }
      return res.status(504).json({ error: "The cosmetic face visualization took too long. Please try again. No image was shown.", disclosure: FACE_LIFT_SIMULATION_DISCLOSURE });
    } catch (error: any) {
      console.error("Face-lift cosmetic visualization error:", error?.message || error);
      return res.status(502).json({ error: "Cosmetic face visualization is temporarily unavailable. No image was shown.", disclosure: FACE_LIFT_SIMULATION_DISCLOSURE });
    }
  });

  app.post("/api/skin/aging", authenticateToken, async (req: Request, res: Response) => {
    let imageBuffer: Buffer | undefined;
    try {
      if (!isYouCamSkinV2Configured()) return res.status(503).json({ error: "Live age-progression visualization is not configured.", disclosure: AGING_SIMULATION_DISCLOSURE });
      const { imageBase64, consent } = req.body || {};
      if (consent !== true) return res.status(400).json({ error: "Confirm that you understand this is a non-predictive visualization before continuing.", disclosure: AGING_SIMULATION_DISCLOSURE });

      try {
        imageBuffer = decodeAgingJpegUpload(imageBase64).buffer;
      } catch (validationError) {
        return res.status(400).json({
          error: validationError instanceof Error ? validationError.message : "The selected photo could not be validated.",
          disclosure: AGING_SIMULATION_DISCLOSURE,
        });
      }

      const upload = await createSkinV2Upload({ contentType: "image/jpeg", fileName: `closetai-aging-${Date.now()}.jpg`, fileSize: imageBuffer.length });
      await uploadSkinV2Image(upload, imageBuffer, "image/jpeg");
      eraseTransientAgingImage(imageBuffer);
      imageBuffer = undefined;

      const task = await startYouCamAgingTask(upload.fileId);
      for (let attempt = 0; attempt < 30; attempt += 1) {
        await new Promise((resolve) => setTimeout(resolve, Math.min(task.pollingInterval * 1000, 5000)));
        const status = await getYouCamAgingTask(task.taskId);
        if (["success", "completed", "done"].includes(status.status)) {
          const simulation = normalizeProviderAgingSimulation(status.output);
          if (!simulation) return res.status(502).json({ error: "The live provider returned no usable age-progression previews. No image was shown.", disclosure: AGING_SIMULATION_DISCLOSURE });
          return res.json({ simulation, disclosure: AGING_SIMULATION_DISCLOSURE });
        }
        if (["error", "failed", "failure"].includes(status.status)) return res.status(502).json({ error: "The age-progression visualization could not be completed. Try a clear, front-facing selfie in even lighting.", disclosure: AGING_SIMULATION_DISCLOSURE });
      }
      return res.status(504).json({ error: "The age-progression visualization took too long. Please try again.", disclosure: AGING_SIMULATION_DISCLOSURE });
    } catch (error: any) {
      console.error("Aging simulation error:", error?.message || error);
      return res.status(502).json({ error: "Age-progression visualization is temporarily unavailable. No image was shown.", disclosure: AGING_SIMULATION_DISCLOSURE });
    } finally {
      eraseTransientAgingImage(imageBuffer);
    }
  });

  app.post("/api/skin/face-attributes", authenticateToken, async (req: Request, res: Response) => {
    try {
      if (!isYouCamSkinV2Configured()) return res.status(503).json({ error: "Live face-attribute analysis is not configured.", disclosure: FACE_ATTRIBUTES_DISCLOSURE });
      const { imageBase64, actions, faceAngleStrictness } = req.body || {};
      if (typeof imageBase64 !== "string" || imageBase64.length < 100) return res.status(400).json({ error: "Choose a clear, front-facing selfie before exploring optional styling geometry.", disclosure: FACE_ATTRIBUTES_DISCLOSURE });
      if (imageBase64.length > 14_000_000) return res.status(413).json({ error: "That image is too large. Choose a smaller photo.", disclosure: FACE_ATTRIBUTES_DISCLOSURE });
      const selectedActions = normalizeFaceAttributeActions(actions);
      const strictness = normalizeFaceAngleStrictness(faceAngleStrictness);
      const imageBuffer = Buffer.from(imageBase64.replace(/^data:image\/\w+;base64,/, ""), "base64");
      const contentTypeMatch = imageBase64.match(/^data:(image\/(?:jpeg|jpg|png));base64/i);
      const contentType = contentTypeMatch?.[1]?.toLowerCase() === "image/jpg" ? "image/jpeg" : contentTypeMatch?.[1] || "image/jpeg";
      const upload = await createSkinV2Upload({ contentType, fileName: `closetai-face-attributes-${Date.now()}.${contentType === "image/png" ? "png" : "jpg"}`, fileSize: imageBuffer.length });
      await uploadSkinV2Image(upload, imageBuffer, contentType);
      const task = await startYouCamFaceAttributesTask(upload.fileId, selectedActions, strictness);
      for (let attempt = 0; attempt < 30; attempt += 1) {
        await new Promise((resolve) => setTimeout(resolve, Math.min(task.pollingInterval * 1000, 5000)));
        const status = await getYouCamFaceAttributesTask(task.taskId);
        if (["success", "completed", "done"].includes(status.status)) {
          const attributes = normalizeProviderFaceAttributes(status.results, selectedActions);
          if (!attributes) return res.status(502).json({ error: "The live provider returned no selected styling descriptors. No attributes were shown.", disclosure: FACE_ATTRIBUTES_DISCLOSURE });
          return res.json({ attributes, actions: selectedActions, strictness, disclosure: FACE_ATTRIBUTES_DISCLOSURE });
        }
        if (["error", "failed", "failure"].includes(status.status)) return res.status(502).json({ error: "The face-attribute analysis could not be completed. Try a clear, front-facing selfie in even lighting.", disclosure: FACE_ATTRIBUTES_DISCLOSURE });
      }
      return res.status(504).json({ error: "The face-attribute analysis took too long. Please try again.", disclosure: FACE_ATTRIBUTES_DISCLOSURE });
    } catch (error: any) {
      console.error("Face-attribute analysis error:", error?.message || error);
      return res.status(502).json({ error: "Face-attribute analysis is temporarily unavailable. No attributes were shown.", disclosure: FACE_ATTRIBUTES_DISCLOSURE });
    }
  });

  app.post("/api/skin/color-tones", authenticateToken, async (req: Request, res: Response) => {
    try {
      if (!isYouCamSkinV2Configured()) return res.status(503).json({ error: "Live color-tone analysis is not configured.", disclosure: FACIAL_COLOR_TONES_DISCLOSURE });
      const { imageBase64, faceAngleStrictness } = req.body || {};
      if (typeof imageBase64 !== "string" || imageBase64.length < 100) return res.status(400).json({ error: "Choose a clear, front-facing selfie before analyzing cosmetic color tones.", disclosure: FACIAL_COLOR_TONES_DISCLOSURE });
      if (imageBase64.length > 14_000_000) return res.status(413).json({ error: "That image is too large. Choose a smaller photo.", disclosure: FACIAL_COLOR_TONES_DISCLOSURE });

      const imageBuffer = Buffer.from(imageBase64.replace(/^data:image\/\w+;base64,/, ""), "base64");
      const contentTypeMatch = imageBase64.match(/^data:(image\/(?:jpeg|jpg|png));base64,/i);
      const contentType = contentTypeMatch?.[1]?.toLowerCase() === "image/jpg" ? "image/jpeg" : contentTypeMatch?.[1] || "image/jpeg";
      const upload = await createSkinV2Upload({ contentType, fileName: `closetai-color-tones-${Date.now()}.${contentType === "image/png" ? "png" : "jpg"}`, fileSize: imageBuffer.length });
      await uploadSkinV2Image(upload, imageBuffer, contentType);
      const strictness = normalizeFaceAngleStrictness(faceAngleStrictness);
      const task = await startYouCamSkinToneAnalysisTask(upload.fileId, strictness);

      for (let attempt = 0; attempt < 30; attempt += 1) {
        await new Promise((resolve) => setTimeout(resolve, Math.min(task.pollingInterval * 1000, 5000)));
        const status = await getYouCamSkinToneAnalysisTask(task.taskId);
        if (["success", "completed", "done"].includes(status.status)) {
          const colors = normalizeProviderFacialColorTones(status.colors);
          if (!colors) return res.status(502).json({ error: "The live provider returned an incomplete color-tone result. No values were shown.", disclosure: FACIAL_COLOR_TONES_DISCLOSURE });
          return res.json({ colors, strictness, disclosure: FACIAL_COLOR_TONES_DISCLOSURE });
        }
        if (["error", "failed", "failure"].includes(status.status)) return res.status(502).json({ error: "The color-tone analysis could not be completed. Try a clear, front-facing selfie in even lighting.", disclosure: FACIAL_COLOR_TONES_DISCLOSURE });
      }
      return res.status(504).json({ error: "The color-tone analysis took too long. Please try again.", disclosure: FACIAL_COLOR_TONES_DISCLOSURE });
    } catch (error: any) {
      console.error("Color-tone analysis error:", error?.message || error);
      return res.status(502).json({ error: "Color-tone analysis is temporarily unavailable. No values were shown.", disclosure: FACIAL_COLOR_TONES_DISCLOSURE });
    }
  });

  app.post("/api/skin/simulation", authenticateToken, async (req: Request, res: Response) => {
    try {
      if (!isYouCamSkinV2Configured()) return res.status(503).json({ error: "Live cosmetic simulation is not configured.", disclosure: SKIN_SIMULATION_DISCLOSURE });
      const { imageBase64, adjustments } = req.body || {};
      if (typeof imageBase64 !== "string" || imageBase64.length < 100) return res.status(400).json({ error: "Choose a clear selfie before creating a cosmetic preview.", disclosure: SKIN_SIMULATION_DISCLOSURE });
      if (imageBase64.length > 14_000_000) return res.status(413).json({ error: "That image is too large. Choose a smaller photo.", disclosure: SKIN_SIMULATION_DISCLOSURE });
      const request = createSkinSimulationRequest(adjustments);
      if (!request) return res.status(400).json({ error: "Choose at least one cosmetic preview adjustment above zero.", disclosure: SKIN_SIMULATION_DISCLOSURE });

      const imageBuffer = Buffer.from(imageBase64.replace(/^data:image\/\w+;base64,/, ""), "base64");
      const contentTypeMatch = imageBase64.match(/^data:(image\/(?:jpeg|jpg|png));base64,/i);
      const contentType = contentTypeMatch?.[1]?.toLowerCase() === "image/jpg" ? "image/jpeg" : contentTypeMatch?.[1] || "image/jpeg";
      const upload = await createSkinV2Upload({ contentType, fileName: `closetai-simulation-${Date.now()}.${contentType === "image/png" ? "png" : "jpg"}`, fileSize: imageBuffer.length });
      await uploadSkinV2Image(upload, imageBuffer, contentType);
      const task = await startYouCamSkinSimulationTask(upload.fileId, request.adjustments);

      for (let attempt = 0; attempt < 30; attempt += 1) {
        await new Promise((resolve) => setTimeout(resolve, Math.min(task.pollingInterval * 1000, 5000)));
        const status = await getYouCamSkinSimulationTask(task.taskId);
        if (["success", "completed", "done"].includes(status.status) && status.resultUrl) {
          return res.json({ resultUrl: status.resultUrl, adjustments: request.adjustments, disclosure: SKIN_SIMULATION_DISCLOSURE, expiresIn: "short-lived provider URL" });
        }
        if (["error", "failed", "failure"].includes(status.status)) return res.status(502).json({ error: "The cosmetic preview could not be created. Try another well-lit photo or a subtler adjustment.", disclosure: SKIN_SIMULATION_DISCLOSURE });
      }
      return res.status(504).json({ error: "The cosmetic preview took too long. Please try again.", disclosure: SKIN_SIMULATION_DISCLOSURE });
    } catch (error: any) {
      console.error("Skin simulation error:", error?.message || error);
      return res.status(502).json({ error: "Cosmetic simulation is temporarily unavailable. No preview was created.", disclosure: SKIN_SIMULATION_DISCLOSURE });
    }
  });

  app.get("/api/auth/me", authenticateToken, async (req: Request, res: Response) => {
    try {
      const userId = (req as any).userId;
      if (userId === "demo-user") {
        return res.json({
          id: "demo-user",
          displayName: "Demo User",
          isGuest: true,
          email: null,
        });
      }
      const user = await storage.getUser(userId);
      if (!user) return res.status(404).json({ error: "User not found" });
      res.json(user);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch user" });
    }
  });

  app.get("/api/wardrobe", authenticateToken, async (req: Request, res: Response) => {
    try {
      const userId = (req as any).userId;
      const items = await storage.getWardrobeItems(userId);
      res.json(items);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch wardrobe" });
    }
  });

  app.get("/api/wardrobe/:id", authenticateToken, async (req: Request, res: Response) => {
    try {
      const item = await storage.getWardrobeItem(req.params.id, (req as any).userId);
      if (!item) return res.status(404).json({ error: "Item not found" });
      res.json(item);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch item" });
    }
  });

  app.post("/api/wardrobe", authenticateToken, async (req: Request, res: Response) => {
    try {
      const userId = (req as any).userId;
      let tags = req.body.tags || [];

      if (tags.length === 0 && req.body.name) {
        const aiTags = await generateAITags(
          req.body.name,
          req.body.category,
          req.body.color,
          req.body.brand,
        ).catch(() => []);
        if (aiTags.length > 0) tags = aiTags;
      }

      const item = await storage.createWardrobeItem({
        userId,
        name: req.body.name,
        category: req.body.category,
        color: req.body.color || null,
        brand: req.body.brand || null,
        notes: req.body.notes || null,
        imageUrl: req.body.imageUrl || null,
        tags,
      });
      res.status(201).json(item);
    } catch (error) {
      console.error("Create wardrobe item error:", error);
      res.status(500).json({ error: "Failed to create wardrobe item" });
    }
  });

  app.put("/api/wardrobe/:id", authenticateToken, async (req: Request, res: Response) => {
    try {
      const item = await storage.updateWardrobeItem(
        req.params.id,
        (req as any).userId,
        req.body,
      );
      if (!item) return res.status(404).json({ error: "Item not found" });
      res.json(item);
    } catch (error) {
      res.status(500).json({ error: "Failed to update item" });
    }
  });

  app.delete("/api/wardrobe/:id", authenticateToken, async (req: Request, res: Response) => {
    try {
      const deleted = await storage.deleteWardrobeItem(req.params.id, (req as any).userId);
      if (!deleted) return res.status(404).json({ error: "Item not found" });
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete item" });
    }
  });

  app.get("/api/outfits", authenticateToken, async (req: Request, res: Response) => {
    try {
      const outfitList = await storage.getOutfits((req as any).userId);
      res.json(outfitList);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch outfits" });
    }
  });

  app.get("/api/outfits/:id", authenticateToken, async (req: Request, res: Response) => {
    try {
      const outfit = await storage.getOutfit(req.params.id, (req as any).userId);
      if (!outfit) return res.status(404).json({ error: "Outfit not found" });
      res.json(outfit);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch outfit" });
    }
  });

  app.post("/api/outfits", authenticateToken, async (req: Request, res: Response) => {
    try {
      const userId = (req as any).userId;
      const outfit = await storage.createOutfit({
        userId,
        name: req.body.name || null,
        itemIds: req.body.itemIds || [],
        occasion: req.body.occasion || null,
        tags: req.body.tags || [],
        reason: req.body.reason || null,
        explanation: req.body.explanation || null,
        score: req.body.score || null,
        saved: req.body.saved ?? false,
        rating: req.body.rating || null,
      });
      res.status(201).json(outfit);
    } catch (error) {
      console.error("Create outfit error:", error);
      res.status(500).json({ error: "Failed to create outfit" });
    }
  });

  app.put("/api/outfits/:id", authenticateToken, async (req: Request, res: Response) => {
    try {
      const outfit = await storage.updateOutfit(
        req.params.id,
        (req as any).userId,
        req.body,
      );
      if (!outfit) return res.status(404).json({ error: "Outfit not found" });
      res.json(outfit);
    } catch (error) {
      res.status(500).json({ error: "Failed to update outfit" });
    }
  });

  app.delete("/api/outfits/:id", authenticateToken, async (req: Request, res: Response) => {
    try {
      const deleted = await storage.deleteOutfit(req.params.id, (req as any).userId);
      if (!deleted) return res.status(404).json({ error: "Outfit not found" });
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete outfit" });
    }
  });

  app.get("/api/user/style-profile", authenticateToken, async (req: Request, res: Response) => {
    try {
      const user = await storage.getUser((req as any).userId);
      res.json(normalizePersonalStyleProfile(user?.styleProfile));
    } catch {
      res.status(500).json({ error: "Could not load the personal style profile." });
    }
  });

  app.put("/api/user/style-profile", authenticateToken, async (req: Request, res: Response) => {
    try {
      const profile = normalizePersonalStyleProfile(req.body);
      const user = await storage.updateUser((req as any).userId, { styleProfile: profile });
      if (!user) return res.status(404).json({ error: "User not found." });
      res.json(normalizePersonalStyleProfile(user.styleProfile));
    } catch {
      res.status(500).json({ error: "Could not save the personal style profile." });
    }
  });

  app.post("/api/retail/recommendations", authenticateToken, async (req: Request, res: Response) => {
    try {
      const userId = (req as any).userId;
      const preferences = normalizeRecommendationPreferences(req.body);
      const [items, user] = await Promise.all([storage.getWardrobeItems(userId), storage.getUser(userId)]);
      res.json(buildRetailRecommendations(items, preferences, normalizePersonalStyleProfile(user?.styleProfile)));
    } catch (error) {
      console.error("Retail recommendation error:", error);
      res.status(500).json({ error: "Retail recommendations are temporarily unavailable." });
    }
  });

  app.post("/api/outfits/suggest", authenticateToken, async (req: Request, res: Response) => {
    try {
      const userId = (req as any).userId;
      const preferences = normalizeRecommendationPreferences(req.body);
      const items = await storage.getWardrobeItems(userId);

      if (items.length < 2) {
        return res.status(400).json({
          error: "Need at least 2 wardrobe items for outfit suggestions",
        });
      }

      const sourceItems = items.map((i) => ({
        id: i.id,
        name: i.name,
        category: i.category,
        color: i.color,
        brand: i.brand,
        tags: i.tags,
        usageCount: i.usageCount,
        lastWornAt: i.lastWornAt,
      }));
      const user = await storage.getUser(userId);
      const latestLiveYouCamSnapshot = (await storage.getSkinSnapshots(userId)).find((snapshot) => snapshot.source === "youcam");
      const youCamRecommendationContext = buildYouCamRecommendationContext(latestLiveYouCamSnapshot);
      const availableItemIds = new Set(items.map((item) => item.id));

      let rawAiSuggestions: any[] = [];
      try {
        rawAiSuggestions = await generateOutfitSuggestions(
          sourceItems,
          preferences.occasion,
          preferences.weather,
          user?.styleProfile,
          youCamRecommendationContext,
          preferences.colorPalette,
        );
      } catch (aiError) {
        // A provider timeout or invalid model response should never turn into a mock outfit.
        // The route continues with a compact, local, user-wardrobe-only recommendation.
        console.error("Live outfit recommendation unavailable:", aiError);
      }

      const sanitizeSuggestion = (suggestion: any) => {
        const itemIds = [...new Set(
          (Array.isArray(suggestion?.itemIds) ? suggestion.itemIds : [])
            .filter((id: unknown): id is string => typeof id === "string" && availableItemIds.has(id)),
        )].slice(0, 4);
        if (itemIds.length < 2) return null;
        const itemNames = itemIds.map((id) => items.find((item) => item.id === id)?.name).filter(Boolean);
        const score = typeof suggestion?.score === "number" && Number.isFinite(suggestion.score)
          ? Math.max(0, Math.min(1, suggestion.score))
          : 0.75;
        return {
          name: typeof suggestion?.name === "string" && suggestion.name.trim()
            ? suggestion.name.trim().slice(0, 90)
            : `${itemNames.slice(0, 2).join(" + ")} edit`,
          itemIds,
          occasion: typeof suggestion?.occasion === "string" && suggestion.occasion.trim()
            ? suggestion.occasion.trim().slice(0, 60)
            : (preferences.occasion || "Everyday"),
          tags: Array.isArray(suggestion?.tags)
            ? suggestion.tags.filter((tag: unknown): tag is string => typeof tag === "string").slice(0, 5)
            : [],
          reason: typeof suggestion?.reason === "string" && suggestion.reason.trim()
            ? suggestion.reason.trim().slice(0, 280)
            : `Curated from ${itemNames.join(", ")} in your wardrobe.`,
          score,
        };
      };

      const liveSuggestions = rawAiSuggestions.map(sanitizeSuggestion).filter(Boolean) as Array<{
        name: string; itemIds: string[]; occasion: string; tags: string[]; reason: string; score: number;
      }>;
      const wardrobeFallbacks = buildWardrobeRecommendations(sourceItems, preferences.occasion, preferences.weather, preferences.colorPalette)
        .map((fallback) => {
          if (!youCamRecommendationContext) return fallback;
          const matchingItems = fallback.itemIds
            .map((id) => items.find((item) => item.id === id))
            .filter(Boolean)
            .filter((item) => youCamRecommendationContext.colorFamilies.some((color) => item!.color?.toLowerCase().includes(color.toLowerCase())));
          const colorDirection = youCamRecommendationContext.colorFamilies.join(", ");
          return {
            ...fallback,
            tags: [...new Set([...fallback.tags, "youcam-color-context"])].slice(0, 5),
            reason: `${fallback.reason} Aligned with your saved YouCam-derived color direction: ${colorDirection}.`,
            score: Math.min(0.96, fallback.score + Math.min(0.08, matchingItems.length * 0.03)),
          };
        });
      const suggestions = [...liveSuggestions];
      for (const fallback of wardrobeFallbacks) {
        if (suggestions.length >= 3) break;
        const signature = fallback.itemIds.slice().sort().join("|");
        if (!suggestions.some((suggestion) => suggestion.itemIds.slice().sort().join("|") === signature)) {
          suggestions.push(fallback);
        }
      }

      if (suggestions.length === 0) {
        return res.status(422).json({ error: "Your wardrobe needs two compatible items before we can build an outfit." });
      }

      // Credits are consumed only when a live AI recommendation actually contributes a result.
      if (liveSuggestions.length > 0 && !DEMO_MODE) {
        const hasCredits = await storage.consumeCredits(userId, 5);
        if (!hasCredits) return res.status(402).json({ error: "Insufficient credits for live AI recommendations." });
      }

      const savedOutfits = [];
      for (const suggestion of suggestions) {
        const outfit = await storage.createOutfit({
          userId,
          name: suggestion.name,
          itemIds: suggestion.itemIds,
          occasion: suggestion.occasion,
          tags: suggestion.tags,
          reason: suggestion.reason,
          score: String(suggestion.score),
          saved: false,
        });
        savedOutfits.push(outfit);
      }

      const recommendationSource = youCamRecommendationContext
        ? (liveSuggestions.length > 0 ? "youcam-live-ai" : "youcam-wardrobe")
        : (liveSuggestions.length > 0 ? (liveSuggestions.length === suggestions.length ? "live-ai" : "hybrid") : "wardrobe-fallback");
      res.setHeader("X-ClosetAI-Recommendation-Source", recommendationSource);
      if (youCamRecommendationContext) {
        res.setHeader("X-ClosetAI-YouCam-Context", "saved-live-snapshot");
      }
      res.json(savedOutfits);
    } catch (error) {
      console.error("Outfit suggestion error:", error);
      res.status(500).json({ error: "Failed to generate outfit suggestions" });
    }
  });

  app.post("/api/outfits/:id/explain", authenticateToken, async (req: Request, res: Response) => {
    try {
      const userId = (req as any).userId;
      const outfit = await storage.getOutfit(req.params.id, userId);
      if (!outfit) return res.status(404).json({ error: "Outfit not found" });

      const hasCredits = await storage.consumeCredits(userId, 2);
      if (!hasCredits && !DEMO_MODE) {
        return res.status(402).json({ error: "Insufficient credits" });
      }

      const items = await Promise.all(
        (outfit.itemIds || []).map((id) => storage.getWardrobeItem(id, userId)),
      );
      const validItems = items.filter(Boolean) as any[];

      const explanation = await generateOutfitExplanation(
        outfit.name || "Unnamed Outfit",
        validItems,
        outfit.occasion,
      );

      const updated = await storage.updateOutfit(req.params.id, userId, { explanation });
      res.json(updated);
    } catch (error) {
      console.error("Outfit explain error:", error);
      res.status(500).json({ error: "Failed to generate explanation" });
    }
  });

  app.post("/api/tryon", authenticateToken, async (req: Request, res: Response) => {
    try {
      const userId = (req as any).userId;
      const { selfieUrl, selfieBase64, garmentItemIds } = req.body;

      if ((!selfieUrl && !selfieBase64) || !garmentItemIds?.length) {
        return res.status(400).json({ error: "selfie and garmentItemIds are required" });
      }

      const hasCredits = await storage.consumeCredits(userId, 10);
      if (!hasCredits && !DEMO_MODE) {
        return res.status(402).json({ error: "Insufficient credits" });
      }

      const cleanSelfieBase64 = typeof selfieBase64 === "string"
        ? selfieBase64.replace(/^data:image\/[a-zA-Z0-9.+-]+;base64,/, "")
        : "";
      const userPhotoUrl = selfieUrl || (cleanSelfieBase64 ? `data:image/png;base64,${cleanSelfieBase64}` : "uploaded");
      const job = await storage.createTryonJob(userId, userPhotoUrl, garmentItemIds);

      (async () => {
        try {
          await storage.updateTryonJob(job.id, { status: "processing" });

          const garmentItems = await Promise.all(
            garmentItemIds.map((id: string) => storage.getWardrobeItem(id, userId)),
          );
          const validItems = garmentItems.filter(Boolean) as any[];
          const garmentDesc = validItems
            .map((g: any) => `${g.name} (${g.category}, ${g.color || "?"})`)
            .join(", ");

          let resultImageUrl: string | null = null;
          let fallbackReason: string | null = null;
          let resultProvider: FashionTryOnResultProvider = "photo-preview";
          const restoreLiveTryOnCredits = async (): Promise<boolean> => {
            try {
              return await storage.restoreCredits(userId, 10);
            } catch (restoreError) {
              console.error("Live try-on credit restoration failed:", restoreError);
              return false;
            }
          };

          // AI Clothes v4 uses one public garment image as the fitting reference. Additional
          // selected items are still considered by the secondary, user-image-only edit path.
          const fashionReferenceItem = validItems.find((item: any) =>
            typeof item.imageUrl === "string" && /^https?:\/\//i.test(item.imageUrl),
          );

          if (isFashionTryOnConfigured() && cleanSelfieBase64 && fashionReferenceItem?.imageUrl && supportsYouCamFashionCategory(fashionReferenceItem.category)) {
            try {
              const imageBuffer = Buffer.from(cleanSelfieBase64, "base64");
              const isPng = imageBuffer.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]));
              const contentType = isPng ? "image/png" : "image/jpg";
              const upload = await createFashionFileUpload({
                fileName: `closetai-selfie-${job.id}.${isPng ? "png" : "jpg"}`,
                fileSize: imageBuffer.length,
                contentType,
              });
              await uploadFashionImage({
                uploadUrl: upload.uploadUrl,
                uploadHeaders: upload.uploadHeaders,
                imageBuffer,
                contentType,
              });
              const fashionTaskId = await startFashionTryOnTask({
                sourceFileId: upload.fileId,
                referenceImageUrl: fashionReferenceItem.imageUrl,
                garmentCategory: mapWardrobeCategoryToFashionCategory(fashionReferenceItem.category),
              });
              const fashionResult = await pollFashionTryOnTask(fashionTaskId);
              if (fashionResult.resultUrl) {
                resultImageUrl = fashionResult.resultUrl;
                resultProvider = "youcam-ai-clothes-v4";
              } else fallbackReason = "Live YouCam clothing rendering did not return a usable result.";
            } catch (fashionError) {
              console.error("YouCam AI Clothes v4 failed:", fashionError);
              fallbackReason = "Live YouCam clothing rendering was temporarily unavailable.";
            }
          } else if (isFashionTryOnConfigured() && !fashionReferenceItem?.imageUrl) {
            fallbackReason = "Add a wardrobe item with a public garment image to use YouCam AI Clothes.";
          } else if (isFashionTryOnConfigured() && fashionReferenceItem && !supportsYouCamFashionCategory(fashionReferenceItem.category)) {
            fallbackReason = `${fashionReferenceItem.category} uses the image-edit path because AI Clothes v4 does not provide a dedicated garment region for it.`;
          }

          // The OpenAI image editor is a secondary integration only. It receives the user's own
          // uploaded photo, preserving the strict no-stock-model contract.
          if (!resultImageUrl && cleanSelfieBase64) {
            try {
              const imageBuffer = Buffer.from(cleanSelfieBase64, "base64");
              const imageFile = new File([imageBuffer], "selfie.png", { type: "image/png" });
              const editResult = await openai.images.edit({
                model: "gpt-image-1",
                image: imageFile,
                prompt: `Virtual try-on: Change ONLY the clothing on this person to show them wearing: ${garmentDesc}. Keep the person's face, skin tone, hair, body shape, and pose exactly the same. Replace their current outfit with the described garments. The clothing should look realistic, well-fitted, and naturally styled on the person. Maintain the same background and lighting.`,
                size: "1024x1024",
              });
              const editData = editResult.data?.[0];
              if (editData?.b64_json) {
                resultImageUrl = `data:image/png;base64,${editData.b64_json}`;
                resultProvider = "image-edit";
              } else if (editData?.url) {
                resultImageUrl = editData.url;
                resultProvider = "image-edit";
              }
            } catch (openAiError) {
              console.error("Secondary try-on image edit failed:", openAiError);
              fallbackReason = fallbackReason || "Live clothing edit was temporarily unavailable.";
            }
          }

          if (!resultImageUrl) {
            const creditsRestored = await restoreLiveTryOnCredits();
            const errorMsg = fallbackReason || "Live YouCam AI Clothes v4 and secondary AI editing were temporarily unavailable. Your credits have been restored. Ensure PERFECT_YOUCAM_API_KEY and PERFECT_YOUCAM_SECRET_KEY are configured.";
            await storage.updateTryonJob(job.id, {
              status: "error",
              resultImageUrl: userPhotoUrl,
              errorMessage: `${errorMsg}${creditsRestored ? " Your live try-on credits were restored." : ""}`,
            });
          } else {
            await storage.updateTryonJob(job.id, {
              status: completedStatusForFashionProvider(resultProvider),
              resultImageUrl,
              errorMessage: null,
            });
          }
        } catch (e) {
          console.error("Try-on processing error:", e);
          const creditsRestored = await restoreLiveTryOnCredits();
          await storage.updateTryonJob(job.id, {
            status: "error",
            resultImageUrl: userPhotoUrl,
            errorMessage: `Live virtual try-on encountered an unexpected error. Your credits have been restored.${creditsRestored ? " Credits restored." : ""}`,
          });
        }
      })();

      res.status(201).json(job);
    } catch (error) {
      console.error("Try-on job error:", error);
      res.status(500).json({ error: "Failed to create try-on job" });
    }
  });

  app.get("/api/tryon/:id", authenticateToken, async (req: Request, res: Response) => {
    try {
      const job = await storage.getTryonJob(req.params.id, (req as any).userId);
      if (!job) return res.status(404).json({ error: "Job not found" });
      if (job.status === "failed") {
        const repaired = await storage.updateTryonJob(job.id, {
          status: completedStatusForFashionProvider("photo-preview"),
          resultImageUrl: job.resultImageUrl || job.selfieUrl,
          errorMessage: "Live virtual try-on was unavailable. User-photo preview shown instead.",
        });
        return res.json(repaired || job);
      }
      res.json(job);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch try-on job" });
    }
  });

  app.post("/api/content", authenticateToken, async (req: Request, res: Response) => {
    try {
      const userId = (req as any).userId;
      const { outfitId, tone, platform } = req.body;

      if (!outfitId) {
        return res.status(400).json({ error: "outfitId is required" });
      }

      const hasCredits = await storage.consumeCredits(userId, 3);
      if (!hasCredits && !DEMO_MODE) {
        return res.status(402).json({ error: "Insufficient credits" });
      }

      const job = await storage.createContentJob(userId, outfitId, tone || "casual", platform || "instagram");

      (async () => {
        try {
          const outfit = await storage.getOutfit(outfitId, userId);
          if (!outfit) throw new Error("Outfit not found");

          const items = await Promise.all(
            (outfit.itemIds || []).map((id) => storage.getWardrobeItem(id, userId)),
          );
          const validItems = items.filter(Boolean) as any[];

          const { caption, hashtags } = await generateCaptionAndHashtags(
            outfit.name || "My Outfit",
            validItems,
            tone || "casual",
            platform || "instagram",
          );

          await storage.updateContentJob(job.id, {
            status: "completed",
            caption,
            hashtags,
          });
        } catch (e) {
          console.error("Content job error:", e);
          await storage.updateContentJob(job.id, {
            status: "failed",
          });
        }
      })();

      res.status(201).json(job);
    } catch (error) {
      console.error("Content job creation error:", error);
      res.status(500).json({ error: "Failed to create content job" });
    }
  });

  app.get("/api/content/:id", authenticateToken, async (req: Request, res: Response) => {
    try {
      const job = await storage.getContentJob(req.params.id, (req as any).userId);
      if (!job) return res.status(404).json({ error: "Job not found" });
      res.json(job);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch content job" });
    }
  });

  app.get("/api/credits", authenticateToken, async (req: Request, res: Response) => {
    try {
      const credits = await storage.getCredits((req as any).userId);
      res.json({ credits });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch credits" });
    }
  });

  app.post("/api/ai/style-insight", authenticateToken, async (req: Request, res: Response) => {
    try {
      const userId = (req as any).userId;
      const items = await storage.getWardrobeItems(userId);

      if (items.length < 3) {
        return res.json({
          insight: "Add more items to get personalized style insights!",
          dominantStyle: "Getting Started",
          suggestion: "Add at least 3 items to unlock AI style analysis.",
        });
      }

      const hasCredits = await storage.consumeCredits(userId, 2);
      if (!hasCredits && !DEMO_MODE) {
        return res.status(402).json({ error: "Insufficient credits" });
      }

      const insight = await generateStyleInsight(
        items.map((i) => ({
          name: i.name,
          category: i.category,
          color: i.color,
          tags: i.tags,
        })),
      );

      res.json(insight);
    } catch (error) {
      console.error("Style insight error:", error);
      res.status(500).json({ error: "Failed to generate style insight" });
    }
  });

  app.post("/api/wardrobe/:id/auto-tag", authenticateToken, async (req: Request, res: Response) => {
    try {
      const userId = (req as any).userId;
      const item = await storage.getWardrobeItem(req.params.id, userId);
      if (!item) return res.status(404).json({ error: "Item not found" });

      const tags = await generateAITags(item.name, item.category, item.color, item.brand);
      const updated = await storage.updateWardrobeItem(req.params.id, userId, { tags });
      res.json(updated);
    } catch (error) {
      console.error("Auto-tag error:", error);
      res.status(500).json({ error: "Failed to auto-tag item" });
    }
  });

  app.put("/api/wardrobe/:id", authenticateToken, async (req: Request, res: Response) => {
    try {
      const item = await storage.updateWardrobeItem(req.params.id, (req as any).userId, req.body);
      if (!item) return res.status(404).json({ error: "Item not found" });
      res.json(item);
    } catch (error) {
      console.error("Update wardrobe item error:", error);
      res.status(500).json({ error: "Failed to update item" });
    }
  });

  app.post("/api/wardrobe/:id/mark-worn", authenticateToken, async (req: Request, res: Response) => {
    try {
      const item = await storage.markItemAsWorn(req.params.id, (req as any).userId);
      if (!item) return res.status(404).json({ error: "Item not found" });
      await storage.trackEvent((req as any).userId, "item_worn", { itemId: req.params.id });
      res.json(item);
    } catch (error) {
      console.error("Mark worn error:", error);
      res.status(500).json({ error: "Failed to mark item as worn" });
    }
  });

  app.get("/api/wardrobe-stats", authenticateToken, async (req: Request, res: Response) => {
    try {
      const stats = await storage.getWardrobeStats((req as any).userId);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch wardrobe stats" });
    }
  });

  app.post("/api/feedback", authenticateToken, async (req: Request, res: Response) => {
    try {
      const { outfitId, rating, comment } = req.body;
      if (!outfitId || rating === undefined) {
        return res.status(400).json({ error: "outfitId and rating are required" });
      }
      const fb = await storage.createFeedback((req as any).userId, outfitId, rating, comment);
      res.status(201).json(fb);
    } catch (error) {
      console.error("Feedback error:", error);
      res.status(500).json({ error: "Failed to save feedback" });
    }
  });

  setupStripeBillingRoutes(app, authenticateToken);

  app.get("/api/subscription", authenticateToken, async (req: Request, res: Response) => {
    try {
      let sub = await storage.getSubscription((req as any).userId);
      if (!sub) {
        sub = await storage.createOrUpdateSubscription((req as any).userId, "free", 25);
      }
      res.json(sub);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch subscription" });
    }
  });

  app.post("/api/subscription/upgrade", authenticateToken, async (req: Request, res: Response) => {
    try {
      const { tier } = req.body;
      const tierConfig: Record<string, number> = { free: 25, pro: 1000, enterprise: 100000 };
      const monthlyCredits = tierConfig[tier] || 25;
      const sub = await storage.createOrUpdateSubscription((req as any).userId, tier, monthlyCredits);
      await storage.trackEvent((req as any).userId, "subscription_upgrade", { tier });
      res.json(sub);
    } catch (error) {
      res.status(500).json({ error: "Failed to upgrade subscription" });
    }
  });

  app.post("/api/subscription/consume-credit", authenticateToken, async (req: Request, res: Response) => {
    try {
      const result = await storage.consumeSubscriptionCredit((req as any).userId);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: "Failed to consume credit" });
    }
  });

  app.get("/api/analytics", authenticateToken, async (req: Request, res: Response) => {
    try {
      const analytics = await storage.getAnalytics((req as any).userId);
      res.json(analytics);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch analytics" });
    }
  });

  app.post("/api/affiliate/click", authenticateToken, async (req: Request, res: Response) => {
    try {
      const { productName, productUrl, source } = req.body;
      const click = await storage.trackAffiliateClick((req as any).userId, productName, productUrl, source || "app");
      res.json(click);
    } catch (error) {
      res.status(500).json({ error: "Failed to track affiliate click" });
    }
  });

  app.get("/api/youcam/fashion-capability", (_req: Request, res: Response) => {
    res.json(getFashionTryOnCapability());
  });

  app.get("/api/youcam/test", async (_req: Request, res: Response) => {
    try {
      const result = await testYouCamApiKey();
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ success: false, message: error.message });
    }
  });

  app.get("/api/youcam/styles", authenticateToken, async (_req: Request, res: Response) => {
    try {
      const groups = await getHairStyleGroups();
      res.json(groups);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/health", (_req: Request, res: Response) => {
    res.json({ status: "ok", demoMode: DEMO_MODE, timestamp: new Date().toISOString() });
  });

  const httpServer = createServer(app);
  return httpServer;
}
