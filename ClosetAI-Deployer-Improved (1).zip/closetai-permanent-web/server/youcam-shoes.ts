import type { AiShoesRenderStyle, AiShoesRenderingSetting } from "@shared/ai-shoes-tryon";
import { requestYouCamSkinV2 } from "./youcam-skin-v2";

export type AiShoesTask = { taskId: string; pollingInterval: number };

export async function startYouCamAiShoesTask(
  targetFileId: string,
  referenceFileId: string,
  renderingSetting: AiShoesRenderingSetting,
  style: AiShoesRenderStyle,
): Promise<AiShoesTask> {
  const response = await requestYouCamSkinV2("/s2s/v2.0/task/shoes", {
    method: "POST",
    body: JSON.stringify({
      src_file_id: targetFileId,
      ref_file_id: referenceFileId,
      gender: renderingSetting,
      style,
    }),
  });
  const taskId = response.data?.data?.task_id || response.data?.task_id;
  if (!response.ok || typeof taskId !== "string" || !taskId) throw new Error(`YouCam AI Shoes task creation failed (${response.status})`);
  return { taskId, pollingInterval: 3 };
}

export async function getYouCamAiShoesTask(taskId: string): Promise<{ status: string; output?: unknown; error?: string }> {
  const response = await requestYouCamSkinV2(`/s2s/v2.0/task/shoes/${encodeURIComponent(taskId)}`);
  if (!response.ok) throw new Error(`YouCam AI Shoes task status failed (${response.status})`);
  const data = response.data?.data || response.data || {};
  const status = String(data.task_status || data.status || (typeof data.results?.url === "string" || typeof data.url === "string" ? "success" : "running")).toLowerCase();
  return { status, output: data, error: typeof data.error === "string" ? data.error : typeof data.error_message === "string" ? data.error_message : undefined };
}
