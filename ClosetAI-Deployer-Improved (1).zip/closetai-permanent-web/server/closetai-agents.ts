import { randomUUID } from "node:crypto";
import OpenAI from "openai";

import {
  AGENT_BLOCKED_LANGUAGE,
  agentDisclosure,
  type AgentContextSource,
  type ClosetAgentCategoryReference,
  type ClosetAgentPlan,
  type ClosetAgentRequest,
  type ClosetAgentStep,
  type FashionAgentRequest,
  type SkincareAgentRequest,
} from "@shared/closetai-agent-contracts";
import { storage } from "./storage";

type MinimalWardrobeItem = {
  id: string;
  name: string;
  category: string;
  color: string | null;
  tags: string[];
  usageCount: number;
};

type AgentDraft = {
  title?: unknown;
  summary?: unknown;
  steps?: unknown;
  selectedWardrobeItemIds?: unknown;
  categoryReferenceIds?: unknown;
};

const MAX_PROMPT_LENGTH = 360;
const MAX_STEPS = 4;
const AGENT_MODEL = process.env.CLOSETAI_AGENT_MODEL || "gpt-4o-mini";
const hasLiveModel = Boolean(process.env.AI_INTEGRATIONS_OPENAI_API_KEY?.trim());
const agentOpenAi = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY || "not-configured",
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

const CATEGORY_REFERENCES: ClosetAgentCategoryReference[] = [
  { id: "cerave-hydrating-facial-cleanser", label: "Hydrating cleanser category", category: "Cleanser", sourceLabel: "Manufacturer product page" },
  { id: "cerave-am-facial-lotion-spf-30", label: "Daytime-protection category", category: "SPF", sourceLabel: "Manufacturer product page" },
  { id: "cerave-skin-renewing-night-cream", label: "Night moisturizer category", category: "Moisturizer", sourceLabel: "Manufacturer product page" },
  { id: "ordinary-niacinamide-zinc", label: "Serum category reference", category: "Serum", sourceLabel: "Manufacturer product page" },
];

const FICTIONAL_WARDROBE: MinimalWardrobeItem[] = [
  { id: "fictional-demo-cream-knit", name: "Fictional cream knit", category: "top", color: "cream", tags: ["relaxed", "layering"], usageCount: 0 },
  { id: "fictional-demo-navy-trouser", name: "Fictional navy trouser", category: "bottom", color: "navy", tags: ["polished", "versatile"], usageCount: 0 },
  { id: "fictional-demo-loafer", name: "Fictional leather loafer", category: "shoes", color: "brown", tags: ["smart casual"], usageCount: 0 },
];

function cleanText(value: unknown, maxLength: number): string | null {
  if (typeof value !== "string") return null;
  const normalized = value.replace(/\s+/g, " ").trim();
  return normalized ? normalized.slice(0, maxLength) : null;
}

function safePrompt(value: unknown): string {
  return cleanText(value, MAX_PROMPT_LENGTH) || "";
}

function hasBlockedLanguage(value: string): boolean {
  const normalized = value.toLowerCase();
  return AGENT_BLOCKED_LANGUAGE.some((phrase) => normalized.includes(phrase));
}

function safeSteps(value: unknown, kind: ClosetAgentStep["kind"]): ClosetAgentStep[] {
  if (!Array.isArray(value)) return [];
  const steps: ClosetAgentStep[] = [];
  for (const entry of value.slice(0, MAX_STEPS - 1)) {
    if (!entry || typeof entry !== "object") continue;
    const item = entry as { title?: unknown; detail?: unknown };
    const title = cleanText(item.title, 64);
    const detail = cleanText(item.detail, 220);
    if (!title || !detail || hasBlockedLanguage(`${title} ${detail}`)) continue;
    steps.push({ id: `agent-step-${steps.length + 1}`, title, detail, kind });
  }
  return steps;
}

function normalizeWardrobe(items: Awaited<ReturnType<typeof storage.getWardrobeItems>>): MinimalWardrobeItem[] {
  return items.slice(0, 12).map((item) => ({
    id: item.id,
    name: cleanText(item.name, 72) || "Wardrobe item",
    category: cleanText(item.category, 40) || "other",
    color: cleanText(item.color, 32),
    tags: Array.isArray(item.tags) ? item.tags.map((tag) => cleanText(tag, 28)).filter((tag): tag is string => Boolean(tag)).slice(0, 5) : [],
    usageCount: Math.max(0, item.usageCount || 0),
  }));
}

function selectFashionItems(items: MinimalWardrobeItem[], palette: string): MinimalWardrobeItem[] {
  const paletteNeedle = palette.toLowerCase();
  return [...items]
    .sort((left, right) => {
      const leftPalette = left.color?.toLowerCase().includes(paletteNeedle) ? 1 : 0;
      const rightPalette = right.color?.toLowerCase().includes(paletteNeedle) ? 1 : 0;
      if (leftPalette !== rightPalette) return rightPalette - leftPalette;
      return left.usageCount - right.usageCount;
    })
    .slice(0, 3);
}

function fashionFallback(input: FashionAgentRequest, items: MinimalWardrobeItem[], requestId: string): ClosetAgentPlan {
  const selected = selectFashionItems(items, input.palette || "");
  const demo = input.demoMode === true;
  const baseSources: AgentContextSource[] = demo
    ? ["selected_preferences", "fictional_demo"]
    : ["selected_preferences", "local_wardrobe"];

  if (selected.length === 0) {
    return {
      requestId,
      agent: "fashion",
      mode: demo ? "fictional_demo" : "local_fallback",
      title: "Start with a few pieces you own",
      summary: demo ? "Fictional Demo Mode is ready for exploration, but no fictional wardrobe pieces were selected." : "Add a few owned wardrobe items to unlock a more specific look plan.",
      steps: [
        { id: "agent-step-1", title: "Add an owned piece", detail: "Start with a top, bottom, dress, or pair of shoes you already own.", kind: "style" },
        { id: "agent-step-2", title: "Choose an occasion", detail: "Use a specific context such as work, dinner, travel, or relaxed weekend.", kind: "style" },
        { id: "agent-step-3", title: "Build deliberately", detail: "Review every piece before saving or creating an outfit.", kind: "boundary" },
      ],
      selectedWardrobeItemIds: [],
      categoryReferences: [],
      contextSources: baseSources,
      disclosure: agentDisclosure("fashion"),
      usedFallback: true,
      validationFlags: ["no_wardrobe_items"],
    };
  }

  const title = input.occasion ? `${input.occasion} wardrobe outline` : "A considered wardrobe outline";
  const names = selected.map((item) => item.name).join(", ");
  return {
    requestId,
    agent: "fashion",
    mode: demo ? "fictional_demo" : "local_fallback",
    title,
    summary: `${demo ? "Fictional Demo Mode: " : "Local planning fallback: "}start with ${names}, then adjust the balance for your own comfort and plans.`,
    steps: [
      { id: "agent-step-1", title: "Choose the anchor", detail: `Begin with ${selected[0].name} as the visual anchor for this look.`, kind: "style" },
      { id: "agent-step-2", title: "Build contrast gently", detail: "Add one complementary layer or accessory from your wardrobe rather than changing every element at once.", kind: "style" },
      { id: "agent-step-3", title: "Review before saving", detail: "This is a styling outline, not a fit, stock, price, or purchase recommendation.", kind: "boundary" },
    ],
    selectedWardrobeItemIds: selected.map((item) => item.id),
    categoryReferences: [],
    contextSources: baseSources,
    disclosure: agentDisclosure("fashion"),
    usedFallback: true,
    validationFlags: ["local_fallback"],
  };
}

function skincareFallback(input: SkincareAgentRequest, sourceSummary: string | null, requestId: string): ClosetAgentPlan {
  const demo = input.demoMode === true;
  const contextSources: AgentContextSource[] = ["selected_preferences", "external_category_reference"];
  if (demo) contextSources.push("fictional_demo");
  if (input.includeLatestNormalizedSummary && sourceSummary && !demo) contextSources.push("saved_normalized_skin_summary");
  const time = input.routineTime || "AM_PM";
  const goal = input.skincareGoal || "simple_routine";
  const goalLabel: Record<NonNullable<SkincareAgentRequest["skincareGoal"]>, string> = {
    comfort: "comfort-focused",
    hydration: "hydration-focused",
    radiance: "radiance-focused",
    texture_appearance: "texture-appearance-focused",
    simple_routine: "simple",
  };
  const references = time === "PM"
    ? CATEGORY_REFERENCES.filter((reference) => reference.id !== "cerave-am-facial-lotion-spf-30")
    : CATEGORY_REFERENCES.slice(0, 3);

  return {
    requestId,
    agent: "skincare",
    mode: demo ? "fictional_demo" : "local_fallback",
    title: `${goalLabel[goal]} cosmetic routine outline`,
    summary: `${demo ? "Fictional Demo Mode: " : "Local planning fallback: "}${sourceSummary ? "the selected saved normalized summary is acknowledged as optional context. " : "no selfie or scan is required for this general plan. "}Keep the sequence simple and follow each current product label.`,
    steps: [
      { id: "agent-step-1", title: "Cleanse gently", detail: "Use a cleanser category that you choose, following the current package instructions.", kind: "routine" },
      { id: "agent-step-2", title: time === "PM" ? "Keep the middle simple" : "Add comfort as needed", detail: "Introduce only one optional category at a time and stop if a product does not feel right for you.", kind: "routine" },
      { id: "agent-step-3", title: time === "PM" ? "Finish with moisture" : "Follow daytime label guidance", detail: time === "PM" ? "Use a moisturizer category if desired, according to its label." : "For daytime products, follow the product’s current label for application and reapplication.", kind: "routine" },
      { id: "agent-step-4", title: "Keep this in context", detail: "This is general cosmetic organization, not a medical assessment, treatment plan, or product-suitability decision.", kind: "boundary" },
    ],
    selectedWardrobeItemIds: [],
    categoryReferences: references,
    contextSources,
    disclosure: agentDisclosure("skincare"),
    usedFallback: true,
    validationFlags: ["local_fallback"],
  };
}

function parseAgentDraft(value: string): AgentDraft | null {
  try {
    const parsed = JSON.parse(value);
    return parsed && typeof parsed === "object" ? parsed as AgentDraft : null;
  } catch {
    return null;
  }
}

function planFromDraft(
  agent: ClosetAgentRequest["agent"],
  requestId: string,
  draft: AgentDraft,
  fallback: ClosetAgentPlan,
  permittedItems: MinimalWardrobeItem[],
  contextSources: AgentContextSource[],
): ClosetAgentPlan {
  const title = cleanText(draft.title, 88);
  const summary = cleanText(draft.summary, 300);
  if (!title || !summary || hasBlockedLanguage(`${title} ${summary}`)) return { ...fallback, validationFlags: [...fallback.validationFlags, "unsafe_or_invalid_draft"] };
  const steps = safeSteps(draft.steps, agent === "fashion" ? "style" : "routine");
  if (steps.length === 0) return { ...fallback, validationFlags: [...fallback.validationFlags, "empty_draft_steps"] };

  const permittedIds = new Set(permittedItems.map((item) => item.id));
  const draftItemIds = Array.isArray(draft.selectedWardrobeItemIds)
    ? draft.selectedWardrobeItemIds.filter((id): id is string => typeof id === "string" && permittedIds.has(id)).slice(0, 3)
    : [];
  const categoryIds = new Set(CATEGORY_REFERENCES.map((reference) => reference.id));
  const categoryReferences = Array.isArray(draft.categoryReferenceIds)
    ? draft.categoryReferenceIds
      .filter((id): id is string => typeof id === "string" && categoryIds.has(id))
      .slice(0, 3)
      .map((id) => CATEGORY_REFERENCES.find((reference) => reference.id === id))
      .filter((reference): reference is ClosetAgentCategoryReference => Boolean(reference))
    : [];

  if (agent === "fashion" && permittedItems.length > 0 && draftItemIds.length === 0) {
    return { ...fallback, validationFlags: [...fallback.validationFlags, "draft_referenced_no_known_wardrobe_items"] };
  }

  return {
    requestId,
    agent,
    mode: "live_model",
    title,
    summary,
    steps: [...steps, { id: "agent-boundary", title: "Keep the plan user-directed", detail: agent === "fashion" ? "Review your selected items yourself; the agent cannot verify fit, price, inventory, or purchase eligibility." : "Review current labels and seek qualified care for consequential concerns; this plan is not medical guidance.", kind: "boundary" }].slice(0, MAX_STEPS),
    selectedWardrobeItemIds: agent === "fashion" ? draftItemIds : [],
    categoryReferences: agent === "skincare" ? categoryReferences : [],
    contextSources,
    disclosure: agentDisclosure(agent),
    usedFallback: false,
    validationFlags: ["validated_structured_response"],
  };
}

async function buildLiveDraft(agent: ClosetAgentRequest["agent"], context: Record<string, unknown>): Promise<AgentDraft | null> {
  if (!hasLiveModel) return null;
  const system = agent === "fashion"
    ? "You are ClosetAI Fashion Look Planner. Return JSON only with title, summary, steps [{title,detail}], selectedWardrobeItemIds, and categoryReferenceIds. Use only supplied wardrobe IDs. Offer styling ideas only. Never mention price, inventory, purchase, checkout, fit certainty, body judgment, medical claims, external brands, or URLs."
    : "You are ClosetAI Skin Routine Companion. Return JSON only with title, summary, steps [{title,detail}], selectedWardrobeItemIds, and categoryReferenceIds. Offer only general cosmetic routine organization using supplied category reference IDs. Never diagnose, prescribe, treat, predict results, claim suitability or efficacy, mention formulas, or infer personal traits from a photo or summary.";
  try {
    const response = await agentOpenAi.chat.completions.create({
      model: AGENT_MODEL,
      messages: [
        { role: "system", content: system },
        { role: "user", content: JSON.stringify(context) },
      ],
      max_completion_tokens: 500,
      response_format: { type: "json_object" },
    });
    return parseAgentDraft(response.choices[0]?.message?.content || "");
  } catch {
    return null;
  }
}

export async function createClosetAgentPlan(userId: string, input: ClosetAgentRequest): Promise<ClosetAgentPlan> {
  const requestId = randomUUID();
  if (input.agent === "fashion") {
    const wardrobe = input.demoMode ? FICTIONAL_WARDROBE : normalizeWardrobe(await storage.getWardrobeItems(userId));
    const fallback = fashionFallback(input, wardrobe, requestId);
    const sources = fallback.contextSources;
    const draft = await buildLiveDraft("fashion", {
      agent: "Fashion Look Planner",
      prompt: safePrompt(input.prompt),
      occasion: cleanText(input.occasion, 48),
      palette: cleanText(input.palette, 48),
      wardrobe: wardrobe.map(({ id, name, category, color, tags }) => ({ id, name, category, color, tags })),
      contextSources: sources,
      requiredDisclosure: agentDisclosure("fashion"),
    });
    return draft ? planFromDraft("fashion", requestId, draft, fallback, wardrobe, sources) : fallback;
  }

  const latestSnapshot = input.includeLatestNormalizedSummary && !input.demoMode
    ? (await storage.getSkinSnapshots(userId))[0]
    : undefined;
  const sourceSummary = latestSnapshot ? cleanText(latestSnapshot.overallSummary, 220) : null;
  const fallback = skincareFallback(input, sourceSummary, requestId);
  const draft = await buildLiveDraft("skincare", {
    agent: "Skin Routine Companion",
    prompt: safePrompt(input.prompt),
    routineTime: input.routineTime || "AM_PM",
    skincareGoal: input.skincareGoal || "simple_routine",
    selectedSummarySource: latestSnapshot ? latestSnapshot.source : input.demoMode ? "fictional_demo" : null,
    normalizedSummary: sourceSummary,
    categoryReferences: CATEGORY_REFERENCES,
    contextSources: fallback.contextSources,
    requiredDisclosure: agentDisclosure("skincare"),
  });
  return draft ? planFromDraft("skincare", requestId, draft, fallback, [], fallback.contextSources) : fallback;
}
