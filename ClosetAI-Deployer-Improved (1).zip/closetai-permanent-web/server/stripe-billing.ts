import { Request, Response } from "express";
import * as storage from "./storage";
import crypto from "node:crypto";

export function setupStripeBillingRoutes(app: any, authenticateToken: any) {
  app.post("/api/subscription/stripe-checkout", authenticateToken, async (req: Request, res: Response) => {
    try {
      const { tier } = req.body;
      if (!tier || !["free", "pro", "enterprise"].includes(tier)) {
        return res.status(400).json({ error: "Invalid subscription tier selected." });
      }
      const userId = String((req as any).userId);
      const user = await storage.storage.getUser(userId);
      const userEmail = user?.email || `user-${userId}@closetai.local`;

      const stripeSecretKey = process.env.STRIPE_SECRET_KEY || process.env.CLOSETAI_STRIPE_SECRET_KEY;
      const frontendDomain = process.env.EXPO_PUBLIC_DOMAIN || process.env.REPLIT_DEV_DOMAIN || "closetai-preview.replit.dev";
      const successUrl = `https://${frontendDomain}/subscription?success=true&tier=${tier}`;
      const cancelUrl = `https://${frontendDomain}/subscription?canceled=true`;

      const basicTestPrices: Record<string, { unitAmount: number; name: string }> = {
        pro: { unitAmount: 1900, name: "ClosetAI Pro Plan (Basic Test Price)" },
        enterprise: { unitAmount: 9900, name: "ClosetAI Enterprise Plan (Basic Test Price)" },
      };

      if (!stripeSecretKey || stripeSecretKey.trim() === "" || stripeSecretKey.startsWith("sk_mock_")) {
        const tierConfig: Record<string, number> = { free: 25, pro: 1000, enterprise: 100000 };
        const monthlyCredits = tierConfig[tier] || 25;
        const sub = await storage.storage.createOrUpdateSubscription(userId, tier, monthlyCredits);
        await storage.storage.trackEvent(userId, "stripe_checkout_mock_fallback", { tier });
        return res.json({
          checkoutUrl: successUrl,
          sessionId: `mock_sess_${Date.now()}`,
          status: "mock-simulated-basic-price",
          subscription: sub,
        });
      }

      const priceInfo = basicTestPrices[tier] || { unitAmount: 1900, name: `ClosetAI ${tier.toUpperCase()} Plan` };

      const response = await fetch("https://api.stripe.com/v1/checkout/sessions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${stripeSecretKey}`,
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: new URLSearchParams({
          "payment_method_types[0]": "card",
          "line_items[0][price_data][currency]": "usd",
          "line_items[0][price_data][product_data][name]": priceInfo.name,
          "line_items[0][price_data][unit_amount]": String(priceInfo.unitAmount),
          ...(tier !== "free" ? { "line_items[0][price_data][recurring][interval]": "month" } : {}),
          "line_items[0][quantity]": "1",
          mode: tier === "free" ? "payment" : "subscription",
          customer_email: userEmail,
          "client_reference_id": String(userId),
          success_url: successUrl,
          cancel_url: cancelUrl,
          "metadata[tier]": tier,
          "metadata[userId]": String(userId),
        }).toString(),
      });

      const session = await response.json() as any;
      if (!response.ok || !session || session.error) {
        return res.status(400).json({ error: session?.error?.message || "Failed to create Stripe Checkout session." });
      }

      await storage.storage.trackEvent(userId, "stripe_checkout_session_created", { sessionId: session.id, tier });

      return res.json({
        checkoutUrl: session.url,
        sessionId: session.id,
        status: session.status || "open",
      });
    } catch (error) {
      return res.status(500).json({ error: error instanceof Error ? error.message : "Failed to initiate Stripe checkout." });
    }
  });

  app.post("/api/subscription/stripe-webhook", async (req: Request, res: Response) => {
    try {
      const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET || process.env.CLOSETAI_STRIPE_WEBHOOK_SECRET;
      const signature = req.headers["stripe-signature"];

      if (webhookSecret && webhookSecret.trim() !== "" && signature && typeof signature === "string") {
        const rawBody = (req as any).rawBody || JSON.stringify(req.body);
        try {
          const elements = signature.split(",");
          let timestamp = "";
          let v1Sig = "";
          for (const el of elements) {
            const [key, val] = el.split("=");
            if (key === "t") timestamp = val;
            if (key === "v1") v1Sig = val;
          }
          if (timestamp && v1Sig) {
            const signedPayload = `${timestamp}.${rawBody}`;
            const expectedSig = crypto.createHmac("sha256", webhookSecret).update(signedPayload).digest("hex");
            if (expectedSig !== v1Sig) {
              return res.status(400).json({ error: "Invalid webhook signature." });
            }
          }
        } catch (sigErr) {
          console.warn("Webhook signature verification warning:", sigErr);
        }
      }

      const event = req.body;
      if (!event || !event.type) {
        return res.status(400).json({ error: "Invalid webhook payload." });
      }

      if (event.type === "checkout.session.completed" || event.type === "payment_intent.succeeded") {
        const session = event.data?.object;
        const userId = session?.client_reference_id || session?.metadata?.userId;
        const tier = session?.metadata?.tier;
        if (userId && tier && ["free", "pro", "enterprise"].includes(tier)) {
          const tierConfig: Record<string, number> = { free: 25, pro: 1000, enterprise: 100000 };
          const monthlyCredits = tierConfig[tier] || 25;
          await storage.storage.createOrUpdateSubscription(String(userId), tier, monthlyCredits);
          await storage.storage.trackEvent(String(userId), "stripe_webhook_subscription_fulfilled", { tier, eventType: event.type, id: session?.id });
        }
      } else if (event.type === "customer.subscription.created" || event.type === "customer.subscription.updated" || event.type === "customer.subscription.deleted") {
        const subscriptionObj = event.data?.object;
        const customerId = subscriptionObj?.customer;
        const status = subscriptionObj?.status;
        const metadataTier = subscriptionObj?.metadata?.tier;
        const metadataUserId = subscriptionObj?.metadata?.userId;

        if (metadataUserId && ["free", "pro", "enterprise"].includes(metadataTier)) {
          const tierConfig: Record<string, number> = { free: 25, pro: 1000, enterprise: 100000 };
          const targetTier = (status === "active" || status === "trialing") ? metadataTier : "free";
          const monthlyCredits = tierConfig[targetTier] || 25;
          await storage.storage.createOrUpdateSubscription(String(metadataUserId), targetTier, monthlyCredits);
          await storage.storage.trackEvent(String(metadataUserId), "stripe_subscription_lifecycle_updated", { eventType: event.type, status, targetTier, customerId });
        }
      } else if (event.type === "invoice.payment_failed" || event.type === "payment_intent.payment_failed" || event.type === "charge.failed") {
        const obj = event.data?.object;
        const customerId = obj?.customer;
        const subscriptionId = obj?.subscription;
        const customerEmail = obj?.customer_email || obj?.receipt_email;
        console.warn(`[Stripe Billing] Payment/Charge failed for customer ${customerId || 'unknown'} (${customerEmail || 'no-email'}) type=${event.type}`);
        if (subscriptionId) {
          try {
            await storage.storage.trackEvent(String(subscriptionId), "stripe_payment_failed", { type: event.type, customerId });
          } catch {}
        }
      }

      return res.json({ received: true });
    } catch (error) {
      return res.status(500).json({ error: error instanceof Error ? error.message : "Webhook processing failed." });
    }
  });
}
