import type { AiSmileExpressionType } from "@shared/ai-smile";
import { requestYouCamSkinV2 } from "./youcam-skin-v2";

export type AiSmileTask = { taskId: string; pollingInterval: number };

export async function startYouCamAiSmileTask(fileId: string, expressionType: AiSmileExpressionType): Promise<AiSmileTask> {
  const response = await requestYouCamSkinV2("/s2s/v2.0/task/ai-smile", {
    method: "POST",
    body: JSON.stringify({ src_file_id: fileId, expression_type: expressionType }),
  });
  const taskId = response.data?.data?.task_id || response.data?.task_id;
  if (!response.ok || typeof taskId !== "string" || !taskId) throw new Error(`YouCam AI Smile task creation failed (${response.status})`);
  return { taskId, pollingInterval: 3 };
}

export async function getYouCamAiSmileTask(taskId: string): Promise<{ status: string; output?: unknown; error?: string }> {
  const response = await requestYouCamSkinV2(`/s2s/v2.0/task/ai-smile/${encodeURIComponent(taskId)}`);
  if (!response.ok) throw new Error(`YouCam AI Smile task status failed (${response.status})`);
  const data = response.data?.data || response.data || {};
  const status = String(data.task_status || data.status || (typeof data.url === "string" ? "success" : "running")).toLowerCase();
  return { status, output: data, error: typeof data.error === "string" ? data.error : typeof data.error_message === "string" ? data.error_message : undefined };
}
