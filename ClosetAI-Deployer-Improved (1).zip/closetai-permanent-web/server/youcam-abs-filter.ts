import type { AbsFilterIntensity, AbsFilterMode } from "@shared/abs-filter-simulation";
import { requestYouCamSkinV2 } from "./youcam-skin-v2";

export type AbsFilterTask = { taskId: string; pollingInterval: number };

export async function startYouCamAbsFilterTask(fileId: string, mode: AbsFilterMode, intensity: AbsFilterIntensity): Promise<AbsFilterTask> {
  const response = await requestYouCamSkinV2("/s2s/v2.0/task/abs-shape", {
    method: "POST",
    body: JSON.stringify({ src_file_id: fileId, mode, intensity }),
  });
  const taskId = response.data?.data?.task_id || response.data?.task_id;
  if (!response.ok || typeof taskId !== "string" || !taskId) throw new Error(`YouCam AI Abs Filter task creation failed (${response.status})`);
  return { taskId, pollingInterval: 3 };
}

export async function getYouCamAbsFilterTask(taskId: string): Promise<{ status: string; output?: unknown; error?: string }> {
  const response = await requestYouCamSkinV2(`/s2s/v2.0/task/abs-shape/${encodeURIComponent(taskId)}`);
  if (!response.ok) throw new Error(`YouCam AI Abs Filter task status failed (${response.status})`);
  const data = response.data?.data || response.data || {};
  const status = String(data.task_status || data.status || (typeof data.results?.url === "string" || typeof data.url === "string" ? "success" : "running")).toLowerCase();
  return { status, output: data, error: typeof data.error === "string" ? data.error : typeof data.error_message === "string" ? data.error_message : undefined };
}
