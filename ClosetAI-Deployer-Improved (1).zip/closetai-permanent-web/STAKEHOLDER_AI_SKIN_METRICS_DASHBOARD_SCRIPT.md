# ClosetAI AI Skin Metrics Dashboard
## Stakeholder Presentation Script

**Recommended duration:** 7–9 minutes  
**Presenter:** Product or engineering lead  
**Demo environment:** Expo mobile app with Demo Mode available as a reliable fallback

> **Opening statement:** ClosetAI provides visual skin-care guidance and wardrobe styling connections. It does not diagnose, treat, or replace professional medical advice.

| Segment | Presenter script | On-screen demonstration |
|---|---|---|
| 1. Product context | “ClosetAI began as a wardrobe intelligence experience. Our Skin Care feature adds an optional visual self-care layer that helps users organize a simple routine and connect style decisions to the clothes they already own.” | Open the **Skin** tab. Point out the separate Skin Care navigation and the Demo Mode label. |
| 2. Trust and choice | “The experience is designed around user choice. A user can explore the complete fictional demo without sharing a photo. When they want a personalized snapshot, they can opt into the camera or select an existing image.” | Tap **Add Selfie** or **Optional selfie flow**. Show the privacy and consent language. |
| 3. Live camera capture | “For real-time capture, ClosetAI now uses Expo Camera with a front-camera guide. The camera stream is used to frame one face, support even-lighting guidance, and take a reviewable frame.” | Tap **Live Camera Scan**. Show the face oval, camera flip control, and capture button. |
| 4. Face guidance boundary | “After capture, on-device face detection checks for a single face when the platform supports it. If the check is unavailable, the user is told clearly and can review the frame manually. We do not claim continuous biometric diagnosis.” | Capture a frame if a device camera is available. Otherwise explain the visible fallback notice. |
| 5. Review before analysis | “The user sees quality guidance, can confirm general-guidance consent, and chooses whether to save a normalized summary. The original selfie is not used as a history thumbnail.” | Show the selfie review screen, consent toggle, and save-summary toggle. |
| 6. Visual AI dashboard | “Instead of displaying raw provider output, ClosetAI transforms available visual signals into an understandable dashboard. We show score cards, source labels, coverage, and a concise AI-prioritized list of focus, watch, and sustain areas.” | Open **Skin Signals** or **Snapshot Results**. Highlight **Live visual analysis**, coverage, metric cards, and priority cards. |
| 7. Explainability | “Each card uses plain language. A ‘focus’ card is a prompt for gradual, general-care planning—not a medical ranking. Radiance, hydration, texture, pores, and other available signals are visualized consistently.” | Select or point to **Hydration**, **Radiance**, **Texture**, and **Pores** cards. |
| 8. Personal routine and style connection | “The dashboard connects signals to a simple AM/PM sequence and optional wardrobe direction. The user remains in control: the output is an inspiration layer, not a rule engine.” | Open **Routine** and **Skin × Wardrobe**. Show actual wardrobe handoff when inventory exists, or the clear empty state when it does not. |
| 9. Local history and charts | “Approved normalized metrics are stored locally in SQLite as timestamps and scores only. The progression chart does not retain selfies, masks, or raw API payloads. It becomes meaningful after at least two saved snapshots.” | Open **Progress dashboard**. Show chart metric tabs, the SQLite explanation, and the no-data state if fewer than two snapshots exist. |
| 10. Demo reliability | “For a reliable stakeholder demo, Demo Mode contains three complete fictional profiles. Each profile includes all skin signals, AM/PM routines, fictional product inspiration, wardrobe looks, accessories, and a clearly labeled history preview.” | Return to Demo Mode. Tap **Run Demo Skin Scan** to rotate profiles. Point out the fictional-data banner. |
| 11. Privacy and safety | “Our data boundary is deliberate: normalized summaries support the user experience, while raw provider output is not presented in the dashboard. We communicate source, privacy choices, and non-medical boundaries throughout the flow.” | Open **Privacy** from Skin Care settings. Reiterate that history stores summaries rather than selfie previews. |
| 12. Closing value | “ClosetAI turns an intimidating analysis flow into an understandable self-care and style experience: optional camera capture, transparent visual intelligence, durable personal history, and direct wardrobe relevance.” | Return to the Skin dashboard or Outfit tab. |

## Key Messages to Reinforce

| Theme | Message |
|---|---|
| **AI clarity** | The product transforms normalized visual signals into plain-language cards, priorities, and trends instead of exposing raw API payloads. |
| **User agency** | Selfie capture is optional; Demo Mode works without camera access or a live provider. |
| **Privacy by design** | Local SQLite history stores only normalized metric values, timestamps, and source labels—not the original selfie or raw analysis payload. |
| **Safe framing** | The experience provides general visual wellness and style guidance. It never presents a medical diagnosis. |
| **Product integration** | Skin insight connects to AM/PM care planning, color direction, accessories, and outfits built from the user’s wardrobe. |
| **Operational resilience** | Permission-denied, unsupported face-detection, unavailable network, and sparse-history states are handled with clear user-facing fallbacks. |

## Anticipated Questions and Suggested Answers

| Question | Suggested answer |
|---|---|
| “Does the app diagnose skin conditions?” | “No. The dashboard is explicitly framed as general visual wellness and style guidance. It does not diagnose, treat, or replace medical care.” |
| “What happens if face detection is not supported?” | “The optional camera still supports capture. The app discloses that face validation is unavailable and sends the frame through the normal review and quality-check flow.” |
| “What is stored locally?” | “Only approved normalized metric scores, timestamps, source labels, and high-level summary fields required for the chart. The SQLite history does not store the original selfie.” |
| “Can the demo run without external services?” | “Yes. Demo Mode is self-contained and clearly marked as fictional. It presents complete profile, routine, product, wardrobe, and history examples.” |
| “How does this help ClosetAI’s core wardrobe experience?” | “It adds a user-controlled self-care context to existing outfit recommendations: palette direction, accessory ideas, and looks are grounded in the user’s own wardrobe whenever inventory is available.” |

## Presenter Checklist

Before presenting, confirm that the Expo app is built with the camera and SQLite native modules, camera permission is available on the device, and at least two approved snapshots have been saved if you plan to show a populated local progression chart. Keep Demo Mode enabled as a no-network fallback. Do not describe fictional demo products, pricing, history, or profiles as live data.
