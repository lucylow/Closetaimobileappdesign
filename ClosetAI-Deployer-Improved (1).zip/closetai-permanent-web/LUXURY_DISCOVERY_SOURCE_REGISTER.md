# Luxury Discovery Source Register

ClosetAI uses the following destinations only as external discovery links. Catalog records must remain labeled as mock discovery data and must not claim live price, inventory, checkout availability, affiliation, or current regional availability.

| Brand | Official discovery destination | Verified use in ClosetAI |
| --- | --- | --- |
| Louis Vuitton | https://us.louisvuitton.com/eng-us/women/handbags/all-handbags/_/N-tfr7qdp | External handbag-collection discovery link; the page presents Louis Vuitton as its official USA website and lists handbag collections such as Neverfull, Speedy, and Alma. |
| Gucci | https://www.gucci.com/us/en/ca/women/handbags-c-women-handbags | External handbag-collection discovery link; the page presents Gucci’s women’s handbag catalog. |
| Dior | https://www.dior.com/en_us/fashion/womens-fashion/bags/all-the-bags | External Dior bags discovery destination identified from the official search result; the sandbox browser currently reports the page as unavailable, so the app must describe it only as an external official-site link and must not infer catalog availability. |
| Hermès | https://www.hermes.com/us/en/category/leather-goods/bags-and-clutches/womens-bags-and-clutches/ | External women’s bags discovery link; the official catalog identifies women’s bags and clutches and product names such as Plume mini bag and Lindy II mini bag. |
| Chanel | https://www.chanel.com/us/fashion/handbags/c/1x1x1/ | External handbags discovery link; the official site presents its handbags selection. |

The records will use no copied product images from these sites. Garment visual references remain generic, garment-only, and clearly associated with ClosetAI Demo Mode rather than any luxury house.
