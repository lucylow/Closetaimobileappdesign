export const FITZPATRICK_TYPES = ["I", "II", "III", "IV", "V", "VI"] as const;

export type FitzpatrickType = (typeof FITZPATRICK_TYPES)[number];
export type FitzpatrickProfileSource = "provider" | "unavailable";

export type FitzpatrickProfile = {
  type: FitzpatrickType;
  source: "provider";
  analyzedAt: string;
  providerLabel: string;
};

export type FitzpatrickCapability = {
  available: boolean;
  state: "configured" | "not_configured";
  sourceLabel: string;
  message: string;
  disclosure: string;
};

export const FITZPATRICK_DISCLOSURE = "Optional cosmetic skin-tone profile only. It is not an ethnicity inference. It is not a medical diagnosis, UV-risk assessment, or sunscreen recommendation.";

export function normalizeFitzpatrickType(value: unknown): FitzpatrickType | null {
  const candidate = String(value || "").trim().toUpperCase().replace(/^TYPE\s*/, "");
  return (FITZPATRICK_TYPES as readonly string[]).includes(candidate) ? candidate as FitzpatrickType : null;
}

/** Accepts only an explicit provider-returned type; it never derives a type from a local selfie. */
export function normalizeProviderFitzpatrickProfile(value: unknown, providerLabel = "Live provider"): FitzpatrickProfile | null {
  if (!value || typeof value !== "object") return null;
  const source = value as Record<string, unknown>;
  const type = normalizeFitzpatrickType(source.type ?? source.fitzpatrick_type ?? source.fitzpatrickType ?? source.result);
  return type ? { type, source: "provider", analyzedAt: new Date().toISOString(), providerLabel } : null;
}
