export const AI_SHOES_RENDER_STYLES = [
  "random", "style_minimalist", "style_bohemian", "style_cottagecore", "style_french_elegance", "style_retro_fashion",
] as const;
export type AiShoesRenderStyle = typeof AI_SHOES_RENDER_STYLES[number];

/** Provider-required rendering parameter. It is always explicitly selected and never inferred from the image or stored as identity data. */
export const AI_SHOES_RENDERING_SETTINGS = ["female", "male"] as const;
export type AiShoesRenderingSetting = typeof AI_SHOES_RENDERING_SETTINGS[number];

export type AiShoesTryOnResult = {
  resultUrl: string;
  style: AiShoesRenderStyle;
  renderingSetting: AiShoesRenderingSetting;
  source: "provider";
  expiresInHours: 2;
  analyzedAt: string;
};

export const AI_SHOES_TRYON_DISCLOSURE = "Creative shoe virtual try-on visualization only. It is not a fit, size, comfort, availability, purchase, body-measurement, identity, or gender assessment. Your target photo and shoe reference are used only after you select them. The provider-required rendering setting is selected by you for rendering only; ClosetAI never infers it from an image or stores it as identity data. Results are temporary and not saved to history. No stock model or fallback image will be shown.";

export function normalizeAiShoesRenderStyle(value: unknown): AiShoesRenderStyle | null {
  return typeof value === "string" && (AI_SHOES_RENDER_STYLES as readonly string[]).includes(value)
    ? value as AiShoesRenderStyle
    : null;
}

export function normalizeAiShoesRenderingSetting(value: unknown): AiShoesRenderingSetting | null {
  return typeof value === "string" && (AI_SHOES_RENDERING_SETTINGS as readonly string[]).includes(value)
    ? value as AiShoesRenderingSetting
    : null;
}

/** Returns only a temporary secure provider result and user-selected documented rendering controls. */
export function normalizeProviderAiShoesTryOn(value: unknown, style: unknown, renderingSetting: unknown): AiShoesTryOnResult | null {
  const normalizedStyle = normalizeAiShoesRenderStyle(style);
  const normalizedRenderingSetting = normalizeAiShoesRenderingSetting(renderingSetting);
  if (!normalizedStyle || !normalizedRenderingSetting || !value || typeof value !== "object") return null;
  const raw = value as Record<string, unknown>;
  const candidates = [raw.url, (raw.data as Record<string, unknown> | undefined)?.url, (raw.results as Record<string, unknown> | undefined)?.url];
  const resultUrl = candidates.find((candidate): candidate is string => typeof candidate === "string" && /^https:\/\//.test(candidate));
  return resultUrl ? { resultUrl, style: normalizedStyle, renderingSetting: normalizedRenderingSetting, source: "provider", expiresInHours: 2, analyzedAt: new Date().toISOString() } : null;
}
