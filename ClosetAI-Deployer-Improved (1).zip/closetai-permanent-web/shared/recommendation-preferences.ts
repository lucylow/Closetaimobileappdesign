export type RecommendationPreferences = {
  occasion?: string;
  weather?: string;
  colorPalette?: string[];
};

const MAX_TEXT_LENGTH = 80;
const MAX_COLORS = 6;

function cleanText(value: unknown): string | undefined {
  if (typeof value !== "string") return undefined;
  const cleaned = value.replace(/\s+/g, " ").trim().slice(0, MAX_TEXT_LENGTH);
  return cleaned || undefined;
}

export function normalizeRecommendationPreferences(input: unknown): RecommendationPreferences {
  const record = input && typeof input === "object" ? input as Record<string, unknown> : {};
  const colors = Array.isArray(record.colorPalette)
    ? record.colorPalette
      .map(cleanText)
      .filter((color): color is string => Boolean(color))
      .filter((color, index, values) => values.findIndex((value) => value.toLowerCase() === color.toLowerCase()) === index)
      .slice(0, MAX_COLORS)
    : [];
  return {
    occasion: cleanText(record.occasion),
    weather: cleanText(record.weather),
    colorPalette: colors,
  };
}

export function colorMatchesPalette(color: string | null | undefined, palette?: string[]): boolean {
  if (!color || !palette?.length) return false;
  const normalizedColor = color.toLowerCase();
  return palette.some((preference) => normalizedColor.includes(preference.toLowerCase()) || preference.toLowerCase().includes(normalizedColor));
}
