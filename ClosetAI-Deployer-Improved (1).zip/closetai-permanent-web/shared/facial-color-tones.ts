export const FACE_ANGLE_STRICTNESS_LEVELS = ["strict", "high", "medium", "low", "flexible"] as const;
export type FaceAngleStrictness = (typeof FACE_ANGLE_STRICTNESS_LEVELS)[number];

export type FacialColorTones = {
  skinColor: string;
  eyeColor: string;
  eyeColorName?: "Amber" | "Brown" | "Green" | "Blue" | "Gray" | "Other";
  lipColor: string;
  eyebrowColor: string;
  hairColor: string;
  hairColorName?: "Auburn" | "Black" | "Blonde" | "Brown" | "Grey/White" | "Red";
  source: "provider";
  analyzedAt: string;
};

export const FACIAL_COLOR_TONES_DISCLOSURE = "Cosmetic color-tone values from a selected selfie only. They are not an ethnicity, identity, health, or suitability assessment, and no result is fabricated when live analysis is unavailable.";

function normalizeHex(value: unknown): string | null {
  const candidate = String(value || "").trim();
  const normalized = candidate.startsWith("#") ? candidate : `#${candidate}`;
  return /^#[0-9a-fA-F]{6}$/.test(normalized) ? normalized.toUpperCase() : null;
}

function normalizeNamedValue<T extends readonly string[]>(value: unknown, allowed: T): T[number] | undefined {
  const candidate = String(value || "").trim().toLowerCase();
  return allowed.find((entry) => entry.toLowerCase() === candidate) as T[number] | undefined;
}

/** Only explicit provider-returned color fields are accepted; no local color extraction is performed. */
export function normalizeProviderFacialColorTones(value: unknown): FacialColorTones | null {
  if (!value || typeof value !== "object") return null;
  const raw = value as Record<string, unknown>;
  const skinColor = normalizeHex(raw.skin_color ?? raw.skinColor);
  const eyeColor = normalizeHex(raw.eye_color ?? raw.eyeColor);
  const lipColor = normalizeHex(raw.lip_color ?? raw.lipColor);
  const eyebrowColor = normalizeHex(raw.eyebrow_color ?? raw.eyebrowColor);
  const hairColor = normalizeHex(raw.hair_color ?? raw.hairColor);
  if (!skinColor || !eyeColor || !lipColor || !eyebrowColor || !hairColor) return null;
  return {
    skinColor, eyeColor, lipColor, eyebrowColor, hairColor,
    eyeColorName: normalizeNamedValue(raw.eye_color_name ?? raw.eyeColorName, ["Amber", "Brown", "Green", "Blue", "Gray", "Other"] as const),
    hairColorName: normalizeNamedValue(raw.hair_color_name ?? raw.hairColorName, ["Auburn", "Black", "Blonde", "Brown", "Grey/White", "Red"] as const),
    source: "provider",
    analyzedAt: new Date().toISOString(),
  };
}

export function normalizeFaceAngleStrictness(value: unknown): FaceAngleStrictness {
  const candidate = String(value || "high").trim().toLowerCase();
  return (FACE_ANGLE_STRICTNESS_LEVELS as readonly string[]).includes(candidate) ? candidate as FaceAngleStrictness : "high";
}
