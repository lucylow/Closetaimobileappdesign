import { getFashionTryOnCategory, normalizeFashionTryOnCategory } from "./fashion-tryon-categories";
import type { RecommendationPreferences } from "./recommendation-preferences";
import { normalizePersonalStyleProfile, type PersonalStyleProfile } from "./personal-style-profile";

export type RetailWardrobeItem = { id: string; name: string; category: string; color?: string | null; tags?: string[] | null };
export type RetailRecommendation = {
  id: string;
  title: string;
  reason: string;
  searchQuery: string;
  searchUrl: string;
  category: string;
  source: "retailer-search";
};

function searchUrl(query: string): string {
  return `https://www.google.com/search?tbm=shop&q=${encodeURIComponent(query)}`;
}

function makeRecommendation(id: string, title: string, reason: string, query: string, category: string): RetailRecommendation {
  return { id, title, reason, searchQuery: query, searchUrl: searchUrl(query), category, source: "retailer-search" };
}

/**
 * Suggests open retailer searches for genuine gaps in the user's wardrobe. It never creates a
 * fictional stock item, retailer, price, discount, or affiliate claim.
 */
export function buildRetailRecommendations(items: RetailWardrobeItem[], preferences: RecommendationPreferences, profile?: PersonalStyleProfile | null): RetailRecommendation[] {
  const categories = new Set(items.map((item) => normalizeFashionTryOnCategory(item.category) || item.category.toLowerCase()));
  const normalizedProfile = normalizePersonalStyleProfile(profile);
  const palette = preferences.colorPalette?.[0] || normalizedProfile.colors[0] || "versatile";
  const weather = preferences.weather?.toLowerCase() || "";
  const occasion = preferences.occasion || "everyday";
  const recommendations: RetailRecommendation[] = [];
  const weatherNeedsLayer = /(cold|cool|rain|snow|wind|wet)/.test(weather);
  const weatherNeedsAccessories = /(rain|snow|wind|cold)/.test(weather);

  if (weatherNeedsLayer && !categories.has("outerwear")) {
    recommendations.push(makeRecommendation("outerwear-gap", "Weather-ready outer layer", `Your wardrobe has no outerwear while the selected weather calls for layering.`, `${palette} ${occasion} weather-ready jacket`, "outerwear"));
  }
  if (!categories.has("shoes")) {
    recommendations.push(makeRecommendation("shoe-gap", "Versatile footwear", "Add a footwear option to complete recommendations built from your current wardrobe.", `${palette} versatile ${occasion} shoes`, "shoes"));
  }
  if (!categories.has("bag")) {
    recommendations.push(makeRecommendation("bag-gap", "Everyday bag", "A bag is not currently represented in your wardrobe, so this search targets a practical finishing piece.", `${palette} ${occasion} bag`, "bag"));
  }
  if (!categories.has("jewelry") && /(office|business|date|party)/i.test(occasion)) {
    recommendations.push(makeRecommendation("watch-gap", "Versatile watch", "Your selected occasion benefits from a concise finishing detail, and no watch or jewelry item is currently in your wardrobe.", `${palette} ${occasion} watch`, "jewelry"));
  }
  if (weatherNeedsAccessories && !categories.has("hat") && !categories.has("jewelry")) {
    const accessory = /(wind|cold|snow)/.test(weather) ? "scarf" : "hat";
    recommendations.push(makeRecommendation("weather-accessory-gap", `Weather-ready ${accessory}`, `The selected weather suggests a protective accessory, and none is currently in your wardrobe.`, `${palette} ${accessory} ${occasion}`, accessory === "scarf" ? "jewelry" : "hat"));
  }
  if (recommendations.length === 0) {
    const selectedCategory = items.map((item) => getFashionTryOnCategory(item.category)?.label).find(Boolean) || "wardrobe";
    recommendations.push(makeRecommendation("style-refresh", "Optional style refresh", `Your selected filters already have wardrobe coverage. This is an optional open search based on your ${selectedCategory.toLowerCase()} pieces.`, `${palette} ${occasion} accessory`, "accessories"));
  }
  return recommendations.slice(0, 3);
}
