export type SavedYouCamSnapshot = {
  id: string;
  source: string;
  createdAt: string | Date;
  consentVersion?: string | null;
  styleInsights?: unknown;
};

export type YouCamRecommendationContext = {
  source: "youcam-skin-snapshot";
  snapshotId: string;
  createdAt: string;
  colorFamilies: string[];
  styleNotes: string[];
};

function cleanText(value: unknown, maxLength: number): string | null {
  if (typeof value !== "string") return null;
  const normalized = value.replace(/\s+/g, " ").trim();
  return normalized ? normalized.slice(0, maxLength) : null;
}

/**
 * Produces fashion-only context from a saved, live YouCam snapshot. It deliberately excludes
 * biometric scores, face masks, skin age, diagnoses, and the original image. The caller must
 * label this as YouCam-derived styling context, not a recommendation directly issued by YouCam.
 */
export function buildYouCamRecommendationContext(snapshot?: SavedYouCamSnapshot | null): YouCamRecommendationContext | null {
  if (!snapshot || snapshot.source !== "youcam") return null;
  const insights = Array.isArray(snapshot.styleInsights) ? snapshot.styleInsights : [];
  const colorFamilies = new Set<string>();
  const styleNotes: string[] = [];

  for (const insight of insights) {
    if (!insight || typeof insight !== "object") continue;
    const record = insight as { title?: unknown; detail?: unknown; colorFamilies?: unknown };
    if (Array.isArray(record.colorFamilies)) {
      for (const color of record.colorFamilies) {
        const cleanColor = cleanText(color, 32);
        if (cleanColor) colorFamilies.add(cleanColor);
      }
    }
    const title = cleanText(record.title, 60);
    const detail = cleanText(record.detail, 180);
    if (title && detail) styleNotes.push(`${title}: ${detail}`);
    else if (detail) styleNotes.push(detail);
  }

  if (colorFamilies.size === 0 && styleNotes.length === 0) return null;
  return {
    source: "youcam-skin-snapshot",
    snapshotId: snapshot.id,
    createdAt: new Date(snapshot.createdAt).toISOString(),
    colorFamilies: [...colorFamilies].slice(0, 6),
    styleNotes: styleNotes.slice(0, 2),
  };
}
