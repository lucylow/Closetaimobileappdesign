import { FASHION_TRY_ON_CATEGORIES, getFashionTryOnCategory } from "@shared/fashion-tryon-categories";

export const YOUCAM_USER_PHOTO_GUARANTEE = "ClosetAI only uses the photo you select for try-on and never substitutes a stock model image.";

export type YouCamFashionMode = "live-ready" | "needs-garment-reference" | "assisted-edit" | "provider-unavailable" | "selection-needed";

export type YouCamFashionCapability = {
  configured: boolean;
  provider: "youcam-ai-clothes-v4";
  liveCategoryIds: string[];
  assistedCategoryIds: string[];
  requirements: string[];
  userPhotoOnly: true;
  resultCacheMinutes: number;
  maxImageBytes: number;
};

export type FashionSelectionInput = { id: string; category?: string; imageUrl?: string };
export type YouCamFashionReadiness = {
  mode: YouCamFashionMode;
  headline: string;
  detail: string;
  liveEligibleItemIds: string[];
  assistedItemIds: string[];
  missingReferenceItemIds: string[];
  checklist: string[];
};

export function buildYouCamFashionCapability(configured: boolean): YouCamFashionCapability {
  return {
    configured,
    provider: "youcam-ai-clothes-v4",
    liveCategoryIds: FASHION_TRY_ON_CATEGORIES.filter((entry) => entry.provider === "youcam-clothes").map((entry) => entry.id),
    assistedCategoryIds: FASHION_TRY_ON_CATEGORIES.filter((entry) => entry.provider === "image-edit").map((entry) => entry.id),
    requirements: ["a user-selected photo", "one selected wardrobe item with a public garment image for AI Clothes v4"],
    userPhotoOnly: true,
    resultCacheMinutes: 10,
    maxImageBytes: 10 * 1024 * 1024,
  };
}

function isStringArray(value: unknown): value is string[] {
  return Array.isArray(value) && value.every((entry) => typeof entry === "string");
}

export function normalizeYouCamFashionCapability(value: unknown): YouCamFashionCapability | null {
  if (!value || typeof value !== "object") return null;
  const capability = value as Record<string, unknown>;
  if (
    typeof capability.configured !== "boolean"
    || capability.provider !== "youcam-ai-clothes-v4"
    || !isStringArray(capability.liveCategoryIds)
    || !isStringArray(capability.assistedCategoryIds)
    || !isStringArray(capability.requirements)
    || capability.userPhotoOnly !== true
    || typeof capability.resultCacheMinutes !== "number"
    || !Number.isFinite(capability.resultCacheMinutes)
    || capability.resultCacheMinutes < 0
    || typeof capability.maxImageBytes !== "number"
    || !Number.isFinite(capability.maxImageBytes)
    || capability.maxImageBytes <= 0
  ) {
    return null;
  }
  return {
    configured: capability.configured,
    provider: capability.provider,
    liveCategoryIds: capability.liveCategoryIds,
    assistedCategoryIds: capability.assistedCategoryIds,
    requirements: capability.requirements,
    userPhotoOnly: capability.userPhotoOnly,
    resultCacheMinutes: capability.resultCacheMinutes,
    maxImageBytes: capability.maxImageBytes,
  };
}

export function buildYouCamFashionReadiness(input: { configured: boolean; selectedItems: FashionSelectionInput[] }): YouCamFashionReadiness {
  const selectedItems = input.selectedItems;
  if (selectedItems.length === 0) {
    return { mode: "selection-needed", headline: "Select a wardrobe item", detail: "Choose an item to see whether it can use YouCam AI Clothes or the user-photo-safe assisted path.", liveEligibleItemIds: [], assistedItemIds: [], missingReferenceItemIds: [], checklist: ["Add your photo", "Select a wardrobe item"] };
  }
  const liveEligible = selectedItems.filter((item) => getFashionTryOnCategory(item.category)?.provider === "youcam-clothes");
  const liveReady = liveEligible.filter((item) => /^https?:\/\//i.test(item.imageUrl || ""));
  const assisted = selectedItems.filter((item) => getFashionTryOnCategory(item.category)?.provider === "image-edit");
  const missingReference = liveEligible.filter((item) => !/^https?:\/\//i.test(item.imageUrl || ""));
  if (!input.configured) {
    return { mode: "provider-unavailable", headline: "Photo-safe preview is ready", detail: "YouCam AI Clothes is not configured for this session. ClosetAI will preserve your selected photo and describe the chosen garments instead of substituting another person.", liveEligibleItemIds: liveEligible.map((item) => item.id), assistedItemIds: assisted.map((item) => item.id), missingReferenceItemIds: missingReference.map((item) => item.id), checklist: ["Your selected photo is required", "Live AI availability will be checked again next session"] };
  }
  if (liveReady.length > 0) {
    return { mode: "live-ready", headline: "YouCam AI Clothes is ready", detail: "A selected clothing item has a public garment image and an AI Clothes-compatible category. The final result will use your selected photo.", liveEligibleItemIds: liveReady.map((item) => item.id), assistedItemIds: assisted.map((item) => item.id), missingReferenceItemIds: missingReference.map((item) => item.id), checklist: ["Your photo selected", "Public garment reference found", "AI Clothes-compatible category"] };
  }
  if (assisted.length > 0 && missingReference.length === 0) {
    return { mode: "assisted-edit", headline: "Accessory-aware assisted path", detail: "The selected accessory category has no dedicated AI Clothes region. ClosetAI can attempt its secondary user-photo-only edit path, with a clearly labeled preview if no live result is returned.", liveEligibleItemIds: [], assistedItemIds: assisted.map((item) => item.id), missingReferenceItemIds: [], checklist: ["Your photo selected", "Accessory category selected", "No stock model substitution"] };
  }
  return { mode: "needs-garment-reference", headline: "Add a garment reference to unlock YouCam", detail: "This clothing category supports AI Clothes, but no selected item has a public garment image yet. ClosetAI will keep your uploaded photo as the safe fallback preview.", liveEligibleItemIds: liveEligible.map((item) => item.id), assistedItemIds: assisted.map((item) => item.id), missingReferenceItemIds: missingReference.map((item) => item.id), checklist: ["Your photo selected", "AI Clothes category selected", "Public garment image still needed"] };
}
