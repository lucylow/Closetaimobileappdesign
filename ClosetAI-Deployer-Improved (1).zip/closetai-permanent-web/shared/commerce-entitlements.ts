export interface CreditPack {
  id: string;
  name: string;
  credits: number;
  priceUSD: number;
  tagline: string;
}

export const COMMERCE_CREDIT_PACKS: CreditPack[] = [
  {
    id: "pack_starter",
    name: "Starter Credit Pack",
    credits: 100,
    priceUSD: 4.99,
    tagline: "100 AI search & price-watch credits",
  },
  {
    id: "pack_pro",
    name: "Pro Creator Pack",
    credits: 500,
    priceUSD: 14.99,
    tagline: "500 credits for advanced agent workflows",
  },
  {
    id: "pack_vip",
    name: "VIP Power Pack",
    credits: 1500,
    priceUSD: 29.99,
    tagline: "1,500 priority credits with unlimited search dispatch",
  },
];

export interface MonetizationFunnelEvent {
  eventName: string;
  timestamp: string;
  tierId: string;
  metadata?: Record<string, any>;
}
