export type SkinAnalysisQualityTier = "sd" | "hd";

export type SkinAnalysisAction =
  | "moisture" | "oiliness" | "redness" | "radiance" | "pore" | "texture" | "acne" | "age_spot" | "wrinkle" | "skin_type"
  | "hd_moisture" | "hd_oiliness" | "hd_redness" | "hd_radiance" | "hd_pore" | "hd_texture" | "hd_acne" | "hd_age_spot" | "hd_wrinkle" | "hd_skin_type";

export type SkinAnalysisPlan = {
  tier: SkinAnalysisQualityTier;
  actions: SkinAnalysisAction[];
  requestMaskOverlay: boolean;
  outputFormat: "json";
};

const SD_ACTIONS: SkinAnalysisAction[] = ["moisture", "oiliness", "redness", "radiance", "pore", "texture", "acne", "age_spot", "wrinkle", "skin_type"];
const HD_ACTIONS: SkinAnalysisAction[] = ["hd_moisture", "hd_oiliness", "hd_redness", "hd_radiance", "hd_pore", "hd_texture", "hd_acne", "hd_age_spot", "hd_wrinkle", "hd_skin_type"];

/**
 * Builds a valid provider action set. SD and HD actions are never combined because the provider
 * rejects mixed tiers. Detection-mask URLs are not requested by default because ClosetAI renders
 * normalized scores and does not retain selfie-derived visual artifacts.
 */
export function buildSkinAnalysisPlan(tier: SkinAnalysisQualityTier = "sd"): SkinAnalysisPlan {
  return {
    tier,
    actions: tier === "hd" ? [...HD_ACTIONS] : [...SD_ACTIONS],
    requestMaskOverlay: false,
    outputFormat: "json",
  };
}

export function isValidSkinAnalysisPlan(value: unknown): value is SkinAnalysisPlan {
  if (!value || typeof value !== "object") return false;
  const plan = value as Partial<SkinAnalysisPlan>;
  if (plan.tier !== "sd" && plan.tier !== "hd") return false;
  if (!Array.isArray(plan.actions) || plan.actions.length === 0 || plan.outputFormat !== "json") return false;
  const expected = plan.tier === "hd" ? HD_ACTIONS : SD_ACTIONS;
  return plan.actions.every((action) => expected.includes(action));
}

export function resolveSkinAnalysisPlan(value: unknown): SkinAnalysisPlan {
  if (!isValidSkinAnalysisPlan(value)) return buildSkinAnalysisPlan();
  return {
    tier: value.tier,
    actions: [...new Set(value.actions)],
    requestMaskOverlay: value.requestMaskOverlay === true,
    outputFormat: "json",
  };
}
