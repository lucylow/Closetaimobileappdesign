import { normalizeFashionTryOnCategory } from "./fashion-tryon-categories";

export type AnalyticsWardrobeItem = { id: string; category: string; usageCount?: number | null; lastWornAt?: string | null };
export type AnalyticsOutfit = { saved?: boolean | null };
export type AnalyticsSkinSnapshot = { source?: string | null };

export type ClosetAnalytics = {
  subscription: { tier: string; creditsUsed: number; monthlyCredits: number };
  wardrobe: { total: number; worn: number; utilizationPct: number; accessories: number };
  outfits: { total: number; saved: number };
  usage: { totalTryOns: number; avgPerItem: number };
  care: { savedSnapshots: number; liveSnapshots: number };
  commerce: { trackedSearches: number };
  categories: Record<string, number>;
};

export function buildClosetAnalytics(input: {
  items: AnalyticsWardrobeItem[];
  outfits: AnalyticsOutfit[];
  snapshots?: AnalyticsSkinSnapshot[];
  trackedSearches?: number;
  subscription?: { tier?: string | null; creditsUsed?: number | null; monthlyCredits?: number | null } | null;
}): ClosetAnalytics {
  const categories: Record<string, number> = {};
  let accessories = 0;
  let worn = 0;
  let totalTryOns = 0;
  for (const item of input.items) {
    const normalized = normalizeFashionTryOnCategory(item.category) || item.category.toLowerCase();
    categories[normalized] = (categories[normalized] || 0) + 1;
    if (["bag", "hat", "jewelry"].includes(normalized)) accessories += 1;
    const usage = Math.max(0, item.usageCount || 0);
    totalTryOns += usage;
    if (usage > 0 || item.lastWornAt) worn += 1;
  }
  const snapshotList = input.snapshots || [];
  const total = input.items.length;
  return {
    subscription: {
      tier: input.subscription?.tier || "free",
      creditsUsed: input.subscription?.creditsUsed || 0,
      monthlyCredits: input.subscription?.monthlyCredits || 25,
    },
    wardrobe: { total, worn, utilizationPct: total ? Math.round((worn / total) * 100) : 0, accessories },
    outfits: { total: input.outfits.length, saved: input.outfits.filter((outfit) => Boolean(outfit.saved)).length },
    usage: { totalTryOns, avgPerItem: total ? Math.round((totalTryOns / total) * 10) / 10 : 0 },
    care: { savedSnapshots: snapshotList.length, liveSnapshots: snapshotList.filter((snapshot) => snapshot.source === "youcam").length },
    commerce: { trackedSearches: Math.max(0, input.trackedSearches || 0) },
    categories,
  };
}
