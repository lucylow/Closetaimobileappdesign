export const FASHION_TRY_ON_CATEGORIES = [
  { id: "top", label: "Tops", icon: "shirt-outline", provider: "youcam-clothes", garmentCategory: "upper_body" },
  { id: "bottom", label: "Bottoms", icon: "body-outline", provider: "youcam-clothes", garmentCategory: "lower_body" },
  { id: "dress", label: "Dresses", icon: "woman-outline", provider: "youcam-clothes", garmentCategory: "full_body" },
  { id: "outerwear", label: "Outerwear", icon: "cloudy-outline", provider: "youcam-clothes", garmentCategory: "outerwear" },
  { id: "shoes", label: "Shoes", icon: "footsteps-outline", provider: "youcam-clothes", garmentCategory: "shoes" },
  { id: "activewear", label: "Activewear", icon: "fitness-outline", provider: "youcam-clothes", garmentCategory: "auto" },
  { id: "swimwear", label: "Swimwear", icon: "water-outline", provider: "youcam-clothes", garmentCategory: "full_body" },
  { id: "bag", label: "Bags", icon: "bag-outline", provider: "image-edit", garmentCategory: "auto" },
  { id: "hat", label: "Hats", icon: "sunny-outline", provider: "image-edit", garmentCategory: "auto" },
  { id: "jewelry", label: "Jewelry, Watches & Scarves", icon: "diamond-outline", provider: "image-edit", garmentCategory: "auto" },
] as const;

export type FashionTryOnCategoryId = (typeof FASHION_TRY_ON_CATEGORIES)[number]["id"];
export type FashionTryOnProvider = (typeof FASHION_TRY_ON_CATEGORIES)[number]["provider"];
export type FashionGarmentCategory = (typeof FASHION_TRY_ON_CATEGORIES)[number]["garmentCategory"];

const LEGACY_CATEGORY_ALIASES: Record<string, FashionTryOnCategoryId> = {
  tops: "top",
  shirt: "top",
  blouse: "top",
  sweater: "top",
  bottoms: "bottom",
  pants: "bottom",
  jeans: "bottom",
  skirt: "bottom",
  dresses: "dress",
  jacket: "outerwear",
  coat: "outerwear",
  accessories: "jewelry",
  bags: "bag",
  hats: "hat",
  scarf: "jewelry",
  scarves: "jewelry",
  watch: "jewelry",
  watches: "jewelry",
};

export function normalizeFashionTryOnCategory(category?: string): FashionTryOnCategoryId | undefined {
  if (!category) return undefined;
  const normalized = category.trim().toLowerCase();
  const direct = FASHION_TRY_ON_CATEGORIES.find((entry) => entry.id === normalized);
  if (direct) return direct.id;
  if (LEGACY_CATEGORY_ALIASES[normalized]) return LEGACY_CATEGORY_ALIASES[normalized];
  if (/(shoe|boot|sneaker|sandal|heel|loafer)/.test(normalized)) return "shoes";
  if (/(jacket|coat|vest|blazer|outer)/.test(normalized)) return "outerwear";
  if (/(swim|bikini|one-piece)/.test(normalized)) return "swimwear";
  if (/(active|sport|gym|workout|athletic)/.test(normalized)) return "activewear";
  if (/(bag|tote|purse|backpack|clutch)/.test(normalized)) return "bag";
  if (/(hat|cap|beanie|visor)/.test(normalized)) return "hat";
  if (/(jewel|necklace|earring|bracelet|ring|watch|scarf|shawl)/.test(normalized)) return "jewelry";
  if (/(dress|jumpsuit|romper)/.test(normalized)) return "dress";
  if (/(pant|jean|skirt|short|trouser|legging|bottom)/.test(normalized)) return "bottom";
  if (/(top|shirt|blouse|sweater|tee|knit|hoodie)/.test(normalized)) return "top";
  return undefined;
}

export function getFashionTryOnCategory(category?: string) {
  const id = normalizeFashionTryOnCategory(category);
  return id ? FASHION_TRY_ON_CATEGORIES.find((entry) => entry.id === id) : undefined;
}
