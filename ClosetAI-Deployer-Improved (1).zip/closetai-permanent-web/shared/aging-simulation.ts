export type AgingPreview = {
  resultUrl: string;
  displayAge: number;
};

export type AgingSimulationResult = {
  previews: AgingPreview[];
  source: "provider";
  expiresInHours: 2;
  analyzedAt: string;
};

export const AGING_SIMULATION_DISCLOSURE = "Creative age-progression visualization only. It does not predict your future appearance, estimate your current age, diagnose health or skin conditions, or replace professional advice. Results use your selected photo only and are not saved to history.";

/**
 * Normalize only documented output URLs and target display ages. The provider's inferred `age`
 * field is intentionally excluded from the application model and UI.
 */
export function normalizeProviderAgingSimulation(value: unknown): AgingSimulationResult | null {
  if (!value || typeof value !== "object") return null;
  const raw = value as Record<string, unknown>;
  const output = Array.isArray(raw.output) ? raw.output : [];
  const previews = output.flatMap((item): AgingPreview[] => {
    if (!item || typeof item !== "object") return [];
    const entry = item as Record<string, unknown>;
    const resultUrl = typeof entry.url === "string" && /^https:\/\//.test(entry.url) ? entry.url : null;
    const displayAge = typeof entry.res_age === "number" && Number.isInteger(entry.res_age) && entry.res_age >= 0 && entry.res_age <= 120 ? entry.res_age : null;
    return resultUrl && displayAge !== null ? [{ resultUrl, displayAge }] : [];
  }).sort((left, right) => left.displayAge - right.displayAge);
  return previews.length ? { previews, source: "provider", expiresInHours: 2, analyzedAt: new Date().toISOString() } : null;
}
