export const ABS_FILTER_MODES = ["Six-pack", "Vest-line"] as const;
export type AbsFilterMode = typeof ABS_FILTER_MODES[number];

export const ABS_FILTER_INTENSITIES = [1, 2] as const;
export type AbsFilterIntensity = typeof ABS_FILTER_INTENSITIES[number];

export type AbsFilterSimulationResult = {
  resultUrl: string;
  mode: AbsFilterMode;
  intensity: AbsFilterIntensity;
  source: "provider";
  expiresInHours: 2;
  analyzedAt: string;
};

export const ABS_FILTER_SIMULATION_DISCLOSURE = "Adult-only cosmetic abdominal photo visualization. It is not medical advice, a health or fitness assessment, body-fat or anatomy measurement, diagnosis, treatment plan, attractiveness rating, or promise of an actual outcome. Use a clothed photo you selected yourself. The temporary result is not saved to history, and no stock or fallback image will be shown.";

export function normalizeAbsFilterMode(value: unknown): AbsFilterMode | null {
  return typeof value === "string" && (ABS_FILTER_MODES as readonly string[]).includes(value)
    ? value as AbsFilterMode
    : null;
}

export function normalizeAbsFilterIntensity(value: unknown): AbsFilterIntensity | null {
  return typeof value === "number" && ABS_FILTER_INTENSITIES.includes(value as AbsFilterIntensity)
    ? value as AbsFilterIntensity
    : null;
}

/** Reduces provider output to the selected documented controls and a verified temporary HTTPS URL. */
export function normalizeProviderAbsFilterSimulation(value: unknown, mode: unknown, intensity: unknown): AbsFilterSimulationResult | null {
  const normalizedMode = normalizeAbsFilterMode(mode);
  const normalizedIntensity = normalizeAbsFilterIntensity(intensity);
  if (!normalizedMode || !normalizedIntensity || !value || typeof value !== "object") return null;
  const raw = value as Record<string, unknown>;
  const candidates = [raw.url, (raw.data as Record<string, unknown> | undefined)?.url, (raw.results as Record<string, unknown> | undefined)?.url];
  const resultUrl = candidates.find((candidate): candidate is string => typeof candidate === "string" && /^https:\/\//.test(candidate));
  return resultUrl ? { resultUrl, mode: normalizedMode, intensity: normalizedIntensity, source: "provider", expiresInHours: 2, analyzedAt: new Date().toISOString() } : null;
}
