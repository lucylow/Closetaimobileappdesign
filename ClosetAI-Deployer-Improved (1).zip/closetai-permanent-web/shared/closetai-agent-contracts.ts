export const CLOSET_AGENT_IDS = ["fashion", "skincare"] as const;
export type ClosetAgentId = (typeof CLOSET_AGENT_IDS)[number];

export const AGENT_RESPONSE_MODES = ["live_model", "local_fallback", "fictional_demo"] as const;
export type AgentResponseMode = (typeof AGENT_RESPONSE_MODES)[number];

export const AGENT_CONTEXT_SOURCES = [
  "selected_preferences",
  "local_wardrobe",
  "saved_normalized_skin_summary",
  "fictional_demo",
  "external_category_reference",
] as const;
export type AgentContextSource = (typeof AGENT_CONTEXT_SOURCES)[number];

export const FASHION_AGENT_DISCLOSURE =
  "ClosetAI Fashion Look Planner offers styling ideas from the context you selected. It does not verify fit, price, stock, ownership, availability, or purchase eligibility, and it cannot buy, reserve, or contact a store.";

export const SKINCARE_AGENT_DISCLOSURE =
  "ClosetAI Skin Routine Companion offers general cosmetic-routine organization only. It is not a medical diagnosis, treatment plan, product-suitability decision, formula simulation, or outcome prediction. Check current product labels and consult a qualified clinician for consequential concerns.";

export interface ClosetAgentStep {
  id: string;
  title: string;
  detail: string;
  kind: "style" | "routine" | "browse" | "boundary";
}

export interface ClosetAgentCategoryReference {
  id: string;
  label: string;
  category: string;
  sourceLabel: string;
}

export interface ClosetAgentPlan {
  requestId: string;
  agent: ClosetAgentId;
  mode: AgentResponseMode;
  title: string;
  summary: string;
  steps: ClosetAgentStep[];
  selectedWardrobeItemIds: string[];
  categoryReferences: ClosetAgentCategoryReference[];
  contextSources: AgentContextSource[];
  disclosure: string;
  usedFallback: boolean;
  validationFlags: string[];
}

export interface FashionAgentRequest {
  agent: "fashion";
  prompt?: string;
  occasion?: string;
  palette?: string;
  demoMode?: boolean;
}

export interface SkincareAgentRequest {
  agent: "skincare";
  prompt?: string;
  routineTime?: "AM" | "PM" | "AM_PM";
  skincareGoal?: "comfort" | "hydration" | "radiance" | "texture_appearance" | "simple_routine";
  includeLatestNormalizedSummary?: boolean;
  demoMode?: boolean;
}

export type ClosetAgentRequest = FashionAgentRequest | SkincareAgentRequest;

export const AGENT_BLOCKED_LANGUAGE = [
  "diagnose",
  "diagnosis",
  "treat",
  "treatment",
  "cure",
  "prescription",
  "medical condition",
  "you have",
  "guarantee",
  "will improve",
  "clinically proven",
  "suitable for you",
  "buy now",
  "checkout",
  "in stock",
  "out of stock",
  "price",
  "reserve",
] as const;

export function isClosetAgentId(value: unknown): value is ClosetAgentId {
  return typeof value === "string" && (CLOSET_AGENT_IDS as readonly string[]).includes(value);
}

export function agentDisclosure(agent: ClosetAgentId): string {
  return agent === "fashion" ? FASHION_AGENT_DISCLOSURE : SKINCARE_AGENT_DISCLOSURE;
}
