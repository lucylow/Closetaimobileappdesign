export const FACE_LIFT_FEATURE_KEYS = ["eye_bag", "cheek", "forehead", "shape", "mouth"] as const;
export type FaceLiftFeatureKey = typeof FACE_LIFT_FEATURE_KEYS[number];
export type FaceLiftFeatures = Record<FaceLiftFeatureKey, number>;

export type FaceLiftSimulationResult = {
  resultUrl: string;
  features: FaceLiftFeatures;
  source: "provider";
  expiresInHours: 2;
  analyzedAt: string;
};

export const FACE_LIFT_SIMULATION_DISCLOSURE = "Cosmetic face-photo visualization only. It is not medical advice, a diagnosis, a surgical plan, a prediction, or an assessment of age, identity, attractiveness, or facial proportions. Results use your selected photo only, are temporary, and are not saved to history. No stock or fallback image will be shown.";

export const EMPTY_FACE_LIFT_FEATURES: FaceLiftFeatures = { eye_bag: 0, cheek: 0, forehead: 0, shape: 0, mouth: 0 };

function normalizeFeatureValue(value: unknown): number | null {
  return typeof value === "number" && Number.isInteger(value) && value >= 0 && value <= 100 ? value : null;
}

/** Normalizes the documented custom controls; an all-zero face-lift request is invalid. */
export function normalizeFaceLiftFeatures(value: unknown): FaceLiftFeatures | null {
  if (!value || typeof value !== "object") return null;
  const raw = value as Record<string, unknown>;
  const entries: Partial<FaceLiftFeatures> = {};
  for (const key of FACE_LIFT_FEATURE_KEYS) {
    const normalized = normalizeFeatureValue(raw[key]);
    if (normalized === null) return null;
    entries[key] = normalized;
  }
  const features = entries as FaceLiftFeatures;
  return Object.values(features).some((feature) => feature > 0) ? features : null;
}

/** Exposes only a secure, temporary provider-rendered output URL plus the user-selected controls. */
export function normalizeProviderFaceLiftSimulation(value: unknown, features: FaceLiftFeatures): FaceLiftSimulationResult | null {
  if (!value || typeof value !== "object") return null;
  const raw = value as Record<string, unknown>;
  const candidates = [raw.url, (raw.data as Record<string, unknown> | undefined)?.url, (raw.results as Record<string, unknown> | undefined)?.url];
  const resultUrl = candidates.find((candidate): candidate is string => typeof candidate === "string" && /^https:\/\//.test(candidate));
  return resultUrl ? { resultUrl, features, source: "provider", expiresInHours: 2, analyzedAt: new Date().toISOString() } : null;
}
