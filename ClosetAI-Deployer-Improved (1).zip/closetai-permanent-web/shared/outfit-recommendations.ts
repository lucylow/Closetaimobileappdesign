import { colorMatchesPalette } from "./recommendation-preferences";

export type RecommendationItem = {
  id: string;
  name: string;
  category: string;
  color?: string | null;
  tags?: string[] | null;
  usageCount?: number | null;
  lastWornAt?: string | Date | null;
};

export type WardrobeRecommendation = {
  name: string;
  itemIds: string[];
  occasion: string;
  tags: string[];
  reason: string;
  score: number;
};

const MAX_RECOMMENDATIONS = 3;

function normalizedCategory(category: string): string {
  const value = category.toLowerCase();
  if (/(dress|jumpsuit|romper)/.test(value)) return "dress";
  if (/(top|shirt|tee|blouse|sweater|hoodie|knit)/.test(value)) return "top";
  if (/(bottom|pant|jean|skirt|short|trouser|legging)/.test(value)) return "bottom";
  if (/(outer|jacket|coat|blazer|vest)/.test(value)) return "outerwear";
  if (/(shoe|boot|sneaker|sandal|heel|loafer)/.test(value)) return "shoes";
  return "accessories";
}

function stableWardrobeOrder(items: RecommendationItem[], colorPalette?: string[]): RecommendationItem[] {
  return [...items].sort((left, right) => {
    const leftPaletteMatch = colorMatchesPalette(left.color, colorPalette) ? 1 : 0;
    const rightPaletteMatch = colorMatchesPalette(right.color, colorPalette) ? 1 : 0;
    if (leftPaletteMatch !== rightPaletteMatch) return rightPaletteMatch - leftPaletteMatch;
    const usageDelta = (left.usageCount || 0) - (right.usageCount || 0);
    if (usageDelta !== 0) return usageDelta;
    const leftWorn = left.lastWornAt ? new Date(left.lastWornAt).getTime() : 0;
    const rightWorn = right.lastWornAt ? new Date(right.lastWornAt).getTime() : 0;
    if (leftWorn !== rightWorn) return leftWorn - rightWorn;
    return left.name.localeCompare(right.name);
  });
}

function uniqueItems(items: Array<RecommendationItem | undefined>): RecommendationItem[] {
  const selected = new Map<string, RecommendationItem>();
  for (const item of items) {
    if (item && !selected.has(item.id)) selected.set(item.id, item);
  }
  return [...selected.values()];
}

function pickAlternative(items: RecommendationItem[], current: RecommendationItem | undefined, offset: number): RecommendationItem | undefined {
  if (items.length === 0) return undefined;
  const index = Math.min(offset, items.length - 1);
  return items[index] || current || items[0];
}

function contextTags(items: RecommendationItem[], occasion: string, weather?: string, colorPalette?: string[]): string[] {
  const tags = items.flatMap((item) => item.tags || []).filter(Boolean);
  return [...new Set([occasion.toLowerCase(), ...(weather ? [weather.toLowerCase()] : []), ...(colorPalette || []).map((color) => `palette:${color.toLowerCase()}`), ...tags])].slice(0, 5);
}

function makeRecommendation(items: Array<RecommendationItem | undefined>, occasion: string, weather?: string, colorPalette?: string[]): WardrobeRecommendation | null {
  const unique = uniqueItems(items);
  if (unique.length < 2) return null;
  const itemNames = unique.map((item) => item.name);
  const colorNames = [...new Set(unique.map((item) => item.color).filter(Boolean))];
  const colorPhrase = colorNames.length > 0 ? ` with ${colorNames.join(" and ")} tones` : "";
  const weatherPhrase = weather ? ` for ${weather}` : "";
  return {
    name: `${itemNames.slice(0, 2).join(" + ")} edit`,
    itemIds: unique.map((item) => item.id).slice(0, 4),
    occasion,
    tags: contextTags(unique, occasion, weather, colorPalette),
    reason: `Built from ${itemNames.join(", ")} in your wardrobe${colorPhrase}.`,
    score: Math.min(0.92, 0.68 + unique.length * 0.06),
  };
}

/**
 * Builds compact, explainable fallbacks from the caller's actual wardrobe. This function never
 * introduces a catalog, stock garment, or pre-authored demo outfit.
 */
export function buildWardrobeRecommendations(
  inventory: RecommendationItem[],
  occasion?: string,
  weather?: string,
  colorPalette?: string[],
): WardrobeRecommendation[] {
  const ordered = stableWardrobeOrder(inventory, colorPalette);
  const occasionLabel = occasion?.trim() || "Everyday";
  if (ordered.length < 2) return [];

  const buckets = {
    top: ordered.filter((item) => normalizedCategory(item.category) === "top"),
    bottom: ordered.filter((item) => normalizedCategory(item.category) === "bottom"),
    dress: ordered.filter((item) => normalizedCategory(item.category) === "dress"),
    outerwear: ordered.filter((item) => normalizedCategory(item.category) === "outerwear"),
    shoes: ordered.filter((item) => normalizedCategory(item.category) === "shoes"),
    accessories: ordered.filter((item) => normalizedCategory(item.category) === "accessories"),
  };

  const candidates: WardrobeRecommendation[] = [];
  const addCandidate = (items: Array<RecommendationItem | undefined>) => {
    const recommendation = makeRecommendation(items, occasionLabel, weather, colorPalette);
    if (!recommendation) return;
    const signature = recommendation.itemIds.slice().sort().join("|");
    if (!candidates.some((candidate) => candidate.itemIds.slice().sort().join("|") === signature)) {
      candidates.push(recommendation);
    }
  };

  const requiresLayer = Boolean(weather && /(cold|cool|rain|wind|snow)/i.test(weather));
  const lookCount = Math.max(buckets.top.length, buckets.dress.length, 1);
  for (let index = 0; index < Math.min(lookCount, MAX_RECOMMENDATIONS); index += 1) {
    const top = pickAlternative(buckets.top, undefined, index);
    const dress = pickAlternative(buckets.dress, undefined, index);
    const primary = dress || top;
    const bottom = pickAlternative(buckets.bottom, undefined, index);
    const shoe = pickAlternative(buckets.shoes, undefined, index);
    const layer = requiresLayer || index === 0 ? pickAlternative(buckets.outerwear, undefined, index) : undefined;
    const accessory = pickAlternative(buckets.accessories, undefined, index);

    if (dress) addCandidate([dress, layer, shoe, accessory]);
    else if (top && bottom) {
      // Keep a user-owned accessory in the compact four-item result whenever one exists.
      // In cold or wet conditions, an outer layer is prioritized ahead of footwear.
      const finishingItems = requiresLayer
        ? [layer, accessory || shoe]
        : [shoe, accessory || layer];
      addCandidate([top, bottom, ...finishingItems]);
    }
  }

  // Sparse or unconventional wardrobes still receive an honest recommendation using only their
  // own pieces. Choosing distinct items keeps it a real outfit rather than a fabricated look.
  if (candidates.length === 0) addCandidate(ordered.slice(0, Math.min(4, ordered.length)));
  return candidates.slice(0, MAX_RECOMMENDATIONS);
}
