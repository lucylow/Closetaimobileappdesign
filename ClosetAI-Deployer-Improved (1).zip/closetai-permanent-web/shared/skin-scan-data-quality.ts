export const CORE_SKIN_SIGNAL_KEYS = [
  "moisture",
  "oiliness",
  "texture",
  "pores",
  "redness",
  "acne",
  "radiance",
  "spots",
  "wrinkles",
] as const;

export type CoreSkinSignalKey = (typeof CORE_SKIN_SIGNAL_KEYS)[number];

export type SkinScanDataQuality = {
  availableSignals: number;
  expectedSignals: number;
  coveragePercent: number;
  missingSignalKeys: CoreSkinSignalKey[];
  normalizedAt: string;
  note: string;
};

export function buildSkinScanDataQuality(input: { availableKeys: Iterable<string>; normalizedAt?: string }): SkinScanDataQuality {
  const available = new Set(Array.from(input.availableKeys).map((key) => key.toLowerCase()));
  const missingSignalKeys = CORE_SKIN_SIGNAL_KEYS.filter((key) => !available.has(key));
  const availableSignals = CORE_SKIN_SIGNAL_KEYS.length - missingSignalKeys.length;
  const expectedSignals = CORE_SKIN_SIGNAL_KEYS.length;
  const coveragePercent = Math.round((availableSignals / expectedSignals) * 100);
  return {
    availableSignals,
    expectedSignals,
    coveragePercent,
    missingSignalKeys,
    normalizedAt: input.normalizedAt || new Date().toISOString(),
    note: availableSignals === expectedSignals
      ? "All core normalized visual signals are available for this snapshot."
      : `${availableSignals} of ${expectedSignals} core normalized visual signals are available; unavailable signals are not assigned a score.`,
  };
}
