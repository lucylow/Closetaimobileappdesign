export const BREAST_SHAPE_INTENSITIES = [1, 2, 3] as const;
export type BreastShapeIntensity = typeof BREAST_SHAPE_INTENSITIES[number];

export type BreastShapeSimulationResult = {
  resultUrl: string;
  intensity: BreastShapeIntensity;
  source: "provider";
  expiresInHours: 2;
  analyzedAt: string;
};

export const BREAST_SHAPE_SIMULATION_DISCLOSURE = "Adult-only cosmetic photo visualization. It is not medical advice, a diagnosis, a surgical plan, a prediction, or an assessment of your body. Use a clothed photo you selected yourself. The temporary result is not saved to history, and no stock or fallback image will be shown.";

export function normalizeBreastShapeIntensity(value: unknown): BreastShapeIntensity | null {
  return typeof value === "number" && BREAST_SHAPE_INTENSITIES.includes(value as BreastShapeIntensity)
    ? value as BreastShapeIntensity
    : null;
}

/** Returns only a verified provider result URL and the documented user-selected intensity. */
export function normalizeProviderBreastShapeSimulation(value: unknown, intensity: unknown): BreastShapeSimulationResult | null {
  const normalizedIntensity = normalizeBreastShapeIntensity(intensity);
  if (!normalizedIntensity || !value || typeof value !== "object") return null;
  const raw = value as Record<string, unknown>;
  const candidates = [raw.url, (raw.data as Record<string, unknown> | undefined)?.url, (raw.results as Record<string, unknown> | undefined)?.url];
  const resultUrl = candidates.find((candidate): candidate is string => typeof candidate === "string" && /^https:\/\//.test(candidate));
  return resultUrl ? { resultUrl, intensity: normalizedIntensity, source: "provider", expiresInHours: 2, analyzedAt: new Date().toISOString() } : null;
}
