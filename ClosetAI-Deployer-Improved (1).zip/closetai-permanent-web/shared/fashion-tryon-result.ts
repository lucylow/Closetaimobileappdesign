export type FashionTryOnResultProvider = "youcam-ai-clothes-v4" | "image-edit" | "photo-preview";
export type FashionTryOnCompletedStatus = "completed-youcam" | "completed-assisted" | "completed-preview";

export type FashionTryOnResultPresentation = {
  label: string;
  detail: string;
  isUserPhotoPreview: boolean;
};

const completionStatusByProvider: Record<FashionTryOnResultProvider, FashionTryOnCompletedStatus> = {
  "youcam-ai-clothes-v4": "completed-youcam",
  "image-edit": "completed-assisted",
  "photo-preview": "completed-preview",
};

const providerByCompletionStatus: Record<FashionTryOnCompletedStatus, FashionTryOnResultProvider> = {
  "completed-youcam": "youcam-ai-clothes-v4",
  "completed-assisted": "image-edit",
  "completed-preview": "photo-preview",
};

export function completedStatusForFashionProvider(provider: FashionTryOnResultProvider): FashionTryOnCompletedStatus {
  return completionStatusByProvider[provider];
}

export function fashionProviderFromJobStatus(status?: string): FashionTryOnResultProvider | undefined {
  return status && status in providerByCompletionStatus
    ? providerByCompletionStatus[status as FashionTryOnCompletedStatus]
    : undefined;
}

export function isCompletedFashionTryOnStatus(status?: string): boolean {
  return Boolean(fashionProviderFromJobStatus(status));
}

export function fashionTryOnResultPresentation(provider: FashionTryOnResultProvider): FashionTryOnResultPresentation {
  if (provider === "youcam-ai-clothes-v4") {
    return {
      label: "YouCam AI Clothes v4 result",
      detail: "Live result using your selected photo and garment reference.",
      isUserPhotoPreview: false,
    };
  }
  if (provider === "image-edit") {
    return {
      label: "User-photo-only assisted edit",
      detail: "Secondary user-photo-only edit; this is not a YouCam AI Clothes v4 result.",
      isUserPhotoPreview: false,
    };
  }
  return {
    label: "Photo Preview",
    detail: "Selected items are not yet composited onto your photo.",
    isUserPhotoPreview: true,
  };
}

export function defaultFashionTryOnDisclosure(provider: FashionTryOnResultProvider): string {
  if (provider === "youcam-ai-clothes-v4") return "YouCam AI Clothes v4 result generated from your selected photo and wardrobe reference.";
  if (provider === "image-edit") return "User-photo-only assisted clothing edit shown. This is not a YouCam AI Clothes v4 result.";
  return "Live clothing edit was unavailable. User-photo preview shown instead.";
}

export function normalizeFashionProvider(provider?: string, isDemo?: boolean): FashionTryOnResultProvider {
  if (isDemo) return "photo-preview";
  if (!provider) return "youcam-ai-clothes-v4";
  if (provider === "youcam-ai-clothes-v4" || provider === "youcam") return "youcam-ai-clothes-v4";
  if (provider === "image-edit") return "image-edit";
  return "photo-preview";
}
