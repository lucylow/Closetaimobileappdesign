export type PersonalStyleProfile = {
  colors: string[];
  styles: string[];
  fitPrefs: string[];
};

export type StyleProfileWardrobeItem = {
  color?: string | null;
  tags?: string[] | null;
  category?: string | null;
};

const MAX_VALUES = 6;

function cleanList(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return value
    .filter((item): item is string => typeof item === "string")
    .map((item) => item.replace(/\s+/g, " ").trim().slice(0, 40))
    .filter(Boolean)
    .filter((item, index, values) => values.findIndex((candidate) => candidate.toLowerCase() === item.toLowerCase()) === index)
    .slice(0, MAX_VALUES);
}

export function normalizePersonalStyleProfile(value: unknown): PersonalStyleProfile {
  const record = value && typeof value === "object" ? value as Record<string, unknown> : {};
  return {
    colors: cleanList(record.colors),
    styles: cleanList(record.styles),
    fitPrefs: cleanList(record.fitPrefs),
  };
}

/** Builds a non-fictional starter profile from colors and tags already present in the user wardrobe. */
export function derivePersonalStyleProfile(items: StyleProfileWardrobeItem[], saved?: unknown): PersonalStyleProfile {
  const savedProfile = normalizePersonalStyleProfile(saved);
  const countValues = (values: Array<string | null | undefined>) => {
    const counts = new Map<string, number>();
    for (const value of values) {
      const clean = value?.trim();
      if (!clean) continue;
      counts.set(clean, (counts.get(clean) || 0) + 1);
    }
    return [...counts.entries()].sort((left, right) => right[1] - left[1] || left[0].localeCompare(right[0])).map(([value]) => value).slice(0, MAX_VALUES);
  };
  return {
    colors: savedProfile.colors.length ? savedProfile.colors : countValues(items.map((item) => item.color)),
    styles: savedProfile.styles.length ? savedProfile.styles : countValues(items.flatMap((item) => item.tags || [])),
    fitPrefs: savedProfile.fitPrefs,
  };
}
