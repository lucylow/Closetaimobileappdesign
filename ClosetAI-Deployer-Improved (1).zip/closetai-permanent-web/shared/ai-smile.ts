export const AI_SMILE_EXPRESSION_TYPES = ["smile_with_teeth_visible", "closed_mouth_smile"] as const;
export type AiSmileExpressionType = typeof AI_SMILE_EXPRESSION_TYPES[number];

export type AiSmileResult = {
  resultUrl: string;
  expressionType: AiSmileExpressionType;
  source: "provider";
  expiresInHours: 2;
  analyzedAt: string;
};

export const AI_SMILE_DISCLOSURE = "Creative smile photo visualization only. It does not assess your emotions, mood, identity, attractiveness, health, or personality; diagnose any condition; or promise an actual outcome. Results use your selected photo only, are temporary, and are not saved to history. No stock or fallback image will be shown.";

export function normalizeAiSmileExpressionType(value: unknown): AiSmileExpressionType | null {
  return typeof value === "string" && (AI_SMILE_EXPRESSION_TYPES as readonly string[]).includes(value)
    ? value as AiSmileExpressionType
    : null;
}

/** Retains only a secure temporary provider URL and the user-selected documented expression style. */
export function normalizeProviderAiSmile(value: unknown, expressionType: unknown): AiSmileResult | null {
  const selectedType = normalizeAiSmileExpressionType(expressionType);
  if (!selectedType || !value || typeof value !== "object") return null;
  const raw = value as Record<string, unknown>;
  const candidates = [raw.url, (raw.data as Record<string, unknown> | undefined)?.url, (raw.results as Record<string, unknown> | undefined)?.url];
  const resultUrl = candidates.find((candidate): candidate is string => typeof candidate === "string" && /^https:\/\//.test(candidate));
  return resultUrl ? { resultUrl, expressionType: selectedType, source: "provider", expiresInHours: 2, analyzedAt: new Date().toISOString() } : null;
}
