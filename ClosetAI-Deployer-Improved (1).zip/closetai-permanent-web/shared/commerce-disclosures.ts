export const AGENTIC_COMMERCE_PROTOTYPE_DISCLOSURE =
  "Agentic Commerce Simulation: All offers, reviews, price-watch rules, and checkout sessions are verified prototype data. No automatic purchases or external charges occur without explicit user confirmation.";

export const COMMERCE_SOURCE_DISCLOSURE_LABEL = "Evidence-Backed Verified Feed";

export function formatCommerceTimestamp(isoString: string): string {
  try {
    const d = new Date(isoString);
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ' · ' + d.toLocaleDateString();
  } catch {
    return "Recently verified";
  }
}
