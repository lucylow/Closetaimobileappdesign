import type { FaceAngleStrictness } from "@shared/facial-color-tones";

export const FACE_ATTRIBUTE_ACTIONS = [
  "faceShape", "eyeShape", "eyeSize", "eyeAngle", "eyeDistance", "eyelid",
  "eyebrowShape", "eyebrowThickness", "eyebrowDistance", "eyebrowShortness",
  "lipShape", "noseWidth", "noseLength", "cheekbones",
  "horizontalThird", "verticalFifth", "faceAspectRatio", "eyeAspectRatio",
  "eyebrowArch", "eyeHeightToEyebrowDistance", "noseAspectRatio",
  "noseWidthToMouthWidth", "noseToLipToChin", "upperLipToLowerLip",
] as const;

export type FaceAttributeAction = (typeof FACE_ATTRIBUTE_ACTIONS)[number];

export type FaceAttributesRequest = {
  actions: FaceAttributeAction[];
  faceAngleStrictness: FaceAngleStrictness;
};

export type FaceAttributeResult = {
  faceShape?: string;
  eyeShape?: string;
  eyeSize?: string;
  eyeAngle?: string;
  eyeDistance?: string;
  eyelid?: string;
  eyebrowShape?: string;
  eyebrowThickness?: string;
  eyebrowDistance?: string;
  eyebrowShortness?: string;
  lipShape?: string;
  noseWidth?: string;
  noseLength?: string;
  cheekbones?: string;
  proportions: Partial<Record<Extract<FaceAttributeAction, "horizontalThird" | "verticalFifth" | "faceAspectRatio" | "eyeAspectRatio" | "eyebrowArch" | "eyeHeightToEyebrowDistance" | "noseAspectRatio" | "noseWidthToMouthWidth" | "noseToLipToChin" | "upperLipToLowerLip">, number[]>>;
  source: "provider";
  analyzedAt: string;
};

export const FACE_ATTRIBUTES_DISCLOSURE = "Optional styling geometry only. These provider-returned descriptors are not an attractiveness score, beauty standard, identity inference, age or gender estimate, medical assessment, or recommendation.";

const PROPORTION_KEYS = new Set(["horizontalThird", "verticalFifth", "faceAspectRatio", "eyeAspectRatio", "eyebrowArch", "eyeHeightToEyebrowDistance", "noseAspectRatio", "noseWidthToMouthWidth", "noseToLipToChin", "upperLipToLowerLip"]);

export function normalizeFaceAttributeActions(value: unknown): FaceAttributeAction[] {
  const source = Array.isArray(value) ? value : [];
  const deduplicated = [...new Set(source.filter((item): item is string => typeof item === "string"))];
  const selected = deduplicated.filter((item): item is FaceAttributeAction => (FACE_ATTRIBUTE_ACTIONS as readonly string[]).includes(item));
  return selected.length ? selected : ["faceShape", "eyeShape", "eyelid", "eyebrowShape", "lipShape", "noseWidth", "noseLength", "cheekbones"];
}

function firstText(value: unknown): string | undefined {
  if (typeof value === "string" && value.trim()) return value.trim();
  if (Array.isArray(value)) return value.filter((item): item is string => typeof item === "string" && Boolean(item.trim())).join(", ") || undefined;
  return undefined;
}

function firstSideValue(value: unknown, fallback: unknown): string | undefined {
  if (value && typeof value === "object") {
    const item = value as Record<string, unknown>;
    return firstText(item.left_shape ?? item.left_eyelid ?? item.left_angle ?? item.left_body_thickness ?? item.left_shortness ?? item.left ?? item.overrall ?? fallback);
  }
  return firstText(fallback);
}

function numericArray(value: unknown): number[] | undefined {
  if (!Array.isArray(value) || !value.length || !value.every((item) => typeof item === "number" && Number.isFinite(item))) return undefined;
  return value.map((item) => Math.round(item * 1000) / 1000);
}

/**
 * Reduces raw provider output to user-selected styling geometry. Age, gender, provider URLs,
 * face-quality internals, and any unrequested fields are intentionally omitted.
 */
export function normalizeProviderFaceAttributes(value: unknown, actions: FaceAttributeAction[]): FaceAttributeResult | null {
  if (!value || typeof value !== "object") return null;
  const raw = value as Record<string, any>;
  const selected = new Set(actions);
  const result: FaceAttributeResult = { proportions: {}, source: "provider", analyzedAt: new Date().toISOString() };
  if (selected.has("faceShape")) result.faceShape = firstText(raw.faceshape);
  if (selected.has("eyeShape")) result.eyeShape = firstSideValue(raw.eyelid, undefined);
  if (selected.has("eyeSize")) result.eyeSize = firstText(raw.eyelid?.size);
  if (selected.has("eyeAngle")) result.eyeAngle = firstText(raw.eyelid?.left_angle);
  if (selected.has("eyeDistance")) result.eyeDistance = firstText(raw.eyelid?.setting);
  if (selected.has("eyelid")) result.eyelid = firstText(raw.eyelid?.left_eyelid);
  if (selected.has("eyebrowShape")) result.eyebrowShape = firstText(raw.eyebrow?.left_shape);
  if (selected.has("eyebrowThickness")) result.eyebrowThickness = firstText(raw.eyebrow?.left_body_thickness);
  if (selected.has("eyebrowDistance")) result.eyebrowDistance = firstText(raw.eyebrow?.gap);
  if (selected.has("eyebrowShortness")) result.eyebrowShortness = firstText(raw.eyebrow?.left_shortness);
  if (selected.has("lipShape")) result.lipShape = firstText(raw.lipshape);
  if (selected.has("noseWidth")) result.noseWidth = firstText(raw.nose?.width);
  if (selected.has("noseLength")) result.noseLength = firstText(raw.nose?.length);
  if (selected.has("cheekbones")) result.cheekbones = firstText(raw.cheekbone?.overrall ?? raw.cheekbone?.left);

  const ratios = raw.facialratio || {};
  for (const action of actions) {
    if (!PROPORTION_KEYS.has(action)) continue;
    const key = action.replace(/[A-Z]/g, (letter) => `_${letter.toLowerCase()}`);
    const direct = numericArray(ratios[key]);
    const side = action === "eyeAspectRatio" ? numericArray(ratios.left_eye_aspect_ratio) : action === "eyebrowArch" ? numericArray(ratios.left_eyebrow_arch_to_eyebrow_width) : action === "eyeHeightToEyebrowDistance" ? numericArray(ratios.overall_eye_height_to_eyebrow_distance) : direct;
    if (side) result.proportions[action as keyof typeof result.proportions] = side;
  }

  const hasDescriptor = Object.entries(result).some(([key, field]) => key !== "proportions" && key !== "source" && key !== "analyzedAt" && Boolean(field));
  return hasDescriptor || Object.keys(result.proportions).length ? result : null;
}
