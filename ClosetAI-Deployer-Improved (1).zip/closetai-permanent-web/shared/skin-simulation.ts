export const SKIN_SIMULATION_CONCERNS = [
  "wrinkle",
  "radiance",
  "oiliness",
  "acne",
  "eye_bags",
  "dark_circle",
  "spots",
  "pores",
  "texture",
  "redness",
] as const;

export type SkinSimulationConcern = (typeof SKIN_SIMULATION_CONCERNS)[number];
export type SkinSimulationAdjustments = Partial<Record<SkinSimulationConcern, number>>;

export type SkinSimulationRequest = {
  adjustments: SkinSimulationAdjustments;
};

export const SKIN_SIMULATION_DISCLOSURE = "Cosmetic visualization only. This generated preview is not a medical assessment, treatment recommendation, or prediction of a real-world outcome.";

function clampIntensity(value: unknown): number | null {
  const parsed = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(parsed)) return null;
  return Math.round(Math.min(1, Math.max(0, parsed)) * 100) / 100;
}

/**
 * Produces a provider-safe, user-explicit set of cosmetic visualization adjustments. At least one
 * concern must be selected above zero; unknown keys are dropped and zero values are omitted.
 */
export function normalizeSkinSimulationAdjustments(value: unknown): SkinSimulationAdjustments | null {
  if (!value || typeof value !== "object") return null;
  const source = value as Record<string, unknown>;
  const adjustments: SkinSimulationAdjustments = {};
  for (const concern of SKIN_SIMULATION_CONCERNS) {
    const intensity = clampIntensity(source[concern]);
    if (intensity !== null && intensity > 0) adjustments[concern] = intensity;
  }
  return Object.keys(adjustments).length > 0 ? adjustments : null;
}

export function createSkinSimulationRequest(adjustments: unknown): SkinSimulationRequest | null {
  const normalized = normalizeSkinSimulationAdjustments(adjustments);
  return normalized ? { adjustments: normalized } : null;
}

export function describeSkinSimulationAdjustments(adjustments: SkinSimulationAdjustments): string {
  const selected = SKIN_SIMULATION_CONCERNS.filter((concern) => (adjustments[concern] || 0) > 0);
  return selected.length ? selected.map((concern) => concern.replace(/_/g, " ")).join(", ") : "no adjustments";
}
