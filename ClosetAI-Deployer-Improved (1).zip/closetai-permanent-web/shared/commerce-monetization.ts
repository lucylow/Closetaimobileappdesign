export interface CommercePlanTier {
  id: "free" | "pro_shopper" | "concierge_enterprise";
  name: string;
  monthlyPrice: number;
  currency: string;
  priceWatchLimit: number;
  aiSearchesPerDay: number;
  priorityDispatch: boolean;
  affiliateCommissionEnabled: boolean;
}

export const COMMERCE_PLAN_TIERS: CommercePlanTier[] = [
  {
    id: "free",
    name: "Free Shopper",
    monthlyPrice: 0,
    currency: "USD",
    priceWatchLimit: 3,
    aiSearchesPerDay: 5,
    priorityDispatch: false,
    affiliateCommissionEnabled: true,
  },
  {
    id: "pro_shopper",
    name: "Pro Shopper",
    monthlyPrice: 9.99,
    currency: "USD",
    priceWatchLimit: 25,
    aiSearchesPerDay: 50,
    priorityDispatch: true,
    affiliateCommissionEnabled: true,
  },
  {
    id: "concierge_enterprise",
    name: "Concierge VIP",
    monthlyPrice: 29.99,
    currency: "USD",
    priceWatchLimit: 100,
    aiSearchesPerDay: 999,
    priorityDispatch: true,
    affiliateCommissionEnabled: true,
  },
];

export const COMMERCE_MONETIZATION_DISCLOSURE =
  "Affiliate & Monetization Disclosure: ClosetAI may earn affiliate commissions or referral fees from participating merchant checkouts initiated through the agentic shopping assistant at no additional cost to you.";
