export type CommerceAgentMode = "live" | "cached" | "demo" | "error";

export type CommerceAction =
  | "search"
  | "compare"
  | "summarize_reviews"
  | "watch_price"
  | "prepare_checkout"
  | "complete_checkout";

export interface Money {
  amount: number;
  currency: string;
}

export type AvailabilityState = "in_stock" | "low_stock" | "out_of_stock" | "unknown";

export interface CommerceSource {
  providerName: string;
  sourceUrl: string;
  retrievedAt: string;
  confidence: number;
  isDemo: boolean;
}

export interface EvidenceRef {
  label: string;
  url?: string;
  timestamp: string;
}

export interface ReviewIntelligenceSummary {
  averageRating?: number;
  totalReviews: number;
  positiveThemes: string[];
  cautionThemes: string[];
  sentimentBreakdown: { positive: number; neutral: number; negative: number };
  evidenceRetrievedAt: string;
}

export interface CommerceCandidate {
  productId: string;
  merchantId: string;
  title: string;
  brand?: string;
  price: Money;
  shipping?: Money;
  total?: Money;
  availability: AvailabilityState;
  productUrl: string;
  lastCheckedAt: string;
  source: CommerceSource;
  evidence: EvidenceRef[];
  reviewSummary?: ReviewIntelligenceSummary;
  matchScore: number;
}

export interface PriceWatchRule {
  id: string;
  candidateId: string;
  title: string;
  targetPrice: Money;
  active: boolean;
  createdAt: string;
}

export interface CheckoutSession {
  sessionId: string;
  candidateId: string;
  title: string;
  merchantName: string;
  quantity: number;
  subtotal: Money;
  shipping: Money;
  tax: Money;
  total: Money;
  returnPolicyUrl: string;
  status: "preparing" | "awaiting_user_approval" | "approved" | "completed" | "cancelled";
  userApproved: boolean;
  createdAt: string;
}

export interface CommerceAgentPlan {
  goal: string;
  category: "fashion" | "skincare" | "beauty" | "accessory";
  budgetMax?: number;
  currency: string;
  country: string;
  actions: string[];
}
