import * as FileSystem from "expo-file-system/legacy";
import { Platform } from "react-native";

/** Converts a user-selected local image to an unprefixed base64 payload for an authenticated server request. */
export async function selectedImageUriToBase64(uri: string): Promise<string> {
  if (Platform.OS !== "web") return FileSystem.readAsStringAsync(uri, { encoding: "base64" as any });
  const response = await fetch(uri);
  const blob = await response.blob();
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const value = String(reader.result || "");
      resolve(value.includes(",") ? value.split(",")[1] : value);
    };
    reader.onerror = () => reject(new Error("Unable to read the selected photo."));
    reader.readAsDataURL(blob);
  });
}
