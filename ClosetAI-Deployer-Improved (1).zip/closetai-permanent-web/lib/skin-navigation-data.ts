import { SKIN_MOCK_RESULT, type SkinMockRoutineStep, type SkinProduct } from "@/lib/skin-mock-data";

export type SkinGoalId = "hydration" | "radiance" | "texture" | "calm" | "tone";

export interface SkinGoal {
  id: SkinGoalId;
  title: string;
  description: string;
  icon: "water-outline" | "sunny-outline" | "sparkles-outline" | "leaf-outline" | "color-palette-outline";
  accent: string;
}

export const skinGoals: SkinGoal[] = [
  { id: "hydration", title: "Support hydration", description: "Keep skin feeling comfortable and balanced.", icon: "water-outline", accent: "#3B82F6" },
  { id: "radiance", title: "Boost radiance", description: "Build a consistent, gentle glow routine.", icon: "sunny-outline", accent: "#F59E0B" },
  { id: "texture", title: "Smooth texture", description: "Use patient, supportive care over time.", icon: "sparkles-outline", accent: "#A855F7" },
  { id: "calm", title: "Keep it calm", description: "Prioritise comfort and a simple routine.", icon: "leaf-outline", accent: "#22C55E" },
  { id: "tone", title: "Even-looking tone", description: "Build daily protection into your routine.", icon: "color-palette-outline", accent: "#EC4899" },
];

export const skinMetrics = [
  { id: "hydration", label: "Hydration", score: 74, status: "Good", detail: "Your skin may benefit from a little more everyday moisture support.", action: "Keep a gentle moisturiser in both routines." },
  { id: "radiance", label: "Radiance", score: 81, status: "Strong", detail: "Your complexion reads naturally bright in this snapshot.", action: "Protect the glow with a daily SPF step." },
  { id: "texture", label: "Texture", score: 67, status: "Watch", detail: "A simple and consistent routine can support smoother-looking skin.", action: "Introduce only one optional targeted-care step at a time." },
  { id: "tone", label: "Tone", score: 78, status: "Balanced", detail: "Your skin tone appears fairly even in this image.", action: "Choose fragrance-free basics if skin feels sensitive." },
] as const;

export interface SkinSnapshotListItem {
  id: string;
  date: string;
  score: number;
  summary: string;
  status: "New" | "Steady" | "Improving";
}

export const savedSnapshots: SkinSnapshotListItem[] = [
  { id: "today", date: "Today", score: 76, summary: "Balanced profile with a hydration focus.", status: "New" },
  { id: "last-week", date: "7 days ago", score: 74, summary: "Comfort and radiance remained steady.", status: "Improving" },
  { id: "last-month", date: "30 days ago", score: 71, summary: "A simple routine was recommended.", status: "Steady" },
];

export const progressSeries = [
  { label: "Hydration", value: 74, change: 6, color: "#3B82F6" },
  { label: "Radiance", value: 81, change: 4, color: "#F59E0B" },
  { label: "Texture", value: 67, change: 3, color: "#A855F7" },
  { label: "Tone", value: 78, change: 2, color: "#EC4899" },
];

export const photoTips = [
  { title: "Choose soft, even light", body: "Face a window during the day. Avoid a bright light directly behind you." },
  { title: "Keep the frame simple", body: "Use a front-facing photo without filters, face coverings, or strong shadows." },
  { title: "Keep your camera steady", body: "Hold the phone at eye level, leave a little space around your face, and use the sharpest image you can." },
  { title: "Make the choice yours", body: "You can choose whether to save only a normalised snapshot summary for later comparison." },
];

export const paletteDirections = [
  { name: "Soft Neutrals", description: "Cream, sand, and warm taupe keep your look polished without competing with your complexion.", colors: ["#F0E7DC", "#CDBBA7", "#A8876D"] },
  { name: "Warm Accents", description: "Terracotta, cinnamon, and muted coral can add controlled warmth to an outfit.", colors: ["#D77455", "#A94E3F", "#E7A18A"] },
  { name: "Deep Balance", description: "Navy, espresso, and olive offer contrast while still feeling approachable.", colors: ["#21314A", "#4B342A", "#66724F"] },
];

export const outfitPlan = [
  { id: "look-one", title: "Cream knit + camel trouser", occasion: "Everyday polish", rationale: "Soft neutral layering supports the palette direction in your latest snapshot.", colors: ["Cream", "Camel"] },
  { id: "look-two", title: "Navy shirt + warm accessory", occasion: "Work or dinner", rationale: "Deep balance creates a clean frame; the warm accessory adds brightness near the face.", colors: ["Navy", "Terracotta"] },
  { id: "look-three", title: "Monochrome sand set", occasion: "Easy weekend", rationale: "A low-contrast tonal look lets the outfit feel intentional and calm.", colors: ["Sand", "Taupe"] },
];

export const careReminders = [
  { id: "am", title: "Morning routine", detail: "A light reminder to complete your AM steps.", time: "08:00" },
  { id: "pm", title: "Evening routine", detail: "A calm end-of-day prompt for your PM steps.", time: "21:30" },
  { id: "check-in", title: "Weekly check-in", detail: "Review how your skin feels and choose a next action.", time: "Sunday" },
];

export const routineSteps: SkinMockRoutineStep[] = SKIN_MOCK_RESULT.routine;
export const skinProducts: SkinProduct[] = SKIN_MOCK_RESULT.products;

export function getMetric(metricId?: string) {
  return skinMetrics.find((metric) => metric.id === metricId) ?? skinMetrics[0];
}

export function getProduct(productId?: string) {
  return skinProducts.find((product) => product.id === productId) ?? skinProducts[0];
}

export function getRoutineSteps(period: "AM" | "PM") {
  return routineSteps.filter((step) => step.time === period);
}

export function getSnapshot(snapshotId?: string) {
  return savedSnapshots.find((snapshot) => snapshot.id === snapshotId) ?? savedSnapshots[0];
}
