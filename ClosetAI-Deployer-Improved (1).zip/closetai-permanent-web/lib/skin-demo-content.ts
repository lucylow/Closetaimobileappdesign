export interface DemoPriority {
  id: string;
  title: string;
  icon: "water-outline" | "sparkles-outline" | "color-palette-outline";
  explanation: string;
  action: string;
}

import { realSkinProductCatalog, type RealSkinProduct } from "@/lib/skin-product-catalog";

export type DemoProduct = RealSkinProduct;

export interface DemoPaletteIdea {
  id: string;
  title: string;
  colors: string[];
  reason: string;
}

export interface DemoProgressPoint {
  label: string;
  score: number;
  change?: number;
}

export interface DemoWardrobeRecommendation {
  id: string;
  title: string;
  occasion: string;
  pieces: string[];
  accessories: string[];
  reason: string;
}

/** Verified catalog records shown in Demo Mode as real product references; only profile and scan data remain fictional. */
export const demoProducts: DemoProduct[] = realSkinProductCatalog;

const productIdsByProfile: Record<string, string[]> = {
  "combination-balanced": ["cerave-hydrating-facial-cleanser", "lrp-toleriane-double-repair", "cerave-am-facial-lotion-spf-30", "ordinary-niacinamide-zinc"],
  "dry-comfort": ["cerave-hydrating-facial-cleanser", "lrp-toleriane-double-repair", "cerave-am-facial-lotion-spf-30", "cerave-skin-renewing-night-cream"],
  "oily-clarity": ["cerave-hydrating-facial-cleanser", "ordinary-niacinamide-zinc", "cerave-am-facial-lotion-spf-30", "lrp-toleriane-double-repair"],
  "normal-radiance": ["cerave-hydrating-facial-cleanser", "lrp-toleriane-double-repair", "cerave-am-facial-lotion-spf-30", "ordinary-niacinamide-zinc"],
  "sensitive-barrier": ["cerave-hydrating-facial-cleanser", "lrp-toleriane-double-repair", "cerave-am-facial-lotion-spf-30", "cerave-skin-renewing-night-cream"],
};

const prioritiesByProfile: Record<string, DemoPriority[]> = {
  "combination-balanced": [
    { id: "hydration", title: "Hydration", icon: "water-outline", explanation: "Keep moisture support simple and consistent in this demo profile.", action: "Demo suggestion: use a gentle moisturizer after cleansing." },
    { id: "texture", title: "Texture", icon: "sparkles-outline", explanation: "A calm, repeatable routine is the focus for this visual demo signal.", action: "Demo suggestion: introduce one optional step at a time." },
    { id: "dark-spots", title: "Dark Spots", icon: "color-palette-outline", explanation: "Tone support is a long-term fictional consideration, not a diagnosis.", action: "Demo suggestion: make broad-spectrum sunscreen a daily final step." },
  ],
  "dry-comfort": [
    { id: "hydration", title: "Comfort", icon: "water-outline", explanation: "This demo profile places comfort and hydration at the center of its routine.", action: "Demo suggestion: choose one supportive moisture layer." },
    { id: "radiance", title: "Radiance", icon: "sparkles-outline", explanation: "Radiance is shown as a supportable visual signal in this fictional profile.", action: "Demo suggestion: finish with sunscreen each morning." },
    { id: "fine-lines", title: "Fine Lines", icon: "color-palette-outline", explanation: "This is a visual demo consideration, never a clinical measurement.", action: "Demo suggestion: keep evening layers gentle and comfortable." },
  ],
  "oily-clarity": [
    { id: "oiliness", title: "Balance", icon: "water-outline", explanation: "This fictional profile favors light, consistent layers instead of stripping steps.", action: "Demo suggestion: keep cleansing gentle and simple." },
    { id: "pores", title: "Pores", icon: "sparkles-outline", explanation: "A prototype visual signal used for routine exploration, not diagnosis.", action: "Demo suggestion: avoid over-exfoliating." },
    { id: "radiance", title: "Radiance", icon: "color-palette-outline", explanation: "Radiance remains a strength in this fictional profile.", action: "Demo suggestion: maintain daily protection." },
  ],
  "normal-radiance": [
    { id: "radiance", title: "Radiance", icon: "sparkles-outline", explanation: "Radiance and glow are highlighted as a standout visual signal in this demo.", action: "Demo suggestion: protect the glow with daily SPF." },
    { id: "hydration", title: "Hydration", icon: "water-outline", explanation: "Maintains a balanced moisture rhythm.", action: "Demo suggestion: keep cleansing gentle." },
  ],
  "sensitive-barrier": [
    { id: "redness", title: "Calmness", icon: "water-outline", explanation: "Focuses on barrier comfort and fragrance-free soothing layers.", action: "Demo suggestion: use centella or ceramide barrier creams." },
    { id: "texture", title: "Gentle Care", icon: "sparkles-outline", explanation: "Avoids physical scrubs or strong active acids.", action: "Demo suggestion: keep the routine minimal." },
  ],
};

const palettesByProfile: Record<string, DemoPaletteIdea[]> = {
  "combination-balanced": [
    { id: "soft-neutrals", title: "Soft Neutrals", colors: ["Cream", "Taupe", "Soft Beige"], reason: "A fictional palette that keeps the skin demo result visually light and minimal." },
    { id: "warm-accent", title: "Warm Accent", colors: ["Terracotta", "Camel", "Muted Coral"], reason: "Adds warmth near the face in this prototype styling direction." },
  ],
  "dry-comfort": [
    { id: "comfort-neutrals", title: "Comfort Neutrals", colors: ["Cream", "Camel", "Soft Blue"], reason: "A fictional warm-and-soft palette tied to the demo comfort focus." },
    { id: "calm-contrast", title: "Calm Contrast", colors: ["Navy", "Oat", "Gold"], reason: "Creates polished contrast without overwhelming the look." },
  ],
  "oily-clarity": [
    { id: "fresh-classics", title: "Fresh Classics", colors: ["White", "Navy", "Denim"], reason: "A crisp fictional palette for the clarity demo profile." },
    { id: "cool-accent", title: "Cool Accent", colors: ["Sage", "Silver", "Charcoal"], reason: "Offers a composed finishing direction for this prototype." },
  ],
  "normal-radiance": [
    { id: "radiant-jewels", title: "Radiant Jewels", colors: ["Emerald", "Gold", "Ivory"], reason: "A vibrant fictional palette for a high-radiance demo profile." },
  ],
  "sensitive-barrier": [
    { id: "soothing-pastels", title: "Soothing Pastels", colors: ["Sage", "Soft Oat", "Cashmere"], reason: "A calm, gentle palette matching the sensitive barrier routine." },
  ],
};

const historyByProfile: Record<string, DemoProgressPoint[]> = {
  "combination-balanced": [{ label: "Today", score: 84, change: 3 }, { label: "1 week ago", score: 81, change: 6 }, { label: "2 weeks ago", score: 78 }, { label: "3 weeks ago", score: 80 }],
  "dry-comfort": [{ label: "Today", score: 79, change: 2 }, { label: "1 week ago", score: 77, change: 4 }, { label: "2 weeks ago", score: 73 }, { label: "3 weeks ago", score: 75 }],
  "oily-clarity": [{ label: "Today", score: 82, change: 4 }, { label: "1 week ago", score: 78, change: 5 }, { label: "2 weeks ago", score: 73 }, { label: "3 weeks ago", score: 76 }],
  "normal-radiance": [{ label: "Today", score: 88, change: 5 }, { label: "1 week ago", score: 85, change: 3 }, { label: "2 weeks ago", score: 82 }, { label: "3 weeks ago", score: 84 }],
  "sensitive-barrier": [{ label: "Today", score: 81, change: 3 }, { label: "1 week ago", score: 79, change: 2 }, { label: "2 weeks ago", score: 76 }, { label: "3 weeks ago", score: 77 }],
};

const wardrobeByProfile: Record<string, DemoWardrobeRecommendation[]> = {
  "combination-balanced": [
    { id: "balanced-work", title: "Soft workday contrast", occasion: "Office", pieces: ["Cream knit", "Navy trouser"], accessories: ["Gold watch", "Structured bag"], reason: "A fictional Skin × Wardrobe look that uses calm contrast and a warm accessory." },
    { id: "balanced-weekend", title: "Warm casual layers", occasion: "Weekend", pieces: ["Taupe tee", "Dark denim"], accessories: ["Camel scarf"], reason: "A compact prototype outfit that follows the demo palette direction." },
  ],
  "dry-comfort": [
    { id: "comfort-office", title: "Comfort-first tailoring", occasion: "Office", pieces: ["Soft blue shirt", "Camel blazer"], accessories: ["Gold watch"], reason: "A fictional outfit using gentle color contrast and soft layers." },
    { id: "comfort-outing", title: "Cream knit outing", occasion: "Day out", pieces: ["Cream knit", "Straight-leg jean"], accessories: ["Warm tote"], reason: "A demo look that reinforces the warm comfort palette." },
  ],
  "oily-clarity": [
    { id: "clarity-office", title: "Crisp navy pairing", occasion: "Office", pieces: ["White shirt", "Navy trouser"], accessories: ["Silver watch"], reason: "A fictional fresh-classic look with concise accessories." },
    { id: "clarity-evening", title: "Clean evening base", occasion: "Dinner", pieces: ["Black top", "Denim jacket"], accessories: ["Mini bag"], reason: "A prototype outfit that keeps the styling frame clear and uncomplicated." },
  ],
  "normal-radiance": [
    { id: "radiant-evening", title: "Jewel-tone evening statement", occasion: "Evening", pieces: ["Silk blouse", "Tailored blazer"], accessories: ["Gold earrings"], reason: "An expressive look tailored for high radiance." },
  ],
  "sensitive-barrier": [
    { id: "calm-casual", title: "Cashmere comfort layer", occasion: "Weekend", pieces: ["Oatmeal knit", "Relaxed pant"], accessories: ["Canvas tote"], reason: "A soothing, low-friction outfit direction." },
  ],
};

export function getDemoProducts(profileId: string): DemoProduct[] {
  const ids = productIdsByProfile[profileId] || productIdsByProfile["combination-balanced"];
  return ids.map((id) => demoProducts.find((product) => product.id === id)).filter((product): product is DemoProduct => Boolean(product));
}
export function getDemoPriorities(profileId: string): DemoPriority[] { return prioritiesByProfile[profileId] || prioritiesByProfile["combination-balanced"]; }
export function getDemoPaletteIdeas(profileId: string): DemoPaletteIdea[] { return palettesByProfile[profileId] || palettesByProfile["combination-balanced"]; }
export function getDemoProgressHistory(profileId: string): DemoProgressPoint[] { return historyByProfile[profileId] || historyByProfile["combination-balanced"]; }
export function getDemoWardrobeRecommendations(profileId: string): DemoWardrobeRecommendation[] { return wardrobeByProfile[profileId] || wardrobeByProfile["combination-balanced"]; }

// Compatibility exports for existing demo-only consumers.
export const demoPriorities = getDemoPriorities("combination-balanced");
export const demoPaletteIdeas = getDemoPaletteIdeas("combination-balanced");
export const demoProgressHistory = getDemoProgressHistory("combination-balanced");
