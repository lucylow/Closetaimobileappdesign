import type { SkinAnalysisResult } from "./skin-analysis-controller";

export type PersistedSkinAnalysisSummary = Omit<SkinAnalysisResult, "imageUri" | "processingTimeMs" | "fallbackReason">;

/**
 * Creates the only form of a scan result permitted in local history. It intentionally excludes
 * image references, transient timing data, and provider failure text while retaining normalized,
 * source-aware signals needed by the dashboard and local trend views.
 */
export function toPersistedSkinAnalysisSummary(result: SkinAnalysisResult): PersistedSkinAnalysisSummary {
  const { imageUri: _imageUri, processingTimeMs: _processingTimeMs, fallbackReason: _fallbackReason, ...summary } = result;
  return summary;
}
