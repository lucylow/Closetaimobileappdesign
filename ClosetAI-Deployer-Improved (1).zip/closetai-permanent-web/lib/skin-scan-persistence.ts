import type { SkinAnalysisResult } from "./skin-analysis-controller";
import { toPersistedSkinAnalysisSummary } from "./skin-analysis-persistence";

function isSkinAnalysisResult(value: unknown): value is SkinAnalysisResult {
  if (!value || typeof value !== "object") return false;
  const candidate = value as Partial<SkinAnalysisResult>;
  return typeof candidate.id === "string"
    && typeof candidate.createdAt === "string"
    && Array.isArray(candidate.metrics)
    && Array.isArray(candidate.routine)
    && typeof candidate.disclaimer === "string";
}

/**
 * Safely restores prior local summaries and migrates legacy entries through the privacy sanitizer.
 * Malformed persisted data is treated as unavailable rather than being trusted as a dashboard result.
 */
export function readPersistedSkinResults(raw: string): SkinAnalysisResult[] {
  try {
    const parsed: unknown = JSON.parse(raw);
    return Array.isArray(parsed)
      ? parsed.filter(isSkinAnalysisResult).map(toPersistedSkinAnalysisSummary)
      : [];
  } catch {
    return [];
  }
}
