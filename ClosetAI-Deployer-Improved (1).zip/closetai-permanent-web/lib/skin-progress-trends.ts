import type { SkinMetricHistoryPoint } from "@/lib/skin-metric-history";

export type SkinProgressDirection = "up" | "down" | "steady" | "insufficient" | "mixed";
export type SkinProgressSource = "youcam" | "demo" | "cached" | "mixed" | "none";

export type ProgressMetricConfig = { key: string; label: string };

export const PROGRESS_METRICS: ProgressMetricConfig[] = [
  { key: "hydration", label: "Hydration" },
  { key: "radiance", label: "Radiance" },
  { key: "texture", label: "Texture" },
  { key: "pores", label: "Pores" },
  { key: "redness", label: "Redness" },
  { key: "blemishes", label: "Blemishes" },
  { key: "darkSpots", label: "Dark spots" },
  { key: "fineLines", label: "Fine lines" },
];

export type SkinProgressMetricSummary = {
  metricKey: string;
  pointCount: number;
  firstScore?: number;
  latestScore?: number;
  delta?: number;
  direction: SkinProgressDirection;
  source: SkinProgressSource;
  note: string;
};

export type SkinProgressOverview = {
  snapshotCount: number;
  captureDayCount: number;
  firstCapturedAt?: string;
  latestCapturedAt?: string;
  sources: Array<Exclude<SkinProgressSource, "mixed" | "none">>;
  metricSummaries: SkinProgressMetricSummary[];
  note: string;
};

export const SKIN_PROGRESS_DISCLOSURE = "Your Progress shows locally stored normalized snapshot values for reflection only. It is not medical advice, a diagnosis, a treatment-response measurement, a prediction, or a clinical progress assessment. Original selfies, image URIs, raw provider output, masks, and provider credentials are not stored in this local trend history.";

function toTime(value: string): number {
  const time = Date.parse(value);
  return Number.isFinite(time) ? time : 0;
}

function sourceFor(points: SkinMetricHistoryPoint[]): SkinProgressSource {
  const sources = [...new Set(points.map((point) => point.source))];
  if (sources.length === 0) return "none";
  if (sources.length > 1) return "mixed";
  return sources[0] === "youcam" || sources[0] === "demo" || sources[0] === "cached" ? sources[0] : "none";
}

function uniqueMetricPoints(points: SkinMetricHistoryPoint[], metricKey: string): SkinMetricHistoryPoint[] {
  const byScan = new Map<string, SkinMetricHistoryPoint>();
  for (const point of points) {
    if (point.metricKey !== metricKey || !Number.isFinite(point.score)) continue;
    const key = `${point.scanId}:${point.metricKey}`;
    const current = byScan.get(key);
    if (!current || toTime(point.capturedAt) >= toTime(current.capturedAt)) byScan.set(key, point);
  }
  return [...byScan.values()].sort((left, right) => toTime(left.capturedAt) - toTime(right.capturedAt));
}

function sourceNote(source: SkinProgressSource, pointCount: number, direction: SkinProgressDirection): string {
  if (source === "mixed") return "Source context varies across these snapshots, so values are not combined into a personal direction.";
  if (pointCount < 2) return "Save at least two snapshots from one source context to view a local direction label.";
  if (source === "demo") return `Fictional Demo Mode reference direction: ${direction}. It is not personal progress.`;
  if (source === "cached") return `Local cached normalized context shows a ${direction} direction. Source context may vary from a new live scan.`;
  return `Normalized live snapshot direction: ${direction}. Small changes should not be over-interpreted.`;
}

export function buildSkinProgressMetricSummary(points: SkinMetricHistoryPoint[], metricKey: string): SkinProgressMetricSummary {
  const metricPoints = uniqueMetricPoints(points, metricKey);
  const source = sourceFor(metricPoints);
  const first = metricPoints[0];
  const latest = metricPoints[metricPoints.length - 1];
  if (source === "mixed") {
    return { metricKey, pointCount: metricPoints.length, firstScore: first?.score, latestScore: latest?.score, direction: "mixed", source, note: sourceNote(source, metricPoints.length, "mixed") };
  }
  if (metricPoints.length < 2 || !first || !latest) {
    return { metricKey, pointCount: metricPoints.length, firstScore: first?.score, latestScore: latest?.score, direction: "insufficient", source, note: sourceNote(source, metricPoints.length, "insufficient") };
  }
  const delta = Math.round((latest.score - first.score) * 10) / 10;
  const direction: SkinProgressDirection = Math.abs(delta) < 3 ? "steady" : delta > 0 ? "up" : "down";
  return { metricKey, pointCount: metricPoints.length, firstScore: first.score, latestScore: latest.score, delta, direction, source, note: sourceNote(source, metricPoints.length, direction) };
}

export function buildSkinProgressOverview(points: SkinMetricHistoryPoint[], metrics: ProgressMetricConfig[] = PROGRESS_METRICS): SkinProgressOverview {
  const uniqueScans = new Map<string, SkinMetricHistoryPoint>();
  for (const point of points) {
    const current = uniqueScans.get(point.scanId);
    if (!current || toTime(point.capturedAt) > toTime(current.capturedAt)) uniqueScans.set(point.scanId, point);
  }
  const scanPoints = [...uniqueScans.values()].sort((left, right) => toTime(left.capturedAt) - toTime(right.capturedAt));
  const sources = [...new Set(scanPoints.map((point) => point.source).filter((source): source is "youcam" | "demo" | "cached" => source === "youcam" || source === "demo" || source === "cached"))];
  const captureDayCount = new Set(scanPoints.map((point) => point.capturedAt.slice(0, 10))).size;
  const metricSummaries = metrics.map((metric) => buildSkinProgressMetricSummary(points, metric.key));
  const note = scanPoints.length === 0
    ? "No local normalized snapshots are available yet. Complete a demo or optional live scan to begin a local reflection history."
    : sources.length > 1
      ? "Your local history contains more than one source context. Metrics remain visible, but mixed sources are not combined into a personal direction."
      : sources[0] === "demo"
        ? "This overview contains fictional Demo Mode reference values, not personal progress."
        : "Local normalized snapshot history is available for reflection. It is not a clinical assessment.";
  return { snapshotCount: scanPoints.length, captureDayCount, firstCapturedAt: scanPoints[0]?.capturedAt, latestCapturedAt: scanPoints[scanPoints.length - 1]?.capturedAt, sources, metricSummaries, note };
}

export function getSkinProgressMetricPoints(points: SkinMetricHistoryPoint[], metricKey: string, limit = 7): SkinMetricHistoryPoint[] {
  return uniqueMetricPoints(points, metricKey).slice(-Math.max(1, Math.min(30, limit)));
}

export function progressDirectionLabel(direction: SkinProgressDirection): string {
  if (direction === "up") return "Up";
  if (direction === "down") return "Down";
  if (direction === "steady") return "Steady";
  if (direction === "mixed") return "Mixed sources";
  return "More snapshots needed";
}
