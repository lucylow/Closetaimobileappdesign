import AsyncStorage from "@react-native-async-storage/async-storage";

import type { AiShoesRenderStyle, AiShoesRenderingSetting } from "@shared/ai-shoes-tryon";

export type AiShoesRetryQueueEntry = {
  targetUri: string;
  referenceUri: string;
  style: AiShoesRenderStyle;
  renderingSetting: AiShoesRenderingSetting;
  targetPhotoConfirmed: true;
  referenceConfirmed: true;
  consent: true;
  queuedAt: string;
  reason: "provider-unavailable";
};

const STORAGE_KEY = "@closetai_ai_shoes_retry_queue_v1";
const MAX_QUEUE_AGE_MS = 24 * 60 * 60 * 1000;

function isValidUri(value: unknown): value is string {
  return typeof value === "string" && value.trim().length > 0 && value.length <= 4096;
}

function isValidEntry(value: unknown): value is AiShoesRetryQueueEntry {
  if (!value || typeof value !== "object") return false;
  const entry = value as Partial<AiShoesRetryQueueEntry>;
  if (!isValidUri(entry.targetUri) || !isValidUri(entry.referenceUri)) return false;
  if (typeof entry.style !== "string" || typeof entry.renderingSetting !== "string") return false;
  if (entry.targetPhotoConfirmed !== true || entry.referenceConfirmed !== true || entry.consent !== true) return false;
  if (entry.reason !== "provider-unavailable" || typeof entry.queuedAt !== "string") return false;
  const queuedAt = Date.parse(entry.queuedAt);
  return Number.isFinite(queuedAt) && Date.now() - queuedAt >= 0 && Date.now() - queuedAt <= MAX_QUEUE_AGE_MS;
}

export function createAiShoesRetryQueueEntry(input: Omit<AiShoesRetryQueueEntry, "queuedAt" | "reason">): AiShoesRetryQueueEntry {
  return {
    ...input,
    queuedAt: new Date().toISOString(),
    reason: "provider-unavailable",
  };
}

export async function saveAiShoesRetryQueue(entry: AiShoesRetryQueueEntry): Promise<void> {
  if (!isValidEntry(entry)) throw new Error("Invalid local AI Shoes retry entry.");
  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(entry));
}

export async function loadAiShoesRetryQueue(): Promise<AiShoesRetryQueueEntry | null> {
  try {
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed: unknown = JSON.parse(raw);
    if (!isValidEntry(parsed)) {
      await AsyncStorage.removeItem(STORAGE_KEY);
      return null;
    }
    return parsed;
  } catch {
    return null;
  }
}

export async function clearAiShoesRetryQueue(): Promise<void> {
  try {
    await AsyncStorage.removeItem(STORAGE_KEY);
  } catch {
    // Local recovery state is best-effort and must never block the native flow.
  }
}
