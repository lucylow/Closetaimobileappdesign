import { apiRequest } from "@/lib/query-client";
import type { AgingSimulationResult } from "@shared/aging-simulation";

export type AgingSimulationResponse = {
  simulation: AgingSimulationResult;
  disclosure: string;
};

export async function createAgingSimulation(imageBase64: string, consent: boolean): Promise<AgingSimulationResponse> {
  const response = await apiRequest("POST", "/api/skin/aging", { imageBase64, consent });
  return response.json();
}
