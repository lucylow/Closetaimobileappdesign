import type { FashionTryOnResultProvider } from '@shared/fashion-tryon-result';

export interface WardrobeItem {
  id: string;
  name: string;
  category: 'top' | 'bottom' | 'dress' | 'outerwear' | 'shoes' | 'activewear' | 'swimwear' | 'bag' | 'hat' | 'jewelry';
  color: string;
  brand: string;
  imageUrl: string;
  tags: string[];
  usageCount: number;
  lastWorn: string | null;
  notes: string;
  createdAt: string;
}

export interface Outfit {
  id: string;
  name: string;
  items: WardrobeItem[];
  tags: string[];
  reason: string;
  occasion: string;
  rating: 'like' | 'neutral' | 'dislike' | null;
  saved: boolean;
  explanation: string;
  score: number;
  imageUrl?: string;
}

export interface TryOnResult {
  id: string;
  selfieUri: string;
  garmentIds: string[];
  resultImageUrl: string;
  status: 'pending' | 'processing' | 'done' | 'error';
  createdAt: string;
  /** True only when the screen is intentionally displaying the user's original image. */
  isUserPhotoPreview?: boolean;
  /** A concise, user-facing explanation for an unavailable live provider or demo fallback. */
  disclosure?: string;
  /** Provider used for the visible result, if known. */
  provider?: FashionTryOnResultProvider;
}

export interface CaptionResult {
  caption: string;
  hashtags: string[];
  styledImageUrl?: string;
  source?: 'live-ai' | 'demo';
  fallbackReason?: string;
}

export const CATEGORY_ICONS: Record<string, { icon: string; family: string }> = {
  top: { icon: 'shirt-outline', family: 'Ionicons' },
  bottom: { icon: 'body-outline', family: 'Ionicons' },
  dress: { icon: 'woman-outline', family: 'Ionicons' },
  outerwear: { icon: 'cloudy-outline', family: 'Ionicons' },
  shoes: { icon: 'footsteps-outline', family: 'Ionicons' },
  activewear: { icon: 'fitness-outline', family: 'Ionicons' },
  swimwear: { icon: 'water-outline', family: 'Ionicons' },
  bag: { icon: 'bag-outline', family: 'Ionicons' },
  hat: { icon: 'sunny-outline', family: 'Ionicons' },
  jewelry: { icon: 'diamond-outline', family: 'Ionicons' },
};

export const CATEGORIES = ['top', 'bottom', 'dress', 'outerwear', 'shoes', 'activewear', 'swimwear', 'bag', 'hat', 'jewelry'] as const;

export const COLORS = [
  { name: 'Black', hex: '#1A1A1A' },
  { name: 'White', hex: '#F5F5F5' },
  { name: 'Navy', hex: '#1B2838' },
  { name: 'Gray', hex: '#808080' },
  { name: 'Beige', hex: '#D4B896' },
  { name: 'Brown', hex: '#8B4513' },
  { name: 'Red', hex: '#C0392B' },
  { name: 'Blue', hex: '#2980B9' },
  { name: 'Green', hex: '#27AE60' },
  { name: 'Pink', hex: '#E91E8C' },
  { name: 'Purple', hex: '#8E44AD' },
  { name: 'Yellow', hex: '#F1C40F' },
  { name: 'Orange', hex: '#E67E22' },
  { name: 'Teal', hex: '#16A085' },
];

const DEMO_IMAGES = [
  'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=400',
  'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=400',
  'https://images.unsplash.com/photo-1434389677669-e08b4cda3a38?w=400',
  'https://images.unsplash.com/photo-1542272604-787c3835535d?w=400',
  'https://images.unsplash.com/photo-1560769629-975ec94e6a86?w=400',
  'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=400',
  'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=400',
  'https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?w=400',
];

/**
 * Additional sourced garment-only reference images used solely by the opt-in fictional Demo Mode.
 * The source register is retained at assets/demo-garments/ASSET_SOURCES.md.
 */
export const FICTIONAL_DEMO_GARMENT_REFERENCE_IMAGES = [
  'https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/QimdFCItxDelThHP.jpg',
  'https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/nSBLCBOpQegKgBaO.jpg',
  'https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/TpsfGKhIQidWfUle.jpg',
  'https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/kUChShMwgUWugMzI.jpg',
  'https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/nVekdlwJfjFlXLyZ.jpg',
  'https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/mtnUoSsWkSbREpFS.jpg',
  'https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/uEGuUQznzoQGxTyI.jpg',
  'https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/aoDpHwsuIVqkqJpl.jpg',
  'https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/GaOMnbGAuDYVmWGG.jpg',
  'https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/hjmzuQIkJyHxhodK.jpg',
  'https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/XEbwjTSbANPzrRPD.jpg',
] as const;

export const demoWardrobeItems: WardrobeItem[] = [
  {
    id: 'demo-1',
    name: 'Classic White Tee',
    category: 'top',
    color: 'White',
    brand: 'Everlane',
    imageUrl: DEMO_IMAGES[0],
    tags: ['casual', 'essential', 'summer'],
    usageCount: 12,
    lastWorn: '2026-02-15',
    notes: 'Perfect basic',
    createdAt: '2026-01-01',
  },
  {
    id: 'demo-2',
    name: 'Navy Blazer',
    category: 'outerwear',
    color: 'Navy',
    brand: 'J.Crew',
    imageUrl: DEMO_IMAGES[1],
    tags: ['office', 'formal', 'versatile'],
    usageCount: 8,
    lastWorn: '2026-02-10',
    notes: 'Great for meetings',
    createdAt: '2026-01-05',
  },
  {
    id: 'demo-3',
    name: 'Silk Blouse',
    category: 'top',
    color: 'Beige',
    brand: 'Reformation',
    imageUrl: DEMO_IMAGES[2],
    tags: ['elegant', 'date night'],
    usageCount: 5,
    lastWorn: '2026-02-12',
    notes: '',
    createdAt: '2026-01-10',
  },
  {
    id: 'demo-4',
    name: 'Dark Wash Jeans',
    category: 'bottom',
    color: 'Blue',
    brand: "Levi's",
    imageUrl: DEMO_IMAGES[3],
    tags: ['casual', 'everyday', 'denim'],
    usageCount: 20,
    lastWorn: '2026-02-18',
    notes: 'Go-to jeans',
    createdAt: '2026-01-02',
  },
  {
    id: 'demo-5',
    name: 'White Sneakers',
    category: 'shoes',
    color: 'White',
    brand: 'Common Projects',
    imageUrl: DEMO_IMAGES[4],
    tags: ['casual', 'clean', 'versatile'],
    usageCount: 15,
    lastWorn: '2026-02-17',
    notes: '',
    createdAt: '2026-01-03',
  },
  {
    id: 'demo-6',
    name: 'Leather Jacket',
    category: 'outerwear',
    color: 'Black',
    brand: 'AllSaints',
    imageUrl: DEMO_IMAGES[5],
    tags: ['edgy', 'night out', 'cool'],
    usageCount: 6,
    lastWorn: '2026-02-08',
    notes: 'Statement piece',
    createdAt: '2026-01-15',
  },
  {
    id: 'demo-7',
    name: 'Striped Oxford',
    category: 'top',
    color: 'Blue',
    brand: 'Brooks Brothers',
    imageUrl: DEMO_IMAGES[6],
    tags: ['office', 'preppy', 'smart casual'],
    usageCount: 9,
    lastWorn: '2026-02-14',
    notes: '',
    createdAt: '2026-01-20',
  },
  {
    id: 'demo-8',
    name: 'Chino Pants',
    category: 'bottom',
    color: 'Beige',
    brand: 'Bonobos',
    imageUrl: DEMO_IMAGES[7],
    tags: ['smart casual', 'office', 'versatile'],
    usageCount: 11,
    lastWorn: '2026-02-16',
    notes: '',
    createdAt: '2026-01-08',
  },
  {
    id: 'demo-9',
    name: 'Birkin 30 Togo',
    category: 'bag',
    color: 'Brown',
    brand: 'Hermès',
    imageUrl: 'https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/uEGuUQznzoQGxTyI.jpg',
    tags: ['luxury', 'heritage', 'statement', 'iconic'],
    usageCount: 18,
    lastWorn: '2026-02-18',
    notes: 'Gold hardware heritage piece',
    createdAt: '2026-01-11',
  },
  {
    id: 'demo-10',
    name: 'Tweed Bouclé Jacket',
    category: 'outerwear',
    color: 'White',
    brand: 'Chanel',
    imageUrl: 'https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/aoDpHwsuIVqkqJpl.jpg',
    tags: ['luxury', 'haute couture', 'classic', 'tweed'],
    usageCount: 7,
    lastWorn: '2026-02-14',
    notes: 'Timeless tailored tweed',
    createdAt: '2026-01-12',
  },
  {
    id: 'demo-11',
    name: 'Horsebit Leather Loafers',
    category: 'shoes',
    color: 'Black',
    brand: 'Gucci',
    imageUrl: 'https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/GaOMnbGAuDYVmWGG.jpg',
    tags: ['luxury', 'tailored', 'leather', 'shoes'],
    usageCount: 22,
    lastWorn: '2026-02-17',
    notes: 'Classic gold horsebit hardware',
    createdAt: '2026-01-13',
  },
  {
    id: 'demo-12',
    name: 'Monogram Silk Square',
    category: 'hat',
    color: 'Red',
    brand: 'Louis Vuitton',
    imageUrl: 'https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/hjmzuQIkJyHxhodK.jpg',
    tags: ['luxury', 'silk', 'accessory', 'scarf'],
    usageCount: 14,
    lastWorn: '2026-02-16',
    notes: 'Vibrant silk twill',
    createdAt: '2026-01-14',
  },
  {
    id: 'demo-13',
    name: 'Saddle Bag with Strap',
    category: 'bag',
    color: 'Blue',
    brand: 'Dior',
    imageUrl: 'https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/XEbwjTSbANPzrRPD.jpg',
    tags: ['luxury', 'statement', 'iconic', 'bag'],
    usageCount: 16,
    lastWorn: '2026-02-17',
    notes: 'Contoured silhouette with hardware signature',
    createdAt: '2026-01-15',
  },
  {
    id: 'demo-14',
    name: 'Baguette Embroidered Canvas',
    category: 'bag',
    color: 'Purple',
    brand: 'Fendi',
    imageUrl: 'https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/aoDpHwsuIVqkqJpl.jpg',
    tags: ['luxury', 'embroidered', 'bag', 'evening'],
    usageCount: 11,
    lastWorn: '2026-02-15',
    notes: 'Iconic underarm shoulder bag',
    createdAt: '2026-01-16',
  },
  {
    id: 'demo-15',
    name: 'Re-Edition Nylon Bomber',
    category: 'outerwear',
    color: 'Black',
    brand: 'Prada',
    imageUrl: 'https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/GaOMnbGAuDYVmWGG.jpg',
    tags: ['luxury', 'technical', 'outerwear', 'modern'],
    usageCount: 9,
    lastWorn: '2026-02-14',
    notes: 'Sleek technical nylon finish',
    createdAt: '2026-01-17',
  },
  {
    id: 'demo-16',
    name: 'Cat-Eye Acetate Sunglasses',
    category: 'hat',
    color: 'Black',
    brand: 'Saint Laurent',
    imageUrl: 'https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/uEGuUQznzoQGxTyI.jpg',
    tags: ['luxury', 'accessory', 'sunglasses'],
    usageCount: 19,
    lastWorn: '2026-02-18',
    notes: 'Bold archival frames',
    createdAt: '2026-01-18',
  },
  {
    id: 'demo-17',
    name: 'Quashed Lambskin Cardholder',
    category: 'jewelry',
    color: 'Burgundy',
    brand: 'Bottega Veneta',
    imageUrl: 'https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/aoDpHwsuIVqkqJpl.jpg',
    tags: ['luxury', 'leather', 'accessory'],
    usageCount: 25,
    lastWorn: '2026-02-18',
    notes: 'Intrecciato woven leather craft',
    createdAt: '2026-01-19',
  },
  {
    id: 'demo-18',
    name: 'Trench Coat in Cotton Gabardine',
    category: 'outerwear',
    color: 'Beige',
    brand: 'Burberry',
    imageUrl: 'https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/GaOMnbGAuDYVmWGG.jpg',
    tags: ['luxury', 'outerwear', 'classic', 'trench'],
    usageCount: 13,
    lastWorn: '2026-02-16',
    notes: 'Heritage double-breasted silhouette',
    createdAt: '2026-01-20',
  },
  {
    id: 'demo-19',
    name: 'Medusa Leather Belt',
    category: 'jewelry',
    color: 'Black',
    brand: 'Versace',
    imageUrl: 'https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/hjmzuQIkJyHxhodK.jpg',
    tags: ['luxury', 'belt', 'statement', 'accessory'],
    usageCount: 10,
    lastWorn: '2026-02-15',
    notes: 'Polished hardware statement buckle',
    createdAt: '2026-01-21',
  },
  {
    id: 'demo-20',
    name: 'Rockstud Leather Pumps',
    category: 'shoes',
    color: 'Nude',
    brand: 'Valentino',
    imageUrl: 'https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/XEbwjTSbANPzrRPD.jpg',
    tags: ['luxury', 'shoes', 'evening', 'pumps'],
    usageCount: 8,
    lastWorn: '2026-02-13',
    notes: 'Signature studded trim detail',
    createdAt: '2026-01-22',
  },
];

export const demoOutfits: Outfit[] = [
  {
    id: 'outfit-1',
    name: 'Smart Casual Friday',
    items: [demoWardrobeItems[6], demoWardrobeItems[3], demoWardrobeItems[4]],
    tags: ['office', 'smart casual', 'friday'],
    reason: 'Perfect balance of professional and relaxed',
    occasion: 'Office',
    rating: null,
    saved: false,
    explanation: 'The striped oxford adds polish while dark jeans and white sneakers keep it relaxed. Great for a Friday office look that transitions to happy hour.',
    score: 0.91,
  },
  {
    id: 'outfit-2',
    name: 'Weekend Brunch',
    items: [demoWardrobeItems[0], demoWardrobeItems[7], demoWardrobeItems[4]],
    tags: ['brunch', 'casual', 'weekend'],
    reason: 'Effortlessly put-together for a relaxed meal',
    occasion: 'Brunch',
    rating: null,
    saved: false,
    explanation: 'A classic white tee with chinos creates a clean, relaxed vibe. The white sneakers tie it together for an effortless weekend look.',
    score: 0.88,
  },
  {
    id: 'outfit-3',
    name: 'Date Night',
    items: [demoWardrobeItems[2], demoWardrobeItems[3], demoWardrobeItems[5]],
    tags: ['date', 'evening', 'chic'],
    reason: 'Elevated evening look with edge',
    occasion: 'Date Night',
    rating: null,
    saved: false,
    explanation: 'The silk blouse adds sophistication, while the leather jacket brings edge. Dark jeans ground the look, making it perfect for dinner and drinks.',
    score: 0.94,
  },
  {
    id: 'outfit-4',
    name: 'Board Meeting',
    items: [demoWardrobeItems[6], demoWardrobeItems[7], demoWardrobeItems[1]],
    tags: ['formal', 'professional', 'meeting'],
    reason: 'Polished and commanding presence',
    occasion: 'Business',
    rating: null,
    saved: false,
    explanation: 'Navy blazer over a striped oxford with chinos strikes the right balance between approachable and authoritative for important meetings.',
    score: 0.95,
  },
  {
    id: 'outfit-5',
    name: 'Haute Couture Heritage',
    items: [demoWardrobeItems[9], demoWardrobeItems[8], demoWardrobeItems[11]],
    tags: ['luxury', 'haute couture', 'statement', 'evening'],
    reason: 'Uncompromising elegance with iconic heritage houses',
    occasion: 'Exhibition',
    rating: null,
    saved: true,
    explanation: 'Combining the Chanel tweed bouclé jacket with the Hermès Birkin and Louis Vuitton silk square creates an exquisite high-fashion statement.',
    score: 0.98,
  },
  {
    id: 'outfit-6',
    name: 'Milanese Tailoring',
    items: [demoWardrobeItems[1], demoWardrobeItems[7], demoWardrobeItems[10]],
    tags: ['luxury', 'tailored', 'shoes', 'smart casual'],
    reason: 'Impeccable Italian tailoring and footwear',
    occasion: 'Meeting',
    rating: null,
    saved: true,
    explanation: 'Gucci horsebit loafers paired with a structured navy blazer and neutral chinos deliver timeless refinement and effortless polish.',
    score: 0.96,
  },
  {
    id: 'outfit-7',
    name: 'Parisian Editorial',
    items: [demoWardrobeItems[12], demoWardrobeItems[15], demoWardrobeItems[11]],
    tags: ['luxury', 'editorial', 'statement', 'chic'],
    reason: 'Bold sculptural contours and luxury accents',
    occasion: 'City Walk',
    rating: null,
    saved: true,
    explanation: 'The Dior Saddle bag paired with Saint Laurent sunglasses and the Louis Vuitton silk square creates an unmistakable editorial presence.',
    score: 0.97,
  },
  {
    id: 'outfit-8',
    name: 'Roman Noir Technical',
    items: [demoWardrobeItems[14], demoWardrobeItems[13], demoWardrobeItems[15]],
    tags: ['luxury', 'technical', 'evening', 'modern'],
    reason: 'Sleek technical outerwear paired with embroidered luxury accessories',
    occasion: 'Evening',
    rating: null,
    saved: true,
    explanation: 'Prada technical bomber paired with the Fendi embroidered Baguette bag and Saint Laurent sunglasses for a striking modern aesthetic.',
    score: 0.95,
  },
  {
    id: 'outfit-9',
    name: 'Mayfair Heritage Trench',
    items: [demoWardrobeItems[17], demoWardrobeItems[16], demoWardrobeItems[19]],
    tags: ['luxury', 'classic', 'trench', 'tailored'],
    reason: 'Timeless trench coat paired with woven leather craft and statement pumps',
    occasion: 'Daytime Formal',
    rating: null,
    saved: true,
    explanation: 'The classic Burberry gabardine trench paired with the Bottega Veneta cardholder and Valentino pumps delivers timeless British refinement.',
    score: 0.97,
  },
  {
    id: 'outfit-10',
    name: 'Mediterranean Glamour',
    items: [demoWardrobeItems[18], demoWardrobeItems[16], demoWardrobeItems[12]],
    tags: ['luxury', 'statement', 'glamour', 'evening'],
    reason: 'Bold hardware statement buckle paired with rich woven leather and silk',
    occasion: 'Evening Gala',
    rating: null,
    saved: true,
    explanation: 'Versace Medusa belt paired with Bottega Veneta leather craft and the Louis Vuitton silk square creates a lavish evening statement.',
    score: 0.96,
  },
];

export const demoCaptions: CaptionResult[] = [
  {
    caption: 'Friday vibes in full effect. Keeping it smart but never boring.',
    hashtags: ['#OOTD', '#SmartCasual', '#FridayStyle', '#WardrobeGoals', '#ClosetAI'],
  },
  {
    caption: 'Brunch-ready and sunshine approved. Simple done right.',
    hashtags: ['#BrunchOutfit', '#WeekendStyle', '#MinimalFashion', '#CleanAesthetic', '#ClosetAI'],
  },
  {
    caption: 'When the night calls for a little edge and a lot of confidence.',
    hashtags: ['#DateNight', '#EveningWear', '#ChicStyle', '#FashionInspo', '#ClosetAI'],
  },
];

export const ONBOARDING_SLIDES = [
  {
    id: '1',
    title: 'Your Wardrobe in Focus',
    subtitle: 'Capture every garment in stunning detail. AI instantly catalogs, sorts, and indexes your collection.',
    iconName: 'camera-outline' as const,
  },
  {
    id: '2',
    title: 'Instant AI Styling',
    subtitle: 'Browse breathtaking outfit combinations curated automatically for your day, weather, and mood.',
    iconName: 'sparkles-outline' as const,
  },
  {
    id: '3',
    title: 'Immersive Try-On',
    subtitle: 'Preview complete looks instantly with a photo you choose — no guesswork, pure visual clarity.',
    iconName: 'body-outline' as const,
  },
  {
    id: '4',
    title: 'Publish & Inspire',
    subtitle: 'Transform your daily style into striking social cards with AI-crafted captions in one tap.',
    iconName: 'share-social-outline' as const,
  },
];


/**
 * Fictional adult women’s style examples are an opt-in prototype aid only.
 * Their names, wardrobes, contexts, item history, and labels are invented; product-reference
 * images are generic garment media and do not depict, identify, or evaluate a user.
 */
export const FICTIONAL_ADULT_WOMEN_DEMO_DISCLOSURE =
  'Fictional adult women’s style examples: names, wardrobes, activities, and usage details are prototype data only. Garment images are generic reference media, not user photos, live inventory, fit advice, or identity assessments.';

export type FictionalAdultWomenDemoExample = {
  id: string;
  displayName: string;
  audienceLabel: 'Fictional adult women’s style example';
  styleContext: string;
  wardrobe: WardrobeItem[];
};

function fictionalDemoItem(
  exampleId: string,
  index: number,
  input: Omit<WardrobeItem, 'id' | 'createdAt' | 'notes'>,
): WardrobeItem {
  return {
    ...input,
    id: `fictional-adult-women-${exampleId}-${index}`,
    createdAt: '2026-08-12T12:00:00.000Z',
    notes: 'Fictional Demo Mode · Adult women’s example wardrobe. Not a user item, live inventory record, or product recommendation.',
  };
}

const MAYA_WARDROBE: WardrobeItem[] = [
  fictionalDemoItem('maya-city-creative', 1, { name: 'Ivory Ribbed Knit', category: 'top', color: 'Cream', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[0], tags: ['fictional-demo', 'creative office', 'layering'], usageCount: 4, lastWorn: '2026-08-08' }),
  fictionalDemoItem('maya-city-creative', 2, { name: 'Charcoal Wide-Leg Trousers', category: 'bottom', color: 'Gray', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[3], tags: ['fictional-demo', 'creative office', 'tailored'], usageCount: 3, lastWorn: '2026-08-06' }),
  fictionalDemoItem('maya-city-creative', 3, { name: 'Soft Navy Blazer', category: 'outerwear', color: 'Navy', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[1], tags: ['fictional-demo', 'meeting', 'layering'], usageCount: 2, lastWorn: '2026-08-04' }),
  fictionalDemoItem('maya-city-creative', 4, { name: 'Black Slingback Flats', category: 'shoes', color: 'Black', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[4], tags: ['fictional-demo', 'city', 'workday'], usageCount: 5, lastWorn: '2026-08-08' }),
  fictionalDemoItem('maya-city-creative', 5, { name: 'Structured Tan Tote', category: 'bag', color: 'Brown', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[7], tags: ['fictional-demo', 'workday', 'carryall'], usageCount: 5, lastWorn: '2026-08-08' }),
  fictionalDemoItem('maya-city-creative', 6, { name: 'Gold Hoop Earrings', category: 'jewelry', color: 'Gold', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[5], tags: ['fictional-demo', 'minimal', 'evening'], usageCount: 3, lastWorn: '2026-08-06' }),
  fictionalDemoItem('maya-city-creative', 7, { name: 'Terracotta Midi Dress', category: 'dress', color: 'Orange', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[2], tags: ['fictional-demo', 'dinner', 'weekend'], usageCount: 1, lastWorn: '2026-08-03' }),
  fictionalDemoItem('maya-city-creative', 8, { name: 'Lightweight Trench', category: 'outerwear', color: 'Beige', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[6], tags: ['fictional-demo', 'transition weather', 'city'], usageCount: 2, lastWorn: '2026-08-03' }),
  fictionalDemoItem('maya-city-creative', 9, { name: 'Camel Wrap Layer', category: 'outerwear', color: 'Brown', brand: 'Prototype Studio', imageUrl: FICTIONAL_DEMO_GARMENT_REFERENCE_IMAGES[8], tags: ['fictional-demo', 'creative office', 'outerwear reference'], usageCount: 2, lastWorn: '2026-08-10' }),
];

const SOFIA_WARDROBE: WardrobeItem[] = [
  fictionalDemoItem('sofia-active-travel', 1, { name: 'Teal Performance Tank', category: 'activewear', color: 'Teal', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[0], tags: ['fictional-demo', 'active', 'travel'], usageCount: 4, lastWorn: '2026-08-09' }),
  fictionalDemoItem('sofia-active-travel', 2, { name: 'Navy Motion Leggings', category: 'activewear', color: 'Navy', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[3], tags: ['fictional-demo', 'active', 'comfort'], usageCount: 5, lastWorn: '2026-08-09' }),
  fictionalDemoItem('sofia-active-travel', 3, { name: 'White Trail Sneakers', category: 'shoes', color: 'White', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[4], tags: ['fictional-demo', 'active', 'walking'], usageCount: 6, lastWorn: '2026-08-09' }),
  fictionalDemoItem('sofia-active-travel', 4, { name: 'Olive Utility Jacket', category: 'outerwear', color: 'Green', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[1], tags: ['fictional-demo', 'travel', 'layering'], usageCount: 3, lastWorn: '2026-08-07' }),
  fictionalDemoItem('sofia-active-travel', 5, { name: 'Canvas Crossbody Bag', category: 'bag', color: 'Beige', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[7], tags: ['fictional-demo', 'travel', 'hands-free'], usageCount: 4, lastWorn: '2026-08-09' }),
  fictionalDemoItem('sofia-active-travel', 6, { name: 'White Linen Shirt', category: 'top', color: 'White', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[2], tags: ['fictional-demo', 'travel', 'layering'], usageCount: 2, lastWorn: '2026-08-07' }),
  fictionalDemoItem('sofia-active-travel', 7, { name: 'Rose Relaxed Shorts', category: 'bottom', color: 'Pink', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[5], tags: ['fictional-demo', 'weekend', 'warm weather'], usageCount: 2, lastWorn: '2026-08-05' }),
  fictionalDemoItem('sofia-active-travel', 8, { name: 'Coral Sun Hat', category: 'hat', color: 'Orange', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[6], tags: ['fictional-demo', 'outdoors', 'sun'], usageCount: 2, lastWorn: '2026-08-05' }),
  fictionalDemoItem('sofia-active-travel', 9, { name: 'Bright Travel Capsule', category: 'bag', color: 'Pink', brand: 'Prototype Studio', imageUrl: FICTIONAL_DEMO_GARMENT_REFERENCE_IMAGES[10], tags: ['fictional-demo', 'travel', 'accessories reference'], usageCount: 1, lastWorn: '2026-08-10' }),
];

const LEILA_COLOR_CAPSULE_WARDROBE: WardrobeItem[] = [
  fictionalDemoItem('leila-color-capsule', 1, { name: 'Fuchsia Cotton Shirt', category: 'top', color: 'Pink', brand: 'Prototype Studio', imageUrl: FICTIONAL_DEMO_GARMENT_REFERENCE_IMAGES[1], tags: ['fictional-demo', 'color capsule', 'weekend'], usageCount: 3, lastWorn: '2026-08-09' }),
  fictionalDemoItem('leila-color-capsule', 2, { name: 'Indigo Cropped Denim', category: 'bottom', color: 'Blue', brand: 'Prototype Studio', imageUrl: FICTIONAL_DEMO_GARMENT_REFERENCE_IMAGES[1], tags: ['fictional-demo', 'color capsule', 'denim'], usageCount: 4, lastWorn: '2026-08-09' }),
  fictionalDemoItem('leila-color-capsule', 3, { name: 'Red Tailored Blazer', category: 'outerwear', color: 'Red', brand: 'Prototype Studio', imageUrl: FICTIONAL_DEMO_GARMENT_REFERENCE_IMAGES[3], tags: ['fictional-demo', 'color capsule', 'tailored'], usageCount: 2, lastWorn: '2026-08-07' }),
  fictionalDemoItem('leila-color-capsule', 4, { name: 'Minimal Leather Sneakers', category: 'shoes', color: 'White', brand: 'Prototype Studio', imageUrl: FICTIONAL_DEMO_GARMENT_REFERENCE_IMAGES[0], tags: ['fictional-demo', 'city', 'walkable'], usageCount: 5, lastWorn: '2026-08-09' }),
  fictionalDemoItem('leila-color-capsule', 5, { name: 'Blush Zip Pouch', category: 'bag', color: 'Pink', brand: 'Prototype Studio', imageUrl: FICTIONAL_DEMO_GARMENT_REFERENCE_IMAGES[0], tags: ['fictional-demo', 'accessory', 'color capsule'], usageCount: 3, lastWorn: '2026-08-09' }),
  fictionalDemoItem('leila-color-capsule', 6, { name: 'Sky Blue Accent Scarf', category: 'hat', color: 'Blue', brand: 'Prototype Studio', imageUrl: FICTIONAL_DEMO_GARMENT_REFERENCE_IMAGES[1], tags: ['fictional-demo', 'accessory', 'color'], usageCount: 1, lastWorn: '2026-08-07' }),
  fictionalDemoItem('leila-color-capsule', 7, { name: 'Cobalt Day Dress', category: 'dress', color: 'Blue', brand: 'Prototype Studio', imageUrl: FICTIONAL_DEMO_GARMENT_REFERENCE_IMAGES[2], tags: ['fictional-demo', 'event', 'color capsule'], usageCount: 2, lastWorn: '2026-08-05' }),
  fictionalDemoItem('leila-color-capsule', 8, { name: 'Silver Hoop Set', category: 'jewelry', color: 'Gray', brand: 'Prototype Studio', imageUrl: FICTIONAL_DEMO_GARMENT_REFERENCE_IMAGES[0], tags: ['fictional-demo', 'minimal', 'detail'], usageCount: 2, lastWorn: '2026-08-05' }),
  fictionalDemoItem('leila-color-capsule', 9, { name: 'Vivid Weekend Set', category: 'activewear', color: 'Purple', brand: 'Prototype Studio', imageUrl: FICTIONAL_DEMO_GARMENT_REFERENCE_IMAGES[7], tags: ['fictional-demo', 'color capsule', 'activewear reference'], usageCount: 1, lastWorn: '2026-08-10' }),
];

const NORA_WEEKEND_LAYERS_WARDROBE: WardrobeItem[] = [
  fictionalDemoItem('nora-weekend-layers', 1, { name: 'Black Moto Jacket', category: 'outerwear', color: 'Black', brand: 'Prototype Studio', imageUrl: FICTIONAL_DEMO_GARMENT_REFERENCE_IMAGES[2], tags: ['fictional-demo', 'weekend', 'layering'], usageCount: 3, lastWorn: '2026-08-08' }),
  fictionalDemoItem('nora-weekend-layers', 2, { name: 'Floral Evening Dress', category: 'dress', color: 'Purple', brand: 'Prototype Studio', imageUrl: FICTIONAL_DEMO_GARMENT_REFERENCE_IMAGES[2], tags: ['fictional-demo', 'dinner', 'evening'], usageCount: 2, lastWorn: '2026-08-06' }),
  fictionalDemoItem('nora-weekend-layers', 3, { name: 'Sand Knit Shell', category: 'top', color: 'Beige', brand: 'Prototype Studio', imageUrl: FICTIONAL_DEMO_GARMENT_REFERENCE_IMAGES[5], tags: ['fictional-demo', 'weekend', 'neutral'], usageCount: 4, lastWorn: '2026-08-08' }),
  fictionalDemoItem('nora-weekend-layers', 4, { name: 'Relaxed Blue Denim', category: 'bottom', color: 'Blue', brand: 'Prototype Studio', imageUrl: FICTIONAL_DEMO_GARMENT_REFERENCE_IMAGES[5], tags: ['fictional-demo', 'weekend', 'denim'], usageCount: 5, lastWorn: '2026-08-08' }),
  fictionalDemoItem('nora-weekend-layers', 5, { name: 'Cognac Sandals', category: 'shoes', color: 'Brown', brand: 'Prototype Studio', imageUrl: FICTIONAL_DEMO_GARMENT_REFERENCE_IMAGES[5], tags: ['fictional-demo', 'summer', 'walkable'], usageCount: 4, lastWorn: '2026-08-08' }),
  fictionalDemoItem('nora-weekend-layers', 6, { name: 'Mini Travel Camera Bag', category: 'bag', color: 'Black', brand: 'Prototype Studio', imageUrl: FICTIONAL_DEMO_GARMENT_REFERENCE_IMAGES[4], tags: ['fictional-demo', 'weekend', 'carry'], usageCount: 2, lastWorn: '2026-08-06' }),
  fictionalDemoItem('nora-weekend-layers', 7, { name: 'Sporty Lavender Cap', category: 'hat', color: 'Purple', brand: 'Prototype Studio', imageUrl: FICTIONAL_DEMO_GARMENT_REFERENCE_IMAGES[4], tags: ['fictional-demo', 'outdoor', 'active'], usageCount: 2, lastWorn: '2026-08-08' }),
  fictionalDemoItem('nora-weekend-layers', 8, { name: 'Everyday Stud Set', category: 'jewelry', color: 'Gold', brand: 'Prototype Studio', imageUrl: FICTIONAL_DEMO_GARMENT_REFERENCE_IMAGES[0], tags: ['fictional-demo', 'minimal', 'detail'], usageCount: 2, lastWorn: '2026-08-06' }),
  fictionalDemoItem('nora-weekend-layers', 9, { name: 'Neutral Accessory Edit', category: 'bag', color: 'Beige', brand: 'Prototype Studio', imageUrl: FICTIONAL_DEMO_GARMENT_REFERENCE_IMAGES[6], tags: ['fictional-demo', 'weekend', 'accessory reference'], usageCount: 1, lastWorn: '2026-08-10' }),
];

const AISHA_WARDROBE: WardrobeItem[] = [
  fictionalDemoItem('aisha-evening-weekend', 1, { name: 'Cobalt Midi Dress', category: 'dress', color: 'Blue', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[2], tags: ['fictional-demo', 'evening', 'occasion'], usageCount: 2, lastWorn: '2026-08-04' }),
  fictionalDemoItem('aisha-evening-weekend', 2, { name: 'Espresso Cropped Cardigan', category: 'outerwear', color: 'Brown', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[1], tags: ['fictional-demo', 'layering', 'evening'], usageCount: 3, lastWorn: '2026-08-04' }),
  fictionalDemoItem('aisha-evening-weekend', 3, { name: 'Patterned Silk Scarf', category: 'hat', color: 'Purple', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[6], tags: ['fictional-demo', 'accessory', 'color'], usageCount: 2, lastWorn: '2026-08-02' }),
  fictionalDemoItem('aisha-evening-weekend', 4, { name: 'Ivory Pointed Flats', category: 'shoes', color: 'Cream', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[4], tags: ['fictional-demo', 'occasion', 'walkable'], usageCount: 3, lastWorn: '2026-08-04' }),
  fictionalDemoItem('aisha-evening-weekend', 5, { name: 'Berry Leather Bag', category: 'bag', color: 'Red', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[7], tags: ['fictional-demo', 'evening', 'carry'], usageCount: 2, lastWorn: '2026-08-04' }),
  fictionalDemoItem('aisha-evening-weekend', 6, { name: 'Pearl Drop Earrings', category: 'jewelry', color: 'White', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[5], tags: ['fictional-demo', 'occasion', 'detail'], usageCount: 2, lastWorn: '2026-08-04' }),
  fictionalDemoItem('aisha-evening-weekend', 7, { name: 'Soft Lilac Blouse', category: 'top', color: 'Purple', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[0], tags: ['fictional-demo', 'weekend', 'soft color'], usageCount: 3, lastWorn: '2026-08-02' }),
  fictionalDemoItem('aisha-evening-weekend', 8, { name: 'Indigo Straight Jeans', category: 'bottom', color: 'Blue', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[3], tags: ['fictional-demo', 'weekend', 'denim'], usageCount: 4, lastWorn: '2026-08-02' }),
  fictionalDemoItem('aisha-evening-weekend', 9, { name: 'Curated Evening Rail', category: 'outerwear', color: 'Brown', brand: 'Prototype Studio', imageUrl: FICTIONAL_DEMO_GARMENT_REFERENCE_IMAGES[9], tags: ['fictional-demo', 'evening', 'garment rail reference'], usageCount: 1, lastWorn: '2026-08-10' }),
];

const ELENA_WARDROBE: WardrobeItem[] = [
  fictionalDemoItem('elena-architectural', 1, { name: 'Structured Slate Blazer', category: 'outerwear', color: 'Gray', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[1], tags: ['fictional-demo', 'architectural', 'tailored'], usageCount: 4, lastWorn: '2026-08-10' }),
  fictionalDemoItem('elena-architectural', 2, { name: 'Minimalist Black Turtleneck', category: 'top', color: 'Black', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[0], tags: ['fictional-demo', 'monochrome', 'essential'], usageCount: 6, lastWorn: '2026-08-10' }),
  fictionalDemoItem('elena-architectural', 3, { name: 'Pleated Charcoal Midi Skirt', category: 'bottom', color: 'Gray', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[3], tags: ['fictional-demo', 'fluid', 'chic'], usageCount: 3, lastWorn: '2026-08-08' }),
  fictionalDemoItem('elena-architectural', 4, { name: 'Architectural Leather Loafers', category: 'shoes', color: 'Black', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[4], tags: ['fictional-demo', 'footwear', 'minimal'], usageCount: 5, lastWorn: '2026-08-09' }),
  fictionalDemoItem('elena-architectural', 5, { name: 'Monochrome Leather Clutch', category: 'bag', color: 'Black', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[7], tags: ['fictional-demo', 'evening', 'clean'], usageCount: 2, lastWorn: '2026-08-07' }),
  fictionalDemoItem('elena-architectural', 6, { name: 'Geometric Silver Cuff', category: 'jewelry', color: 'Gray', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[5], tags: ['fictional-demo', 'statement', 'metallic'], usageCount: 3, lastWorn: '2026-08-06' }),
];

const CLARA_WARDROBE: WardrobeItem[] = [
  fictionalDemoItem('clara-boho-resort', 1, { name: 'Olive Linen Maxi Dress', category: 'dress', color: 'Green', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[2], tags: ['fictional-demo', 'resort', 'relaxed'], usageCount: 3, lastWorn: '2026-08-09' }),
  fictionalDemoItem('clara-boho-resort', 2, { name: 'Crocheted Cream Cardigan', category: 'outerwear', color: 'Cream', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[1], tags: ['fictional-demo', 'texture', 'layering'], usageCount: 4, lastWorn: '2026-08-09' }),
  fictionalDemoItem('clara-boho-resort', 3, { name: 'Tan Woven Leather Sandals', category: 'shoes', color: 'Brown', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[4], tags: ['fictional-demo', 'summer', 'craft'], usageCount: 5, lastWorn: '2026-08-08' }),
  fictionalDemoItem('clara-boho-resort', 4, { name: 'Straw Sun Basket', category: 'bag', color: 'Beige', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[7], tags: ['fictional-demo', 'market', 'natural'], usageCount: 4, lastWorn: '2026-08-08' }),
  fictionalDemoItem('clara-boho-resort', 5, { name: 'Turquoise Pendant Necklace', category: 'jewelry', color: 'Blue', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[5], tags: ['fictional-demo', 'boho', 'detail'], usageCount: 2, lastWorn: '2026-08-05' }),
];

const BEATRICE_WARDROBE: WardrobeItem[] = [
  fictionalDemoItem('beatrice-evening-gala', 1, { name: 'Velvet Emerald Gown', category: 'dress', color: 'Green', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[2], tags: ['fictional-demo', 'gala', 'evening'], usageCount: 2, lastWorn: '2026-08-01' }),
  fictionalDemoItem('beatrice-evening-gala', 2, { name: 'Satin Evening Wrap', category: 'outerwear', color: 'Black', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[1], tags: ['fictional-demo', 'formal', 'wrap'], usageCount: 3, lastWorn: '2026-08-01' }),
  fictionalDemoItem('beatrice-evening-gala', 3, { name: 'Metallic Heeled Sandals', category: 'shoes', color: 'Gold', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[4], tags: ['fictional-demo', 'formal', 'heels'], usageCount: 4, lastWorn: '2026-08-01' }),
  fictionalDemoItem('beatrice-evening-gala', 4, { name: 'Crystal Evening Clutch', category: 'bag', color: 'Silver', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[7], tags: ['fictional-demo', 'gala', 'sparkle'], usageCount: 2, lastWorn: '2026-08-01' }),
  fictionalDemoItem('beatrice-evening-gala', 5, { name: 'Diamond Drop Earrings', category: 'jewelry', color: 'White', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[5], tags: ['fictional-demo', 'luxury', 'jewelry'], usageCount: 3, lastWorn: '2026-08-01' }),
];

const ZOE_WARDROBE: WardrobeItem[] = [
  fictionalDemoItem('zoe-urban-streetwear', 1, { name: 'Oversized Graphic Hoodie', category: 'top', color: 'Black', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[0], tags: ['fictional-demo', 'streetwear', 'casual'], usageCount: 6, lastWorn: '2026-08-11' }),
  fictionalDemoItem('zoe-urban-streetwear', 2, { name: 'Utility Cargo Pants', category: 'bottom', color: 'Green', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[3], tags: ['fictional-demo', 'utility', 'streetwear'], usageCount: 5, lastWorn: '2026-08-11' }),
  fictionalDemoItem('zoe-urban-streetwear', 3, { name: 'Chunky Retro Sneakers', category: 'shoes', color: 'White', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[4], tags: ['fictional-demo', 'sneakers', 'street'], usageCount: 7, lastWorn: '2026-08-11' }),
  fictionalDemoItem('zoe-urban-streetwear', 4, { name: 'Nylon Crossbody Pack', category: 'bag', color: 'Black', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[7], tags: ['fictional-demo', 'utility', 'pack'], usageCount: 4, lastWorn: '2026-08-10' }),
  fictionalDemoItem('zoe-urban-streetwear', 5, { name: 'Minimalist Beanie', category: 'hat', color: 'Gray', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[6], tags: ['fictional-demo', 'accessory', 'headwear'], usageCount: 3, lastWorn: '2026-08-09' }),
];

const MIA_WARDROBE: WardrobeItem[] = [
  fictionalDemoItem('mia-coastal-minimalist', 1, { name: 'Crisp White Poplin Shirt', category: 'top', color: 'White', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[0], tags: ['fictional-demo', 'coastal', 'minimalist'], usageCount: 5, lastWorn: '2026-08-12' }),
  fictionalDemoItem('mia-coastal-minimalist', 2, { name: 'Sand Tailored Linen Trousers', category: 'bottom', color: 'Beige', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[3], tags: ['fictional-demo', 'linen', 'relaxed'], usageCount: 4, lastWorn: '2026-08-12' }),
  fictionalDemoItem('mia-coastal-minimalist', 3, { name: 'Leather Slide Sandals', category: 'shoes', color: 'Brown', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[4], tags: ['fictional-demo', 'summer', 'slide'], usageCount: 6, lastWorn: '2026-08-11' }),
  fictionalDemoItem('mia-coastal-minimalist', 4, { name: 'Canvas Tote Bag', category: 'bag', color: 'Beige', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[7], tags: ['fictional-demo', 'canvas', 'tote'], usageCount: 5, lastWorn: '2026-08-11' }),
  fictionalDemoItem('mia-coastal-minimalist', 5, { name: 'Tortoiseshell Sunglasses', category: 'jewelry', color: 'Brown', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[5], tags: ['fictional-demo', 'accessory', 'sun'], usageCount: 4, lastWorn: '2026-08-10' }),
];

const AMARA_WARDROBE: WardrobeItem[] = [
  fictionalDemoItem('amara-heritage-prep', 1, { name: 'Cable Knit Cream Sweater', category: 'top', color: 'Cream', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[0], tags: ['fictional-demo', 'prep', 'heritage'], usageCount: 5, lastWorn: '2026-08-12' }),
  fictionalDemoItem('amara-heritage-prep', 2, { name: 'Pleated Navy Tennis Skirt', category: 'bottom', color: 'Navy', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[3], tags: ['fictional-demo', 'prep', 'classic'], usageCount: 4, lastWorn: '2026-08-12' }),
  fictionalDemoItem('amara-heritage-prep', 3, { name: 'Leather Penny Loafers', category: 'shoes', color: 'Brown', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[4], tags: ['fictional-demo', 'footwear', 'prep'], usageCount: 6, lastWorn: '2026-08-11' }),
  fictionalDemoItem('amara-heritage-prep', 4, { name: 'Structured Satchel Bag', category: 'bag', color: 'Brown', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[7], tags: ['fictional-demo', 'satchel', 'classic'], usageCount: 4, lastWorn: '2026-08-10' }),
  fictionalDemoItem('amara-heritage-prep', 5, { name: 'Gold Signet Ring', category: 'jewelry', color: 'Gold', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[5], tags: ['fictional-demo', 'heritage', 'detail'], usageCount: 5, lastWorn: '2026-08-10' }),
];

const SELENA_WARDROBE: WardrobeItem[] = [
  fictionalDemoItem('selena-modern-tailoring', 1, { name: 'Tailored Camel Blazer', category: 'outerwear', color: 'Brown', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[1], tags: ['fictional-demo', 'tailoring', 'workwear'], usageCount: 5, lastWorn: '2026-08-12' }),
  fictionalDemoItem('selena-modern-tailoring', 2, { name: 'Silk Satin Camisole', category: 'top', color: 'White', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[0], tags: ['fictional-demo', 'silk', 'luxury'], usageCount: 4, lastWorn: '2026-08-12' }),
  fictionalDemoItem('selena-modern-tailoring', 3, { name: 'High-Waist Black Trousers', category: 'bottom', color: 'Black', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[3], tags: ['fictional-demo', 'tailored', 'sleek'], usageCount: 6, lastWorn: '2026-08-11' }),
  fictionalDemoItem('selena-modern-tailoring', 4, { name: 'Pointed Leather Pumps', category: 'shoes', color: 'Black', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[4], tags: ['fictional-demo', 'pumps', 'formal'], usageCount: 5, lastWorn: '2026-08-11' }),
  fictionalDemoItem('selena-modern-tailoring', 5, { name: 'Structured Leather Briefcase', category: 'bag', color: 'Brown', brand: 'Prototype Studio', imageUrl: DEMO_IMAGES[7], tags: ['fictional-demo', 'executive', 'bag'], usageCount: 4, lastWorn: '2026-08-10' }),
];

export const fictionalAdultWomenDemoExamples: FictionalAdultWomenDemoExample[] = [
  { id: 'maya-city-creative', displayName: 'Maya', audienceLabel: 'Fictional adult women’s style example', styleContext: 'Creative office, gallery opening, and city dinner context.', wardrobe: MAYA_WARDROBE },
  { id: 'sofia-active-travel', displayName: 'Sofia', audienceLabel: 'Fictional adult women’s style example', styleContext: 'Active weekend, travel day, and casual errand context.', wardrobe: SOFIA_WARDROBE },
  { id: 'aisha-evening-weekend', displayName: 'Aisha', audienceLabel: 'Fictional adult women’s style example', styleContext: 'Weekend gathering, evening plan, and elevated casual context.', wardrobe: AISHA_WARDROBE },
  { id: 'leila-color-capsule', displayName: 'Leila', audienceLabel: 'Fictional adult women’s style example', styleContext: 'Color capsule, design studio, and polished daytime context.', wardrobe: LEILA_COLOR_CAPSULE_WARDROBE },
  { id: 'nora-weekend-layers', displayName: 'Nora', audienceLabel: 'Fictional adult women’s style example', styleContext: 'Layered weekend, local event, and relaxed travel context.', wardrobe: NORA_WEEKEND_LAYERS_WARDROBE },
  { id: 'elena-architectural', displayName: 'Elena', audienceLabel: 'Fictional adult women’s style example', styleContext: 'Architectural tailoring, monochrome studio work, and gallery nights.', wardrobe: ELENA_WARDROBE },
  { id: 'clara-boho-resort', displayName: 'Clara', audienceLabel: 'Fictional adult women’s style example', styleContext: 'Boho resort, relaxed weekend getaways, and artisanal styling.', wardrobe: CLARA_WARDROBE },
  { id: 'beatrice-evening-gala', displayName: 'Beatrice', audienceLabel: 'Fictional adult women’s style example', styleContext: 'Black tie gala, opera evenings, and formal luxury events.', wardrobe: BEATRICE_WARDROBE },
  { id: 'zoe-urban-streetwear', displayName: 'Zoe', audienceLabel: 'Fictional adult women’s style example', styleContext: 'Urban streetwear, creative studios, and weekend skateboarding.', wardrobe: ZOE_WARDROBE },
  { id: 'mia-coastal-minimalist', displayName: 'Mia', audienceLabel: 'Fictional adult women’s style example', styleContext: 'Coastal minimalist, seaside brunch, and breezy summer days.', wardrobe: MIA_WARDROBE },
  { id: 'amara-heritage-prep', displayName: 'Amara', audienceLabel: 'Fictional adult women’s style example', styleContext: 'Heritage prep, collegiate campus, and crisp autumn layering.', wardrobe: AMARA_WARDROBE },
  { id: 'selena-modern-tailoring', displayName: 'Selena', audienceLabel: 'Fictional adult women’s style example', styleContext: 'Modern executive tailoring, boardroom presentations, and upscale networking.', wardrobe: SELENA_WARDROBE },
];

/** Returns a fresh local copy so choosing a demo cannot mutate the catalog fixture. */
export function cloneFictionalAdultWomenDemoExample(id: string): FictionalAdultWomenDemoExample | undefined {
  const example = fictionalAdultWomenDemoExamples.find((candidate) => candidate.id === id);
  if (!example) return undefined;
  return {
    ...example,
    wardrobe: example.wardrobe.map((item) => ({ ...item, tags: [...item.tags] })),
  };
}
