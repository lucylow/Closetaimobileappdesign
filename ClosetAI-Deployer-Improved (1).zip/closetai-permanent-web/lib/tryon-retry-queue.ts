import AsyncStorage from "@react-native-async-storage/async-storage";

export type TryOnRetryQueueEntry = {
  selfieUri: string;
  garmentIds: string[];
  queuedAt: string;
  reason: "provider-unavailable";
};

const STORAGE_KEY = "@closetai_tryon_retry_queue_v1";
const MAX_QUEUE_AGE_MS = 24 * 60 * 60 * 1000;
const MAX_GARMENTS = 12;

function isValidUri(value: unknown): value is string {
  return typeof value === "string" && value.trim().length > 0 && value.length <= 4096;
}

function isValidEntry(value: unknown): value is TryOnRetryQueueEntry {
  if (!value || typeof value !== "object") return false;
  const entry = value as Partial<TryOnRetryQueueEntry>;
  if (!isValidUri(entry.selfieUri) || !Array.isArray(entry.garmentIds)) return false;
  if (entry.garmentIds.length === 0 || entry.garmentIds.length > MAX_GARMENTS) return false;
  if (!entry.garmentIds.every((id) => typeof id === "string" && id.trim().length > 0 && id.length <= 160)) return false;
  if (entry.reason !== "provider-unavailable" || typeof entry.queuedAt !== "string") return false;
  const queuedAt = Date.parse(entry.queuedAt);
  return Number.isFinite(queuedAt) && Date.now() - queuedAt >= 0 && Date.now() - queuedAt <= MAX_QUEUE_AGE_MS;
}

export function createTryOnRetryQueueEntry(selfieUri: string, garmentIds: string[]): TryOnRetryQueueEntry {
  return {
    selfieUri,
    garmentIds: [...new Set(garmentIds)].slice(0, MAX_GARMENTS),
    queuedAt: new Date().toISOString(),
    reason: "provider-unavailable",
  };
}

export async function saveTryOnRetryQueue(entry: TryOnRetryQueueEntry): Promise<void> {
  if (!isValidEntry(entry)) throw new Error("Invalid local try-on retry entry.");
  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(entry));
}

export async function loadTryOnRetryQueue(): Promise<TryOnRetryQueueEntry | null> {
  try {
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed: unknown = JSON.parse(raw);
    if (!isValidEntry(parsed)) {
      await AsyncStorage.removeItem(STORAGE_KEY);
      return null;
    }
    return parsed;
  } catch {
    return null;
  }
}

export async function clearTryOnRetryQueue(): Promise<void> {
  try {
    await AsyncStorage.removeItem(STORAGE_KEY);
  } catch {
    // Local recovery state is best-effort and must never block the try-on flow.
  }
}
