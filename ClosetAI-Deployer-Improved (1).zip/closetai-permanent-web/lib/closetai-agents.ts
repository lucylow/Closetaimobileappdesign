import type { ClosetAgentPlan, ClosetAgentRequest } from "@shared/closetai-agent-contracts";
import { apiRequest } from "@/lib/query-client";

export type { ClosetAgentPlan, ClosetAgentRequest } from "@shared/closetai-agent-contracts";

export async function requestClosetAgentPlan(request: ClosetAgentRequest): Promise<ClosetAgentPlan> {
  const response = await apiRequest("POST", "/api/agents/plan", request);
  return response.json();
}
