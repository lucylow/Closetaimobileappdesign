import { apiRequest } from "@/lib/query-client";
import type { FaceLiftFeatures, FaceLiftSimulationResult } from "@shared/face-lift-simulation";

export type FaceLiftSimulationResponse = {
  simulation: FaceLiftSimulationResult;
  disclosure: string;
};

export async function createFaceLiftSimulation(input: {
  imageBase64: string;
  features: FaceLiftFeatures;
  consent: boolean;
}): Promise<FaceLiftSimulationResponse> {
  const response = await apiRequest("POST", "/api/skin/face-lift", input);
  return response.json();
}
