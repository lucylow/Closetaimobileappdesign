import { getCatalogProduct } from "@/lib/skin-product-catalog";
import { ULTRA_LUXURY_SKIN_DISCOVERY_RECORDS } from "@/lib/ultra-luxury-skin-discovery";

export type CommerceProviderName = "mock" | "shopify" | "woocommerce";
export type CommerceAvailability = "in_stock" | "low_stock" | "out_of_stock";

/** Mandatory disclosure whenever prototype commerce values are shown or returned. */
export const MOCK_COMMERCE_DISCLOSURE = "Mock commerce catalog: price, inventory, cart, and checkout values are fictional prototype data. No live store transaction is available.";

export type CommerceListing = {
  provider: CommerceProviderName;
  mode: "mock" | "live";
  productId: string;
  sku: string;
  title: string;
  currency: "USD";
  unitPrice: number;
  availability: CommerceAvailability;
  availableQuantity: number;
  updatedAt: string;
  checkoutEnabled: boolean;
  checkoutUrl?: string;
  disclosure: string;
};

export type CommerceCart = {
  provider: CommerceProviderName;
  mode: "mock" | "live";
  cartId: string;
  lineItems: Array<{ productId: string; quantity: number; unitPrice: number }>;
  subtotal: number;
  currency: "USD";
  checkoutEnabled: boolean;
  checkoutUrl?: string;
  disclosure: string;
};

/** Provider contract: a Shopify or WooCommerce adapter can implement this interface when approved credentials become available. */
export interface SkinCommerceProvider {
  getListing(productId: string): Promise<CommerceListing | null>;
  createCart(productId: string, quantity?: number): Promise<CommerceCart | null>;
}

const mockListingData: Record<string, Pick<CommerceListing, "sku" | "unitPrice" | "availability" | "availableQuantity">> = {
  "cerave-hydrating-facial-cleanser": { sku: "MOCK-CER-HFC-001", unitPrice: 15.99, availability: "in_stock", availableQuantity: 18 },
  "lrp-toleriane-double-repair": { sku: "MOCK-LRP-TDR-001", unitPrice: 24.99, availability: "low_stock", availableQuantity: 4 },
  "ordinary-niacinamide-zinc": { sku: "MOCK-ORD-NIA-001", unitPrice: 6.0, availability: "in_stock", availableQuantity: 12 },
  "cerave-am-facial-lotion-spf-30": { sku: "MOCK-CER-AM30-001", unitPrice: 19.99, availability: "in_stock", availableQuantity: 9 },
  "cerave-skin-renewing-night-cream": { sku: "MOCK-CER-NIGHT-001", unitPrice: 21.99, availability: "out_of_stock", availableQuantity: 0 },
};

/**
 * These are deliberately fictional prototype values for external discovery references.
 * They never mirror a house's current retail price, inventory, or checkout availability.
 */
const ultraLuxuryMockListingData: Record<string, Pick<CommerceListing, "sku" | "unitPrice" | "availability" | "availableQuantity">> = {
  "la-prairie-skin-caviar-luxe-cream": { sku: "MOCK-ULTRA-LP-001", unitPrice: 240, availability: "low_stock", availableQuantity: 2 },
  "la-prairie-skin-caviar-essence": { sku: "MOCK-ULTRA-LP-002", unitPrice: 165, availability: "in_stock", availableQuantity: 5 },
  "guerlain-orchidee-black-cream": { sku: "MOCK-ULTRA-GUE-001", unitPrice: 310, availability: "low_stock", availableQuantity: 1 },
  "guerlain-orchidee-black-symbioserum": { sku: "MOCK-ULTRA-GUE-002", unitPrice: 275, availability: "in_stock", availableQuantity: 3 },
  "la-mer-creme-de-la-mer": { sku: "MOCK-ULTRA-LAM-001", unitPrice: 190, availability: "in_stock", availableQuantity: 4 },
  "la-mer-the-concentrate": { sku: "MOCK-ULTRA-LAM-002", unitPrice: 150, availability: "low_stock", availableQuantity: 2 },
  "augustinus-bader-rich-cream": { sku: "MOCK-ULTRA-AB-001", unitPrice: 185, availability: "in_stock", availableQuantity: 6 },
  "augustinus-bader-cream": { sku: "MOCK-ULTRA-AB-002", unitPrice: 145, availability: "in_stock", availableQuantity: 4 },
  "mbr-moisturizers": { sku: "MOCK-ULTRA-MBR-001", unitPrice: 220, availability: "low_stock", availableQuantity: 2 },
  "mbr-serums-concentrates": { sku: "MOCK-ULTRA-MBR-002", unitPrice: 260, availability: "in_stock", availableQuantity: 3 },
  "valmont-prime-renewing-pack": { sku: "MOCK-ULTRA-VAL-001", unitPrice: 205, availability: "in_stock", availableQuantity: 4 },
  "valmont-skincare": { sku: "MOCK-ULTRA-VAL-002", unitPrice: 175, availability: "out_of_stock", availableQuantity: 0 },
  "la-prairie-skin-caviar-collection": { sku: "MOCK-ULTRA-LP-003", unitPrice: 210, availability: "in_stock", availableQuantity: 4 },
  "guerlain-orchidee-imperiale-collection": { sku: "MOCK-ULTRA-GUE-003", unitPrice: 245, availability: "low_stock", availableQuantity: 2 },
  "la-mer-skincare-collection": { sku: "MOCK-ULTRA-LAM-003", unitPrice: 230, availability: "in_stock", availableQuantity: 3 },
  "augustinus-bader-skincare-collection": { sku: "MOCK-ULTRA-AB-003", unitPrice: 195, availability: "in_stock", availableQuantity: 5 },
  "mbr-skincare-collection": { sku: "MOCK-ULTRA-MBR-003", unitPrice: 285, availability: "low_stock", availableQuantity: 1 },
  "valmont-essentials-collection": { sku: "MOCK-ULTRA-VAL-003", unitPrice: 215, availability: "in_stock", availableQuantity: 4 },
};

const disclosure = MOCK_COMMERCE_DISCLOSURE;

export const mockSkinCommerceProvider: SkinCommerceProvider = {
  async getListing(productId) {
    const product = getCatalogProduct(productId);
    const mock = mockListingData[productId];
    if (product && mock) {
      return { provider: "mock", mode: "mock", productId, title: product.name, currency: "USD", updatedAt: new Date().toISOString(), checkoutEnabled: false, disclosure, ...mock };
    }
    const ultraLuxuryReference = ULTRA_LUXURY_SKIN_DISCOVERY_RECORDS.find((record) => record.id === productId);
    const ultraLuxuryMock = ultraLuxuryMockListingData[productId];
    if (!ultraLuxuryReference || !ultraLuxuryMock) return null;
    return {
      provider: "mock",
      mode: "mock",
      productId,
      title: `${ultraLuxuryReference.brand} · ${ultraLuxuryReference.productName}`,
      currency: "USD",
      updatedAt: new Date().toISOString(),
      checkoutEnabled: false,
      disclosure: `${disclosure} This line is a fictional local simulation for an external discovery reference and is not affiliated with ${ultraLuxuryReference.brand}.`,
      ...ultraLuxuryMock,
    };
  },
  async createCart(productId, quantity = 1) {
    const listing = await this.getListing(productId);
    if (!listing || listing.availability === "out_of_stock") return null;
    const safeQuantity = Math.max(1, Math.min(quantity, listing.availableQuantity));
    return {
      provider: "mock", mode: "mock", cartId: `mock-cart-${Date.now()}`,
      lineItems: [{ productId, quantity: safeQuantity, unitPrice: listing.unitPrice }],
      subtotal: Number((listing.unitPrice * safeQuantity).toFixed(2)), currency: "USD", checkoutEnabled: false, disclosure,
    };
  },
};

/** Active provider selector. Replace only through a server-side Shopify/WooCommerce adapter after user-approved credentials exist. */
export const activeSkinCommerceProvider: SkinCommerceProvider = mockSkinCommerceProvider;
