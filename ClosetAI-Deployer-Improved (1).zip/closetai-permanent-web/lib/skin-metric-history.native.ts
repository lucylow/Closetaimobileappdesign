import * as SQLite from "expo-sqlite";

import type { SkinAnalysisResult } from "@/lib/skin-analysis-controller";

export type SkinMetricHistoryPoint = {
  scanId: string;
  capturedAt: string;
  source: SkinAnalysisResult["source"];
  overallScore?: number;
  metricKey: string;
  score: number;
};

let databasePromise: Promise<SQLite.SQLiteDatabase> | null = null;
let initialized = false;

async function getDatabase() {
  if (!databasePromise) databasePromise = SQLite.openDatabaseAsync("closetai_skin_history.db");
  const database = await databasePromise;
  if (!initialized) {
    await database.execAsync(`
      PRAGMA journal_mode = WAL;
      CREATE TABLE IF NOT EXISTS skin_metric_scans (
        scan_id TEXT PRIMARY KEY NOT NULL,
        captured_at TEXT NOT NULL,
        source TEXT NOT NULL,
        overall_score REAL,
        skin_type TEXT
      );
      CREATE TABLE IF NOT EXISTS skin_metric_values (
        scan_id TEXT NOT NULL,
        metric_key TEXT NOT NULL,
        score REAL NOT NULL,
        PRIMARY KEY (scan_id, metric_key)
      );
      CREATE INDEX IF NOT EXISTS idx_skin_metric_scans_captured_at ON skin_metric_scans(captured_at DESC);
    `);
    initialized = true;
  }
  return database;
}

/** Stores normalized local metric history only; the selfie, image URI, masks, and raw API response are never written to SQLite. */
export async function saveSkinMetricHistory(result: SkinAnalysisResult): Promise<void> {
  const database = await getDatabase();
  await database.withTransactionAsync(async () => {
    await database.runAsync(
      "INSERT OR REPLACE INTO skin_metric_scans (scan_id, captured_at, source, overall_score, skin_type) VALUES (?, ?, ?, ?, ?)",
      result.id,
      result.createdAt,
      result.source,
      result.overallScore ?? null,
      result.skinType ?? null,
    );
    for (const metric of result.metrics.filter((item) => item.available && typeof item.score === "number")) {
      await database.runAsync(
        "INSERT OR REPLACE INTO skin_metric_values (scan_id, metric_key, score) VALUES (?, ?, ?)",
        result.id,
        metric.key,
        metric.score,
      );
    }
  });
}

export async function loadSkinMetricHistory(limit = 120): Promise<SkinMetricHistoryPoint[]> {
  const database = await getDatabase();
  return database.getAllAsync<SkinMetricHistoryPoint>(`
    SELECT scans.scan_id AS scanId, scans.captured_at AS capturedAt, scans.source AS source,
      scans.overall_score AS overallScore, values.metric_key AS metricKey, values.score AS score
    FROM skin_metric_values values
    INNER JOIN skin_metric_scans scans ON scans.scan_id = values.scan_id
    ORDER BY scans.captured_at ASC
    LIMIT ?
  `, Math.max(1, Math.min(500, limit)));
}

export async function clearSkinMetricHistory(): Promise<void> {
  const database = await getDatabase();
  await database.execAsync("DELETE FROM skin_metric_values; DELETE FROM skin_metric_scans;");
}
