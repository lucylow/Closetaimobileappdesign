import type { CommerceCandidate, CommerceAgentPlan } from "../shared/agentic-commerce-contracts";
import { normalizeCandidate } from "./product-normalizer";
import { getReviewIntelligenceForProduct } from "./review-intelligence";
import { FICTIONAL_DEMO_CANDIDATES } from "./fictional-demo-commerce";
import { fetchExternalProductDiscovery } from "./external-commerce-provider";

export function createCommercePlan(query: string, category: "fashion" | "skincare" | "beauty" | "accessory" = "skincare", budgetMax?: number): CommerceAgentPlan {
  return {
    goal: query,
    category,
    budgetMax,
    currency: "USD",
    country: "US",
    actions: [
      "Scan approved product catalogs and verified merchant feeds",
      "Normalize product identity and verify current pricing",
      "Retrieve review intelligence and recurring sentiment themes",
      "Prepare secure, user-approved checkout session",
    ],
  };
}

export function searchCommerceCandidates(query: string, category: string = "skincare", isDemo: boolean = true): CommerceCandidate[] {
  if (isDemo) {
    const q = query.toLowerCase();
    const filtered = FICTIONAL_DEMO_CANDIDATES.filter(item => {
      if (q.includes("blazer") || q.includes("jacket") || q.includes("trouser") || q.includes("silk") || q.includes("outfit")) {
        return item.productId.includes("fashion") || item.productId.includes("accessories");
      }
      if (q.includes("cream") || q.includes("serum") || q.includes("skin") || q.includes("moisturizer")) {
        return item.productId.includes("skincare");
      }
      return true;
    });
    return filtered.length > 0 ? filtered : FICTIONAL_DEMO_CANDIDATES;
  }

  // Live mode with external provider discovery & fallback
  const rawList = [
    {
      productId: "prod-skincare-live-01",
      merchantId: "Verified Live Merchant Feed",
      title: "Advanced Peptide Barrier Cream 50ml",
      brand: "Lurane Laboratories",
      price: 34.00,
      shipping: 3.50,
      availability: "in_stock" as const,
      productUrl: "https://example.com/product/live-barrier-repair",
      providerName: "Live Verified API",
      isDemo: false,
    },
  ];
  return rawList.map(item => {
    const candidate = normalizeCandidate(item);
    candidate.reviewSummary = getReviewIntelligenceForProduct(candidate.productId, false);
    return candidate;
  });
}
