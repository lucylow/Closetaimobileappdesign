export type SelfieQualityBand = "ready" | "review" | "retake";

export interface SelfieQualityCheck {
  id: "orientation" | "framing" | "resolution" | "file-size";
  label: string;
  status: "pass" | "review" | "action";
  detail: string;
}

export interface SelfieQualityReport {
  band: SelfieQualityBand;
  score: number;
  summary: string;
  checks: SelfieQualityCheck[];
}

const MIN_SHORT_EDGE = 640;
const MAX_FILE_SIZE = 12 * 1024 * 1024;
const IDEAL_MIN_ASPECT = 0.68;
const IDEAL_MAX_ASPECT = 0.92;

function scoreFor(status: SelfieQualityCheck["status"]) {
  if (status === "pass") return 100;
  if (status === "review") return 65;
  return 20;
}

export function buildSelfieQualityReport(asset: {
  width: number;
  height: number;
  fileSize?: number | null;
}): SelfieQualityReport {
  const ratio = asset.height > 0 ? asset.width / asset.height : 1;
  const shortestEdge = Math.min(asset.width, asset.height);

  const orientation: SelfieQualityCheck = {
    id: "orientation",
    label: "Portrait framing",
    status: asset.height >= asset.width ? "pass" : "review",
    detail:
      asset.height >= asset.width
        ? "Your image is vertically framed for a comfortable mobile review."
        : "A portrait photo usually keeps your face easier to frame and review.",
  };

  const framing: SelfieQualityCheck = {
    id: "framing",
    label: "Face guide",
    status: ratio >= IDEAL_MIN_ASPECT && ratio <= IDEAL_MAX_ASPECT ? "pass" : "review",
    detail:
      ratio >= IDEAL_MIN_ASPECT && ratio <= IDEAL_MAX_ASPECT
        ? "The image shape is well suited to a front-facing selfie review."
        : "For the clearest experience, centre your face and leave a small amount of space around it.",
  };

  const resolution: SelfieQualityCheck = {
    id: "resolution",
    label: "Image clarity",
    status: shortestEdge >= MIN_SHORT_EDGE ? "pass" : "action",
    detail:
      shortestEdge >= MIN_SHORT_EDGE
        ? "The selected image has enough visible detail for the scan workflow."
        : "Choose a sharper image or retake the selfie in soft, even light before scanning.",
  };

  const fileSize: SelfieQualityCheck = {
    id: "file-size",
    label: "Upload size",
    status: asset.fileSize == null || asset.fileSize <= MAX_FILE_SIZE ? "pass" : "review",
    detail:
      asset.fileSize == null || asset.fileSize <= MAX_FILE_SIZE
        ? "The image size is appropriate for the current upload flow."
        : "This image may upload more slowly. A new selfie can be smaller while remaining clear.",
  };

  const checks = [orientation, framing, resolution, fileSize];
  const score = Math.round(checks.reduce((total, check) => total + scoreFor(check.status), 0) / checks.length);
  const band: SelfieQualityBand = checks.some((check) => check.status === "action")
    ? "retake"
    : checks.some((check) => check.status === "review")
      ? "review"
      : "ready";

  return {
    band,
    score,
    checks,
    summary:
      band === "ready"
        ? "Your selfie is ready for the Skin Care scan workflow."
        : band === "review"
          ? "Your selfie can be used. A small adjustment may improve the scan experience."
          : "A quick retake is recommended before you begin the scan.",
  };
}

export function boundedPercent(value: number | null | undefined) {
  return Math.max(0, Math.min(100, value ?? 0));
}
