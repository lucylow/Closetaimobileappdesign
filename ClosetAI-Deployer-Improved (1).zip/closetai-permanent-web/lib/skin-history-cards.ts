import type { SkinAnalysisResult } from "@/lib/skin-analysis-controller";
import type { SkinSnapshotListItem } from "@/lib/skin-navigation-data";

export interface SkinHistoryCard {
  id: string;
  date: string;
  scoreLabel: string;
  summary: string;
  sourceLabel: "Live visual analysis" | "Fictional Demo Mode";
  disclosure: string;
}

function formatSnapshotDate(createdAt: string): string {
  const timestamp = Date.parse(createdAt);
  if (!Number.isFinite(timestamp)) return "Saved snapshot";
  return new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric", year: "numeric" }).format(timestamp);
}

export function buildSkinHistoryCards(savedResults: SkinAnalysisResult[], demoSnapshots: SkinSnapshotListItem[]): SkinHistoryCard[] {
  if (savedResults.length > 0) {
    return savedResults.map((result) => {
      const isLive = result.source === "youcam";
      return {
        id: result.id,
        date: formatSnapshotDate(result.createdAt),
        scoreLabel: typeof result.overallScore === "number" && Number.isFinite(result.overallScore) ? String(result.overallScore) : "Score unavailable",
        summary: result.visualSignalSummary || result.disclaimer,
        sourceLabel: isLive ? "Live visual analysis" : "Fictional Demo Mode",
        disclosure: isLive ? "Saved normalized summary only. Original selfie previews are not shown in history." : "Fictional Demo Mode reference only; complete a live scan to replace it.",
      };
    });
  }

  return demoSnapshots.map((snapshot) => ({
    id: snapshot.id,
    date: snapshot.date,
    scoreLabel: String(snapshot.score),
    summary: snapshot.summary,
    sourceLabel: "Fictional Demo Mode",
    disclosure: "Fictional Demo Mode reference only; complete a live scan to replace it.",
  }));
}
