import type { SkinAnalysisResult, SkinMetric } from "@/lib/skin-analysis-controller";

export type SkinTrend = "up" | "down" | "steady" | "new";
export type SkinIntelligenceCard = SkinMetric & {
  priority: "sustain" | "watch" | "focus";
  trend: SkinTrend;
  change?: number;
  plainLanguage: string;
};

export type SkinIntelligenceDashboard = {
  sourceLabel: string;
  sourceDetail: string;
  overallScore?: number;
  coveragePercent: number;
  priorities: SkinIntelligenceCard[];
  cards: SkinIntelligenceCard[];
  trendLabel: string;
};

const supportiveKeys = new Set(["hydration", "texture", "radiance", "fineLines"]);
const concernKeys = new Set(["oiliness", "pores", "redness", "blemishes", "darkSpots"]);

function describe(metric: SkinMetric, priority: SkinIntelligenceCard["priority"]): string {
  if (priority === "sustain") return `${metric.label} looks like a strength to maintain with a consistent, comfortable routine.`;
  if (priority === "focus") return `${metric.label} is a visual focus area in this snapshot. Keep changes gradual and use general-care guidance.`;
  return `${metric.label} is a signal to watch over time. A future saved snapshot can add context.`;
}

function trendFor(metric: SkinMetric, previous?: SkinMetric): Pick<SkinIntelligenceCard, "trend" | "change"> {
  if (!previous || previous.score === undefined || metric.score === undefined) return { trend: "new" };
  const change = metric.score - previous.score;
  if (Math.abs(change) <= 3) return { trend: "steady", change };
  return { trend: change > 0 ? "up" : "down", change };
}

function priorityFor(metric: SkinMetric): SkinIntelligenceCard["priority"] {
  if (!metric.available) return "watch";
  const isSupportive = supportiveKeys.has(metric.key);
  const isConcern = concernKeys.has(metric.key);
  if ((isSupportive && metric.score >= 75) || (isConcern && metric.score <= 30)) return "sustain";
  if ((isSupportive && metric.score < 55) || (isConcern && metric.score >= 65)) return "focus";
  return "watch";
}

/**
 * Converts normalized scan output into a bounded visual dashboard model. It deliberately excludes
 * source-image data, provider payloads, masks, and medical interpretation.
 */
export function buildSkinIntelligenceDashboard(current: SkinAnalysisResult, history: SkinAnalysisResult[] = []): SkinIntelligenceDashboard {
  const previous = history.find((result) => result.id !== current.id && result.source === current.source);
  const cards = current.metrics.filter((metric) => metric.available).map((metric) => {
    const priorMetric = previous?.metrics.find((candidate) => candidate.key === metric.key);
    const priority = priorityFor(metric);
    return { ...metric, priority, ...trendFor(metric, priorMetric), plainLanguage: describe(metric, priority) };
  });
  const rank = { focus: 0, watch: 1, sustain: 2 };
  const priorities = [...cards].sort((left, right) => rank[left.priority] - rank[right.priority] || left.label.localeCompare(right.label)).slice(0, 3);
  const coveragePercent = current.visualSignalCoverage?.percent ?? Math.round((cards.length / Math.max(current.metrics.length, 1)) * 100);
  const changed = cards.filter((card) => card.trend === "up" || card.trend === "down").length;
  return {
    sourceLabel: current.source === "youcam" ? "Live visual analysis" : current.source === "cached" ? "Saved visual analysis" : "Demo visual analysis",
    sourceDetail: current.visualSignalSummary || (current.source === "demo" ? "Fictional preview data for Demo Mode; it is not live analysis." : "Normalized visual signals from your saved snapshot; not a medical diagnosis."),
    overallScore: current.overallScore,
    coveragePercent,
    priorities,
    cards,
    trendLabel: previous ? (changed ? `${changed} signal${changed === 1 ? "" : "s"} changed from the previous saved snapshot.` : "Signals are broadly steady from the previous saved snapshot.") : "Save another snapshot later to add visual trend context.",
  };
}
