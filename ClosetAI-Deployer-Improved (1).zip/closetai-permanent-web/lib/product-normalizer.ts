import type { CommerceCandidate, Money, AvailabilityState, CommerceSource } from "../shared/agentic-commerce-contracts";

export function normalizeCandidate(raw: {
  productId: string;
  merchantId: string;
  title: string;
  brand?: string;
  price: number;
  currency?: string;
  shipping?: number;
  availability?: AvailabilityState;
  productUrl: string;
  providerName: string;
  isDemo?: boolean;
}): CommerceCandidate {
  const currency = raw.currency || "USD";
  const priceObj: Money = { amount: Number(raw.price.toFixed(2)), currency };
  const shippingObj: Money = { amount: Number((raw.shipping || 0).toFixed(2)), currency };
  const totalObj: Money = { amount: Number((priceObj.amount + shippingObj.amount).toFixed(2)), currency };
  const availability = raw.availability || "in_stock";
  const now = new Date().toISOString();

  const source: CommerceSource = {
    providerName: raw.providerName,
    sourceUrl: raw.productUrl,
    retrievedAt: now,
    confidence: raw.isDemo ? 0.85 : 0.95,
    isDemo: Boolean(raw.isDemo),
  };

  return {
    productId: raw.productId,
    merchantId: raw.merchantId,
    title: raw.title.trim(),
    brand: raw.brand?.trim(),
    price: priceObj,
    shipping: shippingObj,
    total: totalObj,
    availability,
    productUrl: raw.productUrl,
    lastCheckedAt: now,
    source,
    evidence: [
      { label: `Price verified via ${raw.providerName}`, url: raw.productUrl, timestamp: now },
      { label: `Merchant ID: ${raw.merchantId}`, timestamp: now },
    ],
    matchScore: 0.92,
  };
}
