import AsyncStorage from "@react-native-async-storage/async-storage";

const ATTRIBUTION_STORAGE_KEY = "@closetai_commerce_attribution_v1";

export interface AffiliateClickRecord {
  clickId: string;
  candidateId: string;
  merchantId: string;
  timestamp: string;
  estimatedCommissionRate: number; // e.g., 0.05 for 5%
  status: "clicked" | "converted" | "expired";
}

export async function trackAffiliateClick(
  candidateId: string,
  merchantId: string,
  commissionRate: number = 0.05
): Promise<AffiliateClickRecord> {
  const record: AffiliateClickRecord = {
    clickId: `click_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    candidateId,
    merchantId,
    timestamp: new Date().toISOString(),
    estimatedCommissionRate: commissionRate,
    status: "clicked",
  };

  try {
    const existingRaw = await AsyncStorage.getItem(ATTRIBUTION_STORAGE_KEY);
    const existing: AffiliateClickRecord[] = existingRaw ? JSON.parse(existingRaw) : [];
    const updated = [record, ...existing].slice(0, 100); // keep last 100 clicks
    await AsyncStorage.setItem(ATTRIBUTION_STORAGE_KEY, JSON.stringify(updated));
  } catch (err) {
    console.warn("Failed to persist affiliate click record:", err);
  }

  return record;
}

export async function getAffiliateClicks(): Promise<AffiliateClickRecord[]> {
  try {
    const existingRaw = await AsyncStorage.getItem(ATTRIBUTION_STORAGE_KEY);
    return existingRaw ? JSON.parse(existingRaw) : [];
  } catch (err) {
    console.warn("Failed to load affiliate click records:", err);
    return [];
  }
}
