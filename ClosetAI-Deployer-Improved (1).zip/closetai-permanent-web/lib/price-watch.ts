import AsyncStorage from "@react-native-async-storage/async-storage";
import type { PriceWatchRule, Money } from "../shared/agentic-commerce-contracts";

const STORAGE_KEY = "@closetai_commerce_price_watches_v1";

const DEFAULT_WATCHES: PriceWatchRule[] = [
  {
    id: "pw-101",
    candidateId: "prod-skincare-01",
    title: "Hydrating Barrier Repair Cream",
    targetPrice: { amount: 28.00, currency: "USD" },
    active: true,
    createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
  },
];

export function sanitizeStoredPriceWatches(stored: string | null): PriceWatchRule[] {
  if (!stored) return DEFAULT_WATCHES;
  try {
    const parsed = JSON.parse(stored);
    if (!Array.isArray(parsed)) return DEFAULT_WATCHES;
    return parsed.map((item: any) => ({
      id: String(item.id || `pw-${Math.random()}`),
      candidateId: String(item.candidateId || "unknown-candidate"),
      title: String(item.title || "Watched Product"),
      targetPrice: {
        amount: Number(item.targetPrice?.amount || 0),
        currency: String(item.targetPrice?.currency || "USD"),
      },
      active: Boolean(item.active),
      createdAt: String(item.createdAt || new Date().toISOString()),
    }));
  } catch {
    return DEFAULT_WATCHES;
  }
}

let cachedRules: PriceWatchRule[] = DEFAULT_WATCHES;

export async function loadPriceWatchRules(): Promise<PriceWatchRule[]> {
  try {
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    cachedRules = sanitizeStoredPriceWatches(raw);
    return cachedRules;
  } catch {
    return cachedRules;
  }
}

export function getPriceWatchRules(): PriceWatchRule[] {
  return cachedRules;
}

export async function addPriceWatchRule(candidateId: string, title: string, targetPrice: Money): Promise<PriceWatchRule[]> {
  const rule: PriceWatchRule = {
    id: `pw-${Date.now()}`,
    candidateId,
    title,
    targetPrice,
    active: true,
    createdAt: new Date().toISOString(),
  };
  cachedRules = [rule, ...cachedRules];
  try {
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(cachedRules));
  } catch {
    // Fall back to memory state if storage write fails
  }
  return cachedRules;
}

export async function togglePriceWatchRule(ruleId: string): Promise<PriceWatchRule[]> {
  cachedRules = cachedRules.map(r => r.id === ruleId ? { ...r, active: !r.active } : r);
  try {
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(cachedRules));
  } catch {
    // Fall back to memory state
  }
  return cachedRules;
}
