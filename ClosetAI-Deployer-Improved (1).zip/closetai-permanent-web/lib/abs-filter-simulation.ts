import { apiRequest } from "@/lib/query-client";
import type { AbsFilterIntensity, AbsFilterMode, AbsFilterSimulationResult } from "@shared/abs-filter-simulation";

export type AbsFilterSimulationResponse = {
  simulation: AbsFilterSimulationResult;
  disclosure: string;
};

export async function createAbsFilterSimulation(input: {
  imageBase64: string;
  mode: AbsFilterMode;
  intensity: AbsFilterIntensity;
  consent: boolean;
  adultConfirmed: boolean;
  singlePersonConfirmed: boolean;
}): Promise<AbsFilterSimulationResponse> {
  const response = await apiRequest("POST", "/api/skin/abs-filter", input);
  return response.json();
}
