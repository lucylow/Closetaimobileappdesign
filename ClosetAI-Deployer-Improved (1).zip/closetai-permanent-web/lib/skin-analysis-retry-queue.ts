import AsyncStorage from "@react-native-async-storage/async-storage";

export type SkinAnalysisRetryQueueEntry = {
  selfieUri: string;
  saveSnapshot: boolean;
  acceptsGuidance: true;
  queuedAt: string;
  reason: "youcam-unavailable";
};

const STORAGE_KEY = "@closetai_skin_analysis_retry_queue_v1";
const MAX_QUEUE_AGE_MS = 24 * 60 * 60 * 1000;

function isValidUri(value: unknown): value is string {
  return typeof value === "string" && value.trim().length > 0 && value.length <= 4096;
}

function isValidEntry(value: unknown): value is SkinAnalysisRetryQueueEntry {
  if (!value || typeof value !== "object") return false;
  const entry = value as Partial<SkinAnalysisRetryQueueEntry>;
  if (!isValidUri(entry.selfieUri) || typeof entry.saveSnapshot !== "boolean") return false;
  if (entry.acceptsGuidance !== true || entry.reason !== "youcam-unavailable" || typeof entry.queuedAt !== "string") return false;
  const queuedAt = Date.parse(entry.queuedAt);
  return Number.isFinite(queuedAt) && Date.now() - queuedAt >= 0 && Date.now() - queuedAt <= MAX_QUEUE_AGE_MS;
}

export function createSkinAnalysisRetryQueueEntry(selfieUri: string, saveSnapshot: boolean): SkinAnalysisRetryQueueEntry {
  return { selfieUri, saveSnapshot, acceptsGuidance: true, queuedAt: new Date().toISOString(), reason: "youcam-unavailable" };
}

export async function saveSkinAnalysisRetryQueue(entry: SkinAnalysisRetryQueueEntry): Promise<void> {
  if (!isValidEntry(entry)) throw new Error("Invalid local Skin Care retry entry.");
  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(entry));
}

export async function loadSkinAnalysisRetryQueue(): Promise<SkinAnalysisRetryQueueEntry | null> {
  try {
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed: unknown = JSON.parse(raw);
    if (!isValidEntry(parsed)) {
      await AsyncStorage.removeItem(STORAGE_KEY);
      return null;
    }
    return parsed;
  } catch {
    return null;
  }
}

export async function clearSkinAnalysisRetryQueue(): Promise<void> {
  try {
    await AsyncStorage.removeItem(STORAGE_KEY);
  } catch {
    // Local recovery state is best-effort and must never block Skin Care guidance.
  }
}
