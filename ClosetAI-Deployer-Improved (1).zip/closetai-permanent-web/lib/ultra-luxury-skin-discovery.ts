/**
 * External-only ultra-luxury skin-care discovery data. This intentionally sits outside the
 * verified recommendation and mock-cart models: no record supplies price, inventory, medical
 * suitability, checkout, or efficacy information.
 */
export const ULTRA_LUXURY_SKIN_DISCOVERY_DISCLOSURE =
  'Ultra-luxury skin-care references are curated mock discovery data. Links open official brand destinations when available; ClosetAI is not affiliated with these brands and does not provide live price, inventory, checkout, medical advice, or outcome guarantees.';

export type UltraLuxurySkinBrand = 'La Prairie' | 'Guerlain' | 'La Mer' | 'Augustinus Bader' | 'MBR' | 'Valmont';

export type UltraLuxurySkinDiscoveryRecord = {
  id: string;
  brand: UltraLuxurySkinBrand;
  productName: string;
  category: 'Cream' | 'Serum' | 'Essence' | 'Collection';
  routineContext: 'AM / PM' | 'PM' | 'Flexible';
  discoveryFocus: string;
  officialUrl: string;
  officialSourceLabel: string;
  genericVisualUrl: string;
  imageDisclosure: string;
  dataMode: 'mock-discovery';
  externalOnly: true;
  disclosure: string;
};

const genericVisuals = [
  'https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/ehtxFjXuAKwDWBlf.jpg',
  'https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/JePRBYTLSZdVgqVi.jpg',
  'https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/eQkJerDSJfHVXYrE.jpg',
  'https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/XaJbsClLHcdmDtvO.jpg',
  'https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/qhCtOsBZshcGqZGP.jpg',
] as const;

const imageDisclosure = 'Generic non-branded skincare still-life image. It is not official brand photography, a representation of a listed product, or an availability claim.';

function discovery(input: Omit<UltraLuxurySkinDiscoveryRecord, 'dataMode' | 'externalOnly' | 'disclosure' | 'imageDisclosure'>): UltraLuxurySkinDiscoveryRecord {
  return { ...input, dataMode: 'mock-discovery', externalOnly: true, disclosure: ULTRA_LUXURY_SKIN_DISCOVERY_DISCLOSURE, imageDisclosure };
}

export const ULTRA_LUXURY_SKIN_DISCOVERY_RECORDS: UltraLuxurySkinDiscoveryRecord[] = [
  discovery({ id: 'la-prairie-skin-caviar-luxe-cream', brand: 'La Prairie', productName: 'Skin Caviar Luxe Cream', category: 'Cream', routineContext: 'AM / PM', discoveryFocus: 'Rich cream category reference from the Skin Caviar collection.', officialUrl: 'https://www.laprairie.com/en-us/products/luxe-cream-mv0060', officialSourceLabel: 'La Prairie Skin Caviar Luxe Cream', genericVisualUrl: genericVisuals[4] }),
  discovery({ id: 'la-prairie-skin-caviar-essence', brand: 'La Prairie', productName: 'Skin Caviar Essence-in-Lotion', category: 'Essence', routineContext: 'AM / PM', discoveryFocus: 'Essence category reference from the Skin Caviar collection.', officialUrl: 'https://www.laprairie.com/en-us/products/essence-in-lotion-mv0065', officialSourceLabel: 'La Prairie Skin Caviar Essence-in-Lotion', genericVisualUrl: genericVisuals[1] }),
  discovery({ id: 'guerlain-orchidee-black-cream', brand: 'Guerlain', productName: 'Orchidée Impériale Black The Cream', category: 'Cream', routineContext: 'PM', discoveryFocus: 'Prestige cream category reference from Guerlain’s Orchidée Impériale Black collection.', officialUrl: 'https://www.guerlain.com/us/en-us/p/orchidee-imperiale-black-the-cream-P062002.html', officialSourceLabel: 'Guerlain Orchidée Impériale Black The Cream', genericVisualUrl: genericVisuals[3] }),
  discovery({ id: 'guerlain-orchidee-black-symbioserum', brand: 'Guerlain', productName: 'Orchidée Impériale Black The Symbioserum', category: 'Serum', routineContext: 'Flexible', discoveryFocus: 'Serum category reference from Guerlain’s Orchidée Impériale Black collection.', officialUrl: 'https://www.guerlain.com/us/en-us/p/orchidee-imperiale-black-the-symbioserum-P061597.html', officialSourceLabel: 'Guerlain Orchidée Impériale Black The Symbioserum', genericVisualUrl: genericVisuals[0] }),
  discovery({ id: 'la-mer-creme-de-la-mer', brand: 'La Mer', productName: 'Crème de la Mer', category: 'Cream', routineContext: 'AM / PM', discoveryFocus: 'Moisturizing cream category reference from La Mer’s official product page.', officialUrl: 'https://www.cremedelamer.com/product/5834/12343/face/moisturizers/creme-de-la-mer', officialSourceLabel: 'La Mer Crème de la Mer', genericVisualUrl: genericVisuals[4] }),
  discovery({ id: 'la-mer-the-concentrate', brand: 'La Mer', productName: 'The Concentrate', category: 'Serum', routineContext: 'Flexible', discoveryFocus: 'Serum category reference linked from La Mer’s official Crème de la Mer page.', officialUrl: 'https://www.cremedelamer.com/product/9090/78364/face/serums/the-concentrate-serum', officialSourceLabel: 'La Mer The Concentrate', genericVisualUrl: genericVisuals[2] }),
  discovery({ id: 'augustinus-bader-rich-cream', brand: 'Augustinus Bader', productName: 'The Rich Cream', category: 'Cream', routineContext: 'AM / PM', discoveryFocus: 'Rich moisturizer category reference featuring the brand’s TFC8® technology.', officialUrl: 'https://augustinusbader.com/int/en/the-rich-cream', officialSourceLabel: 'Augustinus Bader The Rich Cream', genericVisualUrl: genericVisuals[0] }),
  discovery({ id: 'augustinus-bader-cream', brand: 'Augustinus Bader', productName: 'The Cream', category: 'Cream', routineContext: 'AM / PM', discoveryFocus: 'Moisturizer category reference from the official Augustinus Bader skincare range.', officialUrl: 'https://augustinusbader.com/us/en/the-cream', officialSourceLabel: 'Augustinus Bader The Cream', genericVisualUrl: genericVisuals[1] }),
  discovery({ id: 'mbr-moisturizers', brand: 'MBR', productName: 'Moisturizers collection', category: 'Collection', routineContext: 'Flexible', discoveryFocus: 'External MBR moisturizers category reference.', officialUrl: 'https://mbrcare.com/', officialSourceLabel: 'MBR Medical Beauty Research official site', genericVisualUrl: genericVisuals[3] }),
  discovery({ id: 'mbr-serums-concentrates', brand: 'MBR', productName: 'Serums & Concentrates collection', category: 'Collection', routineContext: 'Flexible', discoveryFocus: 'External MBR serums and concentrates category reference.', officialUrl: 'https://mbrcare.com/', officialSourceLabel: 'MBR Medical Beauty Research official site', genericVisualUrl: genericVisuals[2] }),
  discovery({ id: 'valmont-prime-renewing-pack', brand: 'Valmont', productName: 'Prime Renewing Pack', category: 'Cream', routineContext: 'Flexible', discoveryFocus: 'Mask and cream category reference from Valmont’s official product destination.', officialUrl: 'https://www.lamaisonvalmont.com/en/prime-renewing-pack.html', officialSourceLabel: 'Valmont Prime Renewing Pack', genericVisualUrl: genericVisuals[4] }),
  discovery({ id: 'valmont-skincare', brand: 'Valmont', productName: 'Valmont skincare destination', category: 'Collection', routineContext: 'Flexible', discoveryFocus: 'External official Valmont skincare range reference.', officialUrl: 'https://www.lamaisonvalmont.com/en/skincare.html', officialSourceLabel: 'Valmont skincare', genericVisualUrl: genericVisuals[1] }),
  discovery({ id: 'la-prairie-skin-caviar-collection', brand: 'La Prairie', productName: 'Skin Caviar collection', category: 'Collection', routineContext: 'AM / PM', discoveryFocus: 'Collection-level reference for a polished, ritual-led skincare mood board.', officialUrl: 'https://www.laprairie.com/en-us/products/luxe-cream-mv0060', officialSourceLabel: 'La Prairie Skin Caviar Luxe Cream page', genericVisualUrl: genericVisuals[2] }),
  discovery({ id: 'guerlain-orchidee-imperiale-collection', brand: 'Guerlain', productName: 'Orchidée Impériale collection', category: 'Collection', routineContext: 'Flexible', discoveryFocus: 'Collection-level reference for a botanical luxury skincare mood board.', officialUrl: 'https://www.guerlain.com/us/en-us/p/orchidee-imperiale-black-the-cream-P062002.html', officialSourceLabel: 'Guerlain Orchidée Impériale Black The Cream page', genericVisualUrl: genericVisuals[4] }),
  discovery({ id: 'la-mer-skincare-collection', brand: 'La Mer', productName: 'La Mer skincare collection', category: 'Collection', routineContext: 'AM / PM', discoveryFocus: 'Collection-level reference for an ocean-inspired luxury skincare mood board.', officialUrl: 'https://www.cremedelamer.com/product/5834/12343/face/moisturizers/creme-de-la-mer', officialSourceLabel: 'La Mer Crème de la Mer page', genericVisualUrl: genericVisuals[0] }),
  discovery({ id: 'augustinus-bader-skincare-collection', brand: 'Augustinus Bader', productName: 'Augustinus Bader skincare collection', category: 'Collection', routineContext: 'AM / PM', discoveryFocus: 'Collection-level reference for a minimalist, research-inspired skincare mood board.', officialUrl: 'https://augustinusbader.com/int/en/the-rich-cream', officialSourceLabel: 'Augustinus Bader The Rich Cream page', genericVisualUrl: genericVisuals[3] }),
  discovery({ id: 'mbr-skincare-collection', brand: 'MBR', productName: 'MBR skincare collection', category: 'Collection', routineContext: 'Flexible', discoveryFocus: 'Collection-level reference for a clinical-luxury skincare mood board.', officialUrl: 'https://mbrcare.com/', officialSourceLabel: 'MBR Medical Beauty Research official site', genericVisualUrl: genericVisuals[0] }),
  discovery({ id: 'valmont-essentials-collection', brand: 'Valmont', productName: 'Valmont skincare collection', category: 'Collection', routineContext: 'Flexible', discoveryFocus: 'Collection-level reference for a Swiss-inspired luxury skincare mood board.', officialUrl: 'https://www.lamaisonvalmont.com/en/skincare.html', officialSourceLabel: 'Valmont skincare page', genericVisualUrl: genericVisuals[2] }),
];

export function getUltraLuxurySkinDiscoveryByBrand(brand: UltraLuxurySkinBrand): UltraLuxurySkinDiscoveryRecord[] {
  return ULTRA_LUXURY_SKIN_DISCOVERY_RECORDS.filter((record) => record.brand === brand);
}
