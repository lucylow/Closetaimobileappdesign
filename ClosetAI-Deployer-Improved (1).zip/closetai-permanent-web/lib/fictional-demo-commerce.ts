import type { CommerceCandidate, PriceWatchRule } from "../shared/agentic-commerce-contracts";
import { normalizeCandidate } from "./product-normalizer";
import { getReviewIntelligenceForProduct } from "./review-intelligence";

export const FICTIONAL_COMMERCE_DEMO_DISCLOSURE =
  "Fictional Demo Mode: All simulated product offers, review summaries, price watches, and reviewable checkouts are demonstration fixtures. No real merchant transactions, live prices, or external orders are executed.";

export const FICTIONAL_DEMO_CANDIDATES: CommerceCandidate[] = [
  normalizeCandidate({
    productId: "demo-skincare-barrier",
    merchantId: "Fictional Apothecary Direct",
    title: "Demo Barrier Protection Cream 60ml",
    brand: "Lurane Laboratories (Demo)",
    price: 29.50,
    shipping: 3.99,
    availability: "in_stock",
    productUrl: "https://example.com/demo/barrier-cream",
    providerName: "Fictional Demo Catalog Feed",
    isDemo: true,
  }),
  normalizeCandidate({
    productId: "demo-skincare-serum",
    merchantId: "Fictional Botanical Labs",
    title: "Demo Niacinamide & Peptide Renewal Serum 30ml",
    brand: "Vogue Botanicals (Demo)",
    price: 38.00,
    shipping: 0.00,
    availability: "in_stock",
    productUrl: "https://example.com/demo/renewal-serum",
    providerName: "Fictional Demo Skincare Feed",
    isDemo: true,
  }),
  normalizeCandidate({
    productId: "demo-fashion-blazer",
    merchantId: "Fictional Studio Apparel",
    title: "Demo Structured Linen Blend Blazer",
    brand: "Atelier Maison (Demo)",
    price: 165.00,
    shipping: 0.00,
    availability: "in_stock",
    productUrl: "https://example.com/demo/linen-blazer",
    providerName: "Fictional Demo Apparel Feed",
    isDemo: true,
  }),
  normalizeCandidate({
    productId: "demo-fashion-trousers",
    merchantId: "Fictional Tailored Edit",
    title: "Demo Pleated High-Waist Trouser",
    brand: "Studio Minimal (Demo)",
    price: 110.00,
    shipping: 5.00,
    availability: "low_stock",
    productUrl: "https://example.com/demo/high-waist-trouser",
    providerName: "Fictional Demo Apparel Feed",
    isDemo: true,
  }),
  normalizeCandidate({
    productId: "demo-accessories-silk",
    merchantId: "Fictional Accessories Lab",
    title: "Demo Pure Mulberry Silk Scarf",
    brand: "Studio Minimal (Demo)",
    price: 48.00,
    shipping: 2.50,
    availability: "low_stock",
    productUrl: "https://example.com/demo/silk-scarf",
    providerName: "Fictional Demo Accessories Feed",
    isDemo: true,
  }),
  normalizeCandidate({
    productId: "demo-accessories-tote",
    merchantId: "Fictional Leather Goods",
    title: "Demo Minimalist Leather Everyday Tote",
    brand: "Vanguard Goods (Demo)",
    price: 210.00,
    shipping: 0.00,
    availability: "in_stock",
    productUrl: "https://example.com/demo/leather-tote",
    providerName: "Fictional Demo Accessories Feed",
    isDemo: true,
  }),
].map(c => ({
  ...c,
  reviewSummary: getReviewIntelligenceForProduct(c.productId, true),
}));

export const FICTIONAL_DEMO_PRICE_WATCHES: PriceWatchRule[] = [
  {
    id: "demo-pw-01",
    candidateId: "demo-skincare-barrier",
    title: "Demo Barrier Protection Cream 60ml",
    targetPrice: { amount: 25.00, currency: "USD" },
    active: true,
    createdAt: new Date(Date.now() - 86400000).toISOString(),
  },
  {
    id: "demo-pw-02",
    candidateId: "demo-fashion-blazer",
    title: "Demo Structured Linen Blend Blazer",
    targetPrice: { amount: 150.00, currency: "USD" },
    active: true,
    createdAt: new Date(Date.now() - 86400000 * 3).toISOString(),
  },
  {
    id: "demo-pw-03",
    candidateId: "demo-accessories-tote",
    title: "Demo Minimalist Leather Everyday Tote",
    targetPrice: { amount: 190.00, currency: "USD" },
    active: true,
    createdAt: new Date(Date.now() - 86400000 * 5).toISOString(),
  },
];
