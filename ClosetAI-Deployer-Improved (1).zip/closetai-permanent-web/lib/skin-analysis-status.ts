export function getSkinScoreStatus(score?: number): string {
  if (score == null || !Number.isFinite(score)) return "Unavailable";
  if (score >= 80) return "Excellent";
  if (score >= 65) return "Good";
  if (score >= 50) return "Fair";
  return "Focus area";
}

export function getSkinAnalysisFallbackReason(error: unknown): string {
  if (error instanceof Error && error.name === "AbortError") {
    return "Live analysis was cancelled before completion.";
  }
  return "Live analysis was unavailable. Fictional Demo Mode visual-signal data is shown instead.";
}
