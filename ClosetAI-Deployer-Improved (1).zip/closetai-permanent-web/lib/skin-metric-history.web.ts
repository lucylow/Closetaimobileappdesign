import type { SkinAnalysisResult } from "@/lib/skin-analysis-controller";

export type SkinMetricHistoryPoint = {
  scanId: string;
  capturedAt: string;
  source: SkinAnalysisResult["source"];
  overallScore?: number;
  metricKey: string;
  score: number;
};

/** SQLite history is intentionally native-only. The web build keeps the chart interface available with an honest unavailable state. */
export async function saveSkinMetricHistory(_result: SkinAnalysisResult): Promise<void> {
  return Promise.resolve();
}

export async function loadSkinMetricHistory(_limit = 120): Promise<SkinMetricHistoryPoint[]> {
  throw new Error("SQLite-backed skin history is available in the native Expo app.");
}

export async function clearSkinMetricHistory(): Promise<void> {
  return Promise.resolve();
}
