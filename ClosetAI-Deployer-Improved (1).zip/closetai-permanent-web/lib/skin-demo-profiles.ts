export type DemoMetricStatus = "Excellent" | "Good" | "Balanced" | "Low" | "Low Concern" | "Moderate";

export interface DemoSkinMetric {
  id: string;
  label: string;
  score: number;
  status: DemoMetricStatus;
  description: string;
  action: string;
}

export interface DemoRoutineStep {
  id: string;
  step: number;
  name: string;
  category: string;
  description: string;
  duration: string;
}

export interface DemoSkinProfile {
  id: string;
  /** Optional fictional demo persona label; never represents a user identity. */
  displayName?: string;
  profileDisclosure?: string;
  overallScore: number;
  skinType: string;
  headline: string;
  summary: string;
  focus: string;
  styleSuggestion: string;
  metrics: DemoSkinMetric[];
  morningRoutine: DemoRoutineStep[];
  eveningRoutine: DemoRoutineStep[];
}

const sharedMorningRoutine: DemoRoutineStep[] = [
  { id: "am-cleanse", step: 1, name: "Gentle Cleanser", category: "Cleanse", description: "Use lukewarm water and keep the cleanse comfortable.", duration: "30 sec" },
  { id: "am-hydrate", step: 2, name: "Hydrating Serum", category: "Hydrate", description: "Press one lightweight layer into slightly damp skin.", duration: "20 sec" },
  { id: "am-moisturise", step: 3, name: "Barrier Moisturizer", category: "Moisturize", description: "Add a comfortable moisture layer before getting dressed.", duration: "20 sec" },
  { id: "am-protect", step: 4, name: "Daily SPF 30+", category: "Protect", description: "Finish with broad-spectrum sunscreen in the morning.", duration: "30 sec" },
];

const sharedEveningRoutine: DemoRoutineStep[] = [
  { id: "pm-cleanse", step: 1, name: "Gentle Cleanser", category: "Cleanse", description: "Remove the day without scrubbing or over-cleansing.", duration: "30 sec" },
  { id: "pm-treat", step: 2, name: "Treatment Serum", category: "Optional care", description: "Introduce one gentle treatment at a time when it suits your routine.", duration: "20 sec" },
  { id: "pm-moisturise", step: 3, name: "Barrier Moisturizer", category: "Moisturize", description: "Use a comfortable moisturizer to support overnight recovery.", duration: "20 sec" },
];

export const skinDemoProfiles: DemoSkinProfile[] = [
  {
    id: "combination-balanced",
    displayName: "Maya",
    profileDisclosure: "Fictional adult demo profile · not a user, diagnosis, or live scan.",
    overallScore: 84,
    skinType: "Combination",
    headline: "Balanced with a hydration opportunity",
    summary: "Your demo skin profile suggests balanced areas with opportunities to support hydration, texture, and radiance.",
    focus: "Hydration + Radiance",
    styleSuggestion: "Soft neutral tones and breathable fabrics complement today’s demo skin profile.",
    metrics: [
      { id: "hydration", label: "Hydration", score: 78, status: "Good", description: "Skin appears reasonably hydrated in this demo profile.", action: "Layer lightweight moisture consistently." },
      { id: "oiliness", label: "Oiliness", score: 46, status: "Balanced", description: "Oil levels are represented as balanced in this demo profile.", action: "Favor light layers over stripping cleansers." },
      { id: "texture", label: "Texture", score: 72, status: "Good", description: "Texture is represented as generally smooth with room for improvement.", action: "Keep changes gradual and repeatable." },
      { id: "pores", label: "Pores", score: 39, status: "Low Concern", description: "Visible pore concern is represented as relatively low.", action: "Maintain gentle cleansing and daily sunscreen." },
      { id: "redness", label: "Redness", score: 28, status: "Low", description: "Redness is represented as relatively low in this demo.", action: "Keep the routine fragrance-conscious if skin feels sensitive." },
      { id: "blemishes", label: "Blemishes", score: 18, status: "Low", description: "Blemish concern is represented as low in this demo profile.", action: "Avoid adding unnecessary treatment steps." },
      { id: "radiance", label: "Radiance", score: 81, status: "Excellent", description: "Radiance is represented as one of this profile’s strongest areas.", action: "Protect the glow with consistent SPF." },
      { id: "dark-spots", label: "Dark Spots", score: 61, status: "Moderate", description: "Dark spot concern is represented as an area for improvement.", action: "Support tone with steady daily protection." },
      { id: "fine-lines", label: "Fine Lines", score: 67, status: "Good", description: "Fine line concern is represented as moderate-to-low in this demo.", action: "Prioritize moisture and gentle consistency." },
    ],
    morningRoutine: sharedMorningRoutine,
    eveningRoutine: sharedEveningRoutine,
  },
  {
    id: "dry-comfort",
    displayName: "Sofia",
    profileDisclosure: "Fictional adult demo profile · not a user, diagnosis, or live scan.",
    overallScore: 79,
    skinType: "Dry",
    headline: "Comfort-first with a barrier focus",
    summary: "Your demo skin profile highlights a comfort-led routine with extra attention to moisture and a simple evening reset.",
    focus: "Comfort + Hydration",
    styleSuggestion: "Cream knits, soft blues, and warm camel layers create a gentle, polished wardrobe direction.",
    metrics: [
      { id: "hydration", label: "Hydration", score: 58, status: "Moderate", description: "Hydration is represented as the main opportunity in this dry demo profile.", action: "Keep a supportive moisturizer in both routines." },
      { id: "oiliness", label: "Oiliness", score: 24, status: "Low", description: "Oil activity is represented as low in this demo profile.", action: "Avoid over-cleansing or stripping product layers." },
      { id: "texture", label: "Texture", score: 63, status: "Good", description: "Texture is represented as steady with room for comfort support.", action: "Introduce only one optional treatment at a time." },
      { id: "pores", label: "Pores", score: 31, status: "Low Concern", description: "Visible pore concern is represented as low.", action: "Use gentle cleansing and avoid aggressive exfoliation." },
      { id: "redness", label: "Redness", score: 41, status: "Balanced", description: "Redness is represented as a gentle watch area in this demo.", action: "Choose calm, fragrance-conscious basics if needed." },
      { id: "blemishes", label: "Blemishes", score: 22, status: "Low", description: "Blemish concern is represented as low in this demo profile.", action: "Keep the routine simple rather than adding extra steps." },
      { id: "radiance", label: "Radiance", score: 68, status: "Good", description: "Radiance is represented as steady and supportable.", action: "Use daily sun protection as a consistent final step." },
      { id: "dark-spots", label: "Dark Spots", score: 54, status: "Moderate", description: "Tone support is represented as an optional focus area.", action: "Stay consistent with broad-spectrum sunscreen." },
      { id: "fine-lines", label: "Fine Lines", score: 61, status: "Moderate", description: "Fine lines are represented as an everyday texture consideration.", action: "Prioritize hydration and comfortable layering." },
    ],
    morningRoutine: sharedMorningRoutine,
    eveningRoutine: sharedEveningRoutine,
  },
  {
    id: "oily-clarity",
    displayName: "Aisha",
    profileDisclosure: "Fictional adult demo profile · not a user, diagnosis, or live scan.",
    overallScore: 82,
    skinType: "Oily",
    headline: "Clear, balanced, and ready for a light routine",
    summary: "Your demo skin profile suggests an uncomplicated balance of lightweight hydration, daily protection, and calm consistency.",
    focus: "Clarity + Radiance",
    styleSuggestion: "Crisp white, navy, and breathable cotton layers create a fresh, confident wardrobe direction.",
    metrics: [
      { id: "hydration", label: "Hydration", score: 71, status: "Good", description: "Hydration is represented as steady with room for lightweight support.", action: "Use light layers rather than skipping moisture." },
      { id: "oiliness", label: "Oiliness", score: 67, status: "Balanced", description: "Oil activity is represented as noticeable but balanced in this demo.", action: "Choose gentle cleansing instead of harsh stripping steps." },
      { id: "texture", label: "Texture", score: 76, status: "Good", description: "Texture is represented as generally smooth in this demo profile.", action: "Keep the routine consistent and low-complexity." },
      { id: "pores", label: "Pores", score: 52, status: "Moderate", description: "Visible pore concern is represented as a moderate watch area.", action: "Use a steady cleanser and avoid over-exfoliating." },
      { id: "redness", label: "Redness", score: 25, status: "Low", description: "Redness is represented as low in this demo profile.", action: "Continue with simple, comfortable product choices." },
      { id: "blemishes", label: "Blemishes", score: 36, status: "Balanced", description: "Blemish concern is represented as a manageable reflection point.", action: "Add only one optional treatment at a time." },
      { id: "radiance", label: "Radiance", score: 84, status: "Excellent", description: "Radiance is represented as a strong area in this demo profile.", action: "Maintain daily sun protection and hydration." },
      { id: "dark-spots", label: "Dark Spots", score: 58, status: "Moderate", description: "Tone support is represented as an optional, long-term focus.", action: "Use daily SPF and patient consistency." },
      { id: "fine-lines", label: "Fine Lines", score: 69, status: "Good", description: "Fine line concern is represented as low-to-moderate in this demo.", action: "Support comfort with lightweight moisturising layers." },
    ],
    morningRoutine: sharedMorningRoutine,
    eveningRoutine: sharedEveningRoutine,
  },
  {
    id: "normal-radiance",
    displayName: "Leila",
    profileDisclosure: "Fictional adult demo profile · not a user, diagnosis, or live scan.",
    overallScore: 88,
    skinType: "Normal",
    headline: "Radiance-led with a simple daily rhythm",
    summary: "This fictional demo profile keeps the routine concise, with visual signals centered on radiance, hydration, and comfortable consistency.",
    focus: "Radiance + Consistency",
    styleSuggestion: "Jewel-tone accents, clean tailoring, and a compact crossbody create a bright, polished styling direction.",
    metrics: [
      { id: "hydration", label: "Hydration", score: 83, status: "Excellent", description: "Hydration is represented as a strong signal in this fictional demo.", action: "Keep the routine comfortable and repeatable." },
      { id: "oiliness", label: "Oiliness", score: 38, status: "Balanced", description: "Oil activity is represented as balanced in this fictional demo.", action: "Favor gentle cleansing over aggressive resets." },
      { id: "texture", label: "Texture", score: 81, status: "Excellent", description: "Texture is represented as generally smooth in this fictional demo.", action: "Change one routine step at a time." },
      { id: "pores", label: "Pores", score: 34, status: "Low Concern", description: "Visible pore concern is represented as low in this fictional demo.", action: "Maintain a simple cleanse-and-protect rhythm." },
      { id: "redness", label: "Redness", score: 22, status: "Low", description: "Redness is represented as low in this fictional demo.", action: "Choose comfortable basics if skin feels reactive." },
      { id: "blemishes", label: "Blemishes", score: 19, status: "Low", description: "Blemish concern is represented as low in this fictional demo.", action: "Avoid adding unnecessary active steps." },
      { id: "radiance", label: "Radiance", score: 91, status: "Excellent", description: "Radiance is represented as the strongest signal in this fictional demo.", action: "Protect the visual result with daily SPF." },
      { id: "dark-spots", label: "Dark Spots", score: 48, status: "Balanced", description: "Tone variation is represented as a moderate visual consideration, not a diagnosis.", action: "Keep sun protection consistent." },
      { id: "fine-lines", label: "Fine Lines", score: 73, status: "Good", description: "Fine lines are represented as a low-priority visual signal in this fictional demo.", action: "Support comfort with steady moisture." },
    ],
    morningRoutine: sharedMorningRoutine,
    eveningRoutine: sharedEveningRoutine,
  },
  {
    id: "calm-comfort",
    displayName: "Nora",
    profileDisclosure: "Fictional adult demo profile · not a user, diagnosis, or live scan.",
    overallScore: 76,
    skinType: "Comfort-focused",
    headline: "A calm, minimal routine direction",
    summary: "This fictional demo profile emphasizes a smaller routine, comfortable layers, and gentle consistency rather than more products.",
    focus: "Comfort + Texture",
    styleSuggestion: "Soft gray, oat, and relaxed denim create an easy wardrobe direction for a low-complexity demo routine.",
    metrics: [
      { id: "hydration", label: "Hydration", score: 64, status: "Good", description: "Hydration is represented as steady with room for comfortable support.", action: "Use one dependable moisture layer." },
      { id: "oiliness", label: "Oiliness", score: 31, status: "Low", description: "Oil activity is represented as low in this fictional demo.", action: "Avoid over-cleansing or stacking too many steps." },
      { id: "texture", label: "Texture", score: 59, status: "Moderate", description: "Texture is represented as an optional visual focus, not a clinical measurement.", action: "Keep changes gradual and easy to pause." },
      { id: "pores", label: "Pores", score: 42, status: "Balanced", description: "Visible pore concern is represented as balanced in this fictional demo.", action: "Choose a gentle cleanser and avoid harsh scrubbing." },
      { id: "redness", label: "Redness", score: 46, status: "Balanced", description: "Redness is represented as a watch area in this fictional demo.", action: "Prefer fragrance-conscious basics when helpful." },
      { id: "blemishes", label: "Blemishes", score: 29, status: "Low", description: "Blemish concern is represented as low in this fictional demo.", action: "Keep the routine simple rather than adding more actives." },
      { id: "radiance", label: "Radiance", score: 70, status: "Good", description: "Radiance is represented as steady in this fictional demo.", action: "Use daily protection as the final AM step." },
      { id: "dark-spots", label: "Dark Spots", score: 51, status: "Moderate", description: "Tone variation is represented as an optional visual focus, not a diagnosis.", action: "Stay consistent with broad-spectrum sunscreen." },
      { id: "fine-lines", label: "Fine Lines", score: 57, status: "Moderate", description: "Fine lines are represented as a visual texture consideration only.", action: "Prioritize hydration and comfortable layering." },
    ],
    morningRoutine: sharedMorningRoutine,
    eveningRoutine: sharedEveningRoutine,
  },
];

export function getNextSkinDemoProfile(currentIndex: number) {
  return skinDemoProfiles[(currentIndex + 1) % skinDemoProfiles.length];
}
