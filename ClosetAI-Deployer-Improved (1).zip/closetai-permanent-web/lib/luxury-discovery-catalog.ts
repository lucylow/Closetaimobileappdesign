/**
 * Curated external discovery records for Luxury Houses. These are not product listings,
 * store integrations, affiliate offers, price records, or evidence of availability.
 */
export const LUXURY_DISCOVERY_DISCLOSURE =
  'Luxury discovery references are curated mock data for inspiration only. Links open official brand destinations when available; ClosetAI is not affiliated with these houses and does not provide live price, inventory, checkout, authenticity, resale, or availability information.';

export type LuxuryHouse = 'Hermès' | 'Louis Vuitton' | 'Chanel' | 'Dior' | 'Gucci' | 'Fendi';

export type LuxuryDiscoveryRecord = {
  id: string;
  house: LuxuryHouse;
  pieceName: string;
  category: 'bag' | 'ready-to-wear' | 'shoe' | 'accessory';
  styleDirection: string;
  occasionTags: string[];
  palette: string[];
  officialUrl: string;
  officialSourceLabel: string;
  genericReferenceImageUrl: string;
  imageDisclosure: string;
  dataMode: 'mock-discovery';
  externalOnly: true;
  disclosure: string;
};

const genericVisual = [
  'https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/uEGuUQznzoQGxTyI.jpg',
  'https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/aoDpHwsuIVqkqJpl.jpg',
  'https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/GaOMnbGAuDYVmWGG.jpg',
  'https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/hjmzuQIkJyHxhodK.jpg',
  'https://files.manuscdn.com/user_upload_by_module/session_file/310519663046827250/XEbwjTSbANPzrRPD.jpg',
] as const;

const visualDisclosure = 'Generic garment-only Demo Mode reference image. It is not official brand photography, a representation of a listed piece, or live inventory.';

function discovery(input: Omit<LuxuryDiscoveryRecord, 'dataMode' | 'externalOnly' | 'disclosure' | 'imageDisclosure'>): LuxuryDiscoveryRecord {
  return {
    ...input,
    dataMode: 'mock-discovery',
    externalOnly: true,
    disclosure: LUXURY_DISCOVERY_DISCLOSURE,
    imageDisclosure: visualDisclosure,
  };
}

export const LUXURY_DISCOVERY_RECORDS: LuxuryDiscoveryRecord[] = [
  discovery({ id: 'hermes-birkin-collection', house: 'Hermès', pieceName: 'Birkin bag collection', category: 'bag', styleDirection: 'Structured heritage carryall study', occasionTags: ['occasion', 'travel', 'heritage'], palette: ['Tan', 'Black', 'Neutral'], officialUrl: 'https://www.hermes.com/us/en/content/106191-birkin/', officialSourceLabel: 'Hermès Birkin collection', genericReferenceImageUrl: genericVisual[0] }),
  discovery({ id: 'hermes-womens-bags', house: 'Hermès', pieceName: 'Women’s bags and clutches', category: 'bag', styleDirection: 'Leather-goods silhouettes and evening accessories', occasionTags: ['work', 'evening', 'travel'], palette: ['Brown', 'Black', 'Red'], officialUrl: 'https://www.hermes.com/us/en/category/leather-goods/bags-and-clutches/womens-bags-and-clutches/', officialSourceLabel: 'Hermès women’s bags and clutches', genericReferenceImageUrl: genericVisual[2] }),
  discovery({ id: 'louis-vuitton-neverfull', house: 'Louis Vuitton', pieceName: 'Neverfull handbag collection', category: 'bag', styleDirection: 'Open tote and day-to-evening carryall inspiration', occasionTags: ['work', 'travel', 'everyday'], palette: ['Brown', 'Black', 'Neutral'], officialUrl: 'https://us.louisvuitton.com/eng-us/women/handbags/all-handbags/neverfull/_/N-tfr7qdp-akyxcuct', officialSourceLabel: 'Louis Vuitton Neverfull collection', genericReferenceImageUrl: genericVisual[2] }),
  discovery({ id: 'louis-vuitton-speedy', house: 'Louis Vuitton', pieceName: 'Speedy handbag collection', category: 'bag', styleDirection: 'Compact top-handle travel-inspired silhouette', occasionTags: ['travel', 'weekend', 'everyday'], palette: ['Brown', 'Black', 'Red'], officialUrl: 'https://us.louisvuitton.com/eng-us/women/handbags/all-handbags/speedy/_/N-tfr7qdp-ak5wlig', officialSourceLabel: 'Louis Vuitton Speedy collection', genericReferenceImageUrl: genericVisual[1] }),
  discovery({ id: 'chanel-25', house: 'Chanel', pieceName: 'CHANEL 25 handbag', category: 'bag', styleDirection: 'Soft shoulder-bag proportions and refined utility', occasionTags: ['city', 'evening', 'weekend'], palette: ['Black', 'Pink', 'Neutral'], officialUrl: 'https://www.chanel.com/us/fashion/handbags/chanel-25/', officialSourceLabel: 'CHANEL 25 handbags', genericReferenceImageUrl: genericVisual[4] }),
  discovery({ id: 'chanel-handbags', house: 'Chanel', pieceName: 'Handbags selection', category: 'bag', styleDirection: 'Classic flap, shopping, and shoulder-bag styling references', occasionTags: ['evening', 'occasion', 'city'], palette: ['Black', 'Burgundy', 'Gold'], officialUrl: 'https://www.chanel.com/us/fashion/handbags/c/1x1x1/', officialSourceLabel: 'CHANEL handbags', genericReferenceImageUrl: genericVisual[0] }),
  discovery({ id: 'dior-lady-dior', house: 'Dior', pieceName: 'Lady Dior bags', category: 'bag', styleDirection: 'Structured top-handle and polished occasion styling', occasionTags: ['occasion', 'evening', 'work'], palette: ['Black', 'Neutral', 'Blue'], officialUrl: 'https://www.dior.com/en_us/fashion/womens-fashion/bags/lady-dior', officialSourceLabel: 'Dior Lady Dior bags', genericReferenceImageUrl: genericVisual[3] }),
  discovery({ id: 'dior-all-bags', house: 'Dior', pieceName: 'Women’s designer bags', category: 'bag', styleDirection: 'Editorial handbag silhouettes for wardrobe mood boards', occasionTags: ['city', 'occasion', 'travel'], palette: ['Neutral', 'Black', 'Red'], officialUrl: 'https://www.dior.com/en_us/fashion/womens-fashion/bags/all-the-bags', officialSourceLabel: 'Dior women’s bags', genericReferenceImageUrl: genericVisual[2] }),
  discovery({ id: 'gucci-gg-marmont', house: 'Gucci', pieceName: 'GG Marmont shoulder bag', category: 'bag', styleDirection: 'Statement shoulder-bag and evening accessory direction', occasionTags: ['evening', 'city', 'occasion'], palette: ['Black', 'Burgundy', 'Pink'], officialUrl: 'https://www.gucci.com/us/en/ca/women/handbags-c-women-handbags', officialSourceLabel: 'Gucci women’s designer handbags', genericReferenceImageUrl: genericVisual[4] }),
  discovery({ id: 'gucci-giglio-tote', house: 'Gucci', pieceName: 'Gucci Giglio tote', category: 'bag', styleDirection: 'Large tote and polished workday carry inspiration', occasionTags: ['work', 'travel', 'everyday'], palette: ['Brown', 'Neutral', 'Black'], officialUrl: 'https://www.gucci.com/us/en/ca/women/handbags-c-women-handbags', officialSourceLabel: 'Gucci women’s designer handbags', genericReferenceImageUrl: genericVisual[0] }),
  discovery({ id: 'fendi-baguette', house: 'Fendi', pieceName: 'Baguette bag collection', category: 'bag', styleDirection: 'Compact shoulder-bag and accessory color-story inspiration', occasionTags: ['city', 'evening', 'weekend'], palette: ['Purple', 'Pink', 'Neutral'], officialUrl: 'https://www.fendi.com/us-en/woman/bags/baguette', officialSourceLabel: 'Fendi Baguette bags', genericReferenceImageUrl: genericVisual[1] }),
  discovery({ id: 'fendi-peekaboo', house: 'Fendi', pieceName: 'Peekaboo bag collection', category: 'bag', styleDirection: 'Structured carryall and understated tailoring direction', occasionTags: ['work', 'occasion', 'travel'], palette: ['Black', 'Brown', 'Neutral'], officialUrl: 'https://www.fendi.com/us-en/woman/bags/peekaboo', officialSourceLabel: 'Fendi Peekaboo bags', genericReferenceImageUrl: genericVisual[3] }),
  discovery({ id: 'hermes-silk-selection', house: 'Hermès', pieceName: 'Silk scarf selection', category: 'accessory', styleDirection: 'Color-story accent for a neutral wardrobe base', occasionTags: ['travel', 'weekend', 'occasion'], palette: ['Red', 'Blue', 'Gold'], officialUrl: 'https://www.hermes.com/us/en/category/silk/', officialSourceLabel: 'Hermès silk selection', genericReferenceImageUrl: genericVisual[1] }),
  discovery({ id: 'hermes-womens-ready-to-wear', house: 'Hermès', pieceName: 'Women’s ready-to-wear selection', category: 'ready-to-wear', styleDirection: 'Quiet luxury tailoring and relaxed structured layers', occasionTags: ['work', 'city', 'occasion'], palette: ['Camel', 'Black', 'Cream'], officialUrl: 'https://www.hermes.com/us/en/category/women/ready-to-wear/', officialSourceLabel: 'Hermès women’s ready-to-wear', genericReferenceImageUrl: genericVisual[3] }),
  discovery({ id: 'louis-vuitton-womens-shoes', house: 'Louis Vuitton', pieceName: 'Women’s shoe selection', category: 'shoe', styleDirection: 'Polished finishing piece for travel and city looks', occasionTags: ['city', 'travel', 'evening'], palette: ['Black', 'White', 'Gold'], officialUrl: 'https://us.louisvuitton.com/eng-us/women/shoes/_/N-1s0h1h', officialSourceLabel: 'Louis Vuitton women’s shoes', genericReferenceImageUrl: genericVisual[4] }),
  discovery({ id: 'louis-vuitton-fashion-jewelry', house: 'Louis Vuitton', pieceName: 'Fashion jewelry selection', category: 'accessory', styleDirection: 'Monogram-inspired accent direction for a simple base', occasionTags: ['occasion', 'city', 'evening'], palette: ['Gold', 'Silver', 'Black'], officialUrl: 'https://us.louisvuitton.com/eng-us/women/fashion-jewelry/_/N-1j1h3s', officialSourceLabel: 'Louis Vuitton women’s fashion jewelry', genericReferenceImageUrl: genericVisual[0] }),
  discovery({ id: 'chanel-shoes-selection', house: 'Chanel', pieceName: 'Women’s shoes selection', category: 'shoe', styleDirection: 'Classic two-tone and occasion-ready finishing ideas', occasionTags: ['city', 'occasion', 'evening'], palette: ['Black', 'Beige', 'White'], officialUrl: 'https://www.chanel.com/us/fashion/shoes/c/1x1x2/', officialSourceLabel: 'CHANEL women’s shoes', genericReferenceImageUrl: genericVisual[2] }),
  discovery({ id: 'chanel-costume-jewelry', house: 'Chanel', pieceName: 'Costume jewelry selection', category: 'accessory', styleDirection: 'Pearl, chain, and gold-tone accents for evening styling', occasionTags: ['evening', 'occasion', 'city'], palette: ['Gold', 'Pearl', 'Black'], officialUrl: 'https://www.chanel.com/us/fashion/jewelry/costume-jewelry/c/1x1x3/', officialSourceLabel: 'CHANEL costume jewelry', genericReferenceImageUrl: genericVisual[1] }),
  discovery({ id: 'dior-ready-to-wear-selection', house: 'Dior', pieceName: 'Women’s ready-to-wear selection', category: 'ready-to-wear', styleDirection: 'Tailored silhouettes with an editorial occasion direction', occasionTags: ['work', 'occasion', 'evening'], palette: ['Navy', 'Cream', 'Black'], officialUrl: 'https://www.dior.com/en_us/fashion/womens-fashion/ready-to-wear', officialSourceLabel: 'Dior women’s ready-to-wear', genericReferenceImageUrl: genericVisual[0] }),
  discovery({ id: 'dior-womens-shoes', house: 'Dior', pieceName: 'Women’s shoes selection', category: 'shoe', styleDirection: 'Polished footwear reference for tailored and evening looks', occasionTags: ['city', 'occasion', 'evening'], palette: ['Black', 'Red', 'Neutral'], officialUrl: 'https://www.dior.com/en_us/fashion/womens-fashion/shoes', officialSourceLabel: 'Dior women’s shoes', genericReferenceImageUrl: genericVisual[4] }),
  discovery({ id: 'gucci-ready-to-wear-selection', house: 'Gucci', pieceName: 'Women’s ready-to-wear selection', category: 'ready-to-wear', styleDirection: 'Maximalist color and heritage tailoring inspiration', occasionTags: ['city', 'evening', 'occasion'], palette: ['Green', 'Red', 'Black'], officialUrl: 'https://www.gucci.com/us/en/ca/women/ready-to-wear-c-women-ready-to-wear', officialSourceLabel: 'Gucci women’s ready-to-wear', genericReferenceImageUrl: genericVisual[2] }),
  discovery({ id: 'gucci-womens-shoes', house: 'Gucci', pieceName: 'Women’s shoes selection', category: 'shoe', styleDirection: 'Loafer, boot, and statement footwear mood-board direction', occasionTags: ['work', 'city', 'weekend'], palette: ['Brown', 'Black', 'Red'], officialUrl: 'https://www.gucci.com/us/en/ca/women/shoes-c-women-shoes', officialSourceLabel: 'Gucci women’s shoes', genericReferenceImageUrl: genericVisual[3] }),
  discovery({ id: 'fendi-ready-to-wear-selection', house: 'Fendi', pieceName: 'Women’s ready-to-wear selection', category: 'ready-to-wear', styleDirection: 'Graphic tailoring and refined city-layering inspiration', occasionTags: ['city', 'work', 'evening'], palette: ['Brown', 'Black', 'Yellow'], officialUrl: 'https://www.fendi.com/us-en/woman/ready-to-wear', officialSourceLabel: 'Fendi women’s ready-to-wear', genericReferenceImageUrl: genericVisual[0] }),
  discovery({ id: 'fendi-womens-shoes', house: 'Fendi', pieceName: 'Women’s shoes selection', category: 'shoe', styleDirection: 'A polished footwear accent for travel and occasion looks', occasionTags: ['travel', 'city', 'occasion'], palette: ['Black', 'White', 'Brown'], officialUrl: 'https://www.fendi.com/us-en/woman/shoes', officialSourceLabel: 'Fendi women’s shoes', genericReferenceImageUrl: genericVisual[4] }),
];

export function getLuxuryDiscoveryByHouse(house: LuxuryHouse): LuxuryDiscoveryRecord[] {
  return LUXURY_DISCOVERY_RECORDS.filter((record) => record.house === house);
}
