/**
 * Shared UI-only cosmetic visual presets. They are not face tracking, skin analysis,
 * product simulation, treatment prediction, color-neutralization evidence, or a formula model.
 */
export type ArVisualMode = {
  id: 'guide' | 'dewy-light' | 'satin-veil' | 'soft-focus';
  title: string;
  description: string;
  overlay: readonly [string, string, string];
};

export const AR_VISUAL_MODES: ArVisualMode[] = [
  { id: 'guide', title: 'Guide only', description: 'No cosmetic overlay; use the frame guide only.', overlay: ['rgba(0,0,0,0)', 'rgba(0,0,0,0)', 'rgba(0,0,0,0)'] },
  { id: 'dewy-light', title: 'Dewy light', description: 'A warm translucent lighting overlay for visual styling only.', overlay: ['rgba(255,247,230,0.03)', 'rgba(255,224,166,0.22)', 'rgba(255,255,255,0.09)'] },
  { id: 'satin-veil', title: 'Satin veil', description: 'A neutral color-balance overlay for visual styling only.', overlay: ['rgba(246,240,231,0.11)', 'rgba(218,196,169,0.15)', 'rgba(255,255,255,0.03)'] },
  { id: 'soft-focus', title: 'Soft-focus glow', description: 'A gentle peach-toned overlay for visual styling only.', overlay: ['rgba(255,239,234,0.14)', 'rgba(240,191,178,0.12)', 'rgba(255,255,255,0.05)'] },
];

export type ArOverlayIntensity = {
  id: 'subtle' | 'balanced' | 'full';
  title: string;
  opacity: number;
  description: string;
};

export const AR_OVERLAY_INTENSITIES: ArOverlayIntensity[] = [
  { id: 'subtle', title: 'Subtle', opacity: 0.35, description: 'A light local overlay for side-by-side visual comparison.' },
  { id: 'balanced', title: 'Balanced', opacity: 0.65, description: 'A medium local overlay for side-by-side visual comparison.' },
  { id: 'full', title: 'Full', opacity: 1, description: 'The full local overlay rendering for side-by-side visual comparison.' },
];

export type ArEnvironmentCue = {
  id: 'indoor-dry' | 'warm-humid' | 'outdoor-daylight' | 'calm-day';
  title: string;
  description: string;
  preferredCategories: Array<'Moisturizer' | 'SPF' | 'Cleanser' | 'Serum' | 'Treatment'>;
};

export const AR_ENVIRONMENT_CUES: ArEnvironmentCue[] = [
  { id: 'indoor-dry', title: 'Indoor / dry-air feel', description: 'A local comfort cue; review a moisturizer category and your product label.', preferredCategories: ['Moisturizer', 'Cleanser'] },
  { id: 'warm-humid', title: 'Warm / humid feel', description: 'A local comfort cue; review a simple cleanser or lightweight routine category.', preferredCategories: ['Cleanser', 'Serum'] },
  { id: 'outdoor-daylight', title: 'Outdoor daylight', description: 'A local context cue; review an SPF category and follow the current product label.', preferredCategories: ['SPF', 'Moisturizer'] },
  { id: 'calm-day', title: 'Calm / no added cue', description: 'No environmental inference is made; explore a basic routine category only.', preferredCategories: ['Cleanser', 'Moisturizer'] },
];

export const AR_VISUAL_PREVIEW_DISCLOSURE = 'AR visual modes are local cosmetic-style overlays for interface exploration only. They do not track facial features, assess skin, diagnose a condition, neutralize redness, predict treatment results, demonstrate product efficacy, or replicate any product or brand formula. Comparison controls show only your original selected photo and the local interface overlay.';
