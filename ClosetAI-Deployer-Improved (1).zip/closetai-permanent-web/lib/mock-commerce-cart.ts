import { MOCK_COMMERCE_DISCLOSURE, type CommerceAvailability, type CommerceListing } from "@/lib/skin-commerce-provider";

export { MOCK_COMMERCE_DISCLOSURE };

export type MockCartLine = {
  productId: string;
  title: string;
  unitPrice: number;
  quantity: number;
  availability: CommerceAvailability;
  availableQuantity: number;
};

export type MockCartState = {
  cartId: string;
  lines: MockCartLine[];
  currency: "USD";
  updatedAt: string;
  disclosure: string;
};

export type MockCartOperation = "added" | "quantity_updated" | "removed" | "unavailable" | "stock_limit";
export type MockCartOperationResult = { cart: MockCartState; operation: MockCartOperation; message: string };

export function emptyMockCart(): MockCartState {
  return { cartId: "mock-cart-local", lines: [], currency: "USD", updatedAt: new Date().toISOString(), disclosure: MOCK_COMMERCE_DISCLOSURE };
}

export function mockCartSubtotal(cart: MockCartState) {
  return Number(cart.lines.reduce((total, line) => total + line.unitPrice * line.quantity, 0).toFixed(2));
}

export function mockCartItemCount(cart: MockCartState) {
  return cart.lines.reduce((total, line) => total + line.quantity, 0);
}

function withUpdatedAt(cart: MockCartState, lines: MockCartLine[]): MockCartState {
  return { ...cart, lines, updatedAt: new Date().toISOString(), disclosure: MOCK_COMMERCE_DISCLOSURE };
}

function asLine(listing: CommerceListing, quantity: number): MockCartLine {
  return { productId: listing.productId, title: listing.title, unitPrice: listing.unitPrice, quantity, availability: listing.availability, availableQuantity: listing.availableQuantity };
}

/** Adds a single unit while respecting the current mock listing state and available stock. */
export function addMockCartItem(cart: MockCartState, listing: CommerceListing): MockCartOperationResult {
  if (listing.availability === "out_of_stock" || listing.availableQuantity < 1) {
    return { cart, operation: "unavailable", message: `${listing.title} is unavailable in the mock catalog.` };
  }
  const existing = cart.lines.find((line) => line.productId === listing.productId);
  const nextQuantity = (existing?.quantity || 0) + 1;
  if (nextQuantity > listing.availableQuantity) {
    return { cart: withUpdatedAt(cart, cart.lines.map((line) => line.productId === listing.productId ? asLine(listing, line.quantity) : line)), operation: "stock_limit", message: `Mock inventory limit reached: ${listing.availableQuantity} available.` };
  }
  const nextLines = existing
    ? cart.lines.map((line) => line.productId === listing.productId ? asLine(listing, nextQuantity) : line)
    : [...cart.lines, asLine(listing, 1)];
  return { cart: withUpdatedAt(cart, nextLines), operation: "added", message: `${listing.title} was added to the mock cart.` };
}

/** Sets a line quantity, removes at zero, and caps positive quantities at the mock inventory limit. */
export function setMockCartItemQuantity(cart: MockCartState, listing: CommerceListing, requestedQuantity: number): MockCartOperationResult {
  const existing = cart.lines.find((line) => line.productId === listing.productId);
  if (!existing) return { cart, operation: "unavailable", message: "This item is not currently in the mock cart." };
  if (requestedQuantity <= 0) {
    return { cart: withUpdatedAt(cart, cart.lines.filter((line) => line.productId !== listing.productId)), operation: "removed", message: `${listing.title} was removed from the mock cart.` };
  }
  if (listing.availability === "out_of_stock" || listing.availableQuantity < 1) {
    return { cart: withUpdatedAt(cart, cart.lines.map((line) => line.productId === listing.productId ? asLine(listing, line.quantity) : line)), operation: "unavailable", message: `${listing.title} is now unavailable in the mock catalog. Remove it or wait for a future mock restock.` };
  }
  const safeQuantity = Math.min(Math.max(1, Math.floor(requestedQuantity)), listing.availableQuantity);
  const operation: MockCartOperation = safeQuantity < requestedQuantity ? "stock_limit" : "quantity_updated";
  const message = operation === "stock_limit" ? `Quantity was limited to ${listing.availableQuantity} by mock inventory.` : `${listing.title} quantity updated to ${safeQuantity}.`;
  return { cart: withUpdatedAt(cart, cart.lines.map((line) => line.productId === listing.productId ? asLine(listing, safeQuantity) : line)), operation, message };
}

/** Removes a persisted prototype line without requiring a catalog refresh. */
export function removeMockCartItem(cart: MockCartState, productId: string): MockCartOperationResult {
  const line = cart.lines.find((item) => item.productId === productId);
  if (!line) return { cart, operation: "unavailable", message: "This item is not currently in the mock cart." };
  return {
    cart: withUpdatedAt(cart, cart.lines.filter((item) => item.productId !== productId)),
    operation: "removed",
    message: `${line.title} was removed from the mock cart.`,
  };
}
