import { apiRequest } from "@/lib/query-client";
import type { FaceAttributeAction, FaceAttributeResult } from "@shared/face-attributes";
import type { FaceAngleStrictness } from "@shared/facial-color-tones";

export type FaceAttributesResponse = {
  attributes: FaceAttributeResult;
  actions: FaceAttributeAction[];
  strictness: FaceAngleStrictness;
  disclosure: string;
};

export async function analyzeFaceAttributes(
  imageBase64: string,
  actions?: FaceAttributeAction[],
  faceAngleStrictness: FaceAngleStrictness = "high",
): Promise<FaceAttributesResponse> {
  const response = await apiRequest("POST", "/api/skin/face-attributes", {
    imageBase64,
    actions,
    faceAngleStrictness,
  });
  return response.json();
}
