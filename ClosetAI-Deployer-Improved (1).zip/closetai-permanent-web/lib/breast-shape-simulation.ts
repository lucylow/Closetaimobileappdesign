import { apiRequest } from "@/lib/query-client";
import type { BreastShapeIntensity, BreastShapeSimulationResult } from "@shared/breast-shape-simulation";

export type BreastShapeSimulationResponse = {
  simulation: BreastShapeSimulationResult;
  disclosure: string;
};

export async function createBreastShapeSimulation(input: {
  imageBase64: string;
  intensity: BreastShapeIntensity;
  adultConfirmed: boolean;
  consent: boolean;
}): Promise<BreastShapeSimulationResponse> {
  const response = await apiRequest("POST", "/api/skin/breast-shape", input);
  return response.json();
}
