import { apiRequest } from "@/lib/query-client";
import type { FaceAngleStrictness, FacialColorTones } from "@shared/facial-color-tones";

export type FacialColorTonesResponse = {
  colors: FacialColorTones;
  strictness: FaceAngleStrictness;
  disclosure: string;
};

export async function analyzeFacialColorTones(imageBase64: string, faceAngleStrictness: FaceAngleStrictness = "high"): Promise<FacialColorTonesResponse> {
  const response = await apiRequest("POST", "/api/skin/color-tones", { imageBase64, faceAngleStrictness });
  return response.json();
}
