import type { SkinGoalId } from "@/lib/skin-navigation-data";
import { realSkinProductCatalog, type RealSkinProduct, type SkinConcernKey } from "@/lib/skin-product-catalog";
import type { SkinAnalysisSource, SkinMetric, SkinMetricKey } from "@/lib/skin-analysis-controller";

export type RecommendedProductsSource = "youcam" | "demo" | "none";
export type RecommendedProductsRoutineFilter = "All" | "AM" | "PM";

export type RecommendedProduct = RealSkinProduct & {
  rank: number;
  source: RecommendedProductsSource;
  recommendationReasons: string[];
  matchedGoals: SkinGoalId[];
  matchedSignals: SkinConcernKey[];
  savedLocally: boolean;
  routineContext: "AM" | "PM" | "AM / PM";
};

export type RecommendedProductsPlan = {
  source: RecommendedProductsSource;
  headline: string;
  sourceLabel: string;
  items: RecommendedProduct[];
  disclosure: string;
};

export const RECOMMENDED_PRODUCTS_DISCLOSURE = "Product discovery is general cosmetic and wellness guidance, not medical advice, diagnosis, treatment, a product-suitability or ingredient-compatibility guarantee, an efficacy claim, or a promise of results. Verify current official product directions, ingredients, availability, and pricing before purchase or use.";

const goalLabels: Record<SkinGoalId, string> = {
  hydration: "hydration support",
  radiance: "radiance support",
  texture: "texture support",
  calm: "comfort-first care",
  tone: "tone-support habits",
};

const goalSupportMap: Record<SkinGoalId, SkinConcernKey[]> = {
  hydration: ["hydration"],
  radiance: ["radiance", "fineLines"],
  texture: ["texture", "pores"],
  calm: ["redness", "blemishes"],
  tone: ["darkSpots", "radiance"],
};

const categoryOrder: RealSkinProduct["category"][] = ["Cleanser", "SPF", "Moisturizer", "Serum", "Treatment"];

function normalizeSource(source: SkinAnalysisSource | "none" | undefined): RecommendedProductsSource {
  return source === "youcam" ? "youcam" : source === "demo" ? "demo" : "none";
}

function concernKey(metric: Pick<SkinMetric, "key">): SkinConcernKey | null {
  const map: Record<SkinMetricKey, SkinConcernKey> = {
    hydration: "hydration", oiliness: "oiliness", texture: "texture", pores: "pores", redness: "redness",
    blemishes: "blemishes", radiance: "radiance", darkSpots: "darkSpots", fineLines: "fineLines",
  };
  return map[metric.key] ?? null;
}

function relevantSignals(metrics: Pick<SkinMetric, "key" | "score" | "available">[]): SkinConcernKey[] {
  return metrics
    .filter((metric) => metric.available && Number.isFinite(metric.score))
    .filter((metric) => {
      if (["hydration", "texture", "radiance", "fineLines"].includes(metric.key)) return metric.score < 70;
      return metric.score > 35;
    })
    .map(concernKey)
    .filter((item): item is SkinConcernKey => Boolean(item));
}

function sourceLabel(source: RecommendedProductsSource): string {
  if (source === "youcam") return "Live visual context + local care goals. Signals are normalized general guidance, not a diagnosis.";
  if (source === "demo") return "Fictional Demo Mode context + local care goals. Catalog links are real manufacturer references; demo signals are not a personal assessment.";
  return "Local care goals only. Complete a demo or optional live scan to add source-aware visual context.";
}

function headline(source: RecommendedProductsSource): string {
  if (source === "youcam") return "Recommended products for your current routine";
  if (source === "demo") return "Recommended product references for the fictional demo routine";
  return "Starter product references for your local care goals";
}

function eligibleForRoutine(product: RealSkinProduct, filter: RecommendedProductsRoutineFilter): boolean {
  return filter === "All" || product.routine === "AM / PM" || product.routine === filter;
}

export function buildRecommendedProducts(input: {
  source?: SkinAnalysisSource | "none";
  metrics?: Pick<SkinMetric, "key" | "score" | "available">[];
  selectedGoals?: SkinGoalId[];
  savedProductIds?: string[];
  routineFilter?: RecommendedProductsRoutineFilter;
  limit?: number;
}): RecommendedProductsPlan {
  const source = normalizeSource(input.source);
  const metrics = input.metrics ?? [];
  const selectedGoals = [...new Set(input.selectedGoals ?? [])];
  const savedProductIds = input.savedProductIds ?? [];
  const filter = input.routineFilter ?? "All";
  const signals = relevantSignals(metrics);
  const goalSupports = new Set(selectedGoals.flatMap((goal) => goalSupportMap[goal]));

  const items = realSkinProductCatalog
    .filter((product) => eligibleForRoutine(product, filter))
    .map((product) => {
      const matchedGoals = selectedGoals.filter((goal) => goalSupportMap[goal].some((support) => product.supports.includes(support)));
      const matchedSignals = product.supports.filter((support) => signals.includes(support));
      const savedLocally = savedProductIds.includes(product.id);
      const recommendationReasons: string[] = [];
      if (matchedGoals.length) recommendationReasons.push(`Matches your local ${matchedGoals.map((goal) => goalLabels[goal]).join(" and ")} focus.`);
      if (matchedSignals.length && source === "youcam") recommendationReasons.push(`Matches available normalized visual context: ${matchedSignals.join(", ")}.`);
      if (matchedSignals.length && source === "demo") recommendationReasons.push(`Matches fictional demo context: ${matchedSignals.join(", ")}.`);
      if (savedLocally) recommendationReasons.push("You saved this catalog reference locally.");
      if (!recommendationReasons.length) recommendationReasons.push("Verified catalog foundation item for routine exploration.");
      const rank = matchedGoals.length * 12 + matchedSignals.length * 10 + (savedLocally ? 2 : 0) + (product.routine === "AM / PM" ? 1 : 0) - categoryOrder.indexOf(product.category) * 0.1;
      return { ...product, rank, source, recommendationReasons, matchedGoals, matchedSignals, savedLocally, routineContext: product.routine };
    })
    .sort((left, right) => right.rank - left.rank || categoryOrder.indexOf(left.category) - categoryOrder.indexOf(right.category))
    .slice(0, input.limit ?? 5);

  return { source, headline: headline(source), sourceLabel: sourceLabel(source), items, disclosure: RECOMMENDED_PRODUCTS_DISCLOSURE };
}
