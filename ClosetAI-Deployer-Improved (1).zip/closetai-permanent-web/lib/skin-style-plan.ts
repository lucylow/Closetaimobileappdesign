import type { WardrobeItem } from "@/lib/demo-data";
import type { SkinGoalId } from "@/lib/skin-navigation-data";
import type { SkinAnalysisSource, SkinMetric, SkinMetricKey } from "@/lib/skin-analysis-controller";
import { buildWardrobeRecommendations, type WardrobeRecommendation } from "@shared/outfit-recommendations";

export type SkinStyleSource = "youcam" | "demo" | "none";

export type SkinStylePlan = {
  source: SkinStyleSource;
  headline: string;
  sourceLabel: string;
  palette: string[];
  reasons: string[];
  weatherNote: string;
  looks: WardrobeRecommendation[];
  wardrobeItemCount: number;
  disclosure: string;
  emptyMessage?: string;
};

export const SKIN_STYLE_DISCLOSURE = "Skin × Style provides optional inspiration from your local goals, available normalized visual context, and wardrobe items you own. It is not medical advice, a color-science certification, an identity, ethnicity, health, or attractiveness inference, a body assessment, a shopping recommendation, or a promise that a color or outfit will change your appearance. Every suggested look uses only your actual ClosetAI wardrobe items.";

const goalLabels: Record<SkinGoalId, string> = {
  hydration: "hydration support",
  radiance: "radiance support",
  texture: "texture support",
  calm: "comfort-first care",
  tone: "tone-support habits",
};

const paletteByGoal: Record<SkinGoalId, string[]> = {
  hydration: ["Cream", "Soft Blue", "Taupe"],
  radiance: ["Warm White", "Camel", "Muted Coral"],
  texture: ["Navy", "Denim", "Soft Grey"],
  calm: ["Sage", "Oat", "Soft Blue"],
  tone: ["Terracotta", "Cream", "Gold"],
};

const goalSignalKeys: Record<SkinGoalId, SkinMetricKey[]> = {
  hydration: ["hydration"],
  radiance: ["radiance", "fineLines"],
  texture: ["texture", "pores"],
  calm: ["redness", "blemishes"],
  tone: ["darkSpots", "radiance"],
};

function normalizeSource(source: SkinAnalysisSource | "none" | undefined): SkinStyleSource {
  return source === "youcam" ? "youcam" : source === "demo" ? "demo" : "none";
}

function relevantSignalKeys(metrics: Pick<SkinMetric, "key" | "score" | "available">[]): SkinMetricKey[] {
  return metrics
    .filter((metric) => metric.available && Number.isFinite(metric.score))
    .filter((metric) => {
      if (["hydration", "texture", "radiance", "fineLines"].includes(metric.key)) return metric.score < 70;
      return metric.score > 35;
    })
    .map((metric) => metric.key);
}

function focusGoals(selectedGoals: SkinGoalId[], metrics: Pick<SkinMetric, "key" | "score" | "available">[]): SkinGoalId[] {
  const selected = [...new Set(selectedGoals)];
  if (selected.length) return selected.slice(0, 2);
  const signalKeys = relevantSignalKeys(metrics);
  const derived = (Object.keys(goalSignalKeys) as SkinGoalId[]).filter((goal) => goalSignalKeys[goal].some((key) => signalKeys.includes(key)));
  return (derived.length ? derived : (["hydration"] as SkinGoalId[])).slice(0, 2);
}

function sourceLabel(source: SkinStyleSource): string {
  if (source === "youcam") return "Live normalized visual context + your actual wardrobe. General style inspiration only.";
  if (source === "demo") return "Fictional Demo Mode context + your actual wardrobe. Demo signals are not a personal assessment.";
  return "Your actual wardrobe + local style choices. Complete a demo or optional live scan to add source-aware context.";
}

function headline(source: SkinStyleSource): string {
  if (source === "youcam") return "Your source-aware Skin × Style edit";
  if (source === "demo") return "Your fictional Demo Mode Skin × Style edit";
  return "Your wardrobe-first Skin × Style edit";
}

export function buildSkinStylePlan(input: {
  source?: SkinAnalysisSource | "none";
  metrics?: Pick<SkinMetric, "key" | "score" | "available">[];
  selectedGoals?: SkinGoalId[];
  wardrobe: WardrobeItem[];
  occasion?: string;
  weather?: string;
}): SkinStylePlan {
  const source = normalizeSource(input.source);
  const metrics = input.metrics ?? [];
  const goals = focusGoals(input.selectedGoals ?? [], metrics);
  const palette = [...new Set(goals.flatMap((goal) => paletteByGoal[goal]))].slice(0, 4);
  const signalKeys = relevantSignalKeys(metrics);
  const reasons = goals.map((goal) => {
    const linkedSignal = goalSignalKeys[goal].find((key) => signalKeys.includes(key));
    const signalNote = linkedSignal && source === "youcam" ? ` Available ${linkedSignal} visual context is included as general inspiration.` : linkedSignal && source === "demo" ? ` Fictional demo ${linkedSignal} context is included as inspiration.` : "";
    return `Local focus: ${goalLabels[goal]}.${signalNote}`;
  });
  if (source === "demo") reasons.push("Fictional Demo Mode context is used for optional style inspiration only.");
  if (source === "none") reasons.push("No scan context is used; this plan is built from local style choices and your wardrobe only.");
  const weatherNote = input.weather?.trim()
    ? `Weather context available: ${input.weather.trim()}. Outfit assembly may prioritize a user-owned layer when appropriate.`
    : "Weather context is unavailable; these looks use your wardrobe and local style choices only.";
  const looks = input.wardrobe.length >= 2
    ? buildWardrobeRecommendations(input.wardrobe.map((item) => ({ id: item.id, name: item.name, category: item.category, color: item.color, tags: item.tags, usageCount: item.usageCount, lastWornAt: item.lastWorn })), input.occasion || "Everyday", input.weather, palette)
    : [];
  return {
    source,
    headline: headline(source),
    sourceLabel: sourceLabel(source),
    palette,
    reasons,
    weatherNote,
    looks,
    wardrobeItemCount: input.wardrobe.length,
    disclosure: SKIN_STYLE_DISCLOSURE,
    emptyMessage: looks.length ? undefined : "Add at least two wardrobe pieces to ClosetAI to build a live Skin × Style look from items you own. No stock or fictional outfit is shown.",
  };
}

export function resolveSkinStyleLookItems(look: WardrobeRecommendation, wardrobe: WardrobeItem[]): WardrobeItem[] {
  const byId = new Map(wardrobe.map((item) => [item.id, item]));
  return look.itemIds.map((id) => byId.get(id)).filter((item): item is WardrobeItem => Boolean(item));
}
