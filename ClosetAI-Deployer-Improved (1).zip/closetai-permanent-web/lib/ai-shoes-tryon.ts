import { apiRequest } from "@/lib/query-client";
import type { AiShoesRenderStyle, AiShoesRenderingSetting, AiShoesTryOnResult } from "@shared/ai-shoes-tryon";

export type AiShoesTryOnResponse = {
  tryOn: AiShoesTryOnResult;
  disclosure: string;
};

export async function createAiShoesTryOn(input: {
  targetImageBase64: string;
  shoeReferenceBase64: string;
  style: AiShoesRenderStyle;
  renderingSetting: AiShoesRenderingSetting;
  consent: boolean;
  targetPhotoConfirmed: boolean;
  referenceConfirmed: boolean;
}): Promise<AiShoesTryOnResponse> {
  const response = await apiRequest("POST", "/api/fashion/shoes-tryon", input);
  return response.json();
}
