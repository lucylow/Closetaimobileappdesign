import { apiRequest } from "@/lib/query-client";
import type { SkinSimulationAdjustments } from "@shared/skin-simulation";

export type SkinSimulationResponse = {
  resultUrl: string;
  adjustments: SkinSimulationAdjustments;
  disclosure: string;
  expiresIn: string;
};

export async function createSkinSimulation(imageBase64: string, adjustments: SkinSimulationAdjustments): Promise<SkinSimulationResponse> {
  const response = await apiRequest("POST", "/api/skin/simulation", { imageBase64, adjustments });
  return response.json();
}
