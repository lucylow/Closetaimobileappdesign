import { scanSkin } from "@/lib/skin";
import { skinDemoProfiles } from "@/lib/skin-demo-profiles";
import type { SkinSnapshot } from "@shared/skin";
import { buildSkinAnalysisPlan, type SkinAnalysisQualityTier } from "@shared/skin-analysis-plan";
import { getSkinAnalysisFallbackReason, getSkinScoreStatus } from "@/lib/skin-analysis-status";

export { getSkinAnalysisFallbackReason, getSkinScoreStatus } from "@/lib/skin-analysis-status";

export type SkinAnalysisSource = "demo" | "youcam" | "cached";
export type SkinMetricKey = "hydration" | "oiliness" | "texture" | "pores" | "redness" | "blemishes" | "radiance" | "darkSpots" | "fineLines";

export interface SkinMetric {
  key: SkinMetricKey;
  label: string;
  score: number;
  status: string;
  description?: string;
  available: boolean;
  source: SkinAnalysisSource;
}

export interface SkinRoutineStep {
  id: string;
  period: "AM" | "PM";
  order: number;
  title: string;
  guidance: string;
}

export interface SkinAnalysisResult {
  id: string;
  createdAt: string;
  source: SkinAnalysisSource;
  overallScore?: number;
  skinType?: string;
  metrics: SkinMetric[];
  routine: SkinRoutineStep[];
  imageUri?: string;
  processingTimeMs?: number;
  /** Count-based completeness only; it is not an accuracy, health, or diagnostic confidence claim. */
  visualSignalCoverage?: { available: number; total: number; percent: number };
  visualSignalSummary?: string;
  disclaimer: string;
  fallbackReason?: string;
}

export interface SkinAnalysisInput {
  imageUri?: string;
  imageBase64?: string;
  demo?: boolean;
  saveSnapshot?: boolean;
  analysisTier?: SkinAnalysisQualityTier;
}

export interface SkinAnalysisProvider {
  analyze(input: SkinAnalysisInput): Promise<SkinAnalysisResult>;
}

const keyMap: Record<string, SkinMetricKey> = {
  hydration: "hydration", moisture: "hydration", oiliness: "oiliness", texture: "texture", pores: "pores", redness: "redness", acne: "blemishes", blemishes: "blemishes", radiance: "radiance", spots: "darkSpots", "dark-spots": "darkSpots", darkSpots: "darkSpots", wrinkles: "fineLines", "fine-lines": "fineLines", fineLines: "fineLines",
};

export function buildRoutine(metrics: SkinMetric[]): SkinRoutineStep[] {
  const hydration = metrics.find((metric) => metric.key === "hydration")?.score ?? 70;
  const oiliness = metrics.find((metric) => metric.key === "oiliness")?.score ?? 45;
  const eveningTreatment = hydration < 65 || oiliness > 60 ? "Optional targeted serum" : "Comfort-focused serum";
  return [
    { id: "am-cleanse", period: "AM", order: 1, title: "Gentle cleanser", guidance: "Start with a comfortable, non-stripping cleanse." },
    { id: "am-hydrate", period: "AM", order: 2, title: "Hydrating layer", guidance: hydration < 65 ? "Keep hydration simple and consistent." : "Use a lightweight hydration layer if it feels comfortable." },
    { id: "am-protect", period: "AM", order: 3, title: "Daily sun protection", guidance: "Finish your morning routine with broad-spectrum protection." },
    { id: "pm-cleanse", period: "PM", order: 1, title: "Evening reset", guidance: "Remove the day gently without over-cleansing." },
    { id: "pm-treat", period: "PM", order: 2, title: eveningTreatment, guidance: oiliness > 60 ? "Introduce one optional step at a time." : "Prioritise comfort and gradual changes." },
    { id: "pm-moisturise", period: "PM", order: 3, title: "Moisturise", guidance: "Finish with a comfortable moisture layer." },
  ];
}

function demoMetrics(profileIndex = 0): SkinMetric[] {
  const profile = skinDemoProfiles[profileIndex % skinDemoProfiles.length];
  return profile.metrics.map((metric) => ({
    key: keyMap[metric.id] ?? "texture",
    label: metric.label,
    score: metric.score,
    status: metric.status,
    description: metric.description,
    available: true,
    source: "demo" as const,
  }));
}

export class DemoSkinProvider implements SkinAnalysisProvider {
  private nextProfile = 0;
  async analyze(input: SkinAnalysisInput): Promise<SkinAnalysisResult> {
    const startedAt = Date.now();
    const index = this.nextProfile++ % skinDemoProfiles.length;
    const profile = skinDemoProfiles[index];
    const metrics = demoMetrics(index);
    await new Promise((resolve) => setTimeout(resolve, 850));
    return { id: `demo-skin-${Date.now()}`, createdAt: new Date().toISOString(), source: "demo", overallScore: profile.overallScore, skinType: profile.skinType, metrics, routine: buildRoutine(metrics), imageUri: input.imageUri, processingTimeMs: Date.now() - startedAt, visualSignalCoverage: { available: metrics.filter((metric) => metric.available).length, total: metrics.length, percent: 100 }, visualSignalSummary: "Fictional Demo Mode visual-signal preview. Complete a live scan to replace it.", disclaimer: "Demo preview only. General wellness and style guidance, not medical advice." };
  }
}

function normalizeSnapshot(snapshot: SkinSnapshot, imageUri?: string): SkinAnalysisResult {
  const metrics = snapshot.concerns.map((concern) => ({
    key: keyMap[concern.key] ?? "texture",
    label: concern.label,
    score: concern.score ?? 0,
    status: concern.severityBand === "high" ? "Focus area" : "Good",
    description: concern.explanation,
    available: concern.score !== null,
    source: "youcam" as const,
  }));
  const scoredMetrics = metrics.filter((metric) => metric.available);
  const overallScore = scoredMetrics.length ? Math.round(scoredMetrics.reduce((total, metric) => total + metric.score, 0) / scoredMetrics.length) : undefined;
  const fallbackCoverage = { available: scoredMetrics.length, total: metrics.length, percent: Math.round((scoredMetrics.length / Math.max(metrics.length, 1)) * 100) };
  const visualSignalCoverage = snapshot.dataQuality
    ? { available: snapshot.dataQuality.availableSignals, total: snapshot.dataQuality.expectedSignals, percent: snapshot.dataQuality.coveragePercent }
    : fallbackCoverage;
  const visualSignalSummary = snapshot.dataQuality
    ? `Live YouCam visual analysis: ${snapshot.dataQuality.note}`
    : scoredMetrics.length === metrics.length
      ? `Live YouCam visual analysis returned ${scoredMetrics.length} normalized visual signals.`
      : `Live YouCam visual analysis returned ${scoredMetrics.length} of ${metrics.length} normalized visual signals.`;
  return { id: snapshot.id, createdAt: snapshot.createdAt instanceof Date ? snapshot.createdAt.toISOString() : snapshot.createdAt, source: "youcam", overallScore, skinType: snapshot.skinType ?? undefined, metrics, routine: buildRoutine(metrics), imageUri, visualSignalCoverage, visualSignalSummary, disclaimer: "General wellness and style guidance, not medical advice." };
}

export class YouCamSkinProvider implements SkinAnalysisProvider {
  async analyze(input: SkinAnalysisInput): Promise<SkinAnalysisResult> {
    if (!input.imageBase64) throw new Error("Choose a clear selfie before requesting a live analysis.");
    const startedAt = Date.now();
    const response = await scanSkin(input.imageBase64, input.saveSnapshot ?? true, buildSkinAnalysisPlan(input.analysisTier ?? "sd"));
    const result = normalizeSnapshot(response.snapshot, input.imageUri);
    return { ...result, processingTimeMs: Date.now() - startedAt };
  }
}

const demoProvider = new DemoSkinProvider();
const liveProvider = new YouCamSkinProvider();

export async function analyzeSkin(input: SkinAnalysisInput): Promise<SkinAnalysisResult> {
  if (input.demo || !input.imageBase64) return demoProvider.analyze(input);
  return await liveProvider.analyze(input);
}
