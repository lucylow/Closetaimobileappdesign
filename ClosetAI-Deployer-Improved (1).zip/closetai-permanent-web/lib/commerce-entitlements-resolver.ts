/**
 * ClosetAI Agentic Commerce Entitlement Resolver & Funnel Event Logger
 * Centralizes tier limits, credit deductions, and auditable conversion metrics.
 */

import AsyncStorage from "@react-native-async-storage/async-storage";
import { COMMERCE_PLAN_TIERS } from "../shared/commerce-monetization";

export interface UserEntitlementState {
  tierId: "free" | "pro_shopper" | "concierge_enterprise";
  creditsRemaining: number;
  activePriceWatchesCount: number;
  unlockedAtTimestamp: number;
}

export interface FunnelEvent {
  event: string;
  timestamp: number;
  metadata?: Record<string, any>;
}

const memoryStore: Record<string, string> = {};

async function safeGetItem(key: string): Promise<string | null> {
  try {
    const val = await AsyncStorage.getItem(key);
    if (val !== null) return val;
  } catch (err) {
    // Fallback to memory
  }
  return memoryStore[key] || null;
}

async function safeSetItem(key: string, value: string): Promise<void> {
  memoryStore[key] = value;
  try {
    await AsyncStorage.setItem(key, value);
  } catch (err) {
    // Ignore native storage errors in headless tests
  }
}

const ENTITLEMENT_STORAGE_KEY = "@closetai_commerce_user_entitlements_v1";
const FUNNEL_EVENTS_KEY = "@closetai_commerce_funnel_events_v1";

export async function getUserEntitlements(): Promise<UserEntitlementState> {
  try {
    const raw = await safeGetItem(ENTITLEMENT_STORAGE_KEY);
    if (!raw) {
      const defaultState: UserEntitlementState = {
        tierId: "free",
        creditsRemaining: 25,
        activePriceWatchesCount: 0,
        unlockedAtTimestamp: Date.now(),
      };
      await safeSetItem(ENTITLEMENT_STORAGE_KEY, JSON.stringify(defaultState));
      return defaultState;
    }
    return JSON.parse(raw);
  } catch (err) {
    return {
      tierId: "free",
      creditsRemaining: 25,
      activePriceWatchesCount: 0,
      unlockedAtTimestamp: Date.now(),
    };
  }
}

export async function updateUserTier(tierId: "free" | "pro_shopper" | "concierge_enterprise"): Promise<UserEntitlementState> {
  const current = await getUserEntitlements();
  const credits = tierId === "free" ? 25 : tierId === "pro_shopper" ? 1500 : 10000;
  const updated: UserEntitlementState = {
    ...current,
    tierId,
    creditsRemaining: credits,
    unlockedAtTimestamp: Date.now(),
  };
  await safeSetItem(ENTITLEMENT_STORAGE_KEY, JSON.stringify(updated));
  await logFunnelEvent("subscription_tier_updated", { tierId, credits });
  return updated;
}

export async function logFunnelEvent(event: string, metadata?: Record<string, any>): Promise<void> {
  try {
    const raw = await safeGetItem(FUNNEL_EVENTS_KEY);
    const events: FunnelEvent[] = raw ? JSON.parse(raw) : [];
    events.push({
      event,
      timestamp: Date.now(),
      metadata,
    });
    if (events.length > 200) {
      events.shift();
    }
    await safeSetItem(FUNNEL_EVENTS_KEY, JSON.stringify(events));
  } catch (err) {
    console.error("Failed to log funnel event", err);
  }
}

export async function getFunnelEvents(): Promise<FunnelEvent[]> {
  try {
    const raw = await safeGetItem(FUNNEL_EVENTS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (err) {
    return [];
  }
}
