import type { CommerceCandidate } from "../shared/agentic-commerce-contracts";
import { FICTIONAL_DEMO_CANDIDATES } from "./fictional-demo-commerce";

export interface ExternalProviderConfig {
  endpointUrl?: string;
  apiKey?: string;
  timeoutMs?: number;
  allowedDomains: string[];
}

const DEFAULT_CONFIG: ExternalProviderConfig = {
  timeoutMs: 4000,
  allowedDomains: ["api.example.com", "merchant.closetai.io", "shopify.com"],
};

export async function fetchExternalProductDiscovery(
  query: string,
  category: string,
  config: ExternalProviderConfig = DEFAULT_CONFIG
): Promise<{ candidates: CommerceCandidate[]; liveConnected: boolean }> {
  const endpoint = config.endpointUrl;
  if (!endpoint) {
    // Graceful fallback to demo data if no live endpoint is configured
    return { candidates: FICTIONAL_DEMO_CANDIDATES, liveConnected: false };
  }

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), config.timeoutMs || 4000);

    const response = await fetch(`${endpoint}/search`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(config.apiKey ? { Authorization: `Bearer ${config.apiKey}` } : {}),
      },
      body: JSON.stringify({ query, category }),
      signal: controller.signal,
    });
    clearTimeout(timeout);

    if (!response.ok) {
      throw new Error(`External provider returned status ${response.status}`);
    }

    const data = await response.json();
    if (Array.isArray(data.candidates) && data.candidates.length > 0) {
      return { candidates: data.candidates, liveConnected: true };
    }

    return { candidates: FICTIONAL_DEMO_CANDIDATES, liveConnected: false };
  } catch (err) {
    console.warn("External provider discovery failed or timed out. Falling back to verified demo fixtures:", err);
    return { candidates: FICTIONAL_DEMO_CANDIDATES, liveConnected: false };
  }
}
