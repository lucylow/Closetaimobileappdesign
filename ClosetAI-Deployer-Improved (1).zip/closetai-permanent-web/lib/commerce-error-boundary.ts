/**
 * ClosetAI Commerce Error Boundary & Safe Execution Helpers
 * Ensures all async commerce, billing, and entitlement operations catch exceptions
 * gracefully and return structured Result objects instead of throwing unhandled errors.
 */

export type SafeResult<T> =
  | { success: true; data: T }
  | { success: false; error: string; fallbackUsed: boolean; data: T };

export async function executeSafeCommerceAction<T>(
  actionName: string,
  operation: () => Promise<T>,
  fallbackValue: T
): Promise<SafeResult<T>> {
  try {
    const data = await operation();
    return { success: true, data };
  } catch (err: any) {
    console.warn(`[ClosetAI Commerce Error] Action '${actionName}' failed:`, err?.message || err);
    return {
      success: false,
      error: err?.message || String(err),
      fallbackUsed: true,
      data: fallbackValue,
    };
  }
}
