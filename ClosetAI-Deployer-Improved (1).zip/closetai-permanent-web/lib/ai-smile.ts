import { apiRequest } from "@/lib/query-client";
import type { AiSmileExpressionType, AiSmileResult } from "@shared/ai-smile";

export type AiSmileResponse = {
  simulation: AiSmileResult;
  disclosure: string;
};

export async function createAiSmile(input: {
  imageBase64: string;
  expressionType: AiSmileExpressionType;
  consent: boolean;
}): Promise<AiSmileResponse> {
  const response = await apiRequest("POST", "/api/skin/ai-smile", input);
  return response.json();
}
