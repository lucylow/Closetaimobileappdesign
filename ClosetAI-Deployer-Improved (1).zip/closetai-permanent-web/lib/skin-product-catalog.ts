import type { SkinAnalysisResult, SkinMetric } from "@/lib/skin-analysis-controller";

export type SkinProductCategory = "Cleanser" | "Serum" | "Moisturizer" | "SPF" | "Treatment";
export type SkinConcernKey = "hydration" | "oiliness" | "texture" | "pores" | "redness" | "blemishes" | "radiance" | "darkSpots" | "fineLines";

export type RealSkinProduct = {
  id: string;
  brand: string;
  name: string;
  category: SkinProductCategory;
  routine: "AM" | "PM" | "AM / PM";
  primaryIngredients: string[];
  supports: SkinConcernKey[];
  skinTypes: string[];
  officialUrl: string;
  officialCartAvailable: boolean;
  sourceLabel: "Manufacturer product page";
  availabilityNotice: string;
  usageNote: string;
  compatibilityNotes: string[];
};

export type RankedSkinProduct = RealSkinProduct & {
  rank: number;
  matchedSignals: SkinConcernKey[];
  reason: string;
};

/**
 * Initial real-product catalog verified against manufacturer product pages. Prices and inventory are not embedded;
 * production should refresh these records through an authorized catalog/commerce provider.
 */
export const realSkinProductCatalog: RealSkinProduct[] = [
  {
    id: "cerave-hydrating-facial-cleanser", brand: "CeraVe", name: "Hydrating Facial Cleanser", category: "Cleanser", routine: "AM / PM",
    primaryIngredients: ["Ceramides", "Hyaluronic Acid"], supports: ["hydration", "texture"], skinTypes: ["Normal", "Dry", "Combination"],
    officialUrl: "https://www.cerave.com/skincare/cleansers/hydrating-facial-cleanser", officialCartAvailable: false, sourceLabel: "Manufacturer product page", availabilityNotice: "Availability, package size, and final ingredients must be confirmed on the official listing or product package.",
    usageNote: "Manufacturer guidance: use on wet skin, rinse, then follow with moisturizer.", compatibilityNotes: ["Routine foundation product; not a treatment recommendation.", "Check the current package ingredient list before use."],
  },
  {
    id: "lrp-toleriane-double-repair", brand: "La Roche-Posay", name: "Toleriane Double Repair Face Moisturizer", category: "Moisturizer", routine: "AM / PM",
    primaryIngredients: ["Ceramide-3", "Niacinamide", "Glycerin", "Prebiotic Thermal Water"], supports: ["hydration", "texture", "redness"], skinTypes: ["Normal", "Dry", "Combination", "Sensitive"],
    officialUrl: "https://www.laroche-posay.us/our-products/face/face-moisturizer/toleriane-double-repair-face-moisturizer-tolerianedoublerepair.html", officialCartAvailable: true, sourceLabel: "Manufacturer product page", availabilityNotice: "Price, formulation, package size, and availability can change; verify before checkout.",
    usageNote: "Manufacturer guidance: apply morning and evening after cleansing.", compatibilityNotes: ["Moisturizer option; a user should select one comfortable moisturizer rather than duplicate similar layers.", "Check the current package ingredient list before use."],
  },
  {
    id: "ordinary-niacinamide-zinc", brand: "The Ordinary", name: "Niacinamide 10% + Zinc 1%", category: "Serum", routine: "AM / PM",
    primaryIngredients: ["Niacinamide", "Zinc PCA"], supports: ["oiliness", "pores", "blemishes", "texture", "radiance"], skinTypes: ["All"],
    officialUrl: "https://theordinary.com/en-us/niacinamide-10-zinc-1-serum-100436.html", officialCartAvailable: true, sourceLabel: "Manufacturer product page", availabilityNotice: "Price, formulation, package size, and availability can change; verify before checkout.",
    usageNote: "Manufacturer guidance: apply a few drops in the morning and evening before heavier formulations; patch testing is advised.", compatibilityNotes: ["This is an optional active serum, not a diagnosis or treatment.", "The manufacturer advises separate routines with direct vitamin C products."],
  },
  {
    id: "cerave-am-facial-lotion-spf-30", brand: "CeraVe", name: "AM Facial Moisturizing Lotion SPF 30", category: "SPF", routine: "AM",
    primaryIngredients: ["Ceramides", "Hyaluronic Acid", "Niacinamide", "Zinc Oxide"], supports: ["hydration", "radiance", "darkSpots", "fineLines"], skinTypes: ["Normal", "Dry", "Combination"],
    officialUrl: "https://www.cerave.com/skincare/moisturizers/am-facial-moisturizing-lotion-with-sunscreen", officialCartAvailable: false, sourceLabel: "Manufacturer product page", availabilityNotice: "Availability and current labeling must be verified on the official listing or product package.",
    usageNote: "Manufacturer guidance: apply in the morning and reapply as directed on the product label.", compatibilityNotes: ["Daily protection step; this app does not assess sun exposure or medical suitability.", "Follow the official label for application and reapplication."],
  },
  {
    id: "cerave-skin-renewing-night-cream", brand: "CeraVe", name: "Skin Renewing Night Cream", category: "Treatment", routine: "PM",
    primaryIngredients: ["Biomimetic Peptides", "Hyaluronic Acid", "Ceramides", "Niacinamide"], supports: ["hydration", "texture", "radiance", "fineLines"], skinTypes: ["All"],
    officialUrl: "https://www.cerave.com/skincare/moisturizers/skin-renewing-night-cream", officialCartAvailable: false, sourceLabel: "Manufacturer product page", availabilityNotice: "Availability, formulation, and final ingredients should be checked on the official listing or product package.",
    usageNote: "Manufacturer guidance: apply nightly before bedtime.", compatibilityNotes: ["Night moisturizer option; it is not a clinical anti-aging treatment recommendation.", "Check the current package ingredient list before use."],
  },
];

const priorityOrder: SkinProductCategory[] = ["Cleanser", "SPF", "Moisturizer", "Serum", "Treatment"];
const concernPriority: SkinConcernKey[] = ["hydration", "oiliness", "pores", "texture", "redness", "blemishes", "radiance", "darkSpots", "fineLines"];

function concernFromMetric(metric: SkinMetric): SkinConcernKey | null {
  const map: Record<string, SkinConcernKey> = { darkSpots: "darkSpots", fineLines: "fineLines", hydration: "hydration", oiliness: "oiliness", texture: "texture", pores: "pores", redness: "redness", blemishes: "blemishes", radiance: "radiance" };
  return map[metric.key] ?? null;
}

function isSignalRelevant(metric: SkinMetric): boolean {
  if (!metric.available) return false;
  if (["hydration", "texture", "radiance", "fineLines"].includes(metric.key)) return metric.score < 70;
  return metric.score > 35;
}

/** Ranks catalog records from normalized visual signals only. It never returns a diagnosis or prescribing claim. */
export function rankRealSkinProducts(result?: Pick<SkinAnalysisResult, "metrics" | "skinType">, options: { limit?: number; routine?: "AM" | "PM" } = {}): RankedSkinProduct[] {
  const limit = options.limit ?? 4;
  const relevantSignals = result?.metrics.filter(isSignalRelevant).map(concernFromMetric).filter((item): item is SkinConcernKey => Boolean(item)) ?? [];
  const orderedSignals = concernPriority.filter((signal) => relevantSignals.includes(signal));
  return realSkinProductCatalog
    .filter((product) => !options.routine || product.routine === options.routine || product.routine === "AM / PM")
    .map((product) => {
      const matchedSignals = product.supports.filter((signal) => orderedSignals.includes(signal));
      const skinTypeMatch = result?.skinType ? product.skinTypes.includes("All") || product.skinTypes.some((type) => result.skinType?.toLowerCase().includes(type.toLowerCase())) : false;
      const baseScore = matchedSignals.length * 10 + (skinTypeMatch ? 2 : 0) - priorityOrder.indexOf(product.category) * 0.1;
      const reason = matchedSignals.length ? `Matches your normalized visual signals: ${matchedSignals.join(", ")}.` : "A basic routine category available from the verified catalog.";
      return { ...product, rank: baseScore, matchedSignals, reason };
    })
    .sort((left, right) => right.rank - left.rank || priorityOrder.indexOf(left.category) - priorityOrder.indexOf(right.category))
    .slice(0, limit);
}

export function getCatalogProduct(id: string): RealSkinProduct | undefined {
  return realSkinProductCatalog.find((product) => product.id === id);
}
