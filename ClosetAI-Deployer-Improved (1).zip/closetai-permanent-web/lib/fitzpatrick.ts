import { apiRequest } from "@/lib/query-client";
import type { FitzpatrickCapability } from "@shared/fitzpatrick-profile";

export async function getFitzpatrickCapability(): Promise<FitzpatrickCapability> {
  const response = await apiRequest("GET", "/api/skin/fitzpatrick/capability");
  return response.json();
}
