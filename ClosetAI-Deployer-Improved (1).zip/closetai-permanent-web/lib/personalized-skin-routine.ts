import type { SkinGoalId } from "@/lib/skin-navigation-data";
import { getCatalogProduct } from "@/lib/skin-product-catalog";
import type { SkinAnalysisSource, SkinMetric, SkinMetricKey } from "@/lib/skin-analysis-controller";

export type PersonalizedRoutineSource = "youcam" | "demo" | "none";
export type PersonalizedRoutineFrequency = "daily" | "optional";

export type PersonalizedRoutineStep = {
  id: string;
  period: "AM" | "PM";
  order: number;
  title: string;
  purpose: string;
  guidance: string;
  frequency: PersonalizedRoutineFrequency;
  productId?: string;
  sourceReason: string;
};

export type PersonalizedRoutinePlan = {
  source: PersonalizedRoutineSource;
  headline: string;
  sourceLabel: string;
  focusLabels: string[];
  morning: PersonalizedRoutineStep[];
  evening: PersonalizedRoutineStep[];
  disclosure: string;
};

export const PERSONALIZED_ROUTINE_DISCLOSURE = "This AM/PM plan is general cosmetic and wellness guidance, not medical advice, a diagnosis, treatment plan, ingredient-compatibility guarantee, or predicted result. Follow official product directions, introduce optional products gradually, and seek qualified care for persistent or concerning symptoms.";

const goalLabels: Record<SkinGoalId, string> = {
  hydration: "Hydration support",
  radiance: "Radiance support",
  texture: "Texture support",
  calm: "Comfort-first care",
  tone: "Tone-support habits",
};

const goalSignalKeys: Record<SkinGoalId, SkinMetricKey[]> = {
  hydration: ["hydration"],
  radiance: ["radiance", "fineLines"],
  texture: ["texture", "pores"],
  calm: ["redness", "blemishes"],
  tone: ["darkSpots", "radiance"],
};

const goalProductIds: Record<SkinGoalId, string | undefined> = {
  hydration: "lrp-toleriane-double-repair",
  radiance: "cerave-skin-renewing-night-cream",
  texture: "ordinary-niacinamide-zinc",
  calm: "lrp-toleriane-double-repair",
  tone: "cerave-am-facial-lotion-spf-30",
};

const goalGuidance: Record<SkinGoalId, string> = {
  hydration: "Keep moisture support simple and comfortable; use one supportive layer at a time.",
  radiance: "Prioritise a calm, repeatable routine and daily protection rather than chasing fast changes.",
  texture: "Keep steps gentle and introduce one optional support product at a time.",
  calm: "Choose a low-complexity routine and avoid adding several new optional products at once.",
  tone: "Make daily protection a consistent final morning step and keep the rest of the routine steady.",
};

function normalizeSource(source: SkinAnalysisSource | "none" | undefined): PersonalizedRoutineSource {
  return source === "youcam" ? "youcam" : source === "demo" ? "demo" : "none";
}

function relevantSignalKeys(metrics: SkinMetric[]): SkinMetricKey[] {
  return metrics
    .filter((metric) => metric.available && Number.isFinite(metric.score))
    .filter((metric) => {
      if (["hydration", "texture", "radiance", "fineLines"].includes(metric.key)) return metric.score < 70;
      return metric.score > 35;
    })
    .map((metric) => metric.key);
}

function getFocusGoals(selectedGoals: SkinGoalId[], metrics: SkinMetric[]): SkinGoalId[] {
  const selected = selectedGoals.filter((goal, index) => selectedGoals.indexOf(goal) === index);
  if (selected.length) return selected.slice(0, 2);
  const signals = relevantSignalKeys(metrics);
  const derived = (Object.keys(goalSignalKeys) as SkinGoalId[]).filter((goal) => goalSignalKeys[goal].some((key) => signals.includes(key)));
  return (derived.length ? derived : (["hydration"] as SkinGoalId[])).slice(0, 2);
}

function sourceReason(source: PersonalizedRoutineSource, focusGoal: SkinGoalId, metrics: SkinMetric[]): string {
  const signals = relevantSignalKeys(metrics);
  const linkedSignal = goalSignalKeys[focusGoal].find((key) => signals.includes(key));
  const context = linkedSignal ? ` Available ${linkedSignal} visual context is included as general guidance.` : "";
  if (source === "youcam") return `Local focus: ${goalLabels[focusGoal]}.${context}`;
  if (source === "demo") return `Fictional Demo Mode focus: ${goalLabels[focusGoal]}.${context}`;
  return `Local care focus: ${goalLabels[focusGoal]}. Complete a demo or optional live scan to add visual context.`;
}

function resolveProductId(id: string | undefined): string | undefined {
  return id && getCatalogProduct(id) ? id : undefined;
}

export function buildPersonalizedRoutine(input: {
  source?: SkinAnalysisSource | "none";
  metrics?: SkinMetric[];
  selectedGoals?: SkinGoalId[];
}): PersonalizedRoutinePlan {
  const source = normalizeSource(input.source);
  const metrics = input.metrics ?? [];
  const focusGoals = getFocusGoals(input.selectedGoals ?? [], metrics);
  const primary = focusGoals[0] ?? "hydration";
  const primaryReason = sourceReason(source, primary, metrics);
  const supportProductId = resolveProductId(goalProductIds[primary]);
  const nightProductId = resolveProductId(primary === "radiance" || primary === "texture" ? "cerave-skin-renewing-night-cream" : "lrp-toleriane-double-repair");
  const sourceLabel = source === "youcam"
    ? "Built from your latest normalized live visual signals and local care goals. General guidance only, not medical advice."
    : source === "demo"
      ? "Fictional Demo Mode routine built from the selected demo profile and local care goals. Product links are real catalog references, not a personal assessment."
      : "Starter routine built from local care goals only. Complete a demo or optional live scan to add source-aware context.";
  const headline = source === "youcam" ? "Your source-aware AM/PM plan" : source === "demo" ? "Your fictional Demo Mode AM/PM plan" : "Your starter AM/PM plan";

  const morning: PersonalizedRoutineStep[] = [
    { id: "am-cleanse", period: "AM", order: 1, title: "Gentle cleanse", purpose: "Start simply", guidance: "Follow the cleanser’s official directions and keep cleansing comfortable.", frequency: "daily", productId: resolveProductId("cerave-hydrating-facial-cleanser"), sourceReason: primaryReason },
    { id: "am-support", period: "AM", order: 2, title: "Optional support layer", purpose: goalLabels[primary], guidance: `${goalGuidance[primary]} Follow the official product directions and patch-test information before adding an optional product.`, frequency: "optional", productId: supportProductId, sourceReason: primaryReason },
    { id: "am-protect", period: "AM", order: 3, title: "Daily protection", purpose: "Finish the morning sequence", guidance: "Follow the official product labeling for application and reapplication.", frequency: "daily", productId: resolveProductId("cerave-am-facial-lotion-spf-30"), sourceReason: "A consistent final morning protection step is included as general routine guidance." },
  ];

  const evening: PersonalizedRoutineStep[] = [
    { id: "pm-cleanse", period: "PM", order: 1, title: "Evening reset", purpose: "Remove the day gently", guidance: "Follow the cleanser’s official directions and avoid over-cleansing.", frequency: "daily", productId: resolveProductId("cerave-hydrating-facial-cleanser"), sourceReason: primaryReason },
    { id: "pm-support", period: "PM", order: 2, title: "One optional support step", purpose: goalLabels[primary], guidance: "Introduce one optional product at a time, use it only as directed by the manufacturer, and keep the rest of the routine simple.", frequency: "optional", productId: supportProductId, sourceReason: primaryReason },
    { id: "pm-moisturise", period: "PM", order: 3, title: "Comfortable moisture", purpose: "Finish simply", guidance: "Use a comfortable moisturizer and follow the current official product directions.", frequency: "daily", productId: nightProductId, sourceReason: primaryReason },
  ];

  return { source, headline, sourceLabel, focusLabels: focusGoals.map((goal) => goalLabels[goal]), morning, evening, disclosure: PERSONALIZED_ROUTINE_DISCLOSURE };
}

export function localRoutineDateKey(date = new Date()): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

export function routineCompletionKey(period: "AM" | "PM", stepId: string, date = new Date()): string {
  return `${localRoutineDateKey(date)}:${period}:${stepId}`;
}

export function keepTodayRoutineCompletions(completedSteps: string[], date = new Date()): string[] {
  const prefix = `${localRoutineDateKey(date)}:`;
  return completedSteps.filter((step) => step.startsWith(prefix));
}

export function countRoutineCompletions(plan: PersonalizedRoutinePlan, completedSteps: string[], date = new Date()): number {
  return [...plan.morning, ...plan.evening].filter((step) => completedSteps.includes(routineCompletionKey(step.period, step.id, date))).length;
}
