import type { CheckoutSession, CommerceCandidate } from "../shared/agentic-commerce-contracts";

export function prepareCheckoutSession(candidate: CommerceCandidate, quantity: number = 1): CheckoutSession {
  const subtotalAmount = candidate.price.amount * quantity;
  const shippingAmount = (candidate.shipping?.amount || 5.00);
  const taxAmount = Number((subtotalAmount * 0.08).toFixed(2));
  const totalAmount = Number((subtotalAmount + shippingAmount + taxAmount).toFixed(2));
  const currency = candidate.price.currency;
  const now = new Date().toISOString();

  return {
    sessionId: `chk-${Date.now()}`,
    candidateId: candidate.productId,
    title: candidate.title,
    merchantName: candidate.merchantId,
    quantity,
    subtotal: { amount: Number(subtotalAmount.toFixed(2)), currency },
    shipping: { amount: Number(shippingAmount.toFixed(2)), currency },
    tax: { amount: taxAmount, currency },
    total: { amount: totalAmount, currency },
    returnPolicyUrl: "https://example.com/return-policy",
    status: "awaiting_user_approval",
    userApproved: false,
    createdAt: now,
  };
}

export function approveAndCompleteCheckout(session: CheckoutSession): CheckoutSession {
  return {
    ...session,
    status: "completed",
    userApproved: true,
  };
}
