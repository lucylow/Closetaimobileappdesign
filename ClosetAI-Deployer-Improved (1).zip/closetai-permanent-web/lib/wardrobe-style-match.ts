import type { WardrobeItem } from "@/lib/demo-data";

export interface WardrobeStyleMatch {
  title: string;
  detail: string;
  colors: string[];
  itemCount: number;
}

function readableColor(value?: string) {
  const trimmed = value?.trim();
  return trimmed && trimmed.length > 0 ? trimmed : null;
}

export function buildWardrobeStyleMatch(items: WardrobeItem[]): WardrobeStyleMatch {
  const colors = [...new Set(items.map((item) => readableColor(item.color)).filter(Boolean) as string[])].slice(0, 4);
  const categories = [...new Set(items.map((item) => item.category).filter(Boolean))].slice(0, 3);

  if (items.length === 0) {
    return {
      title: "Your wardrobe is ready for a starting point",
      detail: "Add a few pieces to ClosetAI to generate an outfit using your own colors and categories.",
      colors: [],
      itemCount: 0,
    };
  }

  return {
    title: colors.length ? `Your ${colors.join(" · ")} edit` : "Your wardrobe edit",
    detail: `Built from ${items.length} item${items.length === 1 ? "" : "s"}${categories.length ? ` across ${categories.join(", ")}` : ""}. Use it as a style direction, not a rule.`,
    colors,
    itemCount: items.length,
  };
}
