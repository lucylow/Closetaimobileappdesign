/**
 * ClosetAI Purchase Ledger & Conversion Analytics (Hardened)
 * Separates realized production revenue from demo simulation revenue,
 * and tracks subscription lifecycle states (active, renewed, cancelled).
 */

import AsyncStorage from "@react-native-async-storage/async-storage";

const PURCHASE_LEDGER_STORAGE_KEY = "@closetai_purchase_ledger_v2";

export interface PurchaseRecord {
  transactionId: string;
  type: "subscription" | "credit_pack" | "affiliate_referral" | "agent_checkout";
  title: string;
  amountUSD: number;
  timestamp: number;
  isDemo: boolean;
  lifecycleStatus: "active" | "renewed" | "cancelled";
  metadata?: Record<string, any>;
}

const memoryLedgerStore: Record<string, string> = {};

async function safeGetItem(key: string): Promise<string | null> {
  try {
    const val = await AsyncStorage.getItem(key);
    if (val !== null) return val;
  } catch (err) {
    // Fallback to memory
  }
  return memoryLedgerStore[key] || null;
}

async function safeSetItem(key: string, value: string): Promise<void> {
  memoryLedgerStore[key] = value;
  try {
    await AsyncStorage.setItem(key, value);
  } catch (err) {
    // Ignore native storage errors in headless test
  }
}

export async function getPurchaseLedger(): Promise<PurchaseRecord[]> {
  try {
    const raw = await safeGetItem(PURCHASE_LEDGER_STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (err) {
    return [];
  }
}

export async function recordPurchase(record: Omit<PurchaseRecord, "transactionId" | "timestamp" | "lifecycleStatus"> & { lifecycleStatus?: "active" | "renewed" | "cancelled" }): Promise<PurchaseRecord> {
  const fullRecord: PurchaseRecord = {
    ...record,
    lifecycleStatus: record.lifecycleStatus || "active",
    transactionId: `txn_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
    timestamp: Date.now(),
  };

  try {
    const ledger = await getPurchaseLedger();
    ledger.unshift(fullRecord);
    if (ledger.length > 100) {
      ledger.pop();
    }
    await safeSetItem(PURCHASE_LEDGER_STORAGE_KEY, JSON.stringify(ledger));
  } catch (err) {
    console.error("Failed to record purchase", err);
  }

  return fullRecord;
}

export async function getConversionSummary(): Promise<{ realRevenueUSD: number; demoSimulationRevenueUSD: number; totalTransactions: number; activeSubscriptions: number; cancelledSubscriptions: number }> {
  const ledger = await getPurchaseLedger();
  let realRevenueUSD = 0;
  let demoSimulationRevenueUSD = 0;
  let activeSubscriptions = 0;
  let cancelledSubscriptions = 0;

  for (const item of ledger) {
    if (item.type !== "affiliate_referral") {
      if (item.isDemo) {
        demoSimulationRevenueUSD += item.amountUSD;
      } else {
        realRevenueUSD += item.amountUSD;
      }
    }
    if (item.type === "subscription") {
      if (item.lifecycleStatus === "cancelled") {
        cancelledSubscriptions++;
      } else {
        activeSubscriptions++;
      }
    }
  }

  return {
    realRevenueUSD,
    demoSimulationRevenueUSD,
    totalTransactions: ledger.length,
    activeSubscriptions,
    cancelledSubscriptions,
  };
}
