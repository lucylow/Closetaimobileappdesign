import type { SkinAnalysisResult } from "@/lib/skin-analysis-controller";

export type SkinMetricHistoryPoint = {
  scanId: string;
  capturedAt: string;
  source: SkinAnalysisResult["source"];
  overallScore?: number;
  metricKey: string;
  score: number;
};

// Expo resolves skin-metric-history.native.ts or skin-metric-history.web.ts at runtime.
// This file provides a conservative TypeScript fallback for non-platform-aware tooling.
export async function saveSkinMetricHistory(_result: SkinAnalysisResult): Promise<void> { return Promise.resolve(); }
export async function loadSkinMetricHistory(_limit = 120): Promise<SkinMetricHistoryPoint[]> { return Promise.resolve([]); }
export async function clearSkinMetricHistory(): Promise<void> { return Promise.resolve(); }
