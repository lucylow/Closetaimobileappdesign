# Verified Real Skin Product Catalog Sources

The following manufacturer pages were reviewed on 2026-08-12 for the initial catalog-ready Skin Care product records. Product availability and package ingredient lists can change; production refreshes should use an authorized catalog feed or the manufacturer page.

| Product | Verified manufacturer details used in catalog | Official source |
|---|---|---|
| CeraVe Hydrating Facial Cleanser | Hydrating facial cleanser for normal to dry skin. Manufacturer lists ceramides and hyaluronic acid as key ingredients and gives “anytime” use guidance. | https://www.cerave.com/skincare/cleansers/hydrating-facial-cleanser |
| La Roche-Posay Toleriane Double Repair Face Moisturizer | Face moisturizer. Manufacturer lists ceramide-3, niacinamide, glycerin, and prebiotic thermal water as key ingredients; manufacturer use guidance is morning and evening after cleansing. | https://www.laroche-posay.us/our-products/face/face-moisturizer/toleriane-double-repair-face-moisturizer-tolerianedoublerepair.html |
| The Ordinary Niacinamide 10% + Zinc 1% | Water-based serum. Manufacturer lists niacinamide and zinc PCA as key ingredients; source says use morning and evening after cleansing and before heavier formulations, with patch-testing guidance. | https://theordinary.com/en-us/niacinamide-10-zinc-1-serum-100436.html |

## Catalog Boundary

The app’s catalog records expose a verified product name, brand, product type, primary ingredients, official product URL, routine placement, and general compatibility metadata. The application deliberately does not store price, stock, delivery status, or retailer availability as static truth. The “Add to Cart” action is represented as a cart-ready outbound catalog action until an authorized commerce/catalog partner and checkout integration are configured.
