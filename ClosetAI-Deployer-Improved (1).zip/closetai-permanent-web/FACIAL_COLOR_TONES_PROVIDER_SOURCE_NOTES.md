# Facial Color Tones Analyzer Provider Source Notes

## Source basis

The integration contract below was verified against the **AI Facial Color Tones Analyzer** documentation supplied with this task, including the documented `/s2s/v2.0/task/skin-tone-analysis` task workflow, source-file upload path, face-angle strictness settings, output color fields, and asynchronous polling behavior. The provider documentation is part of the user-supplied feature specification in `pasted_content_20.txt`.

## Verified integration contract

| Item | Provider contract described in supplied specification | ClosetAI implementation |
|---|---|---|
| Task creation | `POST /s2s/v2.0/task/skin-tone-analysis` | Server-only YouCam v2 request using `src_file_id` and validated face-angle strictness. |
| Task status | Asynchronous status polling until a terminal success or error state | Bounded server polling; no task ID or provider credential is returned to Expo. |
| Source photo | Uploaded through provider File API before task creation | Existing signed private upload flow; no public photo URL is required. |
| Strictness settings | `strict`, `high`, `medium`, `low`, `flexible` | Shared bounded type; default is `high`. |
| Required display fields | Skin, eye, lip, eyebrow, and hair colors | All five must be valid six-digit hexadecimal values or the response fails closed. |
| Optional labels | Eye and hair color labels when provider supplied | Normalized only from provider output; no inferred label is added locally. |
| Output source | Provider task response | `source: "provider"` only; no local palette or demo fallback is substituted. |

## ClosetAI product boundary

The Color Tones experience is optional cosmetic style exploration from a user-selected selfie. It is not an ethnicity, identity, health, genetics, suitability, attractiveness, or medical assessment. Original photos and output values are not written to skin history by default. If a provider response is incomplete, malformed, unavailable, or fails validation, the app displays no color values and no fabricated palette.
