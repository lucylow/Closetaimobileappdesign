# AI Breast-Shape Cosmetic Visualization Provider Source Notes

## Verified official source

- [Perfect Corp. AI Breast Augmentation Simulator overview](https://docs.perfectcorp.com/reference/ai_breast_augmentation)
- [Perfect Corp. AI Breast Augmentation Simulator OpenAPI schema](https://docs.perfectcorp.com/_bundle/reference/ai_breast_augmentation.yaml?download)

| Item | Verified provider detail | ClosetAI implementation choice |
|---|---|---|
| Create task | `POST /s2s/v2.0/task/breast-shape` | Server-only request using the existing v2 credential helper. |
| Get task status | `GET /s2s/v2.0/task/breast-shape/{task_id}` | Bounded server polling; no polling credentials on the device. |
| Source image | `src_file_id` or a public `src_file_url` | Private upload + `src_file_id`; never require a public user-photo URL. |
| Adjustment control | `intensity` enum `1`, `2`, or `3` | The UI starts at level 1 and uses only the documented bounded values. |
| Output | Single `url` valid for two hours | Return only a valid HTTPS provider result URL; do not persist it. |
| Provider file specification | `jpg/jpeg/png/heic`, smaller than 10MB, minimum 512×384, long side under 4096px | The app gives photo-quality guidance and rejects oversized mobile payloads before upload. |
| Provider subject guidance | A detectable upper body and both shoulders visible | The UI asks for a clothed, adult, upper-body photo with both shoulders visible. |
| Provider error conditions | Invalid parameter, size, decode, NSFW, pose, and breast-region detection errors | Route maps failures to clear retry guidance; never presents a stock or generated fallback image. |

## ClosetAI safety and product boundary

This optional feature is an **adult-only cosmetic photo visualization**. It is not a prediction, diagnostic tool, medical or surgical planning tool, assessment of anatomy, recommendation for a procedure, or a comparison against an ideal body. The app requires confirmation that the user is 18 or older, requires explicit consent, requests a clothed photo, accepts only the user-selected image, and does not store the original image or the temporary result URL in user history. It will not use a stock person, fictional sample, demo image, or fallback result after a failure.
