/**
 * Expo Router owns the application entry through package.json.
 *
 * This compatibility module remains only because the repository retains a
 * legacy `src/` style directory; it must not import a separate web App tree.
 */
export {};
