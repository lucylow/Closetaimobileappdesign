# Face Attributes Provider Source Notes

## Source

The user supplied Perfect Corp.'s downloadable OpenAPI specification for **AI Face Attributes & Ratio Analyzer**, retrieved at:

- https://docs.perfectcorp.com/_bundle/reference/ai_face_analyzer.yaml

## Verified v2 task details

| Item | Verified contract detail |
|---|---|
| Task creation | `POST /s2s/v2.0/task/face-attr-analysis` |
| Task polling | `GET /s2s/v2.0/task/face-attr-analysis/{task_id}` |
| Auth | Bearer API key, server-only |
| File source | File API `file_id` placed in `payload.file_sets.src_ids` |
| Request deduplication | Top-level numeric `request_id`; same identifier supports safe retry semantics |
| Action envelope | `payload.actions` accepts a single item with `id`, `params.face_angle_strictness_level`, and `dst_actions` |
| Strictness values | `strict`, `high`, `medium`, `low`, `flexible` |
| Result status | `data.task_status`: `running`, `success`, or `error` |

## Ethical application boundary

The upstream schema offers age and gender actions, but ClosetAI deliberately excludes them. The application requests only user-selected style geometry and raw proportion fields. It does not present a golden-ratio ideal, beauty score, attractiveness rank, identity inference, age estimate, or gender estimate.

Source captured in session from official OpenAPI extraction and user-provided documentation.
