# ClosetAI AI Agents — 20-Page Fashion and Skincare Implementation Plan

**Author:** Manus AI  
**Application:** ClosetAI Expo Mobile Application  
**Scope:** User-initiated AI planning agents for wardrobe styling and cosmetic skincare guidance  
**Status:** Implementation blueprint aligned to the supplied Complete AI Hackathon concepts

> **Health boundary:** The skincare agent described here is an informational cosmetic-routine planner, not a medical professional. It must not diagnose conditions, predict treatment outcomes, prescribe products, interpret a selfie as health evidence, or replace a qualified clinician.

## Page 1 — Executive adaptation

The supplied hackathon material establishes a useful product pattern: make multiple specialist agents collaborate around shared context, retain visibility into their actions, and connect those agents directly to an end-user product rather than presenting them as an isolated technical demonstration. It also calls for at least two custom agents and emphasizes realistic product workflows, governance, and an end-to-end experience.[1] ClosetAI can adapt that pattern without importing the source event’s platform requirement or pretending that it is part of the DeveloperWeek project.

This plan converts the pattern into a **ClosetAI Agent Studio**. The first implementation contains two principal, user-initiated agents. The **Fashion Look Planner** turns a request, occasion, weather context, color preference, and local wardrobe summary into a transparent outfit brief. The **Skin Routine Companion** turns a user-selected cosmetic goal, optional saved normalized snapshot context, and routine preference into a conservative AM/PM routine outline and external-only discovery categories. A deterministic **Safety and Evidence Gate** sits between agent output and the user interface. It is not an autonomous health authority; it is a server-side validator that rejects forbidden claims and keeps source, demo, and provider boundaries visible.

| Design objective | ClosetAI interpretation | Explicit non-goal |
| --- | --- | --- |
| Multiple collaborating agents | Fashion planner, skincare routine companion, and a deterministic safety gate share a scoped context packet. | Autonomous agents that take actions without a user request. |
| Persistent shared context | A request-scoped context summary is assembled from the local wardrobe, selected preferences, and permitted snapshot metadata. | Hidden cross-session profiling or raw-selfie retention. |
| Governance and visibility | The response names the active agent, context sources, limitations, and local/demo/provider status. | Opaque model reasoning or unlogged uncontrolled tool use. |
| Product-first experience | Agents live in the existing Home and Skin Care navigation, with accessible loading and recovery states. | A disconnected “chatbot” page that does not use ClosetAI data. |

The implementation is intentionally modest enough to work in Expo Go and Replit. The client never receives provider keys. The server builds a minimum context packet, calls one server-side language model only when an authorized key is available, validates structured JSON, and otherwise returns a deterministic, clearly labeled local fallback. This preserves the current application’s emphasis on offline resilience and fictional-demo disclosures.

## Page 2 — Product vision and user jobs

ClosetAI should not describe every language-model interaction as an “agent.” In this plan, an agent has a defined role, a bounded input contract, a structured output contract, a distinct user-visible purpose, and a named set of permitted operations. That distinction makes the feature understandable to hackathon judges and safer for users. The product’s core question is not “What can AI say about fashion or skin?” It is “How can an assistant help a user make a reversible, well-contextualized next choice?”

The Fashion Look Planner addresses three high-frequency jobs: preparing an outfit for a stated occasion, restyling clothes the user already owns, and identifying a practical gap to browse later. The agent may suggest styling combinations, contrast, layering, and accessory categories. It may never claim a garment is available for purchase, reserve a product, use live stock, or present a sponsor brand as a recommendation unless an external source record already exists in ClosetAI.

The Skin Routine Companion addresses three different jobs: translating a user-chosen cosmetic goal into a simple routine sequence, connecting an optional source-labeled snapshot to general-care language, and helping a user select an external discovery category to inspect. It may explain a neutral cosmetic routine order, recommend verifying the current label, and point to a category within the existing catalog. It may never diagnose acne, rosacea, dermatitis, or any other condition; prescribe an ingredient; forecast improvement; claim a named product is suitable; or infer a person’s identity, age, gender, or medical status from an image.

| Persona | Request | Agent response | User control |
| --- | --- | --- | --- |
| Wardrobe owner | “Help me build a relaxed dinner look.” | A look theme, 2–3 local wardrobe candidates, styling steps, and a single optional gap category. | The user chooses occasion, palette, and whether to save anything. |
| New ClosetAI user | “I have not added many pieces yet.” | A short starter workflow and a request to add owned items before generating a richer look. | The user can continue without a model call. |
| Cosmetic routine explorer | “Give me a simple PM routine outline.” | A three-step general-care outline with a source boundary and optional category references. | The user chooses goal and whether a saved snapshot may be used. |
| Demo reviewer | “Show agent behavior without data.” | A clearly marked fictional demo response and no claim that it came from a real scan or wardrobe. | The user can exit demo at any time. |

## Page 3 — Agent roster and responsibilities

The application begins with two primary agents because the supplied hackathon material explicitly centers on collaboration among at least two custom agents.[1] A third component, the Safety and Evidence Gate, is deterministic code rather than a persona. This separation is important: policy enforcement must not depend on a model successfully following an instruction. In a future milestone, the Fashion Look Planner may delegate deterministic wardrobe selection to a local selector, but the initial release keeps the orchestration legible.

| Component | Type | Inputs it may use | Output it may produce | Operations it may not perform |
| --- | --- | --- | --- | --- |
| Fashion Look Planner | Server-side LLM with schema validation | Explicit user request, occasion, color preference, weather summary if available, local wardrobe metadata. | Outfit concept, local piece IDs, styling notes, confidence/limitation text, optional browse category. | Checkout, external purchase, hidden image upload, price or stock claim. |
| Skin Routine Companion | Server-side LLM with schema validation | Explicit cosmetic goal, AM/PM preference, optional normalized snapshot metadata, existing product category records. | General routine steps, caution text, category reference IDs, source boundary. | Diagnosis, prescription, suitability verdict, treatment result, formula replication. |
| Safety and Evidence Gate | Deterministic server code | Draft structured response, data source labels, permitted identifiers. | Approved response or safe local fallback, disclosure strings, validation flags. | Model inference, health assessment, silent claim rewriting that masks a rejection. |
| Context Assembler | Deterministic server code | Authenticated user scope, request fields, local storage records, optional weather response. | Minimal request-scoped context packet. | Raw image storage, unauthorized records, credential exposure. |

Each agent must expose its name and scope in the UI. The Fashion Look Planner should present “Built from your selected preferences and local wardrobe summary.” The Skin Routine Companion should state “General cosmetic-routine planning from the choices you selected; not medical advice.” When demo data is present, the agent must display “Fictional demo context” rather than disguising example output as live personalization.

## Page 4 — Shared context and minimum-data architecture

Shared context should be useful, not expansive. The source hackathon material celebrates persistent workspace memory, but in a consumer mobile application persistent memory must be opt-in, scoped, and comprehensible.[1] ClosetAI already stores user wardrobe, preferences, mock-commerce context, and normalized skin snapshot summaries. The agent system should consume only the minimum fields necessary to answer the current request. Context is not an excuse to build a shadow profile.

The request should travel from Expo to an authenticated or demo-aware server endpoint. The server validates the request with Zod, loads user-scoped data, builds an internal context object, and strips unnecessary fields before model invocation. For fashion, include only item IDs, categories, colors, tags, seasonality, and use count; exclude image bytes and raw image URLs unless a future image-aware feature has a separately approved consent flow. For skincare, include only the selected goal, routine preference, source label, and normalized metric names when the user explicitly chooses to use a saved snapshot. Exclude original selfie URIs, image base64, medical interpretations, and raw provider payloads.

| Context field | Fashion agent | Skincare agent | Retention rule |
| --- | --- | --- | --- |
| User prompt | Required | Required | Sent only for the current request. |
| Occasion / palette | Optional | Not used | Request-scoped. |
| Wardrobe metadata | Optional | Not used | User-scoped, minimized to display-safe fields. |
| Weather summary | Optional | Not used as a health signal | Fresh or cached only; label as context, not certainty. |
| Normalized snapshot source | Not used | Optional | Included only after an explicit user selection. |
| Original photo or raw provider response | Never | Never | Not placed into agent context. |
| External catalog IDs | Optional source labels | Optional category references | Used only to link existing approved records. |

The server should create a `requestId` for observability and a `contextSummary` array for the UI. The client may display items such as “occasion: dinner,” “wardrobe: 12 local items,” or “skin snapshot: saved normalized summary.” It must not display hidden prompts, raw secret-bearing logs, or chain-of-thought. This delivers the visibility principle from the source material without exposing sensitive internals.

## Page 5 — Fashion Look Planner: behavior specification

The Fashion Look Planner is a wardrobe-first agent. Its default behavior should be to make the user’s existing clothes more usable before suggesting external discovery. The planner receives a maximum of a small, ranked wardrobe candidate set rather than every record. Candidate selection is deterministic: match requested occasion, dominant palette, season, category coverage, and prior use count. The model then produces a structured explanation that references only candidate IDs supplied by the server.

The agent response should contain a title, a concise look direction, up to three selected wardrobe IDs, three styling steps, one optional “consider later” category, a context summary, and a limitation statement. It should not fabricate brands, exact products, store URLs, or facts not present in the context packet. If there are too few items, the agent returns an intentional “wardrobe setup” response that helps the user add owned garments instead of inventing an outfit.

| Fashion request state | Required behavior | Example safe outcome |
| --- | --- | --- |
| Four or more suitable items | Select existing IDs and explain the combination. | “Try the navy blazer with the white tee and dark trousers for a refined casual base.” |
| One to three items | Describe what can be styled and identify one category gap. | “You have a strong top layer; add an owned bottom before building a full look.” |
| No wardrobe items | Guide onboarding, no false personalization. | “Add a few pieces you own to make wardrobe-based planning available.” |
| Demo Mode | Use only labeled fictional inventory. | “Fictional Demo Mode: this suggestion uses the selected demo wardrobe.” |
| Live provider unavailable | Return local deterministic plan. | “Local planning fallback: based on your selected occasion and stored item tags.” |

The design should include an explicit “Use this plan” action that only navigates to an existing outfit creation or saved-look screen. It must not automatically add, delete, purchase, publish, or share anything. An optional “Why these pieces?” toggle makes the agent’s styling logic legible, satisfying the governance expectation of visible actions while maintaining a lightweight mobile experience.

## Page 6 — Wardrobe Curator subroutine and quality gate

The Fashion Look Planner depends on a deterministic Wardrobe Curator subroutine. It is not a free-form agent in the initial release; it is a transparent selector that limits the model’s operating space. It ranks local items by category coverage and relevance, then validates that every `selectedItemId` returned by the model appears in the original context. If the output references an unknown item, the response is rejected and replaced by a local fallback.

The curator should score items with a small explainable function. A top, bottom, shoe, outerwear, and accessory may receive category-balance points. An occasion tag match may receive relevance points. A requested palette match may receive harmony points. A recently worn item may be deprioritized only if the user has indicated they want variety. These are ordinary product rules, not claims about taste quality or the user’s identity.

| Validation check | Why it exists | Failure behavior |
| --- | --- | --- |
| Output ID appears in context | Prevents fabricated wardrobe items. | Remove invalid ID; use local fallback if no valid selection remains. |
| Selected set contains at most three items | Keeps mobile response concise and reviewable. | Trim deterministically and record a validation flag. |
| No product URL or price appears in agent copy | Prevents unsupported commerce claims. | Reject draft and return category-only browse prompt. |
| No appearance or body judgment language | Prevents demeaning or sensitive profiling. | Reject draft and return neutral styling language. |
| No action verb triggers a transaction | Ensures the agent cannot purchase or reserve. | Replace with a user-directed navigation suggestion. |

This approach creates a credible collaboration story: deterministic selection narrows the candidate set, the planner writes a user-readable rationale, and the gate confirms that the response remains inside data and policy boundaries. The user can see the input sources and final plan without needing to inspect model internals.

## Page 7 — Skin Routine Companion: behavior specification

The Skin Routine Companion is designed as an informational cosmetic-routine organizer, not a skin-analysis agent. Its role is to help a user translate a chosen goal such as hydration, comfort, radiance, texture appearance, or a simple AM/PM sequence into a conservative routine order. If the user opts in to a saved normalized snapshot, the agent can mention that its context came from “saved visual summary” or “fictional demo summary,” but it cannot treat that summary as a diagnosis or conclusive health measurement.

The agent should return no more than four routine steps. Each step must be generic, reversible, and label-aware. For example, “cleanse as directed on the label,” “use a moisturizer category if desired,” and “use daytime protection as directed on the product label” are appropriate. It may point to existing product category references in the app. It must use a required disclaimer such as “General cosmetic guidance only; a product label and qualified professional should guide any consequential concern.”

| Skincare request state | Permitted response | Prohibited response |
| --- | --- | --- |
| User selects “simple AM routine” | Cleanse, moisturize, daytime-protection category, label reminder. | “Your skin needs SPF 50 because of your damage.” |
| User selects “comfort-focused PM” | Gentle routine order and a patch-test/label reminder. | “Treat your inflammation with…” |
| Saved source-labeled summary is selected | “Using your saved normalized summary as context.” | “Your scan proves that you have…” |
| Demo source is selected | “Fictional Demo Mode cosmetic routine example.” | “Your live skin analysis found…” |
| No snapshot exists | Goal-first general routine explanation. | A blank state that forces a selfie or diagnosis. |

The agent must not call the existing image analysis endpoint. This is deliberate. Photo analysis has its own consent flow, source labels, provider boundaries, and limited output. The routine companion consumes only the normalized summary the user explicitly elects to use. The result screen should provide a visible “Use without snapshot” path so the feature never coerces image submission.

## Page 8 — Skin source, product, and discovery boundaries

The existing application contains official-source product records, ultra-luxury external discovery records, mock-cart data, and AR visual-preview experiences. The agent system must keep these boundaries distinct. An agent may reference a `categoryReferenceId` or `officialSourceLabel` already approved by the catalog. It may not convert that reference into an endorsement, diagnosis-based match, availability assertion, real checkout, price statement, formula comparison, or brand-specific simulation.

For implementation, the skincare context packet should contain at most five category reference records: ID, display name, category, routine context, source label, and an existing disclaimer. The response includes only those IDs. The client resolves IDs locally to the existing source-aware UI. This avoids allowing model text to introduce uncontrolled URLs and makes every outbound destination reviewable.

| Source type | Agent may do | Agent must not do |
| --- | --- | --- |
| Existing official product record | Link a supplied record as an optional category reference. | Claim a product is in stock, appropriate for the user, or medically effective. |
| Ultra-luxury discovery record | Mention an external discovery category and keep the existing external-only label. | Turn it into a real cart, reservation, price, availability, or affiliated offer. |
| Mock commerce record | Explain that it is a fictional prototype experience. | Use it as live inventory or payment data. |
| AR texture preview | Offer navigation as an optional local visual preview. | Claim it models a formula, outcome, or product effect. |
| Saved normalized snapshot | Explain that it is optional context only. | Infer a disease, a treatment need, or personal attributes. |

This separation is especially important in mobile UI because users may mistake confident language for medical or commercial certainty. The response card must therefore show source chips such as “Local wardrobe,” “Fictional Demo Mode,” “Saved normalized summary,” or “External category reference.” A user should never need to guess where an agent’s suggestion came from.

## Page 9 — Safety and Evidence Gate

The Safety and Evidence Gate is deterministic server code that processes every draft response. It should have four tasks: schema validation, identifier validation, phrase screening, and fallback selection. Schema validation confirms the LLM returned valid JSON with the expected fields. Identifier validation ensures selected wardrobe and catalog IDs exist in the supplied context. Phrase screening rejects high-risk language. Fallback selection returns a deterministic local response rather than showing an error without explanation.

The phrase screen is a defense-in-depth mechanism, not the only safeguard. The system prompt and JSON schema should already forbid diagnostic, prescriptive, predictive, medical, unsupported commerce, and body-judgment language. The gate adds deterministic checks for common claim patterns such as “diagnose,” “treat,” “cure,” “guarantee,” “will improve,” “you have,” “buy now,” “in stock,” “price,” “checkout,” and “prescription.” A rejected response should be logged only as a category and request ID; it should not retain unneeded raw personal content.

| Gate stage | Fashion policy | Skincare policy | User-visible outcome |
| --- | --- | --- | --- |
| Schema check | Requires title, selected IDs, styling steps, limitation. | Requires title, routine steps, disclaimer, source labels. | “The agent response was unavailable; here is a local planning fallback.” |
| Evidence check | All garment IDs must belong to the context packet. | All catalog IDs must be supplied external references. | Invalid references are removed or fallback is used. |
| Claim check | Rejects price, stock, purchase, appearance judgment. | Rejects diagnosis, treatment, efficacy, suitability, prediction. | Neutral copy and a persistent boundary note. |
| Action check | Rejects direct mutations, payments, or external posting. | Rejects changes to treatment plans or medical direction. | User can choose a separate navigation action. |

The gate must run even when the app is in Demo Mode. Demo Mode changes the data source label, not the safety standard. A fictional response must be as explicit about its limitations as a live-provider response.

## Page 10 — Server orchestration and structured output

The server exposes one route, `POST /api/agents/plan`, with an `agent` discriminator of `fashion` or `skincare`. One route enables shared request validation, telemetry, authentication handling, rate limiting, and response semantics. It does not mean both agents have the same prompt or policy. The route dispatches to explicit agent builders with separate schemas and disclosure strings.

The first request phase is deterministic: validate the payload, authenticate or establish the application’s current guest/demo scope, assemble minimum context, and choose a bounded model route if a server credential exists. The second phase is generative only when authorized: ask the relevant agent to return strict JSON. The third phase is deterministic: validate the JSON, run the Safety and Evidence Gate, and return either the approved result or a local fallback. No client-provided system prompt, arbitrary URL, raw image, provider secret, or unrestricted tool call is accepted.

```text
Expo screen
  → apiRequest(POST /api/agents/plan)
    → Zod input validation
      → user/demo scope and context assembly
        → Fashion Look Planner OR Skin Routine Companion
          → strict structured JSON response
            → Safety and Evidence Gate
              → approved agent plan OR deterministic local fallback
                → accessible mobile result card
```

The response contract contains `requestId`, `agent`, `mode`, `title`, `summary`, `steps`, `selectedWardrobeItemIds`, `categoryReferenceIds`, `contextSources`, `disclosure`, `usedFallback`, and `validationFlags`. The mobile client is deliberately unable to interpret arbitrary model text as a deep link, code, executable action, API URL, payment instruction, or raw HTML.

## Page 11 — Model routing and credential isolation

The source hackathon material mentions parallel model use, but ClosetAI should avoid multi-model complexity until it has a concrete product need.[1] The first release uses one configured server-side language model provider. The exact provider may be the existing server-side OpenAI-compatible integration, a future authorized provider, or no provider at all. The model is an implementation detail; the response contract and safety gate are product contracts.

The server should read `AI_INTEGRATIONS_OPENAI_API_KEY` and optional `AI_INTEGRATIONS_OPENAI_BASE_URL` only from Replit Secrets or equivalent server environment configuration. No new `EXPO_PUBLIC_*` provider key should be created. If the provider is absent, rate-limited, malformed, or times out, the route returns the local fallback with `mode: "local_fallback"`. The UI must display this honestly rather than implying a live AI response was generated.

| Condition | Server behavior | Mobile label |
| --- | --- | --- |
| Authorized LLM returns valid plan | Approve after deterministic gate. | “AI-assisted plan” with context chips. |
| Provider key missing | Skip LLM and generate deterministic plan. | “Local planning fallback.” |
| Network timeout / provider error | Skip retry loop after bounded attempts; return fallback. | “A live agent was unavailable; this local plan is based on selected context.” |
| Output fails JSON/schema gate | Discard draft and return fallback. | “The response could not be verified; showing a safe local plan.” |
| Policy screen rejects content | Discard draft; log category only; return fallback. | “Showing a safety-checked local plan.” |

Agent prompts should never ask the model to reveal system instructions, credentials, chain-of-thought, or private records. The app should record only the response metadata needed to debug reliability: request ID, agent type, mode, duration bucket, gate result, and error category. Any persisted user preference must be an explicit app setting, not an accidental copy of the conversation.

## Page 12 — Mobile information architecture

The agent experience should feel integrated rather than added as a sixth tab. The existing Home screen should receive a compact **Plan with Agents** card, because the Fashion Look Planner is primarily a wardrobe workflow. The existing Skin Care hub should receive an **Ask the Routine Companion** card, because the skincare agent is an optional planning workflow adjacent to source-aware routine and AR features. Both cards open one shared `app/agents.tsx` route with a mode selector. A `skin` route parameter or initial mode can open skincare directly.

The shared screen uses two modes. Fashion mode offers occasion, palette, and “use my wardrobe” controls. Skincare mode offers routine timing, cosmetic goal, and an optional switch to use the latest normalized summary. The user may type a short request, but the interface should provide quick prompts so a complete sentence is not required. The send button is disabled while the request is in flight and exposes `accessibilityState={{ busy: true }}`. The result includes context chips, disclosure copy, and only safe navigation actions.

| Entry point | Route | Default mode | Primary action |
| --- | --- | --- | --- |
| Home “Plan with Agents” | `/agents?mode=fashion` | Fashion | Create a wardrobe-aware look plan. |
| Skin Care “Routine Companion” | `/agents?mode=skincare` | Skincare | Create a general cosmetic AM/PM outline. |
| Fashion result | Existing outfit or wardrobe route | Fashion | Review existing wardrobe and create an outfit intentionally. |
| Skincare result | Existing product discovery or texture preview route | Skincare | Browse an external category reference or open optional local visual preview. |

The shared screen should not imitate a general-purpose chat transcript. One request, one reviewed plan, and one explicit “plan again” action is easier to understand, easier to validate, and less likely to encourage the user to seek consequential medical advice from a cosmetic planner.

## Page 13 — Accessibility and inclusive interaction requirements

Every interactive element in the agent interface must provide `accessibilityRole`, `accessibilityLabel`, `accessibilityHint`, and relevant `accessibilityState`. The mode selector should announce its selected state. The response state should use `accessibilityLiveRegion="polite"` to announce “Fashion plan ready” or “Routine plan ready” without interrupting a screen reader. Error and fallback cards should say what happened and offer a retry without blaming the user.

Color alone must not indicate source. A response sourced from demo, local fallback, live model, or saved normalized summary should use an icon, plain-language text, and a visible label. Text should remain selectable and not be rendered only inside decorative images. The design should support Dynamic Type through flexible container heights and avoid fixed text-card heights. Controls should remain usable with keyboard navigation in Expo web, touch targets on mobile, and reduced-motion settings.

| Interaction | Accessible name | State announcement | Failure recovery |
| --- | --- | --- | --- |
| Select Fashion agent | “Choose Fashion Look Planner” | Selected / not selected. | Maintains input when mode changes. |
| Select Skincare agent | “Choose Skin Routine Companion” | Selected / not selected. | States that guidance is cosmetic, not medical. |
| Include saved summary | “Use latest saved normalized skin summary” | Checked / unchecked. | User can turn it off without losing routine goal. |
| Generate plan | “Create agent plan” | Busy while requesting. | Offers “Try again with local context.” |
| Context chip | “Context source: Fictional Demo Mode” | Informational. | Never functions as an undocumented control. |

## Page 14 — Privacy, consent, and data lifecycle

The agent feature must create no new photo-collection path. Fashion planning uses wardrobe metadata that the user has already stored. Skincare planning uses a selected cosmetic goal and, only with an explicit interface choice, a saved normalized summary. The agent flow never receives original image URI, image base64, camera stream, provider token, full raw skin-analysis JSON, or any inferred identity attribute.

The client should explain consent in context: “Use your latest saved normalized summary for general cosmetic planning. Original photos are not sent to the routine companion.” The server should validate a boolean `includeLatestNormalizedSummary` and ignore any client attempt to submit snapshot content directly. It loads the permitted user-scoped summary itself, reduces it to source label and allowed metric labels, and records that the user chose to include it for this request.

| Data item | Device storage | Server request | Provider request | Retention |
| --- | --- | --- | --- | --- |
| User prompt | Temporary screen state | Yes, current request only. | Only if a configured LLM is invoked. | Not stored in new agent history by default. |
| Wardrobe metadata | Existing app state | Selected minimal fields. | Optional LLM context. | Existing product policy only. |
| Original photo | Existing image flow only | No | No | Not part of agent feature. |
| Normalized snapshot summary | Existing controlled state | Yes, only if user opts in. | Optional LLM context after minimization. | Existing snapshot policy only. |
| Provider/API secret | Never | Server environment only. | N/A | Never sent to client or logs. |

The app must explain that a demo response is fictional and that a fallback response is deterministic. Transparency is a privacy feature: users should know whether a response was based on their local selections, a labeled demo profile, or a configured server model.

## Page 15 — Error handling, fallback, and offline resilience

Agentic features must improve the app rather than create a new point of failure. The fallback architecture is therefore a first-class product requirement. The Fashion Look Planner fallback uses the selected occasion and local wardrobe candidate list to produce a concise deterministic look direction. The Skincare Routine Companion fallback uses the selected routine time and cosmetic goal to produce a neutral step order and the same disclosure. Neither fallback fabricates a provider result or pretends to personalize beyond the inputs it actually used.

The mobile screen should distinguish three states: initial, loading, and response. A loading card should say which agent is planning and what sources it can use. A response card should state whether it is AI-assisted or a local fallback. A network error should include “Try again” and “Use a local plan” rather than a vague alert. Existing Expo Go behavior must remain functional even when no AI provider secret is configured.

| Failure mode | Detection | Response | Test requirement |
| --- | --- | --- | --- |
| No AI server credential | Server environment check. | Local fallback. | Contract asserts no client key and labeled fallback. |
| Timeout | AbortController or existing retry boundary. | Local fallback with request ID. | Test simulates timeout category. |
| Invalid model JSON | Zod parse failure. | Local fallback; raw output discarded. | Test invalid structure. |
| Unsafe phrase | Deterministic phrase screen. | Local fallback and policy flag. | Test medical and commerce wording. |
| No wardrobe / no snapshot | Context assembler finds no optional data. | Onboarding or general-goal response. | Test zero-data user. |

## Page 16 — Testing strategy and acceptance criteria

The test suite should use the current repository’s simple TypeScript contract style. Agent tests should read source files and assert essential architecture boundaries, but the most valuable logic should also be isolated into pure functions for direct unit tests. Tests should not make paid provider calls or require a real database. A mocked coordinator response can exercise client rendering and disclosure behavior through the exported formatting helpers.

The acceptance criteria combine functional and safety outcomes. A fashion plan must select only known wardrobe IDs or return a no-wardrobe recovery response. A skincare plan must always show general cosmetic guidance and must reject diagnostic, predictive, prescriptive, and product-suitability language. Both must return a disclosure, context source labels, and a local fallback when a live provider is unavailable. Replit validation must continue to use server-only keys and Expo Go must remain runnable.

| Test layer | Example assertion | Pass condition |
| --- | --- | --- |
| Unit — schema/gate | Unknown wardrobe ID is rejected. | The user sees a fallback with no invented item. |
| Unit — skincare wording | “Diagnose,” “treat,” and “guarantee” are blocked. | The plan remains informational and non-diagnostic. |
| Contract — credentials | Agent module reads server environment only. | No `EXPO_PUBLIC_*` provider secret is introduced. |
| Contract — navigation | Home and Skin Care link to the shared agent route. | Entry points are accessible and registered. |
| Integration — API | Valid fashion and skincare requests return the shared response shape. | Client can render both modes. |
| Release gate | TypeScript, all tests, expo-doctor, web export. | No Expo Router, dependency, or configuration regression. |

## Page 17 — Delivery sequence and developer workflow

The implementation should proceed in small, testable increments. First, add pure shared types and policy constants. Second, add the deterministic context builders and fallback factories. Third, add the coordinator route with a mockable LLM interface and strict response gate. Fourth, add a small client service. Fifth, add the shared mobile agent screen. Sixth, connect home and Skin Care entries. Seventh, add contracts, validate Expo, and package the source release.

Each increment should preserve the ability to run the app with no external AI credentials. The initial code path can use the existing OpenAI-compatible server integration when authorized. It must never have a compile-time dependency on a particular optional provider response. Configuration documentation should list the existing server-only `AI_INTEGRATIONS_OPENAI_API_KEY` and optional base URL, but the agent screen should describe live mode as optional.

| Increment | Main files | Proof before moving on |
| --- | --- | --- |
| Shared contracts | `shared/closetai-agent-contracts.ts` | TypeScript compiles and policy literals are testable. |
| Server planning module | `server/closetai-agents.ts` | Pure fallbacks and gate unit tests pass. |
| Server route | `server/routes.ts` | Input validation and response shape work with a mock/fallback. |
| Client service | `lib/closetai-agents.ts` | Typed request reaches correct API path. |
| Agent screen | `app/agents.tsx` | Fashion and skincare modes render with loading/recovery states. |
| Entry integration | Home and Skin Care hub | Both routes are reachable through accessible controls. |
| Release gate | Tests, Expo doctor, export | Expo Go/Replit package remains compatible. |

## Page 18 — Rollout, measurement, and governance

The first release should be behind an internal configuration switch or treated as an explicit prototype experience. “Agent-assisted plan” should not be an invisible replacement for existing outfit generation or skincare routine cards. Keeping the feature opt-in creates a cleaner experiment and allows the team to observe whether users find the explanations helpful without inadvertently changing their established flows.

Telemetry must focus on reliability and product use, not sensitive content. Record agent type, mode, source labels, request duration bucket, whether fallback was used, gate result category, and navigation action taken. Do not record raw prompts, raw image data, raw provider output, or hidden model reasoning by default. If future user feedback is added, it should be explicit, optional, and stored separately from health-related context.

| Metric | Purpose | Privacy boundary |
| --- | --- | --- |
| Fashion vs. skincare plan requests | Measures feature adoption. | No prompt text retained. |
| Local fallback rate | Measures provider reliability. | Store only agent type and error category. |
| Gate rejection category | Detects prompt/policy weaknesses. | Store policy label, not rejected content. |
| Save or navigation click | Measures usefulness of actionable plans. | No inferred sensitive attribute. |
| Demo vs. live-source selection | Tests clarity of source labels. | Preserve fictional status; do not mix cohorts silently. |

The governance story for a hackathon demo should show the request lifecycle on a single slide or console panel: selected agent, included sources, response mode, fallback status, and disclosure. It should not show secrets, raw image data, or hidden prompt content. This makes the system tangible to reviewers while preserving user trust.

## Page 19 — Future extensions and explicit exclusions

After the initial launch is stable, ClosetAI may expand the agent roster. A Weather Context Curator could normalize an existing weather response for fashion only. A Packing Planner could coordinate selected wardrobe categories for a trip. A Progress Reflection Agent could summarize user-authored routine notes without interpreting health results. These remain optional extensions, each requiring its own input contract, safety review, response schema, and testing plan.

The following ideas are explicitly excluded from this implementation: autonomous background task execution, unsupervised product purchasing, financial or medical decision-making, diagnosis, prescription, age/gender/identity inference, formula replication, live inventory claims, bulk image analysis, agent-to-agent internet browsing, arbitrary tool execution, and any activity that requires payment or external store contact. The app should never be described as a dermatologist, a personal shopper with purchasing authority, or a clinically validated treatment planner.

| Possible later feature | Prerequisite | Why it is deferred |
| --- | --- | --- |
| Multi-turn conversation memory | Explicit consent and retention UX. | Current request/response plans are safer and easier to explain. |
| Image-aware fashion agent | Dedicated ownership/consent and evaluation workflow. | Must preserve user-photo-only and avoid uncontrolled visual inference. |
| Provider tools / web search | Source governance and permissions model. | Prevents unverified commerce/medical claims in the first release. |
| Shared household wardrobe | Multi-user authorization and data model. | Requires a separate privacy and ownership design. |
| Proactive scheduled routines | User-controlled notification system and schedule policy. | Agents are intentionally user-initiated in this plan. |

## Page 20 — Implementation definition of done

The completed implementation should deliver the following: a detailed written plan, a shared agent contract, a server coordinator and gate, a fashion planner, a skincare routine companion, a shared Expo screen, Home and Skin Care entries, accessible states, regression coverage, Replit/Expo validation, and a source ZIP. The demo must make the collaboration visible: the context assembler prepares scoped inputs, the appropriate specialist produces a draft plan only when authorized, and the deterministic gate verifies evidence and policy before the result reaches the user.

The final demonstration should take less than three minutes. Open Home, choose Fashion Look Planner, select an occasion, and show a plan that references only locally stored wardrobe items. Then open Skin Care, choose Routine Companion, select a cosmetic goal with or without a saved normalized summary, and show the required general-care disclaimer and source chips. Finally, remove the server AI key or force the local mode to prove that the application remains functional, transparent, and safe without live model access.

| Definition-of-done item | Completion evidence |
| --- | --- |
| At least two specialist agents | Fashion Look Planner and Skin Routine Companion appear in the mobile UI. |
| Agent collaboration is visible | Context source labels, agent name, mode, and gate/fallback status render in each result. |
| No secret leakage | Provider credentials remain in server environment configuration only. |
| Skincare boundaries hold | No diagnosis, treatment prediction, suitability verdict, or formula claim can pass the gate. |
| Fashion boundaries hold | No invented wardrobe item, price, stock, transaction, or purchase action can pass the gate. |
| Expo compatibility holds | Strict TypeScript, all contracts, expo-doctor, and web export pass after integration. |
| Replit handoff holds | The existing verified Replit Expo flow and secret-safe preflight remain intact. |

## References

[1] Supplied document: *Complete AI Hackathon — CLOSET Add AI Agents Fashion*, provided by the user as `CompleteAIHackathon__CLOSET.ADDA.I.AGENTS.fashion.docx`. The document describes a collaborative multi-agent product pattern, a requirement for at least two custom agents, shared context, governance/visibility, and end-to-end product workflows.
