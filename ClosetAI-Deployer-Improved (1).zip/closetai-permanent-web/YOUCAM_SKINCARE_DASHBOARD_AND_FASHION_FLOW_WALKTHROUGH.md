# ClosetAI YouCam Integration Walkthrough

## Updated Skincare Dashboard: Source-Aware and Privacy-Bounded

The updated skincare dashboard does not render raw YouCam response payloads or retain provider-specific image artifacts in the presentation layer. The flow begins in `lib/skin-analysis-controller.ts`, where a saved live snapshot is normalized into a compact `SkinAnalysisResult`. Each metric is mapped to a fixed application key, bounded to its available normalized score, and tagged with the `youcam` source. The controller computes an **overall visual score** only from available normalized metrics and derives a count-based coverage object: `available`, `total`, and `percent`.

> **Important boundary:** visual-signal coverage measures how many expected normalized fields were returned. It is not an accuracy, clinical, health, or diagnostic confidence score.

| Layer | Main file | What it does | Security and safety boundary |
|---|---|---|---|
| Live analysis normalization | `lib/skin-analysis-controller.ts` | Maps saved live snapshot concerns into a fixed nine-metric interface, creates AM/PM routine guidance, and attaches source-aware coverage. | Does not expose raw provider payloads, uploaded-image data, masks, or medical interpretation. |
| Dashboard model | `lib/skin-intelligence-dashboard.ts` | Derives priorities, trend labels, source label, source detail, and bounded coverage for presentation. | Uses only normalized metrics and excludes provider/image data by design. |
| Dashboard UI | `components/skin/SkinIntelligenceDashboard.tsx` | Shows the live/demo/saved source label, signal-completeness count, metric cards, priorities, and trend context. | Displays general-care language such as “focus gently”; it never diagnoses, predicts, or claims clinical efficacy. |
| Local historical context | `contexts/SelfieScanContext.tsx` and SQLite history utilities | Saves normalized metric summaries for local progression views after an approved scan. | Original selfies are not written into the local metric-history store. |

The source-aware summary now behaves as follows. A live YouCam-derived result reports a message such as “Live YouCam visual analysis returned 9 normalized visual signals.” A partial response reports the available count instead, for example “6 of 9.” Demo Mode explicitly says that its visual-signal preview is fictional, while a live-analysis failure falls back to fictional Demo Mode data and surfaces a direct explanation that live YouCam analysis was unavailable. This prevents the user from mistaking offline fallback data for live analysis.

The dashboard uses `visualSignalSummary` when available and displays `visualSignalCoverage` as both a percentage and an explicit count, such as **9 of 9 normalized visual signals are available**. The UI therefore looks more informative without inferring any provider confidence score that the server did not actually return.

## Secure Source Handling Sequence

| Step | Data entering the step | Output | Safety control |
|---|---|---|---|
| 1. User approves selfie flow | User-selected image | Base64 only for the requested live analysis | The original photo is not placed into the dashboard model. |
| 2. Server-side YouCam request | Base64 image and server-only credentials | Raw provider task result | Credentials remain on the server; the Expo client never receives them. |
| 3. Snapshot normalization | Raw task result | Fixed normalized skin metrics and general routine data | Raw fields, provider payloads, and image data are deliberately omitted. |
| 4. Local approved-history save | Normalized metrics and timestamp | Local progression entry | History stores normalized summaries only, never the original selfie. |
| 5. Dashboard rendering | `SkinAnalysisResult` and local history | Source-aware cards, priorities, and trends | Copy remains non-diagnostic and bounded to visual/general-care context. |

## YouCam AI Clothes: Current Public Garment Reference Unlock Flow

The shared capability contract in `shared/youcam-fashion-experience.ts` separates the experience into five explicit states: `live-ready`, `needs-garment-reference`, `assisted-edit`, `provider-unavailable`, and `selection-needed`. This makes the fashion flow understandable before the user spends time waiting for a result.

A garment is **live-ready** only when all of the following are true: the server is configured for YouCam AI Clothes v4, the selected wardrobe category is among the seven AI Clothes-compatible categories, the user selected their own photo, and at least one selected wardrobe item exposes a public `https://` garment image. The current UI converts that logic into a visible readiness card and checklist instead of a vague error.

| Readiness state | Meaning | Current user-facing response |
|---|---|---|
| `live-ready` | A supported category and public garment reference are present. | “YouCam AI Clothes is ready” with a short checklist. |
| `needs-garment-reference` | The category is supported, but its image is local-only or absent. | Explains that a public garment image is still needed and that a user-photo-safe preview remains available. |
| `assisted-edit` | An accessory category—bags, hats, or jewelry/watches/scarves—has no dedicated AI Clothes region. | Explains the secondary user-photo-only assisted-edit path. |
| `provider-unavailable` | YouCam is not configured or reachable for the session. | Offers a clearly labeled photo-safe preview rather than another person’s image. |
| `selection-needed` | No garment is selected. | Guides the user to select a wardrobe item. |

> **User-photo guarantee:** ClosetAI only uses the photo the user selects for try-on and never substitutes a stock model image.

## Recommended Next Optimizations for Public Garment Reference Unlock

The highest-value improvement is to replace the current requirement for a manually public `https://` image with an intentional wardrobe-image preparation flow. When a user adds a garment, the app can upload the garment image to user-scoped object storage and persist a short-lived signed or public provider-compatible URL. The Try-On screen can then mark that wardrobe item as **reference ready** instead of asking the user to understand URL requirements.

| Priority | Optimization | Implementation direction | Expected UX improvement |
|---|---|---|---|
| 1 | Reference readiness at wardrobe import | On wardrobe-item creation, validate image dimensions/type and generate a provider-reachable URL through the app backend. | Users see “Ready for YouCam” at the wardrobe-item level, not only after a failed try-on attempt. |
| 2 | Add a “Prepare reference” action | For selected local-only garment images, show one action that uploads/prepares the image and updates the readiness state. | Converts the dead-end “public image required” message into a recoverable one-step flow. |
| 3 | Add server-side reference validation | Before creating a YouCam task, issue a safe server-side `HEAD` or bounded fetch to confirm a reachable image, allowed MIME type, and file-size limit. | Earlier, clearer feedback instead of an asynchronous provider failure. |
| 4 | Persist reference metadata | Store `referenceStatus`, `preparedAt`, image content type, source URL expiry, and a non-sensitive failure reason on wardrobe records. | Avoids repeated preparation and supports clear, fast readiness cards. |
| 5 | Use short-lived URLs and refresh logic | Generate provider-reachable URLs only as long as necessary, refreshing them before a task starts. | Reduces durable public exposure while retaining a smooth live unlock experience. |
| 6 | Add category-specific reference tips | Use the shared ten-category taxonomy to request an uncluttered flat-lay for clothing and a clearly visible product image for footwear. | Better provider input quality and more predictable output without overstating guarantees. |
| 7 | Add a preflight summary endpoint | Extend `/api/youcam/fashion-capability` or add an authenticated `/api/tryon/preflight` endpoint that returns readiness for the selected wardrobe IDs. | Makes the client authoritative on the exact next action and prevents unnecessary try-on job creation. |

A practical next implementation would be an authenticated `POST /api/tryon/preflight` route. It should accept selected wardrobe IDs, inspect the server-side wardrobe image URL, classify each item through `getFashionTryOnCategory`, and return the same shared `YouCamFashionReadiness` structure now used by the UI. The client can then show the correct action before it creates a chargeable try-on job. The server must avoid accepting arbitrary external URLs from the client; it should resolve only wardrobe images belonging to the authenticated user and enforce content-type, size, redirect, and domain allow-list checks.

## Current 10-Category YouCam Fashion Contract Validation

The following script was executed successfully from the application source directory:

```bash
npx tsx tests/youcam-fashion-contract.test.ts
```

```json
{
  "result": "PASS",
  "categoryCount": 10,
  "assertions": [
    "Tops -> upper_body",
    "Jeans -> lower_body",
    "Maxi Dress -> full_body",
    "Leather Jacket -> outerwear",
    "Sneakers -> shoes",
    "Activewear -> auto",
    "Swimwear -> full_body",
    "Bag -> auto",
    "Hat -> auto",
    "Jewelry -> auto"
  ],
  "note": "No network request, credential access, or user image processing occurred."
}
```

The test confirms that all ten selectable fashion categories remain represented in the shared taxonomy and that each category maps to its intended garment-region contract. It is a deterministic unit-level contract test: it does **not** claim that a live YouCam call was made, that credentials were used, or that a user image was processed.

## Related Validation Already Passed

The enhanced integration update also passed the following local validations: `npx tsc --noEmit --pretty false`, `npx expo export --platform web`, `npx tsx tests/youcam-fashion-experience.test.ts`, and `npx tsx tests/skin-intelligence-dashboard.test.ts`.
