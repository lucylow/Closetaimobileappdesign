# ClosetAI Mock Data Review and Real-Time Replacement Roadmap

## Executive Assessment

The active Expo application has already moved its main wardrobe, outfits, and virtual try-on fallback behavior away from broad static demo collections. The remaining mock-data concentration is primarily inside the **Skin Care navigation experience** and a small caption fallback. These modules are useful for offline demonstration, but several are currently serving as UI data sources even though the repository already contains live endpoints or server-side processing that can provide the same information when available.

The correct target is not “zero demo data.” The mobile demo must remain usable without network access, credentials, or a configured YouCam service. The target is therefore a **provider-first model**: use live or user-created state when available; use compact, clearly labelled fallback content only when live state is unavailable.

## Active Mock Modules

| Module | Active consumers | Current purpose | Replaceable now? | Recommended live source |
|---|---|---|---|---|
| `lib/demo-data.ts` | `contexts/AppContext.tsx` | Caption fallback templates | **Yes, mostly** | Existing `POST /api/content` and `GET /api/content/:id`; local template fallback derived from the user’s actual outfit items |
| `lib/skin-mock-data.ts` | `SkinScreen`, `MockSkinDashboard`, `skin-navigation-data` | Detailed Skin Care snapshot, routine, products, and progress demo | **Partially** | Existing `POST /api/skin/scan`, `GET /api/skin/snapshots`, and normalised server snapshot fields |
| `lib/skin-demo-profiles.ts` | `skin-analysis-controller`, `SkinScreen` | Three rotating offline Skin Care profiles | **Keep, but reduce** | Preserve one compact deterministic fallback profile; select live analysis whenever a photo and backend are available |
| `lib/skin-navigation-data.ts` | `SkinJourneyPage`, `SkinCareContext` | Static signals, snapshots, trend values, palettes, reminders, products | **Yes, in stages** | Skin history API, normalised live snapshot, locally persisted goals/reminders, and server-generated routine/style insights |

## What Can Move to Real-Time Processing Immediately

### 1. Skin snapshot, signals, and routine

The repository already exposes a secure live scan endpoint at `POST /api/skin/scan` and snapshot history routes at `GET /api/skin/snapshots`. The active `skin-analysis-controller` already normalises a live `SkinSnapshot` into a mobile-safe `SkinAnalysisResult`. The Skin Care dashboard and focused pages should receive this normalised result from one shared controller/context rather than import `SKIN_MOCK_RESULT`, `skinMetrics`, or a separate mock routine.

The replacement sequence should be:

1. On a successful live scan, store the normalised result as the active result in a Skin Care session context.
2. On module entry, request the latest saved snapshot only after the screen has rendered.
3. Map `snapshot.concerns` to metric cards dynamically.
4. Render the returned routine or generate a compact routine with `buildRoutine(metrics)`.
5. Retain one demo result only when the user selects demo mode or the live provider is unavailable.

> The demo fallback should be explicit: “Demo preview — live analysis was unavailable.” It must never be represented as the user’s live scan.

### 2. History and progress

`lib/skin-navigation-data.ts` currently supplies `savedSnapshots` and `progressSeries` as static values. This can be replaced by `GET /api/skin/snapshots`. The mobile client can derive progress directly from real saved summaries: sort the latest snapshots by `createdAt`, calculate per-metric deltas only when both values are available, and otherwise show “Not enough saved snapshots yet.”

This provides real user history without inventing scores. It should also preserve the existing privacy position: history should show normalised summaries and consent information, not the original selfie.

| Current mock output | Live replacement | Empty-state behavior |
|---|---|---|
| Fixed snapshot timeline | User’s saved `/api/skin/snapshots` results | “Complete a scan and choose Save Summary to start your history.” |
| Fixed weekly changes | Delta calculated from comparable saved metrics | “A second saved scan is needed to show a change.” |
| Fixed overall score | Derived average of available normalised metric scores | “No comparable score yet.” |

### 3. Caption fallback

The live content endpoint is already available. The remaining `demoCaptions` array should be replaced with a small local formatter that uses the actual outfit name, tags, and selected platform. This retains offline usability without a catalog of invented captions.

For example, an offline fallback can produce: “Today’s look: {outfit name}. Styled from my ClosetAI wardrobe. #{actual tag}.” This is user-derived, not static mock content.

### 4. Goals, routines, reminders, saved products, and check-ins

These are not good candidates for remote mock data because they are primarily **user preference state**. The existing `SkinCareContext` already persists goals, reminders, saved product IDs, routine completion, and check-in notes with `AsyncStorage`. This is the correct model.

The improvement is to populate routine steps from the current normalised scan result and keep completion records keyed by snapshot ID plus step ID. That prevents a routine state from carrying over incorrectly to a different live scan.

## Areas Requiring New Data Sources Rather Than a Simple Swap

### Product recommendations

The current product cards are fictional examples. There is no product catalog endpoint in the repository, so replacing them with “real-time” content requires a deliberate data decision. The safest next step is a user-managed product shelf: users add products they already own, enter category and usage, and receive routine placement suggestions from the normalised scan metrics. This is useful, avoids affiliate/shopping claims, and works offline.

If external products are later required, add a server-side product-provider adapter with a vetted retailer or product database. Do not call retail APIs directly from Expo and do not imply that a product is medical treatment.

### Skin × Wardrobe palettes and outfit planning

The server currently creates style insight from analysis signals, while the wardrobe and outfit endpoints already expose the user’s collection. The hard-coded palette cards should be replaced with a `StyleMatchProvider` that combines:

1. Normalised current Skin Care style insight;
2. User wardrobe colors, tags, and categories from `/api/wardrobe` or local storage;
3. Existing outfit generation from `POST /api/outfits/suggest`.

When no live Skin Care insight exists, the module should say “Choose a palette direction” rather than inventing a colour assessment. The user can still build an outfit from their wardrobe.

## Recommended Priority Order

| Priority | Replacement | Value | Dependency | Demo fallback to retain |
|---|---|---|---|---|
| P0 | Replace static Skin Care history and progress with snapshot API data | Eliminates misleading personal-history mock values | Existing skin-history endpoint | Empty history state, not fake history |
| P0 | Feed current live normalised scan result into dashboard and journeys | Makes signal cards and routines user-specific | Existing scan endpoint/controller | One compact labelled demo result |
| P1 | Replace caption list with a user-outfit local formatter | Removes static social-copy mock data | Existing outfit state | One deterministic formatter |
| P1 | Generate routines from current metrics and key completion by snapshot | Makes daily workflow relevant to the actual result | Current controller/context | Generic starter routine only without a result |
| P2 | Replace palette mock cards with user-wardrobe-aware style matching | Connects two existing functional modules | Wardrobe and outfit endpoints | User-selectable palette, not inferred palette |
| P2 | Create a user-owned product shelf | Replaces fictional products without external dependency | Local storage or new server table | Empty “add your product” state |
| P3 | Add a server-side retail/product provider adapter | Enables optional external discovery | New provider agreement and backend endpoint | No shopping results rather than fabricated products |

## Safeguards for Every Replacement

The UI should render a useful initial screen before an API request starts. Live processing must never block the Skin Care hub, wardrobe, outfit composer, or virtual try-on photo upload. Each provider should return one of three states: **live data**, **local user data**, or **explicit demo fallback**. Unknown values should remain unavailable rather than being replaced with invented scores.

Every new live provider should have a narrow server-side adapter, normalized client response type, timeout, error message, and fallback strategy. Credentials and third-party requests must remain server-side. The Expo client should only use the repository’s own API endpoints and local persisted state.

## Proposed Next Implementation Sprint

The highest-value next code change is to introduce a `SkinResultRepository` with `getLatest()`, `getHistory()`, and `saveResult()` methods. Its live implementation would call the existing skin endpoints; its local implementation would read user-approved summaries; its demo implementation would provide one compact labelled fallback. The Skin Care dashboard, journey pages, progress view, and style match view would consume this repository instead of importing static values from `skin-navigation-data.ts`.

This single refactor removes the majority of active Skin Care mock-data coupling while preserving a reliable Expo demo mode.
